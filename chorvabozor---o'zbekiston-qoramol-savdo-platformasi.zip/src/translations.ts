import { Language } from './types';

export const translations = {
  uz: {
    brandName: 'ChorvaBozor',
    tagline: 'Oʻzbekiston boʻyicha qoramol va chorva savdosi platformasi',
    navCatalog: 'Barcha Eʼlonlar',
    navAuctions: 'Jonli Auksion',
    navPriceIndex: 'Narx Indeksi',
    navTransport: 'Transport Kalkulyatori',
    navQurbonlik: 'Qurbonlik 2026',
    navTelegram: 'Telegram Bot',
    navAddListing: 'Eʼlon Berish',
    
    // Lite Mode
    liteMode: 'Tejamkor rejim',
    liteModeOn: 'Tejamkor rejim yoqilgan (Past internet)',
    liteModeDesc: 'Trafikni 80% tejaydi, rasmlar ixcham yuklanadi',
    
    // Hero
    heroHeadline: 'Dallolsiz, Halol va Shaffof Chorva Savdosi',
    heroSubheadline: 'Veterinariya koʻrigidan oʻtgan sogʻlom qoramollar, xavfsiz toʻlov kafolati va viloyatlararo ishonchli yetkazib berish xizmati bilan toʻgʻridan-toʻgʻri fermerlardan xarid qiling.',
    searchPlaceholder: 'Nasl, viloyat yoki vazn boʻyicha qidiring (masalan: Golshtin, Toshkent, 450 kg)...',
    statVerifiedFarms: '280+ Tasdiqlangan Fermer',
    statSafeDeals: '100% Xavfsiz Toʻlov (Eskrou)',
    statVetCheck: 'Davlat Vet Xizmati Muhri',
    
    // Categories
    catAll: 'Barchasi',
    catDairy: 'Sut yoʻnalishi',
    catBeef: 'Goʻsht yoʻnalishi',
    catCalf: 'Buzoqlar',
    catQurbonlik: 'Qurbonlik Hayiti',
    catWholesale: 'Ulgurji partiyalar',
    catSheep: 'Qoʻy va Qoʻchqorlar',
    catHorses: 'Otchilik (Otlar)',
    catSports: 'Poyga va Koʻpkari',

    // Badges & Labels
    verifiedSeller: 'Fermer Tasdiqlangan',
    vetVerified: 'Vet Pasport Bor',
    safeEscrow: 'Xavfsiz Toʻlov',
    hasVideoBadge: 'Video Koʻrik',
    deliveryReady: 'Yetkazib beriladi',
    weight: 'Vazni',
    age: 'Yoshi',
    breed: 'Zoti',
    gender: 'Jinsi',
    milkYield: 'Kunlik suti',
    lactation: 'Qorini',
    pregnancy: 'Boʻgʻozlik',
    viewDetails: 'Batafsil koʻrish',
    directCall: 'Qoʻngʻiroq qilish',
    telegramChat: 'Telegram orqali yozish',
    buyWithEscrow: 'Xavfsiz Xarid Qilish',

    // Comparison Feature
    compare: 'Taqqoslash',
    compareSelected: 'Taqqoslashda',
    addToCompare: 'Taqqoslashga qoʻshish',
    removeFromCompare: 'Taqqoslashdan chiqarish',
    compareTrayTitle: 'Taqqoslash uchun tanlandi',
    compareActionBtn: 'Yonma-yon Taqqoslash',
    clearCompare: 'Tozalash',
    compareModalTitle: 'Chorvalarni Yonma-Yon Taqqoslash',
    compareModalSubtitle: 'Tanlangan hayvonlarning narxi, vazni, nasli va veterinariya holatini batafsil solishtiring',
    compareMaxWarning: 'Maksimal 3 ta hayvonni taqqoslash mumkin!',
    compareMinNotice: 'Toʻliq solishtirish uchun kamida 2 ta hayvon tanlang',
    addMoreToCompare: '+ Yana hayvon qoʻshish',
    bestPriceBadge: 'Eng maqbul narx',
    highestWeightBadge: 'Eng ogʻir vazn',
    compareParamMetric: 'Xususiyatlar',

    // Problems Solved callout
    problemSolvedTitle: 'Nima uchun anʼanaviy bozor emas, aynan ChorvaBozor?',
    problem1: 'Dallolsiz toza narx: Oʻrtakashlarning 15-20% gacha sunʼiy ustamasiz toʻgʻridan-toʻgʻri fermer narxi.',
    problem2: 'Safar qilish shart emas: Bozorga sarflanadigan vaqt va xarajat oʻrniga 360° video va jonli koʻrik.',
    problem3: 'Kasal va soxta eʼlon yoʻq: Har bir hayvon davlat veterinariya tizimi va tarozi dalolatnomasi bilan tekshiriladi.',
    problem4: 'Pulingiz kafolatlangan: Hayvonni koʻzingiz bilan koʻrib, qabul qilib olmaguningizcha pul platformada muzlatiladi.',

    // Filters
    filterRegion: 'Viloyat',
    filterAllRegions: 'Barcha viloyatlar',
    filterPriceMin: 'Min narx (soʻm)',
    filterPriceMax: 'Maks narx (soʻm)',
    filterOnlyVerified: 'Faqat tekshirilgan fermerlar',
    filterOnlyVet: 'Faqat Vet pasporti borlar',
    filterOnlyVideo: 'Faqat videoli eʼlonlar',
    filterReset: 'Filtrni tozalash',
    resultsCount: 'ta eʼlon topildi',

    // Price Index
    priceIndexTitle: 'Oʻzbekiston Viloyatlari Boʻyicha Bozor Narxlari Indeksi',
    priceIndexSubtitle: 'Haftalik yangilanuvchi tirik vazn va goʻsht oʻrtacha narxlari. Fermer arzon sotmasin, xaridor aldanmasin!',
    liveWeightBeef: 'Qoramol tirik vazni (kg)',
    liveWeightSheep: 'Qoʻy tirik vazni (kg)',
    dairyCowAvg: 'Sogʻin sigir oʻrtacha narxi',
    trendUp: 'Oʻsmoqda',
    trendDown: 'Tushmoqda',
    trendStable: 'Barqaror',

    // Transport Calculator
    transportTitle: 'Viloyatlararo Chorva Transporti Kalkulyatori',
    transportSubtitle: 'Hayvonni sizning manzilingizga yetkazib berish narxini hisoblang va ixtisoslashgan haydovchilar bilan bogʻlaning.',
    fromLocation: 'Qayerdan (Sotuvchi manzili):',
    toLocation: 'Qayerga (Sizning manzilingiz):',
    selectVehicle: 'Transport turi:',
    laboDesc: 'Labo / Damas (1-2 bosh qoʻy yoki 1 ta kichik buzoq)',
    gazelDesc: 'Gazel (2-3 bosh qoramol yoki 12 bosh qoʻy)',
    isuzuDesc: 'Isuzu bortli / furgon (6-8 bosh qoramol)',
    truckDesc: 'Maxsus chorva tashuvchi (15-20 bosh)',
    calculateRoute: 'Hisoblash',
    estimatedCost: 'Taxminiy yoʻl haqi:',
    estimatedTime: 'Taxminiy vaqt:',
    bookTransport: 'Haydovchiga buyurtma yuborish',

    // Escrow info
    escrowStep1Title: '1. Depozit qilish',
    escrowStep1Desc: 'Xaridor mablagʻni Payme, Click yoki Uzum orqali ChorvaBozor kafolat hisobiga toʻlaydi.',
    escrowStep2Title: '2. Hayvon yetkaziladi',
    escrowStep2Desc: 'Fermer hayvonni transport orqali xaridor manziliga joʻnatadi yoki xaridor oʻzi olib ketadi.',
    escrowStep3Title: '3. Qabul va Tasdiqlash',
    escrowStep3Desc: 'Xaridor hayvonning salomatligi, vazni va hujjatlarini koʻrib chiqib, tasdiqlaydi.',
    escrowStep4Title: '4. Toʻlov oʻtadi',
    escrowStep4Desc: 'Xaridor tasdiqlagach, pul bir zumda sotuvchining kartasiga oʻtadi. Muammo boʻlsa pul xaridorga qaytadi.',

    // Auction
    auctionTitle: 'Jonli Auksion: Buzoqlar va Ulgurji Partiyalar',
    auctionSubtitle: 'Haqiqiy raqobat va shaffof narx. Eng yaxshi taklif egasiga avtomatik taqdim etiladi.',
    timeLeft: 'Qolgan vaqt:',
    currentHighestBid: 'Eng yuqori stavka:',
    minStep: 'Minimal qadam:',
    placeBid: 'Stavka qoʻyish',
    startingPrice: 'Boshlangʻich narx:',
    bidsHistory: 'Stavkalar tarixi:',

    // Qurbonlik
    qurbonlikTitle: 'Qurbonlik Hayiti 2026: Oldindan Bron va Kafolat',
    qurbonlikSubtitle: 'Shariat talablariga toʻliq mos (yoshi yetgan, nuqsonsiz), veterinariya tekshiruvidan oʻtgan qurbonlik mollari. Bozor tirbandligisiz uyingizga yetkazib beriladi.',
    qurbonlikRule1: 'Yoshi: Qoramol kamida 2 yosh, qoʻy kamida 1 yosh (yoki 6 oylik yirik gavdali).',
    qurbonlikRule2: 'Salomatlik: Koʻzi ochiq, oqsoqlanmaydigan, qulogʻi/shoxi butun, ozgʻin boʻlmagan.',
    qurbonlikRule3: 'Xizmatlar: Soʻyish, nimtalash va qassob xizmati bilan buyurtma qilish imkoniyati.',

    // Add Listing Form
    addNewListing: 'Yangi Eʼlon Joylashtirish',
    listingStep1: 'Asosiy maʼlumotlar',
    listingStep2: 'Foto va Qisqa Video',
    listingStep3: 'Veterinariya hujjati',
    listingStep4: 'Narx va Xavfsiz toʻlov',
    publishBtn: 'Eʼlonni chop etish',
    successListing: 'Eʼlon muvaffaqiyatli qabul qilindi va 15 daqiqada tekshirilib saytga joylanadi!',

    // Telegram info
    telegramTitle: 'Telegram orqali savdo qilasizmi?',
    telegramDesc: 'Oʻzbekistondagi koʻpchilik chorvadorlar Telegramdan foydalanadi. Bizning @ChorvaBozor_bot mini-ilovamiz orqali ham barcha eʼlonlarni koʻrishingiz va oʻz chorvangizni 2 daqiqada sotuvga qoʻyishingiz mumkin!',
    openTelegramBot: 'Telegram Botda Ochish',
    shareToTelegram: 'Telegram guruhlarga ulashish',

    currency: 'soʻm',
    litersPerDay: 'litr/kun',
    months: 'oylik',
    years: 'yosh',
    close: 'Yopish',
  },
  ru: {
    brandName: 'ChorvaBozor',
    tagline: 'Платформа торговли скотом и КРС по всему Узбекистану',
    navCatalog: 'Все объявления',
    navAuctions: 'Живой аукцион',
    navPriceIndex: 'Индекс цен',
    navTransport: 'Калькулятор скотовоза',
    navQurbonlik: 'Курбан-хайит 2026',
    navTelegram: 'Telegram бот',
    navAddListing: 'Подать объявление',

    // Lite Mode
    liteMode: 'Экономный режим',
    liteModeOn: 'Экономный режим включен (Низкий трафик)',
    liteModeDesc: 'Экономит до 80% трафика, оптимизировано для 3G/2G',

    // Hero
    heroHeadline: 'Торговля скотом без перекупщиков и посредников',
    heroSubheadline: 'Покупайте напрямую у проверенных фермеров: здоровый скот с ветеринарными паспортами, гарантия безопасной сделки (эскроу) и междугородняя перевозка.',
    searchPlaceholder: 'Поиск по породе, региону или весу (напр.: Голштин, Ташкент, 450 кг)...',
    statVerifiedFarms: '280+ Проверенных ферм',
    statSafeDeals: '100% Безопасная сделка (Эскроу)',
    statVetCheck: 'Печать Госветслужбы',

    // Categories
    catAll: 'Все животные',
    catDairy: 'Молочное направление',
    catBeef: 'Мясное направление',
    catCalf: 'Телята',
    catQurbonlik: 'Курбан-хайит',
    catWholesale: 'Оптовые партии',
    catSheep: 'Овцы и бараны',
    catHorses: 'Лошади и кони',
    catSports: 'Скачки и Купкари',

    // Badges & Labels
    verifiedSeller: 'Проверенный фермер',
    vetVerified: 'Есть ветпаспорт',
    safeEscrow: 'Безопасная сделка',
    hasVideoBadge: 'Видеоосмотр',
    deliveryReady: 'Есть доставка',
    weight: 'Вес',
    age: 'Возраст',
    breed: 'Порода',
    gender: 'Пол',
    milkYield: 'Надой в сутки',
    lactation: 'Отёл',
    pregnancy: 'Стельность',
    viewDetails: 'Подробнее',
    directCall: 'Позвонить',
    telegramChat: 'Написать в Telegram',
    buyWithEscrow: 'Купить безопасно (Эскроу)',

    // Comparison Feature
    compare: 'Сравнить',
    compareSelected: 'В сравнении',
    addToCompare: 'Добавить к сравнению',
    removeFromCompare: 'Удалить из сравнения',
    compareTrayTitle: 'Выбрано для сравнения',
    compareActionBtn: 'Сравнить бок о бок',
    clearCompare: 'Очистить',
    compareModalTitle: 'Сравнение скота бок о бок',
    compareModalSubtitle: 'Сравните вес, стоимость, породу и ветстатус выбранных животных в единой таблице',
    compareMaxWarning: 'Можно сравнивать максимум 3 животных одновременно!',
    compareMinNotice: 'Для наглядного сравнения выберите минимум 2 животных',
    addMoreToCompare: '+ Добавить еще скот',
    bestPriceBadge: 'Лучшая цена',
    highestWeightBadge: 'Наибольший вес',
    compareParamMetric: 'Характеристики',

    // Problems Solved
    problemSolvedTitle: 'Почему именно ChorvaBozor, а не стихийный базар?',
    problem1: 'Честная цена без маклеров: Прямая цена от фермера без наценки перекупщиков в 15-20%.',
    problem2: 'Не нужно ехать в другой вилоят: 360° видео и видеозвонок вместо изнурительных поездок по рынкам.',
    problem3: 'Никаких больных животных: Каждое животное проходит проверку через госветклинику и взвешивание.',
    problem4: 'Деньги заморожены до приемки: Оплата переводится продавцу только после того, как вы лично примете скот.',

    // Filters
    filterRegion: 'Регион',
    filterAllRegions: 'Все регионы',
    filterPriceMin: 'Мин. цена (сум)',
    filterPriceMax: 'Макс. цена (сум)',
    filterOnlyVerified: 'Только проверенные фермеры',
    filterOnlyVet: 'Только с ветпаспортом',
    filterOnlyVideo: 'Только с видео',
    filterReset: 'Сбросить фильтры',
    resultsCount: 'объявлений найдено',

    // Price Index
    priceIndexTitle: 'Индекс рыночных цен по вилоятам Узбекистана',
    priceIndexSubtitle: 'Еженедельно обновляемые средние цены на живой вес и мясо. Чтобы фермер не продал дешево, а покупатель не переплатил!',
    liveWeightBeef: 'Живой вес КРС (кг)',
    liveWeightSheep: 'Живой вес баранины (кг)',
    dairyCowAvg: 'Средняя цена дойной коровы',
    trendUp: 'Растет',
    trendDown: 'Снижается',
    trendStable: 'Стабильно',

    // Transport Calculator
    transportTitle: 'Калькулятор перевозки скота между регионами',
    transportSubtitle: 'Рассчитайте стоимость доставки скотовозом до вашей фермы и свяжитесь с водителями.',
    fromLocation: 'Откуда (адрес продавца):',
    toLocation: 'Куда (ваш адрес):',
    selectVehicle: 'Тип транспорта:',
    laboDesc: 'Лабо / Дамас (1-2 барана или 1 теленок)',
    gazelDesc: 'Газель скотовоз (2-3 коровы или 12 баранов)',
    isuzuDesc: 'Исузу борт/фургон (6-8 голов КРС)',
    truckDesc: 'Специализированный скотовоз (15-20 голов)',
    calculateRoute: 'Рассчитать',
    estimatedCost: 'Ориентировочная стоимость:',
    estimatedTime: 'Время в пути:',
    bookTransport: 'Отправить заявку водителю',

    // Escrow info
    escrowStep1Title: '1. Депозит средств',
    escrowStep1Desc: 'Покупатель вносит оплату через Payme, Click или Uzum на гарантийный счет ChorvaBozor.',
    escrowStep2Title: '2. Доставка животного',
    escrowStep2Desc: 'Фермер отправляет скот транспортом до адреса или покупатель забирает самовывозом.',
    escrowStep3Title: '3. Приемка и осмотр',
    escrowStep3Desc: 'Покупатель проверяет здоровье, вес и ушную бирку животного по факту прибытия.',
    escrowStep4Title: '4. Перевод фермеру',
    escrowStep4Desc: 'После подтверждения деньги мгновенно зачисляются фермеру. При несоответствии — возврат.',

    // Auction
    auctionTitle: 'Живой аукцион: Телята и Оптовые партии',
    auctionSubtitle: 'Прозрачные торги и реальная рыночная цена. Лот достается предложившему наивысшую ставку.',
    timeLeft: 'Осталось времени:',
    currentHighestBid: 'Текущая ставка:',
    minStep: 'Минимальный шаг:',
    placeBid: 'Сделать ставку',
    startingPrice: 'Начальная цена:',
    bidsHistory: 'История ставок:',

    // Qurbonlik
    qurbonlikTitle: 'Курбан-хайит 2026: Предзаказ и гарантия по шариату',
    qurbonlikSubtitle: 'Соответствие шариатским нормам возраста и здоровья, ветконтроль, доставка без предпраздничных пробок на базарах.',
    qurbonlikRule1: 'Возраст: КРС от 2 лет, мелкий рогатый скот от 1 года (или 6-месячный крупный).',
    qurbonlikRule2: 'Здоровье: Без хромоты, без слепоты, целые рога и уши, упитанное телосложение.',
    qurbonlikRule3: 'Услуги: Возможность заказать профессиональный забой и разделку мясником.',

    // Add Listing Form
    addNewListing: 'Подать новое объявление',
    listingStep1: 'Основные данные',
    listingStep2: 'Фото и короткое видео',
    listingStep3: 'Ветеринарный паспорт',
    listingStep4: 'Цена и безопасная сделка',
    publishBtn: 'Опубликовать объявление',
    successListing: 'Объявление принято и будет проверено модератором в течение 15 минут!',

    // Telegram info
    telegramTitle: 'Торгуете через Telegram?',
    telegramDesc: 'Большинство фермеров Узбекистана ведут торговлю в Telegram. Через наш мини-апп @ChorvaBozor_bot вы можете просматривать каталог и публиковать лоты прямо в мессенджере!',
    openTelegramBot: 'Открыть Telegram Бот',
    shareToTelegram: 'Поделиться в группах',

    currency: 'сум',
    litersPerDay: 'л/сутки',
    months: 'мес.',
    years: 'лет',
    close: 'Закрыть',
  }
};
