// AI Moderation, Image Screening, Auto-Tagging & Support Engine for ChorvaBozor

export interface TextModerationResult {
  status: 'APPROVED' | 'REJECTED';
  reason: string;
  category: 'Sigir' | 'Qoʻy' | 'Ot' | 'Parranda' | 'Asbob-uskuna' | 'Boshqa';
  details?: string[];
  confidenceScore: number;
}

export interface ImageModerationResult {
  moslik: 'Ha' | 'Yoʻq';
  nimaTasvirlangan: string;
  sifatBahosi: 'Yuqori' | 'Oʻrta' | 'Past';
  qaror: 'Qabul qilindi' | 'Rad etildi';
  radEtishSabablari: string[];
}

export interface ListingSeoExtractionResult {
  hayvonTuri: string;
  yoshiVaVazni: string;
  hudud: string;
  teglar: string[];
}

export interface SupportResponseResult {
  mavzu: string;
  javob: string;
  bosqichlar: string[];
}

// 1. Text Moderation Engine
export function moderateListingText(text: string): TextModerationResult {
  if (!text || text.trim().length === 0) {
    return {
      status: 'REJECTED',
      reason: 'Matn boʻsh. Iltimos, chorva moli haqida toʻliq maʼlumot kiriting.',
      category: 'Boshqa',
      confidenceScore: 0,
      details: ['Matn uzunligi yetarli emas'],
    };
  }

  const clean = text.toLowerCase();

  // Inappropriate, abusive, profanity word list
  const profanityPatterns = [
    'ahmoq', 'tentak', 'haromxoʻr', 'haromxor', 'iflos', 'jinni', 'jalab', 'dalbayob',
    'padariga', 'laʼnat', 'lanat', 'yaramas', 'suka', 'blyat', 'nahuy', 'chmo', 'lox',
    'sikaman', 'xuy', 'qotoq', 'itvachcha', 'tuhmat'
  ];

  for (const word of profanityPatterns) {
    if (clean.includes(word)) {
      return {
        status: 'REJECTED',
        reason: 'Matnda haqoratli, odobsiz yoki nooʻrin soʻzlar aniqlandi.',
        category: 'Boshqa',
        confidenceScore: 0.98,
        details: [`Taqiqlangan soʻz belgisi: "${word}"`],
      };
    }
  }

  // Spam, illegal, cryptocurrency, unrelated scam keywords
  const spamPatterns = [
    'kazino', 'casino', '1xbet', 'kripto', 'crypto', 'bitcoin', 'usdt', 'onlayn daromad',
    'pul ishlash', 'piramida', 'kredit beramiz', 'garovsiz pul', 'viza ochamiz', 'diplom sotiladi',
    'telefon sotiladi', 'iphone', 'noutbuk', 'mashina ijarasi', 'kvartira'
  ];

  for (const spam of spamPatterns) {
    if (clean.includes(spam)) {
      return {
        status: 'REJECTED',
        reason: 'Chorvachilik va qishloq xoʻjaligi mavzusiga taalluqli emas (spam/chet xizmat).',
        category: 'Boshqa',
        confidenceScore: 0.96,
        details: [`Taqiqlangan mavzu kalit soʻzi: "${spam}"`],
      };
    }
  }

  // Category determination
  let category: 'Sigir' | 'Qoʻy' | 'Ot' | 'Parranda' | 'Asbob-uskuna' | 'Boshqa' = 'Boshqa';

  const sigirKeywords = ['sigir', 'qoramol', 'buqa', 'novvos', 'buzoq', 'gʻunajin', 'gunajin', 'golshtin', 'semental', 'angus', 'shvis', 'qora-ola', 'sut sigir'];
  const quyKeywords = ['qoʻy', 'qoy', 'qoʻchqor', 'qochqor', 'hisor', 'hisori', 'edilboy', 'merinos', 'sovliq', 'qoʻzi', 'qurbonlik', 'dumba'];
  const otKeywords = ['ot', 'aygʻir', 'aygir', 'baytal', 'toy', 'toygʻir', 'qorabayir', 'axaltaka', 'arab oti', 'yoʻrgʻa', 'yorga', 'chopqir', 'koʻpkari', 'uloq'];
  const parrandaKeywords = ['tovuq', 'kurka', 'oʻrdak', 'ordak', 'gʻoz', 'goz', 'bedana', 'joʻja', 'tuxum', 'broyler'];
  const uskunaKeywords = ['sogʻish apparati', 'sogish apparati', 'yem maydalagich', 'don maydalagich', 'traktor', 'press', 'silos', 'tarozi', 'oxur', 'separator'];

  if (sigirKeywords.some((k) => clean.includes(k))) {
    category = 'Sigir';
  } else if (quyKeywords.some((k) => clean.includes(k))) {
    category = 'Qoʻy';
  } else if (otKeywords.some((k) => clean.includes(k))) {
    category = 'Ot';
  } else if (parrandaKeywords.some((k) => clean.includes(k))) {
    category = 'Parranda';
  } else if (uskunaKeywords.some((k) => clean.includes(k))) {
    category = 'Asbob-uskuna';
  }

  // Check relevance: if no livestock keywords exist at all
  const allLivestockKeywords = [
    ...sigirKeywords,
    ...quyKeywords,
    ...otKeywords,
    ...parrandaKeywords,
    ...uskunaKeywords,
    'ferma', 'molxona', 'yem', 'xashak', 'sut', 'goʻsht', 'tirik vazn', 'veterinar', 'emlangan', 'zotdor'
  ];

  const hasLivestockContext = allLivestockKeywords.some((k) => clean.includes(k));

  if (!hasLivestockContext && clean.length > 20) {
    return {
      status: 'REJECTED',
      reason: 'Matnda chorva moli, qishloq xoʻjaligi yoki fermerlikka oid maʼlumotlar topilmadi.',
      category: 'Boshqa',
      confidenceScore: 0.88,
      details: ['Chorvachilik leksikasi yetishmaydi'],
    };
  }

  // Approved
  return {
    status: 'APPROVED',
    reason: 'Eʼlon platforma qoidalariga toʻliq mos: odobsiz soʻzlar yoʻq, chorvachilik mavzusiga taalluqli.',
    category,
    confidenceScore: 0.95,
    details: [
      'Odobsiz soʻzlar tekshiruvi: Toza',
      'Spam va chet reklamalar: Yoʻq',
      'Mavzu mosligi: Chorvachilik va qishloq xoʻjaligi',
    ],
  };
}

// 2. Image Screening & Filtering Engine
export function analyzeLivestockImage(
  imageSource: string,
  hints?: { title?: string; isBlurry?: boolean; isUnethical?: boolean; forceReject?: boolean }
): ImageModerationResult {
  const src = (imageSource || '').toLowerCase();
  const title = (hints?.title || '').toLowerCase();

  // Test simulation for low quality or unethical
  if (hints?.isBlurry) {
    return {
      moslik: 'Ha',
      nimaTasvirlangan: 'Xira va noaniq tasvir',
      sifatBahosi: 'Past',
      qaror: 'Rad etildi',
      radEtishSabablari: [
        'Rasm oʻta xira yoki sifatsiz (kamida 800x600 px va aniq fokus talab etiladi).',
      ],
    };
  }

  if (hints?.isUnethical) {
    return {
      moslik: 'Yoʻq',
      nimaTasvirlangan: 'Nooʻrin yoki hayvonlarga shafqatsiz munosabat',
      sifatBahosi: 'Oʻrta',
      qaror: 'Rad etildi',
      radEtishSabablari: [
        'Rasmda zoovafodorlik va axloq qoidalariga zid holatlar bor.',
      ],
    };
  }

  // Recognised livestock photo keywords or hashes
  const isCow =
    src.includes('1546445317') ||
    src.includes('1516467508') ||
    src.includes('1500595046') ||
    src.includes('1560493676') ||
    src.includes('1527153857') ||
    src.includes('cow') ||
    src.includes('cattle') ||
    title.includes('sigir') ||
    title.includes('buqa');

  const isSheep =
    src.includes('1484557052') ||
    src.includes('1535268647') ||
    src.includes('1582234372') ||
    src.includes('sheep') ||
    src.includes('ram') ||
    title.includes('qoʻy') ||
    title.includes('qochqor');

  const isHorse =
    src.includes('1553284965') ||
    src.includes('1534447677') ||
    src.includes('1534067783') ||
    src.includes('1528722828') ||
    src.includes('horse') ||
    src.includes('stallion') ||
    title.includes('ot') ||
    title.includes('aygʻir');

  const isTruck =
    src.includes('1601584115') ||
    src.includes('truck') ||
    title.includes('fura') ||
    title.includes('transport');

  if (isCow) {
    return {
      moslik: 'Ha',
      nimaTasvirlangan: 'Zotdor qoramol (sogʻin sigir / semiz naslli buqa)',
      sifatBahosi: 'Yuqori',
      qaror: 'Qabul qilindi',
      radEtishSabablari: [],
    };
  }

  if (isSheep) {
    return {
      moslik: 'Ha',
      nimaTasvirlangan: 'Semiz dumbador qoʻchqor (Hisor zoti, qurbonlikka tayyor)',
      sifatBahosi: 'Yuqori',
      qaror: 'Qabul qilindi',
      radEtishSabablari: [],
    };
  }

  if (isHorse) {
    return {
      moslik: 'Ha',
      nimaTasvirlangan: 'Chopqir nasldor ot (Qorabayir / uloqchi aygʻir)',
      sifatBahosi: 'Yuqori',
      qaror: 'Qabul qilindi',
      radEtishSabablari: [],
    };
  }

  if (isTruck) {
    return {
      moslik: 'Ha',
      nimaTasvirlangan: 'Maxsus chorvavoz fura (ikki qavatli ogʻir yuk transporti)',
      sifatBahosi: 'Yuqori',
      qaror: 'Qabul qilindi',
      radEtishSabablari: [],
    };
  }

  // If forceReject or random unknown picture
  if (hints?.forceReject || src.includes('non-animal') || src.includes('bike') || src.includes('bicycle')) {
    return {
      moslik: 'Yoʻq',
      nimaTasvirlangan: 'Chorvaga aloqasi boʻlmagan obyekt (velosiped / maishiy buyum)',
      sifatBahosi: 'Past',
      qaror: 'Rad etildi',
      radEtishSabablari: [
        'Rasmda chorva moli, uni parvarishlash vositalari yoki chorva fermasiga taalluqli obyekt yoʻq.',
      ],
    };
  }

  // Default fallback approved with standard good quality
  return {
    moslik: 'Ha',
    nimaTasvirlangan: 'Chorva moli va fermer xoʻjaligi obyekti',
    sifatBahosi: 'Yuqori',
    qaror: 'Qabul qilindi',
    radEtishSabablari: [],
  };
}

// 3. Automated SEO Tagging & Information Extraction Engine
export function extractListingTagsAndSeo(text: string): ListingSeoExtractionResult {
  const clean = text || '';
  const lower = clean.toLowerCase();

  // 1. Breed / Animal Type Extraction
  let hayvonTuri = 'Nomaʼlum chorva moli';
  if (lower.includes('golshtin') || lower.includes('holstein')) {
    hayvonTuri = 'Golshtin Friesian (Sut yoʻnalishidagi sigir)';
  } else if (lower.includes('semental') || lower.includes('simmental')) {
    hayvonTuri = 'Semental zotli goʻsht-sut qoramoli';
  } else if (lower.includes('angus')) {
    hayvonTuri = 'Aberdin-Angus marmar goʻsht buqasi';
  } else if (lower.includes('qora-ola') || lower.includes('qora ola')) {
    hayvonTuri = 'Qora-ola zotli sogʻin sigir';
  } else if (lower.includes('hisor') || lower.includes('hisori')) {
    hayvonTuri = 'Hisori dumbador naslli qoʻchqor';
  } else if (lower.includes('edilboy')) {
    hayvonTuri = 'Edilboy (Edilbaev) goʻsht-yogʻ qoʻyi';
  } else if (lower.includes('merinos')) {
    hayvonTuri = 'Merinos mayin junli zotdor qoʻy';
  } else if (lower.includes('qorabayir')) {
    hayvonTuri = 'Qorabayir uloqchi chopqir ot';
  } else if (lower.includes('axaltaka')) {
    hayvonTuri = 'Axaltaka sof zotli yaltiroq tulpor';
  } else if (lower.includes('sigir') || lower.includes('buqa')) {
    hayvonTuri = 'Nasldor Qoramol';
  } else if (lower.includes('qoʻy') || lower.includes('qoʻchqor')) {
    hayvonTuri = 'Semiz Qoʻy';
  } else if (lower.includes('ot') || lower.includes('aygʻir')) {
    hayvonTuri = 'Minish va Poyga Oti';
  }

  // 2. Age and Weight Extraction via Regex
  let yoshi = '';
  let vazni = '';

  const ageMatch = clean.match(/(\d+)\s*(yosh|oylik|oy|qorin)/i);
  if (ageMatch) {
    yoshi = `${ageMatch[1]} ${ageMatch[2].toLowerCase()}`;
  }

  const weightMatch = clean.match(/(\d+)\s*(kg|kilogramm|sentner|kgdan)/i);
  if (weightMatch) {
    vazni = `${weightMatch[1]} ${weightMatch[2].toLowerCase()}`;
  }

  const yoshiVaVazni =
    yoshi && vazni
      ? `${yoshi}, vazni: ${vazni}`
      : yoshi
      ? `Yoshi: ${yoshi} (vazni koʻrsatilmagan)`
      : vazni
      ? `Vazni: ${vazni} (yoshi koʻrsatilmagan)`
      : 'Koʻrsatilmagan (aniqlash talab etiladi)';

  // 3. Region / Location Extraction
  const regions = [
    'Toshkent', 'Samarqand', 'Andijon', 'Fargʻona', 'Fargona',
    'Namangan', 'Buxoro', 'Qashqadaryo', 'Surxondaryo', 'Jizzax',
    'Sirdaryo', 'Xorazm', 'Navoiy', 'Qoraqalpogʻiston', 'Chinoz', 'Pastdargʻom', 'Yangiyoʻl'
  ];

  let hudud = 'Oʻzbekiston respublikasi boʻyicha';
  for (const r of regions) {
    if (lower.includes(r.toLowerCase())) {
      hudud = `${r} viloyati`;
      break;
    }
  }

  // 4. SEO Tags Generator (5-8 tags)
  const tagsSet = new Set<string>();

  if (hayvonTuri.includes('Golshtin')) {
    tagsSet.add('#golshtin');
    tagsSet.add('#sut_sigiri');
  }
  if (hayvonTuri.includes('Hisor')) {
    tagsSet.add('#hisori_qochqor');
    tagsSet.add('#dumba');
    tagsSet.add('#qurbonlik2026');
  }
  if (hayvonTuri.includes('Qorabayir')) {
    tagsSet.add('#qorabayir');
    tagsSet.add('#kopkari_uloq');
    tagsSet.add('#chopqir_ot');
  }

  tagsSet.add('#chorvabozor');
  tagsSet.add('#dallolsiz');
  tagsSet.add('#vet_pasport');

  if (hudud !== 'Oʻzbekiston respublikasi boʻyicha') {
    tagsSet.add(`#${hudud.split(' ')[0].toLowerCase()}_chorva`);
  } else {
    tagsSet.add('#toshkent_bozor');
  }

  if (vazni) {
    tagsSet.add('#tirik_vazn');
  }
  tagsSet.add('#halol_savdo');

  const teglar = Array.from(tagsSet).slice(0, 8);

  return {
    hayvonTuri,
    yoshiVaVazni,
    hudud,
    teglar,
  };
}

// 4. Customer Support (FAQ & Helpdesk) Response Template Generator
export function generateSupportResponse(userQuestion: string): SupportResponseResult {
  const clean = (userQuestion || '').toLowerCase();

  // Topic 1: Safe Escrow / To'lov qachon o'tadi
  if (clean.includes('pul') || clean.includes('toʻlov') || clean.includes('tolov') || clean.includes('eskrou') || clean.includes('qachon')) {
    return {
      mavzu: 'Xavfsiz Toʻlov (Eskrou) Kafolati va Pul Qaytarish',
      javob: `Assalomu alaykum! ChorvaBozor mijozlarni qoʻllab-quvvatlash xizmati sizga yordam berishdan mamnun.

Platformamizda barcha xaridlar Davlat standarti asosidagi Eskrou xavfsiz hisob-kitobi bilan 100% himoyalangan. Siz toʻlagan mablagʻ sotuvchiga darhol oʻtmaydi, balki tranzit xavfsiz depozitda muzlatiladi.

Mablagʻ oʻtkazish va tekshirish bosqichlari:
1. Chorva moli maxsus fura orqali manzilingizga yetkazib beriladi.
2. Siz hayvonni koʻzdan kechirasiz: tarozi vazni, sogʻlomligi va veterinariya pasportini tekshirasiz.
3. Platformada «Qabul qildim (Toʻlovni yakunlash)» tugmasini bosganingizdagina mablagʻ sotuvchi hisobiga tushadi.
4. Agar hayvon eʼlondagi maʼlumotga mos kelmasa — buyurtmani rad etishingiz mumkin, toʻlovingiz 100% toʻliq qaytariladi.

Qoʻshimcha savollaringiz boʻlsa, tunu-kun ishlaydigan aloqa markazimiz (+998 71 200 45 67) doim xizmatingizda!`,
      bosqichlar: [
        'Toʻlov xavfsiz depozitda muzlatiladi',
        'Hayvon manzilingizga fura bilan yetkaziladi',
        'Tarozi va vet pasporti bilan tekshiriladi',
        'Tasdiqlaganingizdan keyin pul sotuvchiga oʻtadi',
      ],
    };
  }

  // Topic 2: Fura / Logistika / Yetkazib berish
  if (clean.includes('fura') || clean.includes('yetkaz') || clean.includes('dostavka') || clean.includes('mashina') || clean.includes('km')) {
    return {
      mavzu: 'Viloyatlararo Chorvavoz Fura va Bepul 100 KM Aksiyasi',
      javob: `Assalomu alaykum! Yetkazib berish xizmatimiz boʻyicha maʼlumot beramiz:

Platformamizda barcha qoramol, qoʻy va otlar velosiped yoki moslashtirilmagan texnikada emas, balki maxsus 2 qavatli, shamollatish tizimiga ega ogʻir yuk furalarida tashiladi.

Yetkazib berish tartibi:
1. Hozirgi aksiyamizga koʻra: 100 km masofagacha yetkazib berish MUTLAQO BEPUL (Promokod: #FURA_TEKIN).
2. 100 km dan ortiq masofa uchun har bir km uchun shaffof tabaqalashtirilgan tarif qoʻllaniladi.
3. Yoʻlda har bir hayvon Davlat sugʻurtasi bilan toʻliq himoyalangan va yoʻl davomida ozuqa-suv bilan taʼminlanadi.
4. Fura haydovchisining jonli GPS koordinatasini xaritada kuzatib borishingiz mumkin.`,
      bosqichlar: [
        'Katalogdan molni tanlang va transport buyurtma qiling',
        '100 km gacha bepul chorvavoz fura xizmati qoʻllanadi',
        'Hayvon sugʻurta va GPS monitoring bilan yetkaziladi',
      ],
    };
  }

  // Topic 3: Veterinariya / Vaksina / Sog'lomlik
  if (clean.includes('vet') || clean.includes('kasal') || clean.includes('vaksina') || clean.includes('pasport') || clean.includes('emlash')) {
    return {
      mavzu: 'Davlat Veterinariya Koʻrigi va Yashil Pasport',
      javob: `Assalomu alaykum! ChorvaBozor platformasidagi har bir hayvon qatʼiy tibbiy nazoratdan oʻtkaziladi:

1. Platformaga faqat Davlat veterinariya qoʻmitasining yagona elektron bazasidan tekshirilgan mollar kiritiladi.
2. Har bir hayvon kuydirgi, oqsil, brutselloz va qora oqsoq kasalliklariga qarshi emlangan boʻladi.
3. Sotib olinganda rasmiy №1 Veterinariya yoʻl guvohnomasi va elektron chip/birka maʼlumotnomasi birga beriladi.
4. Shuningdek, har bir eʼlonda «Veterinar Maslahati (Chat)» tugmasi orqali mutaxassis shifokor bilan bevosita onlayn suhbatlashishingiz mumkin.`,
      bosqichlar: [
        'Eʼlondagi «Vet Pasport» boʻlimini koʻrib chiqing',
        'Veterinar bilan chat orqali emlash tarixini soʻrang',
        'Yuk yetib kelganda davlat muhrli guvohnomani qabul qiling',
      ],
    };
  }

  // Topic 4: Auksion va Savdolar
  if (clean.includes('auksion') || clean.includes('stavka') || clean.includes('narx') || clean.includes('yutish')) {
    return {
      mavzu: 'Jonli Auksion Qoidalari va Narx Taklif Qilish',
      javob: `Assalomu alaykum! Jonli auksionimizda qatnashish boʻyicha qisqacha qoʻllanma:

1. Auksion boʻlimiga kiring va oʻzingizga maʼqul nasldor qoramol, Hisor qoʻyi yoki Qorabayir otini tanlang.
2. Minimal qadam (masalan: 300 000 soʻm) bilan stavka bering yoki tayyor tezkor tugmalardan foydalaning.
3. Auksion vaqti tugaguncha eng yuqori taklif bergan ishtirokchi gʻolib boʻladi.
4. Gʻolib boʻlganingizdan soʻng shartnoma avtomatik tarzda shakllanadi va molingiz fura bilan uyingizga joʻnatiladi.`,
      bosqichlar: [
        'Jonli auksion sahifasiga oʻting',
        'Boshlangʻich narxdan yuqori stavka qoldiring',
        'Taymer tugashini kuting va gʻoliblikni qoʻlga kiriting',
      ],
    };
  }

  // Default General Professional Support Template
  return {
    mavzu: 'Umumiy Mijozlar Murojaati va Qoʻllab-quvvatlash',
    javob: `Assalomu alaykum! ChorvaBozor platformasi mijozlarni qoʻllab-quvvatlash xizmatiga murojaat qilganingiz uchun tashakkur.

Sizning murojaatingiz mutaxassislarimiz tomonidan qabul qilindi. 

Muammoni tezkor hal qilish boʻyicha koʻrsatmalar:
1. Eʼlonlar va buyurtmalar sahifasida buyurtma yoki eʼlon raqamini (#ORD yoki #LIVE) tekshiring.
2. Agar savolingiz toʻlov, transport yoki veterinariya boʻyicha boʻlsa, tegishli boʻlim orqali operatorga xabar qoldirishingiz mumkin.
3. Shoshilinch masalalar yuzasidan 24/7 ish tartibida faoliyat yurituvchi bepul ishonch telefonimizga qoʻngʻiroq qiling: +998 71 200 45 67.

Biz har bir mijozimizga shaffof, xavfsiz va halol xizmat koʻrsatishdan mamnunmiz!`,
    bosqichlar: [
      'Buyurtma holatini tekshiring',
      'Operator bilan onlayn aloqaga chiqing',
      'Ishonch telefoni orqali 24/7 yordam oling',
    ],
  };
}
