import { LivestockItem, AuctionItem, RegionPriceStat, Seller } from '../types';
import { allBreedLivestockItems } from './breedCatalogAnimals';
import { mockSellers } from './mockSellers';
export { mockSellers };

// 100% verified, strictly separated by department, real-time timestamps & concise descriptions
export const mockLivestock: LivestockItem[] = allBreedLivestockItems;

export const mockAuctions: AuctionItem[] = [
  {
    id: 'auc-01',
    livestockId: 'breed-qora_ola-3',
    titleUz: 'Golshtin zotli 8 oylik urugʻlik buqacha (Elita nasl)',
    titleRu: 'Племенной 8-месячный бычок породы Голштин (Элита)',
    breed: 'Qora-ola (Holstein / Черно-пестрая)',
    headCount: 1,
    totalWeightKg: 280,
    startingPriceUzs: 11000000,
    currentBidUzs: 12500000,
    minStepUzs: 300000,
    endsAt: '2026-10-06T18:00:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
    region: 'Toshkent viloyati',
    sellerName: 'Toshkent Agro Sut FM',
    status: 'active',
    bids: [
      { id: 'b3', bidderName: 'Shuxrat B. (Samarqand)', bidderRegion: 'Samarqand', amountUzs: 12500000, timestamp: '10 daqiqa oldin' },
      { id: 'b2', bidderName: 'Farrux A. (Fargʻona)', bidderRegion: 'Fargʻona', amountUzs: 12200000, timestamp: '45 daqiqa oldin' },
      { id: 'b1', bidderName: 'Nodirbek (Toshkent)', bidderRegion: 'Toshkent', amountUzs: 11500000, timestamp: '2 soat oldin' }
    ]
  },
  {
    id: 'auc-02',
    livestockId: 'breed-hisor-1',
    titleUz: 'Hisor zotli bahaybat rekord qoʻchqor (150 kg)',
    titleRu: 'Гиссарский баран-великан (150 кг)',
    breed: 'Hisor qoʻylari',
    headCount: 1,
    totalWeightKg: 150,
    startingPriceUzs: 7500000,
    currentBidUzs: 8400000,
    minStepUzs: 200000,
    endsAt: '2026-10-07T12:30:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
    region: 'Qashqadaryo',
    sellerName: 'Hisor Nasl Buloq FM',
    status: 'active',
    bids: [
      { id: 'b22', bidderName: 'Umarxon K. (Buxoro)', bidderRegion: 'Buxoro', amountUzs: 8400000, timestamp: '22 daqiqa oldin' },
      { id: 'b21', bidderName: 'Jahongir (Navoiy)', bidderRegion: 'Navoiy', amountUzs: 8000000, timestamp: '1 soat oldin' }
    ]
  },
  {
    id: 'auc-03',
    livestockId: 'breed-qorabayir-1',
    titleUz: 'Qorabayir zotli 4 yoshli uloqchi chopqir aygʻir',
    titleRu: 'Карабаирский 4-летний жеребец (линия чемпионов улок)',
    breed: 'Qorabayir oti',
    headCount: 1,
    totalWeightKg: 490,
    startingPriceUzs: 42000000,
    currentBidUzs: 46000000,
    minStepUzs: 1000000,
    endsAt: '2026-10-08T15:00:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
    region: 'Samarqand',
    sellerName: 'Samarqand Qorabayir Otchilik Majmuasi',
    status: 'active',
    bids: [
      { id: 'hb2', bidderName: 'Botir Polvon (Qashqadaryo)', bidderRegion: 'Qashqadaryo', amountUzs: 46000000, timestamp: '15 daqiqa oldin' },
      { id: 'hb1', bidderName: 'Rustambek (Jizzax)', bidderRegion: 'Jizzax', amountUzs: 44000000, timestamp: '3 soat oldin' }
    ]
  }
];

export const mockPriceIndex: RegionPriceStat[] = [
  {
    region: 'Toshkent shahri',
    averageLiveWeightPriceBeef: 52500,
    averageLiveWeightPriceSheep: 54000,
    averageDairyCowPrice: 28.5,
    changePercentageLastMonth: 2.1,
    trend: 'up',
    notesUz: 'Poytaxtda sut va goʻshtga talab yuqori, sifatli qoramol narxi barqaror oʻsmoqda.',
    notesRu: 'В столице высокий спрос, цены на качественный скот устойчиво растут.'
  },
  {
    region: 'Toshkent viloyati',
    averageLiveWeightPriceBeef: 50000,
    averageLiveWeightPriceSheep: 52000,
    averageDairyCowPrice: 27.0,
    changePercentageLastMonth: 1.8,
    trend: 'up',
    notesUz: 'Chinoz, Yangiyoʻl bozorlarida faollik yuqori.',
    notesRu: 'Высокая активность на рынках Чиназа и Янгиюля.'
  },
  {
    region: 'Samarqand',
    averageLiveWeightPriceBeef: 48500,
    averageLiveWeightPriceSheep: 50500,
    averageDairyCowPrice: 25.0,
    changePercentageLastMonth: 0.5,
    trend: 'stable',
    notesUz: 'Juma va Pastdargʻom bozorlarida taklif yetarli, Qorabayir otlari savdosi faol.',
    notesRu: 'Предложение на базарах стабильное, активная торговля карабаирами.'
  },
  {
    region: 'Andijon',
    averageLiveWeightPriceBeef: 49500,
    averageLiveWeightPriceSheep: 51000,
    averageDairyCowPrice: 26.5,
    changePercentageLastMonth: 2.4,
    trend: 'up',
    notesUz: 'Vodiyda yem-xashak narxi oshishi fonida tirik vazn biroz qimmatlashgan.',
    notesRu: 'На фоне подорожания кормов живой вес слегка вырос.'
  },
  {
    region: 'Fargʻona',
    averageLiveWeightPriceBeef: 49000,
    averageLiveWeightPriceSheep: 50000,
    averageDairyCowPrice: 25.8,
    changePercentageLastMonth: 1.2,
    trend: 'stable',
    notesUz: 'Qoʻqon va Margʻilon bozorlarida barqaror savdo.',
    notesRu: 'Стабильные торги на рынках Коканда и Маргилана.'
  },
  {
    region: 'Namangan',
    averageLiveWeightPriceBeef: 48800,
    averageLiveWeightPriceSheep: 50200,
    averageDairyCowPrice: 25.4,
    changePercentageLastMonth: 0.8,
    trend: 'stable',
    notesUz: 'Chust va Kosonsoy chorva bozorlarida standart narxlar.',
    notesRu: 'Стандартный уровень цен в Чусте и Касансае.'
  },
  {
    region: 'Qashqadaryo',
    averageLiveWeightPriceBeef: 47000,
    averageLiveWeightPriceSheep: 49000,
    averageDairyCowPrice: 23.5,
    changePercentageLastMonth: -0.5,
    trend: 'stable',
    notesUz: 'Katta yaylovlar hisobiga Hisor qoʻylari va qoramol taklifi moʻl.',
    notesRu: 'Обилие пастбищ обеспечивает доступные цены на гиссарских овец.'
  },
  {
    region: 'Surxondaryo',
    averageLiveWeightPriceBeef: 46800,
    averageLiveWeightPriceSheep: 48500,
    averageDairyCowPrice: 23.0,
    changePercentageLastMonth: 0.2,
    trend: 'stable',
    notesUz: 'Janubiy hududlarda erta bahorgi ozuqa yaxshi taʼsir qilgan.',
    notesRu: 'Раннее тепло благоприятно сказалось на кормовой базе.'
  },
  {
    region: 'Buxoro',
    averageLiveWeightPriceBeef: 48000,
    averageLiveWeightPriceSheep: 49500,
    averageDairyCowPrice: 24.2,
    changePercentageLastMonth: -1.1,
    trend: 'down',
    notesUz: 'Gʻijduvon bozorida qoramol taklifi koʻpaygani hisobiga narx biroz arzonlashgan.',
    notesRu: 'Небольшое снижение цен из-за притока скота в Гиждуван.'
  },
  {
    region: 'Xorazm',
    averageLiveWeightPriceBeef: 48200,
    averageLiveWeightPriceSheep: 49200,
    averageDairyCowPrice: 24.0,
    changePercentageLastMonth: 0.6,
    trend: 'stable',
    notesUz: 'Urganch va Shovotda sutli sigirlarga talab barqaror.',
    notesRu: 'Устойчивый спрос на дойных коров в Ургенче.'
  },
  {
    region: 'Jizzax',
    averageLiveWeightPriceBeef: 47500,
    averageLiveWeightPriceSheep: 49800,
    averageDairyCowPrice: 24.5,
    changePercentageLastMonth: 1.0,
    trend: 'stable',
    notesUz: 'Gʻallaorol va Zomin togʻoldi hududlarida sifatli yaylov mollari.',
    notesRu: 'Качественный пастбищный скот из предгорий Заамина.'
  },
  {
    region: 'Sirdaryo',
    averageLiveWeightPriceBeef: 48000,
    averageLiveWeightPriceSheep: 50000,
    averageDairyCowPrice: 24.8,
    changePercentageLastMonth: 0.4,
    trend: 'stable',
    notesUz: 'Guliston yaqinida poytaxt xaridorlari faol.',
    notesRu: 'Активные покупатели из столичного региона.'
  },
  {
    region: 'Navoiy',
    averageLiveWeightPriceBeef: 47200,
    averageLiveWeightPriceSheep: 48800,
    averageDairyCowPrice: 23.8,
    changePercentageLastMonth: -0.3,
    trend: 'stable',
    notesUz: 'Karmana va Qiziltepa bozorlarida barqaror vaziyat.',
    notesRu: 'Стабильная ситуация в Кармане и Кызылтепе.'
  },
  {
    region: 'Qoraqalpogʻiston Respublikasi',
    averageLiveWeightPriceBeef: 46000,
    averageLiveWeightPriceSheep: 47500,
    averageDairyCowPrice: 22.0,
    changePercentageLastMonth: 0.1,
    trend: 'stable',
    notesUz: 'Nukus va Qoʻngʻirot bozorlarida quruq ozuqa sharoitiga moslashtirilgan chorva.',
    notesRu: 'Адаптированный к местным условиям скот.'
  }
];

export const distanceMatrixKm: Record<string, Record<string, number>> = {
  'Toshkent shahri': {
    'Toshkent viloyati': 35,
    'Samarqand': 310,
    'Andijon': 360,
    'Fargʻona': 325,
    'Namangan': 295,
    'Qashqadaryo': 450,
    'Surxondaryo': 660,
    'Buxoro': 580,
    'Xorazm': 980,
    'Jizzax': 200,
    'Sirdaryo': 85,
    'Navoiy': 480,
    'Qoraqalpogʻiston Respublikasi': 1100,
    'Toshkent shahri': 0
  },
  'Samarqand': {
    'Toshkent shahri': 310,
    'Toshkent viloyati': 290,
    'Samarqand': 0,
    'Andijon': 670,
    'Fargʻona': 635,
    'Namangan': 605,
    'Qashqadaryo': 150,
    'Surxondaryo': 370,
    'Buxoro': 270,
    'Xorazm': 720,
    'Jizzax': 110,
    'Sirdaryo': 230,
    'Navoiy': 170,
    'Qoraqalpogʻiston Respublikasi': 840
  },
  'Andijon': {
    'Toshkent shahri': 360,
    'Toshkent viloyati': 350,
    'Samarqand': 670,
    'Andijon': 0,
    'Fargʻona': 75,
    'Namangan': 65,
    'Qashqadaryo': 810,
    'Surxondaryo': 980,
    'Buxoro': 940,
    'Xorazm': 1340,
    'Jizzax': 560,
    'Sirdaryo': 445,
    'Navoiy': 840,
    'Qoraqalpogʻiston Respublikasi': 1460
  }
};

export const mockEquipment = [
  {
    id: 'eq-01',
    type: 'equipment' as const,
    titleUz: 'Qoʻlda toʻqilgan pishiq chorva arqoni (15 metr, kanop)',
    titleRu: 'Крепкая плетеная веревка для скота (15 м, канат)',
    subcategory: 'arqon' as const,
    material: 'ip' as const,
    sizeOrLength: '15 metr (Diametr 18mm)',
    condition: 'yangi' as const,
    priceUzs: 180000,
    region: 'Samarqand' as const,
    district: 'Urgut tumani',
    descriptionUz: 'Paxta va kanop tolasidan qalin pishiq qilib eshilgan, qoʻlni kesmaydi. 1 tonnalik novvosni ham bemalol ushlaydi.',
    descriptionRu: 'Изготовлена из прочного каната, не режет руки. Выдерживает нагрузку до 1.5 тонны.',
    imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=800&q=80',
    seller: {
      id: 'seller-eq-1',
      name: 'Urgut Hunarmandlar Markazi',
      farmName: 'Urgut Arqonchilik',
      phone: '+998 90 445 11 22',
      telegramUsername: 'urgut_arqon',
      region: 'Samarqand' as const,
      district: 'Urgut tumani',
      isPassportVerified: true,
      isPhoneVerified: true,
      rating: 4.9,
      dealsCompleted: 86,
      memberSince: '2025-01-10',
      badge: 'Fermer xoʻjaligi' as const
    },
    status: 'active' as const,
    createdAt: '2026-10-08',
    viewsCount: 340,
    likesCount: 28
  },
  {
    id: 'eq-02',
    type: 'equipment' as const,
    titleUz: 'Tabiiy charmdan tayyorlangan bezakli yoʻgʻan (Yugan)',
    titleRu: 'Кожаная уздечка ручной работы (Недоуздок)',
    subcategory: 'yugan' as const,
    material: 'charm' as const,
    sizeOrLength: 'Standart (Katta mol va ot uchun)',
    condition: 'yangi' as const,
    priceUzs: 350000,
    region: 'Toshkent viloyati' as const,
    district: 'Chinoz tumani',
    descriptionUz: 'Haqiqiy xrom charmdan tikilgan, mis va guruch halqalari bor. Terini qirmaydi, uzoq yillar xizmat qiladi.',
    descriptionRu: 'Натуральная кожа, латунные кольца, ручная прошивка.',
    imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
    seller: {
      id: 'seller-eq-2',
      name: 'Sherzod Usta',
      farmName: 'Saddi Charmchilik',
      phone: '+998 91 223 88 99',
      telegramUsername: 'sherzod_charm',
      region: 'Toshkent viloyati' as const,
      district: 'Chinoz tumani',
      isPassportVerified: true,
      isPhoneVerified: true,
      rating: 5.0,
      dealsCompleted: 112,
      memberSince: '2024-11-20',
      badge: 'Fermer xoʻjaligi' as const
    },
    status: 'active' as const,
    createdAt: '2026-10-09',
    viewsCount: 512,
    likesCount: 45
  },
  {
    id: 'eq-03',
    type: 'equipment' as const,
    titleUz: 'Uloq va koʻpkari uchun professional terili egar toʻplami',
    titleRu: 'Профессиональное седло для козлодранья (Купкари/Улак)',
    subcategory: 'egar' as const,
    material: 'charm' as const,
    sizeOrLength: 'N2 (Kattalar uchun, uzangi + ayil)',
    condition: 'yangi' as const,
    priceUzs: 2400000,
    region: 'Jizzax' as const,
    district: 'Baxmal tumani',
    descriptionUz: 'Qayragʻoch qoshli, qalin kigiz va charm bilan qoplangan. Uzangilari qora poʻlat, otning belini urmaydi.',
    descriptionRu: 'Деревянный каркас из вяза, толстый войлок, стремена из стали.',
    imageUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&q=80',
    seller: {
      id: 'seller-eq-3',
      name: 'Baxmal Egarchilik Ustaxonasi',
      farmName: 'Usta Rustam',
      phone: '+998 94 332 77 66',
      telegramUsername: 'baxmal_egar',
      region: 'Jizzax' as const,
      district: 'Baxmal tumani',
      isPassportVerified: true,
      isPhoneVerified: true,
      rating: 4.95,
      dealsCompleted: 64,
      memberSince: '2025-02-15',
      badge: 'Fermer xoʻjaligi' as const
    },
    status: 'active' as const,
    createdAt: '2026-10-07',
    viewsCount: 780,
    likesCount: 89
  },
  {
    id: 'eq-04',
    type: 'equipment' as const,
    titleUz: 'Galvanizatsiyalangan 2 tomonlama metall yemdon (Oxur)',
    titleRu: 'Оцинкованная двухсторонняя кормушка для КРС и овец',
    subcategory: 'yemdon' as const,
    material: 'metall' as const,
    sizeOrLength: 'Uzunligi 2.5 metr, chuqurligi 45 sm',
    condition: 'yangi' as const,
    priceUzs: 1100000,
    region: 'Andijon' as const,
    district: 'Asaka tumani',
    descriptionUz: 'Zanglamaydigan qalin tunuka, yem toʻkilmaydi. Qoramol va qoʻylar uchun toza va qulay oziqlantirish vositasi.',
    descriptionRu: 'Прочная оцинкованная сталь, предотвращает рассыпание корма.',
    imageUrl: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=800&q=80',
    seller: {
      id: 'seller-eq-4',
      name: 'AgroTex Sanoat',
      farmName: 'Asaka Agro Jihoz',
      phone: '+998 93 998 01 02',
      telegramUsername: 'asaka_yemdon',
      region: 'Andijon' as const,
      district: 'Asaka tumani',
      isPassportVerified: true,
      isPhoneVerified: true,
      rating: 4.8,
      dealsCompleted: 43,
      memberSince: '2025-03-01',
      badge: 'Fermer xoʻjaligi' as const
    },
    status: 'active' as const,
    createdAt: '2026-10-10',
    viewsCount: 290,
    likesCount: 19
  }
];

