import { LivestockItem, UzbekistanRegion } from '../types';
import { mockSellers } from './mockSellers';

// 1. QORAMOL KABINETI: Faqat va faqat haqiqiy qoramollar, sigirlar, buqalar, g'unajinlar
export const qoramolImages = [
  'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80', // Holstein sut sigiri
  'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=800&q=80', // Qora-ola sogʻlom buqa
  'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=800&q=80', // Simmental qoramollar yaylovda
  'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=800&q=80', // Qizil cho'l sigiri
  'https://images.unsplash.com/photo-1560493676-04071c5f467b?auto=format&fit=crop&w=800&q=80', // Boqilgan semiz novvos
  'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80', // Hereford oq boshli nasldor sigir
  'https://images.unsplash.com/photo-1596733430284-f7437764b1a9?auto=format&fit=crop&w=800&q=80', // Yosh g'unajin
];

// 2. QO'YLAR KABINETI: Faqat va faqat haqiqiy qo'ylar, qo'chqorlar, dumbador Hisor va Edilboylar
export const quyImages = [
  'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80', // Katta shoxli baquvvat qo'chqor
  'https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?auto=format&fit=crop&w=800&q=80', // Oq mayin junli qo'y
  'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=800&q=80', // Yaylovdagi semiz qo'ylar suruvi
  'https://images.unsplash.com/photo-1582234372722-50d7ccc30ebd?auto=format&fit=crop&w=800&q=80', // Qo'ng'ir junli Edilboy / Hisor
  'https://images.unsplash.com/photo-1524024973431-2ad916746881?auto=format&fit=crop&w=800&q=80', // Shoxli yirik qo'chqor
  'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=800&q=80', // O'tloqdagi qo'ylar
];

// 3. OTLAR KABINETI: Faqat va faqat haqiqiy poyga otlari, Qorabayir, Axaltaka, og'ir yuk va sport otlari
export const otImages = [
  'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80', // Chopqir chopayotgan ayg'ir
  'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&q=80', // Sport to'siqdan sakrovchi ot
  'https://images.unsplash.com/photo-1534067783941-51c9c23ecefd?auto=format&fit=crop&w=800&q=80', // Qora ko'rkam ayg'ir
  'https://images.unsplash.com/photo-1528722828814-77b9b83aafb2?auto=format&fit=crop&w=800&q=80', // Qorabayir to'riq minish oti
  'https://images.unsplash.com/photo-1598974357801-cbca100e65d3?auto=format&fit=crop&w=800&q=80', // Rus og'ir yuk baquvvat oti
  'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80', // Nasldor ot
];

const regions: UzbekistanRegion[] = [
  'Toshkent viloyati',
  'Samarqand',
  'Qashqadaryo',
  'Andijon',
  'Buxoro',
  'Fargʻona',
  'Jizzax',
  'Surxondaryo'
];

const realTimeOffsets = [
  '5 daqiqa oldin',
  '12 daqiqa oldin',
  '24 daqiqa oldin',
  'Bugun 11:15 da',
  'Bugun 14:40 da',
  'Bugun 16:05 da',
  'Kecha 18:20 da'
];

interface BreedSeed {
  breedKey: string;
  breedName: string;
  dept: 'qoramol' | 'quy' | 'ot';
  cat: any;
  gender: string;
  baseWeight: number;
  basePrice: number;
  variants: {
    titleUz: string;
    titleRu: string;
    weightDelta: number;
    priceDelta: number;
    age: number;
    district: string;
    descUz: string;
    descRu: string;
    isQurbon: boolean;
  }[];
}

const breedSeeds: BreedSeed[] = [
  // ==========================================
  // 1. QORAMOL KABINETI (5 TA ZOT)
  // ==========================================
  {
    breedKey: 'qora_ola',
    breedName: 'Qora-ola (Holstein / Черно-пестрая)',
    dept: 'qoramol',
    cat: 'dairy',
    gender: 'sigir',
    baseWeight: 620,
    basePrice: 28000000,
    variants: [
      {
        titleUz: 'Qora-ola (Holstein) 2-qorin sogʻin sigir',
        titleRu: 'Голштинская корова 2-й отел (28 л)',
        weightDelta: 0,
        priceDelta: 500000,
        age: 36,
        district: 'Chinoz tumani',
        descUz: 'Holstein sut zoti. Kunlik suti 28 litr, apparatga oʻrgatilgan, klinik sogʻlom, emlangan.',
        descRu: 'Голштинская молочная корова. Суточный удой 28 л, приучена к аппарату, ветпаспорт.',
        isQurbon: false
      },
      {
        titleUz: 'Holstein naslli 1-qorin yosh gʻunajin',
        titleRu: 'Первотёлка голштинская племенная',
        weightDelta: -70,
        priceDelta: -3000000,
        age: 26,
        district: 'Zangiota tumani',
        descUz: 'Birinchi qorin yosh gʻunajin. Bolasi yonida, kuniga 22 litr toza sut beradi.',
        descRu: 'Молодая корова с теленком, удой 22 л, отличный аппетит.',
        isQurbon: false
      },
      {
        titleUz: 'Qora-ola elita naslli 8 oylik urugʻlik buqacha',
        titleRu: 'Племенной бычок черно-пестрый 8 мес',
        weightDelta: -340,
        priceDelta: -16000000,
        age: 8,
        district: 'Oqqoʻrgʻon tumani',
        descUz: 'Naslli xoʻjalikdan olingan urugʻlik buqa. Gavdasi yirik, suyaklari baquvvat.',
        descRu: 'Племенной бычок для стада, крепкий костяк, здоровый рост.',
        isQurbon: false
      },
      {
        titleUz: 'Golshtin Friesian 3-qorin sergoʻsht sogʻin sigir',
        titleRu: 'Голштин фризская 3-й отел (32 л)',
        weightDelta: 50,
        priceDelta: 2000000,
        age: 48,
        district: 'Yangiyoʻl tumani',
        descUz: 'Kuniga 32 litr sut beruvchi sermahsul sigir. Yelini chashasimon, tinch feʼlli.',
        descRu: 'Высокоудойная корова 32 литра в сутки. Идеальное чашеобразное вымя.',
        isQurbon: false
      },
      {
        titleUz: 'Qora-ola zotli 6 oylik nasldor urgʻochi buzoq',
        titleRu: 'Телочка черно-пестрая 6 мес',
        weightDelta: -410,
        priceDelta: -19000000,
        age: 6,
        district: 'Boʻka tumani',
        descUz: 'Sutdor onadan olingan urgʻochi buzoq. Emlangan, vitaminlar berilgan.',
        descRu: 'Племенная телочка от высокоудойной матери, привита.',
        isQurbon: false
      }
    ]
  },
  {
    breedKey: 'qizil_chol',
    breedName: 'Qizil choʻl (Красная степная)',
    dept: 'qoramol',
    cat: 'dairy',
    gender: 'sigir',
    baseWeight: 520,
    basePrice: 22000000,
    variants: [
      {
        titleUz: 'Qizil choʻl zotli 7 oylik boʻgʻoz sigir',
        titleRu: 'Красная степная корова 7 мес стельности',
        weightDelta: 10,
        priceDelta: 0,
        age: 42,
        district: 'Qarshi tumani',
        descUz: 'Janubning issiq iqlimiga toʻliq mos. 7 oylik boʻgʻoz, suti yogʻli (4.3%).',
        descRu: 'Красная степная порода, стельность 7 мес, жирное молоко 4.3%.',
        isQurbon: false
      },
      {
        titleUz: 'Qizil choʻl naslli 2 yoshli boqilgan novvos',
        titleRu: 'Бык красной степной породы 2 года',
        weightDelta: 110,
        priceDelta: 4000000,
        age: 24,
        district: 'Nishon tumani',
        descUz: 'Boqilgan semiz novvos. Tirik vazni 630 kg, toʻy va marosimlarga tayyor.',
        descRu: 'Откормленный бык 630 кг, высокий выход сочного мяса.',
        isQurbon: true
      },
      {
        titleUz: 'Qizil choʻl sogʻin sigir va buzoqchasi (1-qorin)',
        titleRu: 'Красная степная с теленком (18 л)',
        weightDelta: -40,
        priceDelta: 1000000,
        age: 28,
        district: 'Koson tumani',
        descUz: 'Birinchi qorin yosh ona sigir. Kunlik suti 18 litr, buzoqchasi sogʻlom.',
        descRu: 'Корова первого отела с теленком, удой 18 литров.',
        isQurbon: false
      },
      {
        titleUz: 'Qizil choʻl 1 yillik yaylov novvosi',
        titleRu: 'Бычок пастбищный 1 год',
        weightDelta: -210,
        priceDelta: -8000000,
        age: 12,
        district: 'Muborak tumani',
        descUz: 'Dasht yaylovida tabiiy bedada oʻsgan novvos. Kam xarajat, chidamli.',
        descRu: 'Выносливый бычок на естественном выпасе, крепкий иммунитет.',
        isQurbon: false
      },
      {
        titleUz: 'Qizil choʻl 6 oylik boʻgʻoz gʻunajin',
        titleRu: 'Нетель стельная 6 мес',
        weightDelta: -30,
        priceDelta: -1000000,
        age: 22,
        district: 'Kasbi tumani',
        descUz: 'Naslli urugʻlantirilgan gʻunajin. 6 oylik boʻgʻoz, UZI maʼlumotnomasi bor.',
        descRu: 'Стельная нетель 6 месяцев, УЗИ подтверждено.',
        isQurbon: false
      }
    ]
  },
  {
    breedKey: 'simmental',
    breedName: 'Simmental',
    dept: 'qoramol',
    cat: 'beef',
    gender: 'buqa',
    baseWeight: 750,
    basePrice: 34000000,
    variants: [
      {
        titleUz: 'Simmental naslli 2 yoshli bahaybat goʻshtdor buqa',
        titleRu: 'Симментальский бык 2 года (800 кг)',
        weightDelta: 50,
        priceDelta: 4000000,
        age: 24,
        district: 'Pastdargʻom tumani',
        descUz: 'Universal goʻsht-sut zoti. Tirik vazni 800 kg, boʻrdoqiga boqilgan baquvvat buqa.',
        descRu: 'Мощный симментальский бык 800 кг, превосходная мускулатура.',
        isQurbon: true
      },
      {
        titleUz: 'Simmental 3-qorin sogʻin sigir (kunlik 24L sut)',
        titleRu: 'Симментальская корова (24 л)',
        weightDelta: -90,
        priceDelta: -6000000,
        age: 38,
        district: 'Urgut tumani',
        descUz: 'Ham sergoʻsht gavdali, ham kuniga 24 litr toza sut beradi. Tinch va yuvosh.',
        descRu: 'Мясо-молочная симменталка, 24 литра удоя, крепкое здоровье.',
        isQurbon: false
      },
      {
        titleUz: 'Simmental zotli buzoqlar partiyasi (5 bosh)',
        titleRu: 'Партия телят симменталов (5 голов)',
        weightDelta: 100,
        priceDelta: 1000000,
        age: 6,
        district: 'Jomboy tumani',
        descUz: 'Besh bosh sogʻlom buzoqlar partiyasi. Boʻrdoqichilik uchun eng yaxshi tanlov.',
        descRu: 'Партия из 5 телят на откорм, быстрый суточный привес.',
        isQurbon: false
      },
      {
        titleUz: 'Simmental elita gʻunajin (Avstriya liniyasi)',
        titleRu: 'Симментальская элитная нетель',
        weightDelta: -180,
        priceDelta: -8000000,
        age: 18,
        district: 'Bulungʻur tumani',
        descUz: 'Avstriya naslidan koʻpaytirilgan toza qonli Simmental gʻunajin.',
        descRu: 'Чистопородная нетель австрийских линий, племенное свидетельство.',
        isQurbon: false
      },
      {
        titleUz: 'Simmental 1.5 yillik jadal oʻsuvchi novvos',
        titleRu: 'Бычок симментал 1.5 года',
        weightDelta: -160,
        priceDelta: -9000000,
        age: 18,
        district: 'Tayloq tumani',
        descUz: 'Kunjara va silosda parvarishlangan. Kunlik oʻsish surʼati 1.4 kg.',
        descRu: 'Бычок на интенсивном откорме, привес 1.4 кг в день.',
        isQurbon: true
      }
    ]
  },
  {
    breedKey: 'angus_hereford',
    breedName: 'Angus / Hereford',
    dept: 'qoramol',
    cat: 'beef',
    gender: 'buqa',
    baseWeight: 820,
    basePrice: 38000000,
    variants: [
      {
        titleUz: 'Black Angus komol bahaybat buqa (Mramor goʻsht)',
        titleRu: 'Абердин ангус черный комолый бык',
        weightDelta: 20,
        priceDelta: 2000000,
        age: 26,
        district: 'Oqdaryo tumani',
        descUz: 'Sof mramor goʻsht zoti. Shoxsiz (komol), goʻsht chiqishi 65%, sogʻlom.',
        descRu: 'Абердин-ангус, выход мраморного мяса 65%, комолый.',
        isQurbon: true
      },
      {
        titleUz: 'Hereford oq boshli qizil goʻshtdor buqa',
        titleRu: 'Герефорд белый лоб мясной бык',
        weightDelta: -40,
        priceDelta: -2000000,
        age: 24,
        district: 'Payariq tumani',
        descUz: 'Hereford zotli sovuq-issiqqa chidamli buqa. Semiz goʻshtli, tarozi tekshiruvi bor.',
        descRu: 'Герефордский мясной бык, идеальная упитанность.',
        isQurbon: true
      },
      {
        titleUz: 'Black Angus 1 yillik nasldor novvoslar (3 bosh)',
        titleRu: 'Ангусы годовалые (3 головы)',
        weightDelta: 140,
        priceDelta: 16000000,
        age: 12,
        district: 'Narpay tumani',
        descUz: 'Uch bosh Angus novvoslari. Goʻsht fermasi va boʻrdoqi uchun ayni muddao.',
        descRu: 'Группа годовалых ангусов для премиального мясного откорма.',
        isQurbon: false
      },
      {
        titleUz: 'Angus goʻsht yoʻnalishidagi ona moli',
        titleRu: 'Корова ангус мясная',
        weightDelta: -170,
        priceDelta: -10000000,
        age: 34,
        district: 'Ishtixon tumani',
        descUz: 'Oson tugʻadigan, kam xarajat Angus ona moli. Yaylovda erkin boqilgan.',
        descRu: 'Мясная корова породы ангус, легкий отел.',
        isQurbon: false
      },
      {
        titleUz: 'Hereford 8 oylik urugʻlik erkak buzoq',
        titleRu: 'Бычок герефорд 8 мес',
        weightDelta: -500,
        priceDelta: -23000000,
        age: 8,
        district: 'Kattaqoʻrgʻon tumani',
        descUz: 'Goʻsht yoʻnalishidagi eng chidamli zot urugʻligi. Emlashlari toʻliq.',
        descRu: 'Племенной бычок герефорд 8 месяцев, привит.',
        isQurbon: false
      }
    ]
  },
  {
    breedKey: 'jaydari_mol',
    breedName: 'Jaydari qoramollar',
    dept: 'qoramol',
    cat: 'beef',
    gender: 'buqa',
    baseWeight: 490,
    basePrice: 21000000,
    variants: [
      {
        titleUz: 'Semiz Jaydari qoramol (Toʻy va qassoblarga)',
        titleRu: 'Местный откормленный бык джайдари',
        weightDelta: 30,
        priceDelta: 3500000,
        age: 28,
        district: 'Yangiyoʻl tumani',
        descUz: 'Tabiiy yemda semirtirilgan jaydari mol. Mayin goʻshtli, tarozi tekshiruvi bor.',
        descRu: 'Откормленный местный бык на натуральных кормах, нежное мясо.',
        isQurbon: true
      },
      {
        titleUz: 'Jaydari sogʻin sigir (kuniga 14 litr sut)',
        titleRu: 'Местная дойная корова (14 л)',
        weightDelta: -70,
        priceDelta: -4000000,
        age: 40,
        district: 'Gʻuzor tumani',
        descUz: 'Ozuqa tanlamaydi, kam xarajat, roʻzgʻor uchun juda qulay 14L sutli sigir.',
        descRu: 'Неприхотливая домашняя корова, 14 литров молока в сутки.',
        isQurbon: false
      },
      {
        titleUz: 'Jaydari 1 yoshli novvos (xonaki parvarish)',
        titleRu: 'Молодой бычок джайдари 1 год',
        weightDelta: -190,
        priceDelta: -9000000,
        age: 12,
        district: 'Shahrisabz tumani',
        descUz: 'Hovlida bedada parvarish qilingan semiz novvos. Sogʻlom va faol.',
        descRu: 'Домашний упитанный бычок, чистый ветпаспорт.',
        isQurbon: false
      },
      {
        titleUz: 'Jaydari toʻqol sigir bolasi bilan',
        titleRu: 'Корова джайдари с теленком',
        weightDelta: -40,
        priceDelta: -2000000,
        age: 36,
        district: 'Chiroqchi tumani',
        descUz: 'Tishi butun, sogʻlom, bolasi yonida yuvosh ona sigir.',
        descRu: 'Спокойная корова с подсосным теленком.',
        isQurbon: false
      },
      {
        titleUz: 'Jaydari qoramol Qurbonlikka tayyor (2 yosh)',
        titleRu: 'Джайдари бык к Курбан-байраму',
        weightDelta: 10,
        priceDelta: 1000000,
        age: 24,
        district: 'Qamashi tumani',
        descUz: '2 yoshga toʻlgan, tish yorgan, nuqsonsiz, Qurbonlik shartlariga toʻliq mos.',
        descRu: 'Бык 2 года, соответствует всем нормам Курбана.',
        isQurbon: true
      }
    ]
  },

  // ==========================================
  // 2. QOʻY VA QOʻCHQORLAR KABINETI (4 TA ZOT)
  // ==========================================
  {
    breedKey: 'hisor',
    breedName: 'Hisor qoʻylari',
    dept: 'quy',
    cat: 'sheep',
    gender: 'qoʻchqor',
    baseWeight: 145,
    basePrice: 7200000,
    variants: [
      {
        titleUz: 'Hisor bahaybat naslli qoʻchqor (150 kg, Qurbonlikka tayyor)',
        titleRu: 'Гиссарский баран-великан 150 кг',
        weightDelta: 5,
        priceDelta: 800000,
        age: 24,
        district: 'Kitob tumani',
        descUz: 'Tikka dumba, baland boʻy, yirik suyakli afsonaviy Hisor zoti. Qurbonlikka 100% tayyor.',
        descRu: 'Гиссарский гигант 150 кг с плотным стоячим курдюком, идеален для Курбана.',
        isQurbon: true
      },
      {
        titleUz: 'Hisor oq boshli naslli toʻy qoʻchqori',
        titleRu: 'Белоголовый гиссарский баран',
        weightDelta: -10,
        priceDelta: -400000,
        age: 20,
        district: 'Yakkabogʻ tumani',
        descUz: 'Katta dumbali, semiz, marosim va toʻylar uchun 1-raqamli goʻshtdor qoʻchqor.',
        descRu: 'Крупный белоголовый баран гиссарской породы, отличная упитанность.',
        isQurbon: true
      },
      {
        titleUz: 'Hisor zotli boʻgʻoz sovliqlar (5 bosh)',
        titleRu: 'Гиссарские матки суягные (5 голов)',
        weightDelta: 150,
        priceDelta: 14000000,
        age: 26,
        district: 'Shahrisabz tumani',
        descUz: 'Har biri 75-80 kg li toza qonli Hisor sovliqlari. Naslchilik uchun saralangan.',
        descRu: 'Группа чистопородных гиссарских овцематок на племя.',
        isQurbon: false
      },
      {
        titleUz: 'Hisor yosh erkak toʻqli (7 oylik, 65 kg)',
        titleRu: 'Гиссарский ягненок 7 мес 65 кг',
        weightDelta: -80,
        priceDelta: -3400000,
        age: 7,
        district: 'Chiroqchi tumani',
        descUz: 'Tez semiruvchi yosh toʻqli. Boqishga yoki urugʻlikka juda qulay.',
        descRu: 'Молодой ягненок гиссар с быстрым набором веса.',
        isQurbon: false
      },
      {
        titleUz: 'Hisor Elita qora qoʻchqor (165 kg gigant)',
        titleRu: 'Элитный черный гиссарский баран 165 кг',
        weightDelta: 20,
        priceDelta: 2800000,
        age: 30,
        district: 'Qamashi tumani',
        descUz: 'Rekord 165 kg tirik vaznli Hisor qoʻchqori. Katta dumba, uzun boʻy, baquvvat suyak.',
        descRu: 'Рекордный гиссар 165 кг, элитный производитель.',
        isQurbon: true
      }
    ]
  },
  {
    breedKey: 'edilboy',
    breedName: 'Edilboy (Edilbay) qoʻylari',
    dept: 'quy',
    cat: 'sheep',
    gender: 'qoʻchqor',
    baseWeight: 120,
    basePrice: 5800000,
    variants: [
      {
        titleUz: 'Edilboy zotli yirik dumbador qoʻchqor (125 kg)',
        titleRu: 'Эдильбаевский курдючный баран 125 кг',
        weightDelta: 5,
        priceDelta: 100000,
        age: 18,
        district: 'Gʻijduvon tumani',
        descUz: 'Qattiq choʻl iqlimiga chidamli, semiz goʻsht va baquvvat dumba zoti.',
        descRu: 'Крупный эдильбаевский баран 125 кг, устойчив к засухе.',
        isQurbon: true
      },
      {
        titleUz: 'Edilboy qizil tusli semiz qoʻchqor',
        titleRu: 'Эдильбай рыжий упитанный баран',
        weightDelta: -10,
        priceDelta: -500000,
        age: 16,
        district: 'Shofirkon tumani',
        descUz: 'Toza yaylovda oʻtlagan, goʻshti mayin va xushboʻy, tarozi dalolatnomasi bor.',
        descRu: 'Рыжий эдильбай на пастбищном выпасе, нежное мясо.',
        isQurbon: true
      },
      {
        titleUz: 'Edilboy toʻqlilari (3 bosh yosh erkak)',
        titleRu: 'Эдильбаевские ярки (3 головы)',
        weightDelta: 60,
        priceDelta: 4500000,
        age: 10,
        district: 'Kogon tumani',
        descUz: 'Oʻsishi tez, kasalliklarga chidamli semiz yosh qoʻchqorlar partiyasi.',
        descRu: 'Молодняк эдильбаев, крепкое здоровье, быстрый рост.',
        isQurbon: false
      },
      {
        titleUz: 'Edilboy katta dumbali boʻgʻoz sovliq',
        titleRu: 'Овцематка эдильбаевская суягная',
        weightDelta: -35,
        priceDelta: -1800000,
        age: 24,
        district: 'Vobkent tumani',
        descUz: 'Naslli qoʻzilash arafasidagi yirik dumbador sovliq. Emlangan.',
        descRu: 'Суягная матка эдильбай, отличное телосложение.',
        isQurbon: false
      },
      {
        titleUz: 'Edilboy qoʻchqor Qurbonlik 2026 uchun bron',
        titleRu: 'Баран эдильбай на Курбан 2026',
        weightDelta: 10,
        priceDelta: 600000,
        age: 20,
        district: 'Peshku tumani',
        descUz: 'Tish yorgan, koʻzi ravshan, oqsoqliksiz nuqsonsiz, Qurbonlikka munosib.',
        descRu: 'Баран к празднику Курбан, идеальный ветчек.',
        isQurbon: true
      }
    ]
  },
  {
    breedKey: 'merinos',
    breedName: 'Merinos (Shori / jaydari)',
    dept: 'quy',
    cat: 'sheep',
    gender: 'sovliq',
    baseWeight: 80,
    basePrice: 2800000,
    variants: [
      {
        titleUz: 'Merinos mayin junli oq sovliqlar (3 bosh)',
        titleRu: 'Меринос тонкорунные овцы (3 головы)',
        weightDelta: 160,
        priceDelta: 4700000,
        age: 24,
        district: 'Gʻallaorol tumani',
        descUz: 'Mayin qimmatbaho jun va parhez goʻsht yoʻnalishidagi sogʻlom sovliqlar.',
        descRu: 'Тонкорунные мериносы с качественной белой шерстью.',
        isQurbon: false
      },
      {
        titleUz: 'Merinos naslli qalin junli qoʻchqor',
        titleRu: 'Баран-производитель меринос',
        weightDelta: 25,
        priceDelta: 1200000,
        age: 22,
        district: 'Zomin tumani',
        descUz: 'Yillik qirqimda 10 kg mayin jun beradigan nasldor qoʻchqor.',
        descRu: 'Племенной меринос, высокий настриг тонкой шерсти.',
        isQurbon: true
      },
      {
        titleUz: 'Merinos yosh toʻqlilari (togʻ yaylovi)',
        titleRu: 'Ярочки меринос пастбищные',
        weightDelta: -25,
        priceDelta: -900000,
        age: 9,
        district: 'Baxmal tumani',
        descUz: 'Togʻ yonbagʻrida oʻtlagan, tabiiy immuniteti yuqori yosh toʻqlilar.',
        descRu: 'Горные ярочки меринос, высокий иммунитет.',
        isQurbon: false
      },
      {
        titleUz: 'Merinos sovliq egizak qoʻzilar bilan',
        titleRu: 'Меринос с двумя ягнятами',
        weightDelta: 15,
        priceDelta: 1400000,
        age: 30,
        district: 'Forish tumani',
        descUz: 'Sutdor ona qoʻy va sogʻlom egizak qoʻzilari. Xonadonga juda qulay.',
        descRu: 'Матка меринос с двумя здоровыми ягнятами.',
        isQurbon: false
      },
      {
        titleUz: 'Merinos semiz goʻshtdor qoʻchqor',
        titleRu: 'Меринос упитанный баран на мясо',
        weightDelta: 20,
        priceDelta: 1000000,
        age: 18,
        district: 'Sharof Rashidov tumani',
        descUz: 'Parhez goʻshti sersuv, toʻy va tadbirlar uchun tayyorlangan semiz qoʻchqor.',
        descRu: 'Откормленный баран меринос с диетическим нежным мясом.',
        isQurbon: true
      }
    ]
  },
  {
    breedKey: 'jaydari_quy',
    breedName: 'Jaydari (mahalliy) qoʻylar',
    dept: 'quy',
    cat: 'sheep',
    gender: 'qoʻchqor',
    baseWeight: 85,
    basePrice: 3800000,
    variants: [
      {
        titleUz: 'Jaydari semiz qoʻchqor (Hovlida bedada boqilgan)',
        titleRu: 'Местный баран джайдари откормленный',
        weightDelta: 5,
        priceDelta: 200000,
        age: 14,
        district: 'Yangiyoʻl tumani',
        descUz: 'Oila xonadonida tabiiy yemda boqilgan semiz qoʻchqor. Mazali goʻshtli.',
        descRu: 'Домашний откормленный баран джайдари, вкусное мясо.',
        isQurbon: true
      },
      {
        titleUz: 'Jaydari sovliq va 2 oylik qoʻzichasi',
        titleRu: 'Овца джайдари с ягненком',
        weightDelta: -15,
        priceDelta: -600000,
        age: 24,
        district: 'Chinoz tumani',
        descUz: 'Oson boqiladigan, tinch va sutdor mahalliy ona qoʻy.',
        descRu: 'Неприхотливая овцематка с ягненком.',
        isQurbon: false
      },
      {
        titleUz: 'Jaydari semiz qoʻchqorlar guruhi (5 bosh)',
        titleRu: 'Партия баранов джайдари (5 голов)',
        weightDelta: 320,
        priceDelta: 14000000,
        age: 16,
        district: 'Boʻka tumani',
        descUz: 'Toʻy va restoranlar uchun maxsus saralangan semiz qoʻchqorlar partiyasi.',
        descRu: 'Партия упитанных баранов для свадеб и ресторанов.',
        isQurbon: true
      },
      {
        titleUz: 'Jaydari 1 yoshli shoʻrva toʻqlisi',
        titleRu: 'Молодой барашек 1 год',
        weightDelta: -25,
        priceDelta: -1100000,
        age: 11,
        district: 'Parkent tumani',
        descUz: 'Togʻ yaylovida oʻtlagan, shoʻrva va qovurdoqqa oʻta mayin goʻsht.',
        descRu: 'Молодой барашек на натуральных горных травах.',
        isQurbon: false
      },
      {
        titleUz: 'Jaydari dumbali qurbonlik qoʻchqori',
        titleRu: 'Курбанный баран джайдари',
        weightDelta: 0,
        priceDelta: 0,
        age: 15,
        district: 'Piskent tumani',
        descUz: 'Shariat talablariga toʻliq mos: tish yorgan, koʻzi ravshan, nuqsonsiz.',
        descRu: 'Баран к празднику Курбан без изъянов, отличное здоровье.',
        isQurbon: true
      }
    ]
  },

  // ==========================================
  // 3. OTCHILIK KABINETI (4 TA ZOT)
  // ==========================================
  {
    breedKey: 'qorabayir',
    breedName: 'Qorabayir oti',
    dept: 'ot',
    cat: 'horses',
    gender: 'aygʻir',
    baseWeight: 490,
    basePrice: 42000000,
    variants: [
      {
        titleUz: 'Qorabayir 4 yoshli uloqchi chopqir aygʻir',
        titleRu: 'Карабаир 4 года жеребец (для улок/купкари)',
        weightDelta: 10,
        priceDelta: 3000000,
        age: 48,
        district: 'Urgut tumani',
        descUz: 'Toshloq togʻ yoʻllariga chidamli, uloq-koʻpkariga oʻrgatilgan sadoqatli aygʻir.',
        descRu: 'Выносливый карабаирский жеребец для кок-бору и верховой езды.',
        isQurbon: false
      },
      {
        titleUz: 'Qorabayir 2 yoshli saralangan toygʻir',
        titleRu: 'Карабаир 2 года молодой жеребчик',
        weightDelta: -60,
        priceDelta: -10000000,
        age: 24,
        district: 'Ishtixon tumani',
        descUz: 'Boʻyi 155 sm, ota-onasi mashhur uloqchi polvon otlar avlodidan.',
        descRu: 'Перспективный молодой жеребчик от именитых скаковых линий.',
        isQurbon: false
      },
      {
        titleUz: 'Qorabayir zotli boʻgʻoz ona biya',
        titleRu: 'Кобыла карабаир стельная',
        weightDelta: 20,
        priceDelta: -5000000,
        age: 60,
        district: 'Payariq tumani',
        descUz: 'Feʼli juda yuvosh, sayr va minish uchun ham qulay naslli biya.',
        descRu: 'Спокойная стельная кобыла для разведения и прогулок.',
        isQurbon: false
      },
      {
        titleUz: 'Qorabayir toʻriq toycha (1 yosh)',
        titleRu: 'Жеребенок карабаир 1 год',
        weightDelta: -180,
        priceDelta: -22000000,
        age: 12,
        district: 'Narpay tumani',
        descUz: 'Suyagi pishiq, kelajagi porloq toygʻir. Emlangan, pasporti bor.',
        descRu: 'Крепкий годовалый жеребенок, отличная родословная.',
        isQurbon: false
      },
      {
        titleUz: 'Qorabayir jorga yurishli sayr oti',
        titleRu: 'Карабаир иноходец для прогулок',
        weightDelta: -20,
        priceDelta: -4000000,
        age: 50,
        district: 'Samarqand tumani',
        descUz: 'Egar-jabdugʻi bilan, mutlaqo tinch va tekis jorga yuradigan minish oti.',
        descRu: 'Мягкий на ходу иноходец, идеален для любительской верховой езды.',
        isQurbon: false
      }
    ]
  },
  {
    breedKey: 'axaltaka',
    breedName: 'Axaltaka (Ахалтекинская)',
    dept: 'ot',
    cat: 'sports',
    gender: 'aygʻir',
    baseWeight: 460,
    basePrice: 95000000,
    variants: [
      {
        titleUz: 'Axaltaka oltin rangli (Isabelline) elita aygʻir',
        titleRu: 'Ахалтекинец золотисто-изабелловый жеребец',
        weightDelta: 0,
        priceDelta: 25000000,
        age: 48,
        district: 'Qibray tumani',
        descUz: 'Dunyodagi eng goʻzal zot. Oftobda tilla kabi tovlanadi, xalqaro pasporti bor.',
        descRu: 'Легендарный ахалтекинец редкой масти с золотистым блеском, паспорт.',
        isQurbon: false
      },
      {
        titleUz: 'Axaltaka qora qashqa poyga aygʻiri (65 km/soat)',
        titleRu: 'Ахалтекинец вороной скаковой жеребец',
        weightDelta: 10,
        priceDelta: 15000000,
        age: 40,
        district: 'Boʻstonliq tumani',
        descUz: 'Yengil yugurish va sakrash chempioni. Yuqori tezlik va nozik gavda.',
        descRu: 'Резвый скаковой жеребец, скорость до 65 км/ч.',
        isQurbon: false
      },
      {
        titleUz: 'Axaltaka 2 yoshli saralangan baytal',
        titleRu: 'Кобыла ахалтекинская 2 года',
        weightDelta: -40,
        priceDelta: -15000000,
        age: 24,
        district: 'Zangiota tumani',
        descUz: 'Kelishgan boʻyin, nozik oyoqlar, elita koʻrgazmalar gʻolibi qizi.',
        descRu: 'Грациозная молодая кобыла для спорта и выставок.',
        isQurbon: false
      },
      {
        titleUz: 'Axaltaka saman rangli yosh toygʻir',
        titleRu: 'Ахалтекинский жеребчик соловой масти',
        weightDelta: -120,
        priceDelta: -35000000,
        age: 18,
        district: 'Chirchiq shahri',
        descUz: 'Egasiga oʻta sadoqatli, qadamlari ravon va silliq minish toygʻiri.',
        descRu: 'Преданный и чуткий жеребчик соловой масти.',
        isQurbon: false
      },
      {
        titleUz: 'Axaltaka toʻriq minish oti (klub darajasi)',
        titleRu: 'Верховой ахалтекинец гнедой',
        weightDelta: -10,
        priceDelta: 5000000,
        age: 52,
        district: 'Parkent tumani',
        descUz: 'Klub va xususiy minish uchun qulay, egar-jabduqqa toʻliq oʻrgatilgan.',
        descRu: 'Выезженный верховой конь для манежа и прогулок.',
        isQurbon: false
      }
    ]
  },
  {
    breedKey: 'rus_ogir',
    breedName: 'Rus ogʻir yuk tashuvchi oti (Русский тяжеловозы)',
    dept: 'ot',
    cat: 'horses',
    gender: 'aygʻir',
    baseWeight: 780,
    basePrice: 52000000,
    variants: [
      {
        titleUz: 'Rus ogʻir yuk oti: Gigant baquvvat aygʻir (820 kg)',
        titleRu: 'Русский тяжеловоз богатырский жеребец 820 кг',
        weightDelta: 40,
        priceDelta: 4000000,
        age: 54,
        district: 'Gʻallaorol tumani',
        descUz: '2-3 tonna yuk tortish quvvati. Gavdasi bahaybat, feʼli yuvosh va odamsevar.',
        descRu: 'Мощный тяжеловоз 820 кг с колоссальной тягловой силой.',
        isQurbon: false
      },
      {
        titleUz: 'Rus ogʻir yuk zotli ona biya',
        titleRu: 'Кобыла русский тяжеловоз',
        weightDelta: -30,
        priceDelta: -7000000,
        age: 60,
        district: 'Zomin tumani',
        descUz: 'Ferma xoʻjaliklarida ogʻir yumushlar uchun eng ishonchli yordamchi.',
        descRu: 'Рабочая тяжеловозная кобыла, спокойный характер.',
        isQurbon: false
      },
      {
        titleUz: 'Rus ogʻir yuk 2 yoshli baquvvat toygʻir',
        titleRu: 'Жеребчик тяжеловоз 2 года',
        weightDelta: -160,
        priceDelta: -18000000,
        age: 24,
        district: 'Baxmal tumani',
        descUz: 'Keng koʻkrak, qalin suyak, jadal rivojlanayotgan yosh toygʻir.',
        descRu: 'Молодой тяжеловозный жеребчик с мощным костяком.',
        isQurbon: false
      },
      {
        titleUz: 'Rus ogʻir yuk aravaga qoʻshilgan juft otlar',
        titleRu: 'Пара тяжеловозов в упряжке',
        weightDelta: 750,
        priceDelta: 45000000,
        age: 48,
        district: 'Forish tumani',
        descUz: 'Arava va ekin uskunasiga oʻrgatilgan 2 bosh baquvvat juft ishchi ot.',
        descRu: 'Слаженная пара рабочих лошадей в упряжке.',
        isQurbon: false
      },
      {
        titleUz: 'Rus ogʻir yuk zotli yosh aygʻir (720 kg)',
        titleRu: 'Тяжеловоз 3 года 720 кг',
        weightDelta: -60,
        priceDelta: -10000000,
        age: 36,
        district: 'Doʻstlik tumani',
        descUz: 'Mehnatsevar, har qanday ob-havoga chidamli pishiq ishchi aygʻir.',
        descRu: 'Крепкий молодой тяжеловоз для фермерских нужд.',
        isQurbon: false
      }
    ]
  },
  {
    breedKey: 'lofard_sport',
    breedName: 'Lofard / Sport otlari',
    dept: 'ot',
    cat: 'sports',
    gender: 'biya',
    baseWeight: 540,
    basePrice: 85000000,
    variants: [
      {
        titleUz: 'Lofard sport oti: Konkur toʻsiq sakrovchi baytal (130 sm)',
        titleRu: 'Конкурная спортивная кобыла (130 см)',
        weightDelta: 0,
        priceDelta: 0,
        age: 36,
        district: 'Yunusobod tumani',
        descUz: '130 sm toʻsiqlardan bemalol sakraydi. Yumshoq egarlangan, sport litsenziyasi bor.',
        descRu: 'Спортивная кобыла для конкура, высота препятствий 130 см.',
        isQurbon: false
      },
      {
        titleUz: 'Lofard yarim qonli sport aygʻiri (Dresaj va konkur)',
        titleRu: 'Полукровный спортивный жеребец',
        weightDelta: 20,
        priceDelta: 10000000,
        age: 42,
        district: 'Mirzo Ulugʻbek tumani',
        descUz: 'Elastik silliq harakat, baland sakrash refleksiga ega professional sport oti.',
        descRu: 'Профессиональный конкурный жеребец, отличные аллюры.',
        isQurbon: false
      },
      {
        titleUz: 'Sport toifasidagi 2 yoshli istiqbolli baytal',
        titleRu: 'Молодая спортивная лошадь 2 года',
        weightDelta: -50,
        priceDelta: -20000000,
        age: 24,
        district: 'Qibray tumani',
        descUz: 'Boshlangʻich tayyorgarlikdan aʼlo oʻtgan boʻyi baland sport baytali.',
        descRu: 'Перспективная молодая спортивная лошадь для манежа.',
        isQurbon: false
      },
      {
        titleUz: 'Lofard muloyim sayr va minish oti',
        titleRu: 'Прогулочная верховая лошадь',
        weightDelta: -20,
        priceDelta: -15000000,
        age: 60,
        district: 'Boʻstonliq tumani',
        descUz: 'Feʼli oʻta muloyim, yangi chavandozlar va sayr klublari uchun qulay.',
        descRu: 'Спокойная и послушная лошадь для верховых прогулок.',
        isQurbon: false
      },
      {
        titleUz: 'Lofard sport toygʻiri (Nemis qonli liniya)',
        titleRu: 'Спортивный жеребенок немецких линий',
        weightDelta: -180,
        priceDelta: -40000000,
        age: 14,
        district: 'Toshkent shahri',
        descUz: 'Germaniya sport otlari avlodidan, mikropasport va vet tekshiruvi bor.',
        descRu: 'Жеребенок немецких спортивных кровей, микрочип.',
        isQurbon: false
      }
    ]
  }
];

export const allBreedLivestockItems: LivestockItem[] = [];

let counter = 200;
breedSeeds.forEach((b) => {
  // STRICT DEPARTMENT IMAGE ASSIGNMENT:
  // Qoramol gets ONLY qoramolImages
  // Quy gets ONLY quyImages
  // Ot gets ONLY otImages
  const pool =
    b.dept === 'qoramol'
      ? qoramolImages
      : b.dept === 'quy'
      ? quyImages
      : otImages;

  b.variants.forEach((v, idx) => {
    counter++;
    const weight = b.baseWeight + v.weightDelta;
    const price = b.basePrice + v.priceDelta;
    const img = pool[idx % pool.length];
    const nextImg = pool[(idx + 1) % pool.length];
    const reg = regions[(counter + idx) % regions.length];
    const seller =
      b.dept === 'ot'
        ? (idx % 2 === 0 ? mockSellers.seller_horse1 : mockSellers.seller_horse2)
        : idx % 2 === 0
        ? mockSellers.seller1
        : mockSellers.seller3;

    const timeAgoStr = realTimeOffsets[(counter + idx) % realTimeOffsets.length];

    allBreedLivestockItems.push({
      id: `breed-${b.breedKey}-${idx + 1}`,
      titleUz: v.titleUz,
      titleRu: v.titleRu,
      department: b.dept,
      category: b.cat,
      breed: b.breedName,
      breedKey: b.breedKey,
      gender: b.gender as any,
      ageMonths: v.age,
      weightKg: weight,
      priceUzs: price,
      pricePerKg: Math.round(price / weight),
      region: reg,
      district: v.district,
      descriptionUz: v.descUz,
      descriptionRu: v.descRu,
      imageUrl: img,
      additionalImages: [nextImg],
      hasVideo: idx % 2 === 0,
      videoDurationSec: 20 + idx * 4,
      isVerifiedSeller: true,
      vetInfo: {
        id: `vet-${counter}`,
        hasVetPassport: true,
        passportNumber: `UZ-VET-${counter}5-2026`,
        issuedDate: '2026-03-25',
        veterinarianName: 'Davlat Veterinariya Xizmati',
        districtVetClinic: `${v.district} Vet filiali`,
        vaccinatedFor: [
          { nameUz: 'Kuydirgi', nameRu: 'Сибирская язва', date: '2026-03-20', isImmune: true },
          { nameUz: 'Oqsil', nameRu: 'Ящур', date: '2026-03-18', isImmune: true }
        ],
        healthNotes: '100% sogʻlom, tarozi dalolatnomasi bor.',
        status: 'verified'
      },
      isEscrowSupported: true,
      isDeliveryAvailable: true,
      isQurbonlikFit: v.isQurbon,
      qurbonlikConditionsMet: v.isQurbon,
      viewsCount: 180 + idx * 75,
      likesCount: 14 + idx * 6,
      createdAt: '2026-04-05',
      timeAgo: timeAgoStr,
      seller: seller,
      isFeatured: idx === 0
    });
  });
});
