import { BreedInfo } from '../types';

export const breedCatalog: BreedInfo[] = [
  // ========================================================
  // 1. QORAMOL KABINETI (5 TA ASOSIY ZOT)
  // ========================================================
  {
    id: 'qora_ola',
    nameUz: 'Qora-ola (Holstein / Черно-пестрая)',
    nameRu: 'Черно-пестрая (Holstein / Голштинизированная)',
    department: 'qoramol',
    descriptionUz: 'Dunyoda va Oʻzbekistonda eng koʻp tarqalgan sut yoʻnalishidagi zot. Sut berish koʻrsatkichi juda yuqori.',
    descriptionRu: 'Самая распространенная молочная порода в мире и Узбекистане. Рекордные показатели удоя (25-35+ литров в сутки).',
    featuresUz: ['Kunlik 25-35+ litr sut', 'Katta yelin, chashasimon', 'Apparatda sogʻishga qulay'],
    featuresRu: ['Суточный удой 25-35+ л', 'Идеальное вымя', 'Пригодна к доильным аппаратам'],
    recommendedForUz: 'Zamonaviy sut fermalari va yuqori mahsuldorlik',
    recommendedForRu: 'Промышленные молочные комплексы',
    weightRange: '550 - 750 kg',
    icon: '🐄'
  },
  {
    id: 'qizil_chol',
    nameUz: 'Qizil choʻl (Красная степная)',
    nameRu: 'Красная степная порода',
    department: 'qoramol',
    descriptionUz: 'Issiq va quruq iqlimga juda yaxshi moslashgan, ham sut, ham goʻsht beradigan zot.',
    descriptionRu: 'Отлично переносит сухой жаркий климат юга и запада Узбекистана. Комбинированное молочно-мясное направление.',
    featuresUz: ['Issiqqa va qurgʻoqchilikka oʻta chidamli', 'Yogʻli toʻyimli sut (4.2-4.5%)', 'Kam kasal boʻladi'],
    featuresRu: ['Жароустойчивость', 'Высокая жирность молока', 'Высокий иммунитет'],
    recommendedForUz: 'Qashqadaryo, Buxoro, Navoiy va janubiy choʻl hududlar',
    recommendedForRu: 'Степные и пустынные регионы',
    weightRange: '480 - 650 kg',
    icon: '🐄'
  },
  {
    id: 'simmental',
    nameUz: 'Simmental',
    nameRu: 'Симментальская порода',
    department: 'qoramol',
    descriptionUz: 'Universal zot — ham goʻsht, ham sut uchun birdek yaxshi natija beradi, gavdasi yirik.',
    descriptionRu: 'Универсальная мясо-молочная порода. Отличается мощным костяком, высоким качеством мяса и стабильным удоем.',
    featuresUz: ['Ham sut (20-25 L), ham baquvvat goʻsht', 'Buzoqlar tez vazn oladi', 'Mustahkam suyak va tana'],
    featuresRu: ['Мясо и молоко (20-25 л)', 'Быстрый рост телят', 'Крепкое здоровье'],
    recommendedForUz: 'Universal dehqon va aralash fermer xoʻjaliklari',
    recommendedForRu: 'Фермы универсального профиля',
    weightRange: '600 - 900 kg',
    icon: '🐄'
  },
  {
    id: 'angus_hereford',
    nameUz: 'Angus / Hereford',
    nameRu: 'Абердин-Ангус / Герефорд (Мраморное мясо)',
    department: 'qoramol',
    descriptionUz: 'Sof goʻsht yoʻnalishidagi (mramoriy goʻsht) zamonaviy fermerlar orasida ommalashib borayotgan zotlar.',
    descriptionRu: 'Премиальные мясные породы с высоким выходом сочного мраморного мяса. Высокий спрос у ресторанов и стейкхаусов.',
    featuresUz: ['Sof goʻsht chiqishi 62-65%', 'Yumshoq mramor goʻsht', 'Shoxsiz (komol) tabiat'],
    featuresRu: ['Убойный выход 62-65%', 'Мраморная текстура', 'Комолость (без рогов)'],
    recommendedForUz: 'Boʻrdoqichilik va qimmatbaho mramor goʻsht yetishtirish',
    recommendedForRu: 'Откормочные базы премиум-мяса',
    weightRange: '700 - 1100 kg',
    icon: '🐂'
  },
  {
    id: 'jaydari_mol',
    nameUz: 'Jaydari qoramollar',
    nameRu: 'Местный аборигенный КРС',
    department: 'qoramol',
    descriptionUz: 'Mahalliy sharoitga juda chidamli, oddiy qishloq xoʻjaligida koʻp uchraydigan qoramollar.',
    descriptionRu: 'Местный неприхотливый скот. Отличается превосходной выживаемостью на грубых кормах и доступной ценой.',
    featuresUz: ['Ozuqa tanlamaydi, oson boqiladi', 'Hamyonbop bozor narxi', 'Mahalliy iqlimga 100% mos'],
    featuresRu: ['Неприхотливость', 'Доступная стоимость', 'Долговечность'],
    recommendedForUz: 'Oddiy xonadonlar va dehqon xoʻjaliklari',
    recommendedForRu: 'Частные подворья',
    weightRange: '350 - 520 kg',
    icon: '🐂'
  },

  // ========================================================
  // 2. QOʻY VA QOʻCHQORLAR KABINETI (4 TA ASOSIY ZOT)
  // ========================================================
  {
    id: 'hisor',
    nameUz: 'Hisor qoʻylari',
    nameRu: 'Гиссарская порода овец',
    department: 'quy',
    descriptionUz: 'Oʻzbekistonda va mintaqada eng yirik, goʻsht-dumbali zot. Ogʻirligi kattalarida 150–180 kg gacha boradi. Qurbonlik va toʻylar uchun eng talabgiri.',
    descriptionRu: 'Крупнейшая мясо-сальная курдючная порода овец в регионе. Вес взрослых баранов достигает 150-180 кг. Высочайший спрос на Курбан-хайит и свадьбы.',
    featuresUz: ['Gavdasi bahaybat (150-180 kg)', 'Katta tikka dumba', 'Qurbonlikka 1-raqamli talab'],
    featuresRu: ['Гигантское телосложение', 'Крупный плотный курдюк', 'Быстрый привес'],
    recommendedForUz: 'Qurbonlik, toʻy va goʻsht yetishtirish',
    recommendedForRu: 'Курбан, свадьбы и откорм на мясо',
    weightRange: '130 - 180 kg',
    icon: '🐑'
  },
  {
    id: 'edilboy',
    nameUz: 'Edilboy (Edilbay) qoʻylari',
    nameRu: 'Эдильбаевская порода',
    department: 'quy',
    descriptionUz: 'Qattiq iqlimga chidamli, goʻsht va yogʻ yoʻnalishidagi yirik zot.',
    descriptionRu: 'Крупная мясо-сальная порода, устойчивая к суровому климату, сухим пастбищам и резким перепадам температур.',
    featuresUz: ['Qurgʻoqchilik va sovuqqa chidamli', 'Semiz goʻsht va baquvvat yogʻ', 'Mustahkam suyak'],
    featuresRu: ['Выносливость', 'Жирное нежное мясо', 'Крепкий костяк'],
    recommendedForUz: 'Choʻl va dasht yaylovlarida boqish',
    recommendedForRu: 'Пастбищный выпас в степной зоне',
    weightRange: '110 - 150 kg',
    icon: '🐑'
  },
  {
    id: 'merinos',
    nameUz: 'Merinos (Shori / jaydari)',
    nameRu: 'Меринос (тонкорунные овцы / шори)',
    department: 'quy',
    descriptionUz: 'Asosan jun va goʻsht yoʻnalishidagi zotlar.',
    descriptionRu: 'Порода мясо-шерстного направления с высококачественной тонкой шерстью для текстильной промышленности.',
    featuresUz: ['Mayin qimmatbaho jun', 'Yumshoq parhez goʻsht', 'Sokin va yuvosh feʼl'],
    featuresRu: ['Тонкорунная шерсть', 'Диетическое мясо', 'Спокойный нрав'],
    recommendedForUz: 'Jun va goʻsht yetishtiruvchi fermerlar',
    recommendedForRu: 'Шерстное и мясное овцеводство',
    weightRange: '80 - 115 kg',
    icon: '🐑'
  },
  {
    id: 'jaydari_quy',
    nameUz: 'Jaydari (mahalliy) qoʻylar',
    nameRu: 'Местные джайдари овцы',
    department: 'quy',
    descriptionUz: 'Har qanday iqlim sharoitiga oʻrgangan, xonadonlarda eng koʻp boqiladigan oddiy zot.',
    descriptionRu: 'Местная аборигенная порода, идеально адаптированная к условиям кишлаков и приусадебных хозяйств.',
    featuresUz: ['Har qanday sharoitga mos', 'Xonadonda boqishga qulay', 'Yuqori tabiiy immunitet'],
    featuresRu: ['Крепкий иммунитет', 'Неприхотливость в кормах', 'Хорошая плодовитость'],
    recommendedForUz: 'Oila va xonadon xoʻjaliklari, kundalik ehtiyoj',
    recommendedForRu: 'Домашнее содержание и разведение',
    weightRange: '70 - 100 kg',
    icon: '🐑'
  },

  // ========================================================
  // 3. OTCHILIK KABINETI (4 TA ASOSIY ZOT)
  // ========================================================
  {
    id: 'qorabayir',
    nameUz: 'Qorabayir oti',
    nameRu: 'Карабаирская порода (Национальная гордость)',
    department: 'ot',
    descriptionUz: 'Oʻzbekistonning milliy, qadimiy zoti. Togʻli va qattiq yoʻllarga oʻta chidamli, chopqir hamda minish uchun qulay.',
    descriptionRu: 'Национальная узбекская древняя порода. Невероятно вынослива в горах и на жестких грунтах, идеальна для верховой езды и куп-кари (улок).',
    featuresUz: ['Togʻli va toshloq yoʻllarga oʻta chidamli', 'Chopqir, koʻpkari/uloq uchun qulay', 'Sadoqatli feʼl-atvor'],
    featuresRu: ['Идеальна для улок/купкари', 'Горная выносливость', 'Верный и послушный нрав'],
    recommendedForUz: 'Koʻpkari oʻyinlari, minish va togʻli hududlar',
    recommendedForRu: 'Национальные конные игры и прогулки',
    weightRange: '450 - 550 kg',
    icon: '🐎'
  },
  {
    id: 'axaltaka',
    nameUz: 'Axaltaka (Ахалтекинская)',
    nameRu: 'Ахалтекинская порода (Небесные аргамаки)',
    department: 'ot',
    descriptionUz: 'Turkmaniston zoti, dunyodagi eng chiroyli va kelishgan, "oliy" toifadagi poyga va sport otlaridan biri.',
    descriptionRu: 'Легендарные "райские кони". Одна из древнейших и красивейших пород мира с золотистым блеском шерсти для спорта и выставок.',
    featuresUz: ['Dunyodagi eng kelishgan va chiroyli zot', '"Oliy" toifadagi poyga va sport oti', 'Oltindek tovlanuvchi jun'],
    featuresRu: ['Золотистый отлив масти', 'Высокая резвость (65+ км/ч)', 'Грациозный экстерьер'],
    recommendedForUz: 'Poygalar, elita ot sporti va koʻrgazmalar',
    recommendedForRu: 'Конный спорт, скачки и элитные выставки',
    weightRange: '420 - 500 kg',
    icon: '🐎'
  },
  {
    id: 'rus_ogir',
    nameUz: 'Rus ogʻir yuk tashuvchi oti (Русский тяжеловозы)',
    nameRu: 'Русский тяжеловоз (Тяжелоупряжная порода)',
    department: 'ot',
    descriptionUz: 'Gavdasi juda baquvvat, xoʻjalik ishlarida va yuk tashishda ishlatiladigan katta zot.',
    descriptionRu: 'Массивная тяжеловозная порода с колоссальной тягловой силой, спокойным нравом для хозяйственных и фермерских работ.',
    featuresUz: ['Gavdasi juda baquvvat', '2-3 tonna yuk tortish quvvati', 'Xoʻjalik ishlari va aravaga qoʻshish'],
    featuresRu: ['Тягловая сила 2-3 т', 'Покладистый характер', 'Массивный мускулистый круп'],
    recommendedForUz: 'Xoʻjalik ishlari, yuk tashish va ferma yordami',
    recommendedForRu: 'Тяжелые полевые работы и упряжь',
    weightRange: '650 - 850 kg',
    icon: '🐎'
  },
  {
    id: 'lofard_sport',
    nameUz: 'Lofard / Sport otlari',
    nameRu: 'Спортивные полукровные / Лофард (Конкур)',
    department: 'ot',
    descriptionUz: 'Zamonaviy ot sporti va sayr qilish uchun olib kelingan zotlar.',
    descriptionRu: 'Современные полукровные спортивные лошади для конкура, выездки и статусных загородных конных клубов.',
    featuresUz: ['Zamonaviy ot sporti va toʻsiqlardan sakrash', 'Shahar sayr klublari uchun qulay', 'Silliq va elastik harakat'],
    featuresRu: ['Прыгучесть для конкура', 'Эластичные аллюры', 'Спортивный ветпаспорт'],
    recommendedForUz: 'Konkur, zamonaviy ot sporti va shahar klublari',
    recommendedForRu: 'Конкур, манежи и верховые клубы',
    weightRange: '500 - 620 kg',
    icon: '🐎'
  }
];
