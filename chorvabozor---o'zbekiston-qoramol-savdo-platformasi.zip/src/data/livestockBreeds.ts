export type BreedCategory = 'cattle' | 'sheep' | 'horse';

export interface LivestockBreedInfo {
  category: BreedCategory;
  name: string;
  origin: string;
  description: string;
}

export const livestockBreeds: LivestockBreedInfo[] = [
  {
    category: 'cattle',
    name: 'Golshteyn (Holstein)',
    origin: 'Niderlandiya / Shimoliy Germaniya (Frizlandiya)',
    description: "Dunyodagi eng ko'p sut beruvchi va qora-olacha tusli mashhur zot."
  },
  {
    category: 'cattle',
    name: 'Semental (Simmental)',
    origin: 'Shveysariya (Zimmental vodiysi)',
    description: "Ham sut, ham go'sht yo'nalishida boqiladigan, rangi asosan ola-qizil yoki sariq-oq keladigan zot."
  },
  {
    category: 'cattle',
    name: 'Angus (Aberdeen Angus)',
    origin: 'Shotlandiya (Aberdin va Angus grafliklari)',
    description: "Go'shti juda yuqori sifatli (marmar go'sht) hisoblanadigan, shoxsiz qora qoramol zoti."
  },
  {
    category: 'cattle',
    name: 'Qora-ola (Black-and-White)',
    origin: 'Gollandiya / Yevropa seleksiyasi',
    description: "Sut mahsuldorligi yuqori bo'lgan va dunyoda keng tarqalgan zotlardan biri."
  },
  {
    category: 'cattle',
    name: 'Gereford (Hereford)',
    origin: 'Angliya (Xerefordshir)',
    description: "Go'sht yo'nalishidagi, tanasi qizil va boshi oq tusda bo'ladigan chidamli zot."
  },
  {
    category: 'sheep',
    name: 'Gissar (Hisor)',
    origin: "Tojikiston / O'zbekiston (Hisor tog' tizmasi)",
    description: "Markaziy Osiyoda eng keng tarqalgan, yirik dumbali, go'shtdorlik yo'nalishidagi qo'y zoti."
  },
  {
    category: 'sheep',
    name: 'Merinos (Merino)',
    origin: 'Ispaniya / Avstraliya',
    description: "Dunyodagi eng sifatli va mayin jun beruvchi qo'y zoti."
  },
  {
    category: 'sheep',
    name: 'Edilboy (Edilbaev)',
    origin: "G'arbiy Qozog'iston dashtlari",
    description: "Go'sht va yog' (dumba) yo'nalishiga ega, qattiq iqlim sharoitlariga juda chidamli zot."
  },
  {
    category: 'sheep',
    name: 'Romanov',
    origin: 'Rossiya (Yaroslavl viloyati)',
    description: "Asosan mo'yna va go'sht uchun boqiladigan, bir tushganda bir nechta qo'zichoq tug'ishi bilan mashhur rus zoti."
  },
  {
    category: 'sheep',
    name: 'Suffolk',
    origin: 'Angliya (Suffolk grafligi)',
    description: "Go'sht yo'nalishidagi, boshi va oyoqlari qora, tanasi oq jun bilan qoplangan ingliz zoti."
  },
  {
    category: 'horse',
    name: 'Axaltaka (Akhal-Teke)',
    origin: 'Turkmaniston (Axal vohasi)',
    description: "Turkmanistonning milliy faxri bo'lgan, tanasi metall kabi yaltiraydigan, chidamli va kelishgan zot."
  },
  {
    category: 'horse',
    name: 'Arab oti',
    origin: 'Arabiston yarim oroli',
    description: "Dunyodagi eng qadimgi va sof qonli minqi zotlaridan biri, chiroyli qomati va tezkorligi bilan ajralib turadi."
  },
  {
    category: 'horse',
    name: 'Ingliz sof zotlisi (Thoroughbred)',
    origin: 'Buyuk Britaniya',
    description: "Ot poygalari (skachka) uchun maxsus chiqarilgan, dunyodagi eng tez yuguradigan ot zoti."
  },
  {
    category: 'horse',
    name: 'Orlov yo\'rg\'asi (Orlov Trotter)',
    origin: 'Rossiya (Xrenovskiy yilqichilik zavodi)',
    description: "Chiroyli va tez yo'rg'alab yurishi bilan mashhur bo'lgan rus ot zoti."
  },
  {
    category: 'horse',
    name: 'Friz (Friesian)',
    origin: 'Niderlandiya (Frizlandiya viloyati)',
    description: "Niderlandiyadan chiqqan, to'q qora tusli, oyoqlarida uzun shokilalari bor juda ko'rkam ot zoti."
  }
];
