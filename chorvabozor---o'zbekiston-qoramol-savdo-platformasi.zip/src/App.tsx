import React, { useState, useMemo, useEffect } from 'react';
import { mockLivestock } from './data/mockData';
import { Language, LivestockCategory, LivestockItem } from './types';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ProblemsSolvedBanner } from './components/ProblemsSolvedBanner';
import { FilterBar } from './components/FilterBar';
import { LivestockCard } from './components/LivestockCard';
import { LivestockDetailModal } from './components/LivestockDetailModal';
import { SafeEscrowModal } from './components/SafeEscrowModal';
import { PriceIndexModal } from './components/PriceIndexModal';
import { TransportCalculatorModal } from './components/TransportCalculatorModal';
import { LiveAuctionSection } from './components/LiveAuctionSection';
import { QurbonlikSpecialSection } from './components/QurbonlikSpecialSection';
import { TelegramSimulatorModal } from './components/TelegramSimulatorModal';
import { AddListingModal } from './components/AddListingModal';
import { BusinessModelModal } from './components/BusinessModelModal';
import { StrategyPlaybookModal } from './components/StrategyPlaybookModal';
import { QuickAddLivestockBar } from './components/QuickAddLivestockBar';
import { BreedEncyclopediaModal } from './components/BreedEncyclopediaModal';
import { SellerGuideModal } from './components/SellerGuideModal';
import { PlatformAllInfoModal } from './components/PlatformAllInfoModal';
import { ModernWelcomePromoModal } from './components/ModernWelcomePromoModal';
import { VeterinarianConsultModal } from './components/VeterinarianConsultModal';
import { BreedPriceTrendsModal } from './components/BreedPriceTrendsModal';
import { RotatingPromoBanner } from './components/RotatingPromoBanner';
import { MobileBottomNav } from './components/MobileBottomNav';
import { InstagramGrid } from './components/InstagramGrid';
import { LivestockReelsModal } from './components/LivestockReelsModal';
import { ComparisonFloatingBar } from './components/ComparisonFloatingBar';
import { LivestockComparisonModal } from './components/LivestockComparisonModal';
import { SkeletonGrid } from './components/SkeletonGrid';
import { Footer } from './components/Footer';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { translations } from './translations';
import { Sparkles, HelpCircle, Layers, ArrowUpRight, Target, Play, Scale, AlertCircle, Plus } from 'lucide-react';
import { AnimalDepartment } from './types';

export default function App() {
  // State
  const [isAdminView, setIsAdminView] = useState<boolean>(false);
  const [language, setLanguage] = useState<Language>('uz');
  const [liteMode, setLiteMode] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('theme');
      if (saved) return saved === 'dark';
      return typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });
  const [viewMode, setViewMode] = useState<'cards' | 'instagram' | 'reels'>('cards');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  // Initialized with mock livestock data for complete marketplace and admin operations
  const [items, setItems] = useState<LivestockItem[]>(() => (mockLivestock && mockLivestock.length > 0 ? mockLivestock : []));
  const [addListingDepartment, setAddListingDepartment] = useState<'qoramol' | 'quy' | 'ot'>('qoramol');

  const handleOpenAddListingWithDept = (dept: 'qoramol' | 'quy' | 'ot') => {
    setAddListingDepartment(dept);
    setIsAddListingOpen(true);
  };

  // Department & Breed Kabinets
  const [selectedDepartment, setSelectedDepartment] = useState<AnimalDepartment>('all');
  const [selectedBreedKey, setSelectedBreedKey] = useState<string>('all');
  const [isBreedEncyclopediaOpen, setIsBreedEncyclopediaOpen] = useState<boolean>(false);

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<LivestockCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [onlyVet, setOnlyVet] = useState(false);
  const [onlyVideo, setOnlyVideo] = useState(false);

  // Modals
  const [inspectItem, setInspectItem] = useState<LivestockItem | null>(null);
  const [escrowItem, setEscrowItem] = useState<LivestockItem | null>(null);
  const [transportListing, setTransportListing] = useState<LivestockItem | null>(null);
  const [isPriceIndexOpen, setIsPriceIndexOpen] = useState(false);
  const [isTransportOpen, setIsTransportOpen] = useState(false);
  const [isAuctionsOpen, setIsAuctionsOpen] = useState(false);
  const [isQurbonlikOpen, setIsQurbonlikOpen] = useState(false);
  const [isTelegramOpen, setIsTelegramOpen] = useState(false);
  const [isAddListingOpen, setIsAddListingOpen] = useState(false);
  const [isSellerGuideOpen, setIsSellerGuideOpen] = useState(false);
  const [isAllInfoOpen, setIsAllInfoOpen] = useState(false);
  const [isPromoOpen, setIsPromoOpen] = useState<boolean>(() => {
    try {
      return localStorage.getItem('chorvabozor_promo_dismissed_date') !== new Date().toDateString();
    } catch {
      return true;
    }
  });
  const [isBreedPriceTrendsOpen, setIsBreedPriceTrendsOpen] = useState(false);
  const [selectedTrendBreedId, setSelectedTrendBreedId] = useState<string | undefined>(undefined);
  const [isBusinessModelOpen, setIsBusinessModelOpen] = useState(false);
  const [isStrategyOpen, setIsStrategyOpen] = useState(false);
  const [isReelsOpen, setIsReelsOpen] = useState(false);
  const [reelsActiveIndex, setReelsActiveIndex] = useState(0);
  const [vetConsultItem, setVetConsultItem] = useState<LivestockItem | null>(null);

  const handleOpenBreedTrends = (breedKey?: string) => {
    setSelectedTrendBreedId(breedKey);
    setIsBreedPriceTrendsOpen(true);
  };

  // Comparison Feature (max 3 items)
  const [comparedItems, setComparedItems] = useState<LivestockItem[]>([]);
  const [isComparisonModalOpen, setIsComparisonModalOpen] = useState(false);
  const [compareWarningToast, setCompareWarningToast] = useState<string | null>(null);

  // Sync dark mode class on document and persist to localStorage
  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      }
    } catch {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [isDarkMode]);

  // Brief skeleton loader simulation on category or search switch
  const handleCategorySelect = (category: LivestockCategory) => {
    setSelectedCategory(category);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 220);
  };

  const handleRegionSelect = (reg: string) => {
    setSelectedRegion(reg);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 200);
  };

  const t = translations[language];

  // Filtering Logic
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Animal Department Kabinet filter (qoramol, quy, ot)
      if (selectedDepartment !== 'all' && item.department !== selectedDepartment) {
        return false;
      }

      // Specific Breed filter (13 specific breeds)
      if (selectedBreedKey !== 'all' && item.breedKey !== selectedBreedKey) {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'qurbonlik' && !item.isQurbonlikFit) return false;
        if (selectedCategory !== 'qurbonlik' && item.category !== selectedCategory) return false;
      }

      // Region filter
      if (selectedRegion !== 'all' && item.region !== selectedRegion) {
        return false;
      }

      // Checkbox filters
      if (onlyVerified && !item.isVerifiedSeller) return false;
      if (onlyVet && !item.vetInfo?.hasVetPassport) return false;
      if (onlyVideo && !item.hasVideo) return false;

      // Search query - smart multi-token matching (handles voice searches like "Golshtin 500kg")
      if (searchQuery.trim()) {
        const qRaw = searchQuery.toLowerCase().trim();
        const tokens = qRaw.split(/\s+/).filter(Boolean);

        const itemSearchableText = [
          item.titleUz,
          item.titleRu,
          item.breed,
          item.breedKey,
          item.region,
          item.district,
          item.descriptionUz,
          item.descriptionRu,
          `${item.weightKg}`,
          `${item.weightKg}kg`,
          `${item.weightKg} kg`,
          item.category,
          item.gender
        ].join(' ').toLowerCase();

        // Every voice search token must match somewhere in the item's details
        const allTokensMatch = tokens.every((token) => {
          const cleanToken = token.replace(/kg$/i, '').trim();
          return (
            itemSearchableText.includes(token) ||
            (cleanToken.length >= 2 && itemSearchableText.includes(cleanToken))
          );
        });

        if (!allTokensMatch) {
          return false;
        }
      }

      return true;
    });
  }, [items, selectedDepartment, selectedBreedKey, selectedCategory, selectedRegion, onlyVerified, onlyVet, onlyVideo, searchQuery]);

  const handleResetFilters = () => {
    setSelectedRegion('all');
    setSelectedDepartment('all');
    setSelectedBreedKey('all');
    setOnlyVerified(false);
    setOnlyVet(false);
    setOnlyVideo(false);
    setSearchQuery('');
    setSelectedCategory('all');
  };

  const handleAddListing = (newItem: LivestockItem) => {
    setItems((prev) => [newItem, ...prev]);
  };

  const handleOpenTransportForListing = (listing: LivestockItem) => {
    setInspectItem(null);
    setTransportListing(listing);
    setIsTransportOpen(true);
  };

  // Compare Handlers
  const handleToggleCompare = (item: LivestockItem) => {
    setComparedItems((prev) => {
      const exists = prev.some((it) => it.id === item.id);
      if (exists) {
        return prev.filter((it) => it.id !== item.id);
      }
      if (prev.length >= 3) {
        setCompareWarningToast(t.compareMaxWarning);
        setTimeout(() => setCompareWarningToast(null), 3000);
        return prev;
      }
      return [...prev, item];
    });
  };

  const handleRemoveFromCompare = (id: string) => {
    setComparedItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleClearCompare = () => {
    setComparedItems([]);
  };

  const handleAddItemToCompare = (item: LivestockItem) => {
    setComparedItems((prev) => {
      if (prev.length >= 3) return prev;
      if (prev.some((it) => it.id === item.id)) return prev;
      return [...prev, item];
    });
  };

  if (isAdminView) {
    return (
      <AdminDashboardModal
        language={language}
        onLanguageChange={setLanguage}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        onClose={() => setIsAdminView(false)}
        items={items}
        onUpdateItems={setItems}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F9F6] dark:bg-[#061210] text-[#1C2A23] dark:text-[#ECFDF5] font-sans transition-colors relative pb-16 md:pb-0">
      {/* Compare Warning Toast */}
      {compareWarningToast && (
        <div className="fixed top-20 right-4 z-50 bg-rose-900 text-white px-4 py-2.5 rounded-2xl shadow-xl border border-rose-700 text-xs font-bold flex items-center gap-2 animate-in slide-in-from-top-3 duration-150">
          <AlertCircle className="w-4 h-4 text-rose-300 shrink-0" />
          <span>{compareWarningToast}</span>
        </div>
      )}
      {/* Lite Mode Status Banner (if active) */}
      {liteMode && (
        <div className="bg-amber-100 dark:bg-amber-950/80 border-b border-amber-300 dark:border-amber-800 py-1.5 px-4 text-center text-xs font-semibold text-amber-900 dark:text-amber-200 flex items-center justify-center gap-2">
          <span>{t.liteModeOn}</span>
          <button
            onClick={() => setLiteMode(false)}
            className="underline text-amber-950 dark:text-amber-300 hover:text-amber-800 cursor-pointer ml-2"
          >
            Oʻchirish
          </button>
        </div>
      )}

      {/* Top Header */}
      <Header
        language={language}
        onLanguageChange={setLanguage}
        liteMode={liteMode}
        onToggleLiteMode={() => setLiteMode(!liteMode)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        selectedDepartment={selectedDepartment}
        onSelectDepartment={(dept) => {
          setSelectedDepartment(dept);
          setSelectedBreedKey('all');
        }}
        onOpenBreedGuide={() => setIsBreedEncyclopediaOpen(true)}
        onOpenSellerGuide={() => setIsSellerGuideOpen(true)}
        onOpenPromo={() => setIsPromoOpen(true)}
        comparedCount={comparedItems.length}
        onOpenComparison={() => setIsComparisonModalOpen(true)}
        onOpenReels={() => {
          setReelsActiveIndex(0);
          setIsReelsOpen(true);
        }}
        onOpenAddListing={() => setIsAddListingOpen(true)}
        onOpenPriceIndex={() => setIsPriceIndexOpen(true)}
        onOpenTransport={() => {
          setTransportListing(null);
          setIsTransportOpen(true);
        }}
        onOpenTelegram={() => setIsTelegramOpen(true)}
        onOpenAuctions={() => setIsAuctionsOpen(true)}
        onOpenQurbonlik={() => setIsQurbonlikOpen(true)}
        onOpenBreedTrends={() => handleOpenBreedTrends()}
        onOpenAdmin={() => setIsAdminView(true)}
      />

      {/* Dynamic Real-time Rotating Advertisement & Tariff Banner */}
      <RotatingPromoBanner
        onOpenPromo={() => setIsPromoOpen(true)}
        onOpenQurbonlik={() => setIsQurbonlikOpen(true)}
        onOpenAddListing={() => setIsAddListingOpen(true)}
      />

      {/* Hero Section with 3 Quick Add Buttons */}
      <HeroSection
        language={language}
        selectedDepartment={selectedDepartment}
        onSelectDepartment={(dept) => {
          setSelectedDepartment(dept);
          setSelectedBreedKey('all');
        }}
        selectedCategory={selectedCategory}
        onSelectCategory={handleCategorySelect}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenPriceIndex={() => setIsPriceIndexOpen(true)}
        onOpenTransport={() => {
          setTransportListing(null);
          setIsTransportOpen(true);
        }}
        onOpenAuctions={() => setIsAuctionsOpen(true)}
        onOpenReels={() => {
          setReelsActiveIndex(0);
          setIsReelsOpen(true);
        }}
        onOpenBreedGuide={() => setIsBreedEncyclopediaOpen(true)}
        onOpenSellerGuide={() => setIsSellerGuideOpen(true)}
        onOpenPromo={() => setIsPromoOpen(true)}
        onOpenQurbonlik={() => setIsQurbonlikOpen(true)}
        onOpenAddListingWithDept={handleOpenAddListingWithDept}
      />

      {/* Problem Solving Value Banner */}
      <ProblemsSolvedBanner language={language} />

      {/* Mol qo'shish, Qo'y qo'shish, Ot qo'shish bar */}
      <QuickAddLivestockBar
        language={language}
        onOpenAddListingWithDept={handleOpenAddListingWithDept}
        onOpenBreedGuide={() => setIsBreedEncyclopediaOpen(true)}
      />

      {/* Main Catalog Section */}
      <main id="catalog" className="flex-1 max-w-7xl w-full mx-auto pb-16">
        {/* Filter Bar */}
        <FilterBar
          language={language}
          selectedRegion={selectedRegion}
          onSelectRegion={handleRegionSelect}
          onlyVerified={onlyVerified}
          onToggleOnlyVerified={() => setOnlyVerified(!onlyVerified)}
          onlyVet={onlyVet}
          onToggleOnlyVet={() => setOnlyVet(!onlyVet)}
          onlyVideo={onlyVideo}
          onToggleOnlyVideo={() => setOnlyVideo(!onlyVideo)}
          onResetFilters={handleResetFilters}
          totalCount={filteredItems.length}
          viewMode={viewMode}
          onViewModeChange={(m) => {
            if (m === 'reels') {
              setReelsActiveIndex(0);
              setIsReelsOpen(true);
            } else {
              setViewMode(m);
            }
          }}
        />

        {/* Catalog Grid */}
        <div className="px-4 sm:px-6 lg:px-8 pt-6">
          {isLoading ? (
            <SkeletonGrid count={6} />
          ) : filteredItems.length === 0 ? (
            <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-8 sm:p-12 text-center max-w-2xl mx-auto my-8 shadow-sm">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 mx-auto flex items-center justify-center text-3xl mb-4 border border-emerald-200 dark:border-emerald-800 shadow-2xs">
                🐂
              </div>
              <h3 className="text-lg sm:text-xl font-black text-stone-900 dark:text-white font-serif mb-2">
                {language === 'uz'
                  ? 'Platformada barcha mol, qoʻy va otlar olib tashlandi'
                  : 'Все животные удалены с платформы'}
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 max-w-md mx-auto mb-6 leading-relaxed">
                {language === 'uz'
                  ? 'Oʻrniga oʻzingiz toʻgʻridan-toʻgʻri yangi chorva eʼlonini qoʻshishingiz mumkin. Turini tanlang:'
                  : 'Вместо них вы можете добавить новое объявление напрямую. Выберите категорию:'}
              </p>

              {/* 3 Dedicated Add Buttons: Mol qo'shish, Qo'y qo'shish, Ot qo'shish */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 max-w-xl mx-auto">
                <button
                  type="button"
                  onClick={() => handleOpenAddListingWithDept('qoramol')}
                  className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition-all shadow-md shadow-emerald-700/20 cursor-pointer group"
                >
                  <span className="text-3xl group-hover:scale-110 transition-transform">🐂</span>
                  <div className="flex items-center gap-1">
                    <span>Mol qoʻshish</span>
                    <Plus className="w-4 h-4 text-emerald-200" />
                  </div>
                  <span className="text-[10px] text-emerald-100 font-normal">Sigir, buqa, novvos</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenAddListingWithDept('quy')}
                  className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition-all shadow-md shadow-emerald-700/20 cursor-pointer group"
                >
                  <span className="text-3xl group-hover:scale-110 transition-transform">🐑</span>
                  <div className="flex items-center gap-1">
                    <span>Qoʻy qoʻshish</span>
                    <Plus className="w-4 h-4 text-emerald-200" />
                  </div>
                  <span className="text-[10px] text-emerald-100 font-normal">Hisor, qoʻchqor, sovliq</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenAddListingWithDept('ot')}
                  className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition-all shadow-md shadow-emerald-700/20 cursor-pointer group"
                >
                  <span className="text-3xl group-hover:scale-110 transition-transform">🐎</span>
                  <div className="flex items-center gap-1">
                    <span>Ot qoʻshish</span>
                    <Plus className="w-4 h-4 text-emerald-200" />
                  </div>
                  <span className="text-[10px] text-emerald-100 font-normal">Qorabayir, poyga tulpor</span>
                </button>
              </div>

              {items.length > 0 && (
                <div className="mt-5 pt-4 border-t border-stone-100 dark:border-stone-800">
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="py-1.5 px-3 bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-semibold text-xs rounded-xl cursor-pointer transition-colors"
                  >
                    Filtrlarni tozalash
                  </button>
                </div>
              )}
            </div>
          ) : viewMode === 'instagram' ? (
            <InstagramGrid
              items={filteredItems}
              language={language}
              comparedItemIds={comparedItems.map((c) => c.id)}
              onToggleCompare={handleToggleCompare}
              onSelect={(selected) => setInspectItem(selected)}
              onOpenReelsForListing={(selected) => {
                const idx = filteredItems.findIndex((it) => it.id === selected.id);
                setReelsActiveIndex(idx >= 0 ? idx : 0);
                setIsReelsOpen(true);
              }}
              onOpenVetConsult={(selected) => setVetConsultItem(selected)}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((item) => (
                <LivestockCard
                  key={item.id}
                  item={item}
                  language={language}
                  liteMode={liteMode}
                  isCompared={comparedItems.some((c) => c.id === item.id)}
                  onToggleCompare={handleToggleCompare}
                  onSelect={(selected) => setInspectItem(selected)}
                  onStartEscrow={(selected) => setEscrowItem(selected)}
                  onOpenReelsForListing={(selected) => {
                    const idx = filteredItems.findIndex((it) => it.id === selected.id);
                    setReelsActiveIndex(idx >= 0 ? idx : 0);
                    setIsReelsOpen(true);
                  }}
                  onOpenVetConsult={(selected) => setVetConsultItem(selected)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Embedded Live Auction Spotlight Section */}
        <div className="mt-16 border-t border-stone-200 pt-10">
          <LiveAuctionSection language={language} />
        </div>

        {/* Embedded Qurbonlik Special Section */}
        <div className="mt-8 border-t border-stone-200 pt-10">
          <QurbonlikSpecialSection language={language} />
        </div>

        {/* Telegram & Farmer Strategy Banner */}
        <div className="px-4 sm:px-6 lg:px-8 mt-12">
          <div className="bg-sky-950 text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-sky-800">
            <div className="max-w-xl">
              <div className="text-xs font-bold text-sky-400 uppercase tracking-wider mb-1">
                Fermerlar va Chorvadorlar uchun
              </div>
              <h3 className="text-xl sm:text-2xl font-bold font-serif mb-2">
                {t.telegramTitle}
              </h3>
              <p className="text-xs sm:text-sm text-sky-200 leading-relaxed">
                {t.telegramDesc}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setIsTelegramOpen(true)}
                className="py-3 px-5 bg-sky-500 hover:bg-sky-400 text-stone-950 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{t.openTelegramBot}</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setIsStrategyOpen(true)}
                className="py-3 px-5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Target className="w-4 h-4" />
                <span>Startap Rejasi & MVP</span>
              </button>

              <button
                type="button"
                onClick={() => setIsBusinessModelOpen(true)}
                className="py-3 px-5 bg-sky-900/90 hover:bg-sky-800 text-sky-100 border border-sky-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer text-center"
              >
                Daromad modeli (1-3%)
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer
        language={language}
        onOpenPriceIndex={() => setIsPriceIndexOpen(true)}
        onOpenTransport={() => {
          setTransportListing(null);
          setIsTransportOpen(true);
        }}
        onOpenTelegram={() => setIsTelegramOpen(true)}
        onOpenBusinessModel={() => setIsBusinessModelOpen(true)}
        onOpenQurbonlik={() => setIsQurbonlikOpen(true)}
        onOpenStrategy={() => setIsStrategyOpen(true)}
        onOpenSellerGuide={() => setIsSellerGuideOpen(true)}
        onOpenAllInfo={() => setIsAllInfoOpen(true)}
      />

      {/* Modals */}
      {inspectItem && (
        <LivestockDetailModal
          item={inspectItem}
          language={language}
          isCompared={comparedItems.some((c) => c.id === inspectItem.id)}
          onToggleCompare={handleToggleCompare}
          onClose={() => setInspectItem(null)}
          onStartEscrow={(it) => {
            setInspectItem(null);
            setEscrowItem(it);
          }}
          onOpenTransportForListing={handleOpenTransportForListing}
          onOpenVetConsult={(it) => setVetConsultItem(it)}
          onOpenBreedTrends={(breedKey) => handleOpenBreedTrends(breedKey)}
        />
      )}

      {/* Veterinarian Consult Chat Modal */}
      {vetConsultItem && (
        <VeterinarianConsultModal
          isOpen={!!vetConsultItem}
          onClose={() => setVetConsultItem(null)}
          livestockItem={vetConsultItem}
          language={language}
        />
      )}

      {escrowItem && (
        <SafeEscrowModal
          item={escrowItem}
          language={language}
          onClose={() => setEscrowItem(null)}
        />
      )}

      {isPriceIndexOpen && (
        <PriceIndexModal
          language={language}
          onClose={() => setIsPriceIndexOpen(false)}
          onOpenBreedTrends={(breedKey) => handleOpenBreedTrends(breedKey)}
        />
      )}

      {isTransportOpen && (
        <TransportCalculatorModal
          language={language}
          onClose={() => {
            setIsTransportOpen(false);
            setTransportListing(null);
          }}
          preselectedListing={transportListing}
        />
      )}

      {isAuctionsOpen && (
        <LiveAuctionSection
          language={language}
          isModal={true}
          onClose={() => setIsAuctionsOpen(false)}
        />
      )}

      {isQurbonlikOpen && (
        <QurbonlikSpecialSection
          language={language}
          isModal={true}
          onClose={() => setIsQurbonlikOpen(false)}
        />
      )}

      {isTelegramOpen && (
        <TelegramSimulatorModal
          language={language}
          onClose={() => setIsTelegramOpen(false)}
        />
      )}

      {isAddListingOpen && (
        <AddListingModal
          key={addListingDepartment}
          language={language}
          initialDepartment={addListingDepartment}
          onClose={() => setIsAddListingOpen(false)}
          onAddListing={handleAddListing}
          onOpenSellerGuide={() => setIsSellerGuideOpen(true)}
        />
      )}

      {isSellerGuideOpen && (
        <SellerGuideModal
          language={language}
          isOpen={isSellerGuideOpen}
          onClose={() => setIsSellerGuideOpen(false)}
        />
      )}

      {isAllInfoOpen && (
        <PlatformAllInfoModal
          isOpen={isAllInfoOpen}
          onClose={() => setIsAllInfoOpen(false)}
          language={language}
          onOpenPriceIndex={() => setIsPriceIndexOpen(true)}
          onOpenTransport={() => {
            setTransportListing(null);
            setIsTransportOpen(true);
          }}
          onOpenAuctions={() => setIsAuctionsOpen(true)}
          onOpenReels={() => {
            setReelsActiveIndex(0);
            setIsReelsOpen(true);
          }}
          onOpenBreedGuide={() => setIsBreedEncyclopediaOpen(true)}
          onOpenSellerGuide={() => setIsSellerGuideOpen(true)}
          onOpenQurbonlik={() => setIsQurbonlikOpen(true)}
          onOpenTelegram={() => setIsTelegramOpen(true)}
          onOpenBusinessModel={() => setIsBusinessModelOpen(true)}
          onOpenStrategy={() => setIsStrategyOpen(true)}
        />
      )}

      {isBusinessModelOpen && (
        <BusinessModelModal
          language={language}
          onClose={() => setIsBusinessModelOpen(false)}
        />
      )}

      {isStrategyOpen && (
        <StrategyPlaybookModal
          language={language}
          onClose={() => setIsStrategyOpen(false)}
        />
      )}

      {/* Modern Welcome Promo Entry Advertisement Modal */}
      {isPromoOpen && (
        <ModernWelcomePromoModal
          isOpen={isPromoOpen}
          onClose={() => setIsPromoOpen(false)}
          language={language}
          onOpenQurbonlik={() => {
            setIsPromoOpen(false);
            setIsQurbonlikOpen(true);
          }}
          onOpenAddListing={() => {
            setIsPromoOpen(false);
            setIsAddListingOpen(true);
          }}
          onOpenReels={() => {
            setIsPromoOpen(false);
            setReelsActiveIndex(0);
            setIsReelsOpen(true);
          }}
        />
      )}


      {isBreedEncyclopediaOpen && (
        <BreedEncyclopediaModal
          language={language}
          onClose={() => setIsBreedEncyclopediaOpen(false)}
          onFilterByBreed={(breedKey, department) => {
            setSelectedDepartment(department);
            setSelectedBreedKey(breedKey);
            setIsBreedEncyclopediaOpen(false);
            const el = document.getElementById('catalog');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenBreedTrends={(breedKey) => {
            setIsBreedEncyclopediaOpen(false);
            handleOpenBreedTrends(breedKey);
          }}
        />
      )}

      {/* Dynamic Breed Historical Price Trends & Seasonality Modal */}
      {isBreedPriceTrendsOpen && (
        <BreedPriceTrendsModal
          language={language}
          initialBreedId={selectedTrendBreedId}
          onClose={() => setIsBreedPriceTrendsOpen(false)}
          onFilterByBreed={(breedKey, department) => {
            setSelectedDepartment(department);
            setSelectedBreedKey(breedKey);
            setIsBreedPriceTrendsOpen(false);
            const el = document.getElementById('catalog');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />
      )}

      {isReelsOpen && (
        <LivestockReelsModal
          items={filteredItems}
          initialIndex={reelsActiveIndex}
          language={language}
          onClose={() => setIsReelsOpen(false)}
          onStartEscrow={(item) => {
            setIsReelsOpen(false);
            setEscrowItem(item);
          }}
        />
      )}

      {/* Floating Sticky Comparison Bar (when items selected) */}
      <ComparisonFloatingBar
        items={comparedItems}
        language={language}
        onRemoveItem={handleRemoveFromCompare}
        onClearAll={handleClearCompare}
        onOpenComparisonModal={() => setIsComparisonModalOpen(true)}
      />

      {/* Side-by-Side Comparison Modal Table View */}
      {isComparisonModalOpen && (
        <LivestockComparisonModal
          items={comparedItems}
          allItems={items}
          language={language}
          onClose={() => setIsComparisonModalOpen(false)}
          onRemoveItem={handleRemoveFromCompare}
          onAddItem={handleAddItemToCompare}
          onStartEscrow={(it) => {
            setIsComparisonModalOpen(false);
            setEscrowItem(it);
          }}
          onViewDetails={(it) => {
            setIsComparisonModalOpen(false);
            setInspectItem(it);
          }}
        />
      )}

      {/* Native Thumb-Friendly Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        language={language}
        onGoHome={() => {
          setSelectedDepartment('all');
          setSelectedBreedKey('all');
          setSelectedCategory('all');
          const el = document.getElementById('catalog');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenReels={() => {
          setReelsActiveIndex(0);
          setIsReelsOpen(true);
        }}
        onOpenAddListing={() => setIsAddListingOpen(true)}
        onOpenQurbonlik={() => setIsQurbonlikOpen(true)}
        onOpenAuctions={() => setIsAuctionsOpen(true)}
      />
    </div>
  );
}
