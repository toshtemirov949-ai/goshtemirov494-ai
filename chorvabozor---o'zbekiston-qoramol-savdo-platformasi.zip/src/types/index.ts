export type Language = 'uz' | 'ru';

export type AnimalDepartment = 'all' | 'qoramol' | 'quy' | 'ot';

export type LivestockCategory = 
  | 'all'
  | 'dairy'       // Sut yo'nalishi
  | 'beef'        // Go'sht yo'nalishi
  | 'calf'        // Buzoqlar
  | 'qurbonlik'   // Qurbonlik uchun
  | 'wholesale'   // Ulgurji partiya
  | 'sheep'       // Qo'y / Qo'chqor
  | 'horses'      // Otlar
  | 'sports';     // Poyga / Ko'pkari

export type UzbekistanRegion =
  | 'Toshkent shahri'
  | 'Toshkent viloyati'
  | 'Samarqand'
  | 'Andijon'
  | 'Fargʻona'
  | 'Namangan'
  | 'Qashqadaryo'
  | 'Surxondaryo'
  | 'Buxoro'
  | 'Xorazm'
  | 'Jizzax'
  | 'Sirdaryo'
  | 'Navoiy'
  | 'Qoraqalpogʻiston Respublikasi';

export interface BreedInfo {
  id: string;
  nameUz: string;
  nameRu: string;
  department: 'qoramol' | 'quy' | 'ot';
  descriptionUz: string;
  descriptionRu: string;
  featuresUz: string[];
  featuresRu: string[];
  recommendedForUz: string;
  recommendedForRu: string;
  weightRange: string;
  icon: string;
}

export interface VetCertificate {
  id: string;
  hasVetPassport: boolean;
  passportNumber: string;
  issuedDate: string;
  veterinarianName: string;
  districtVetClinic: string;
  vaccinatedFor: {
    nameUz: string;
    nameRu: string;
    date: string;
    isImmune: boolean;
  }[];
  healthNotes: string;
  status: 'verified' | 'pending' | 'none';
}

export interface Seller {
  id: string;
  name: string;
  farmName: string;
  phone: string;
  telegramUsername: string;
  region: UzbekistanRegion;
  district: string;
  isPassportVerified: boolean;
  isPhoneVerified: boolean;
  rating: number; // e.g. 4.9
  dealsCompleted: number;
  memberSince: string;
  badge: 'Fermer xoʻjaligi' | 'Xususiy chorvador' | 'Naslchilik xoʻjaligi';
}

export interface LivestockItem {
  id: string;
  titleUz: string;
  titleRu: string;
  department: 'qoramol' | 'quy' | 'ot';
  category: LivestockCategory;
  breed: string; // e.g., "Golshtin (Holstein)", "Qora-ola", "Angus", "Simmental", "Hisor", "Qorabayir", "Axaltaka"
  breedKey?: string;
  gender: 'buqa' | 'sigir' | 'buzoq' | 'qoʻchqor' | 'sovliq' | 'aygʻir' | 'biya' | 'toygʻir';
  ageMonths: number;
  weightKg: number;
  priceUzs: number;
  pricePerKg?: number;
  dailyMilkYieldLiters?: number; // for dairy
  lactationNumber?: number; // nechanchi qorin
  isPregnant?: boolean;
  pregnancyMonths?: number;
  speedKmh?: number; // for horses
  withersHeightCm?: number; // otlar bo'yi (sm)
  region: UzbekistanRegion;
  district: string;
  descriptionUz: string;
  descriptionRu: string;
  
  // Media
  imageUrl: string;
  additionalImages: string[];
  hasVideo: boolean;
  videoDurationSec?: number;
  videoCaptionUz?: string;

  // Features
  isVerifiedSeller: boolean;
  vetInfo: VetCertificate;
  isEscrowSupported: boolean; // Xavfsiz to'lov
  isDeliveryAvailable: boolean;
  isQurbonlikFit: boolean;
  qurbonlikConditionsMet?: boolean; // Tish yorgan, aybsiz

  // Stats
  viewsCount: number;
  likesCount: number;
  createdAt: string;
  timeAgo?: string;
  seller: Seller;
  isFeatured?: boolean;
}

export interface AuctionBid {
  id: string;
  bidderName: string;
  bidderRegion: string;
  amountUzs: number;
  timestamp: string;
}

export interface AuctionItem {
  id: string;
  livestockId: string;
  titleUz: string;
  titleRu: string;
  breed: string;
  headCount: number; // e.g. 5 bosh buzoq
  totalWeightKg: number;
  startingPriceUzs: number;
  currentBidUzs: number;
  minStepUzs: number;
  endsAt: string; // ISO string
  bids: AuctionBid[];
  imageUrl: string;
  region: UzbekistanRegion;
  sellerName: string;
  status: 'active' | 'completed';
}

export interface RegionPriceStat {
  region: UzbekistanRegion;
  averageLiveWeightPriceBeef: number; // so'm/kg
  averageLiveWeightPriceSheep: number;
  averageDairyCowPrice: number; // mln so'm
  changePercentageLastMonth: number;
  trend: 'up' | 'stable' | 'down';
  notesUz: string;
  notesRu: string;
}

export interface TransportQuote {
  fromRegion: UzbekistanRegion;
  toRegion: UzbekistanRegion;
  distanceKm: number;
  vehicleType: 'labo' | 'gazel' | 'isuzu' | 'cattle_truck';
  estimatedCostUzs: number;
  estimatedHours: number;
  availableDriversCount: number;
}

export type ListingMainType = 'livestock' | 'equipment';

export type EquipmentSubcategory = 
  | 'arqon'        // Arqonlar (Ropes)
  | 'yugan'        // Yo'g'an / Yugan (Halters & Bridles)
  | 'egar'         // Egar / Jabduq (Saddles & Harnesses)
  | 'yemdon'       // Yemdon / Oxur (Feeders & Troughs)
  | 'taqa'         // Taqa & Temirchilik asboblari
  | 'parvarish';   // Parvarish, taroq va qaychilar

export type EquipmentMaterial = 
  | 'charm'        // Tabiiy charm (Leather)
  | 'neylon'       // Neylon (Nylon)
  | 'ip'           // Paxta / Kanop (Cotton/Hemp rope)
  | 'metall'       // Temir / Po'lat (Metal)
  | 'yogoch'       // Yog'och (Wood)
  | 'boshqa';      // Boshqa

export type EquipmentCondition = 'yangi' | 'ishlatilgan';

export interface EquipmentItem {
  id: string;
  type: 'equipment';
  titleUz: string;
  titleRu: string;
  subcategory: EquipmentSubcategory;
  material: EquipmentMaterial;
  sizeOrLength: string; // e.g. "12 metr", "Standart (Katta mol uchun)", "Ot egari N2"
  condition: EquipmentCondition;
  priceUzs: number;
  region: UzbekistanRegion;
  district: string;
  descriptionUz: string;
  descriptionRu: string;
  imageUrl: string;
  additionalImages?: string[];
  seller: Seller;
  status: 'active' | 'sold' | 'pending';
  createdAt: string;
  viewsCount: number;
  likesCount: number;
}

export interface UserCabinetAdItem {
  id: string;
  itemType: 'livestock' | 'equipment';
  title: string;
  categoryLabel: string;
  priceUzs: number;
  imageUrl: string;
  status: 'active' | 'sold' | 'pending';
  viewsCount: number;
  createdAt: string;
  region: string;
  details: string;
  livestockRef?: LivestockItem;
  equipmentRef?: EquipmentItem;
}
