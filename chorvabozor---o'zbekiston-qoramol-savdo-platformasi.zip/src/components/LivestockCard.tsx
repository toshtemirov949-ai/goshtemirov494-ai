import React, { useState } from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import { Video, ShieldCheck, CheckCircle2, Play, Lock, Scale, Clock, Stethoscope } from 'lucide-react';

interface LivestockCardProps {
  item: LivestockItem;
  language: Language;
  liteMode: boolean;
  isCompared?: boolean;
  onToggleCompare?: (item: LivestockItem) => void;
  onSelect: (item: LivestockItem) => void;
  onStartEscrow: (item: LivestockItem) => void;
  onOpenReelsForListing?: (item: LivestockItem) => void;
  onOpenVetConsult?: (item: LivestockItem) => void;
}

export const LivestockCard: React.FC<LivestockCardProps> = ({
  item,
  language,
  liteMode,
  isCompared = false,
  onToggleCompare,
  onSelect,
  onStartEscrow,
  onOpenReelsForListing,
  onOpenVetConsult,
}) => {
  const [imgError, setImgError] = useState(false);
  const t = translations[language];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ').format(price);
  };

  return (
    <article className="group bg-white dark:bg-[#072D24] rounded-2xl border border-[#E5ECE7] dark:border-[#0E3D32] hover:border-[#047857]/60 dark:hover:border-[#10B981]/60 transition-all duration-200 flex flex-col overflow-hidden shadow-2xs hover:shadow-md text-[#1C2A23] dark:text-[#ECFDF5]">
      {/* Visual Area (65-70% visual focus) */}
      <div
        className="relative aspect-[4/3] bg-[#F7F9F6] dark:bg-[#041C16] overflow-hidden cursor-pointer"
        onClick={() => onSelect(item)}
      >
        {liteMode ? (
          // Lite Mode: Clean, data-efficient graphic rendering
          <div className="w-full h-full flex flex-col items-center justify-center bg-stone-100 dark:bg-stone-800 p-4 text-center">
            <span className="text-3xl mb-1">
              {item.category === 'sheep' ? '🐑' : '🐂'}
            </span>
            <span className="text-xs font-semibold text-stone-700 dark:text-stone-300 font-mono">
              {item.breed}
            </span>
            <span className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
              {item.weightKg} kg · {item.region}
            </span>
          </div>
        ) : !imgError ? (
          <img
            src={item.imageUrl}
            alt={language === 'uz' ? item.titleUz : item.titleRu}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center group-hover:scale-[1.03] transition-transform duration-300"
          />
        ) : (
          // Styled CSS/SVG Fallback Container (Zero-Broken-Image Policy)
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-stone-200 to-stone-300 dark:from-stone-800 dark:to-stone-900 p-6 text-center text-stone-600 dark:text-stone-400">
            <div className="w-12 h-12 rounded-full bg-white/70 dark:bg-stone-700 flex items-center justify-center mb-2 text-stone-700 dark:text-stone-200 font-bold">
              {item.category === 'sheep' ? '🐑' : '🐂'}
            </div>
            <span className="text-xs font-semibold text-stone-800 dark:text-stone-200">{item.breed}</span>
            <span className="text-[11px] text-stone-500 dark:text-stone-400">{item.region}</span>
          </div>
        )}

        {/* Video Reel Clickable Indicator (Top Right) */}
        {item.hasVideo && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onOpenReelsForListing) {
                onOpenReelsForListing(item);
              } else {
                onSelect(item);
              }
            }}
            className="absolute top-2.5 right-2.5 bg-black/75 hover:bg-black/90 backdrop-blur-xs text-white text-[11px] font-medium px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-sm transition-transform hover:scale-105 cursor-pointer z-10"
            title="Dinamik Reelsda koʻrish"
          >
            <Play className="w-3 h-3 fill-sky-400 text-sky-400" />
            <span className="font-mono">{item.videoDurationSec ? `${item.videoDurationSec}s` : 'Reels'}</span>
          </button>
        )}

        {/* Vet Inspection Checkmark (Top Left) */}
        {item.vetInfo?.hasVetPassport && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenVetConsult?.(item);
            }}
            className="absolute top-2.5 left-2.5 bg-emerald-950/85 hover:bg-emerald-900 backdrop-blur-xs text-emerald-200 text-[11px] font-semibold px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-2xs z-10 cursor-pointer transition-transform hover:scale-105 active:scale-95"
            title="Veterinar konsultatsiyasi va tekshiruvi"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Vet Pasport</span>
          </button>
        )}

        {/* Qurbonlik label if applicable */}
        {item.isQurbonlikFit && (
          <div className="absolute bottom-2.5 left-2.5 bg-amber-950/85 text-amber-200 text-[11px] font-medium px-2 py-0.5 rounded-md">
            Qurbonlikka loyiq
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Unboxed Metadata with Real-time Freshness Timestamp */}
          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 mb-1.5">
            <div className="flex items-center gap-1.5 truncate">
              <span className="font-bold text-emerald-900 dark:text-emerald-300 shrink-0">
                {item.department === 'qoramol' ? '🐂 Qoramol' : item.department === 'quy' ? '🐑 Qoʻy' : '🐎 Ot'}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-stone-700 dark:text-stone-300 truncate">{item.breed}</span>
            </div>
            {item.timeAgo && (
              <span className="shrink-0 text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold font-mono flex items-center gap-1 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded-md">
                <Clock className="w-2.5 h-2.5" />
                {item.timeAgo}
              </span>
            )}
          </div>

          {/* Title */}
          <h3
            onClick={() => onSelect(item)}
            className="text-sm sm:text-base font-bold text-stone-900 dark:text-stone-100 line-clamp-1 hover:text-emerald-800 dark:hover:text-emerald-400 cursor-pointer transition-colors leading-snug mb-1.5"
          >
            {language === 'uz' ? item.titleUz : item.titleRu}
          </h3>

          {/* Short & Crisp Description */}
          <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-2 mb-2.5 leading-relaxed font-normal">
            {language === 'uz' ? item.descriptionUz : item.descriptionRu}
          </p>

          {/* Key Specifications: Weight, Age, Milk */}
          <div className="grid grid-cols-3 gap-2 py-2 mb-3 border-y border-stone-100 dark:border-stone-800/80 text-xs text-stone-700 dark:text-stone-300 font-mono">
            <div className="flex flex-col">
              <span className="text-[10px] text-stone-400 uppercase font-sans">
                {t.weight}
              </span>
              <span className="font-semibold text-stone-900 dark:text-stone-100">{item.weightKg} kg</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-stone-400 uppercase font-sans">
                {t.age}
              </span>
              <span className="font-semibold text-stone-900 dark:text-stone-100">
                {item.ageMonths >= 12
                  ? `${(item.ageMonths / 12).toFixed(1)} ${t.years}`
                  : `${item.ageMonths} ${t.months}`}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-stone-400 uppercase font-sans">
                {item.dailyMilkYieldLiters ? t.milkYield : 'Tirik kg narx'}
              </span>
              <span className="font-semibold text-emerald-800 dark:text-emerald-400">
                {item.dailyMilkYieldLiters
                  ? `${item.dailyMilkYieldLiters} L`
                  : item.pricePerKg
                  ? `${Math.round(item.pricePerKg / 1000)}k`
                  : 'Kelishiladi'}
              </span>
            </div>
          </div>

          {/* Farmer & Trust Info with Galochka */}
          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 mb-3">
            <div className="flex items-center gap-1.5 truncate">
              <span className="truncate font-medium text-stone-800 dark:text-stone-200">{item.seller.name}</span>
              {item.seller.isPassportVerified && (
                <span title={t.verifiedSeller} className="inline-flex">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                </span>
              )}
            </div>
            <span className="shrink-0 text-amber-700 dark:text-amber-400 font-semibold font-mono">
              ★ {item.seller.rating.toFixed(1)}
            </span>
          </div>
        </div>

        {/* Pricing & Actions */}
        <div className="pt-2 border-t border-stone-100 dark:border-stone-800/80">
          <div className="flex items-baseline justify-between mb-3">
            <span className="text-lg sm:text-xl font-extrabold text-stone-900 dark:text-stone-100 font-mono tabular-nums">
              {formatPrice(item.priceUzs)}
            </span>
            <span className="text-xs text-stone-500 dark:text-stone-400 font-medium">
              {t.currency}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-2">
            <button
              type="button"
              onClick={() => onSelect(item)}
              className="w-full py-2 px-3 text-xs font-semibold rounded-xl bg-[#F7F9F6] dark:bg-[#041C16] hover:bg-stone-200 dark:hover:bg-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] transition-colors text-center cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
            >
              {t.viewDetails}
            </button>
            <button
              type="button"
              onClick={() => onStartEscrow(item)}
              className="w-full py-2 px-3 text-xs font-bold rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white shadow-sm shadow-[#F59E0B]/25 active:scale-95 transition-all text-center cursor-pointer truncate"
              title="Xavfsiz to'lov bilan xarid qilish"
            >
              {t.safeEscrow}
            </button>
          </div>

          {/* Veterinarian Consult Button */}
          {onOpenVetConsult && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenVetConsult(item);
              }}
              className="w-full py-1.5 px-3 mb-2 text-xs font-semibold rounded-xl border border-sky-300 dark:border-[#0E3D32] bg-sky-50/80 dark:bg-[#041C16] hover:bg-sky-100 dark:hover:bg-[#072D24] text-sky-900 dark:text-emerald-300 transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs group"
              title="Veterinar vrach bilan onlayn chat maslahati"
            >
              <Stethoscope className="w-3.5 h-3.5 text-sky-600 dark:text-[#10B981] group-hover:scale-110 transition-transform" />
              <span>{language === 'uz' ? 'Veterinar Maslahati (Chat)' : 'Консультация ветеринара'}</span>
            </button>
          )}

          {/* Compare Toggle Button */}
          {onToggleCompare && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleCompare(item);
              }}
              className={`w-full py-1.5 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                isCompared
                  ? 'bg-[#047857] text-white border-[#10B981] font-bold shadow-2xs'
                  : 'bg-[#F7F9F6] dark:bg-[#041C16] hover:bg-stone-200 dark:hover:bg-[#072D24] text-[#1C2A23] dark:text-[#ECFDF5] border-[#E5ECE7] dark:border-[#0E3D32]'
              }`}
            >
              <Scale className={`w-3.5 h-3.5 ${isCompared ? 'text-[#ECFDF5]' : 'text-stone-500 dark:text-stone-400'}`} />
              <span>{isCompared ? `✓ ${t.compareSelected}` : t.compare}</span>
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
