import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { Award, CheckCircle2, ShieldCheck, Calendar, Truck, HeartHandshake, Phone, X, Check } from 'lucide-react';

interface QurbonlikSpecialSectionProps {
  language: Language;
  onClose?: () => void;
  isModal?: boolean;
}

export const QurbonlikSpecialSection: React.FC<QurbonlikSpecialSectionProps> = ({
  language,
  onClose,
  isModal = false,
}) => {
  const t = translations[language];
  const [reservedSuccess, setReservedSuccess] = useState(false);
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [animalType, setAnimalType] = useState<'qoy' | 'buqa'>('qoy');
  const [needButcher, setNeedButcher] = useState(true);

  const handleSubmitReservation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formPhone) return;
    setReservedSuccess(true);
  };

  const content = (
    <div className="space-y-6">
      {/* Hero Card */}
      <div className="bg-gradient-to-r from-[#064E3B] via-[#043E30] to-[#064E3B] text-white p-6 sm:p-8 rounded-3xl border border-[#047857]/40 relative overflow-hidden">
        <div className="max-w-2xl relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F59E0B] text-[#02100C] text-xs font-black mb-3 shadow-md shadow-[#F59E0B]/20">
            <Award className="w-3.5 h-3.5 text-[#02100C]" />
            <span>Qurbonlik Hayiti 2026 Maxsus Dasturi</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-serif mb-2 text-white">
            {t.qurbonlikTitle}
          </h2>

          <p className="text-stone-300 text-xs sm:text-sm leading-relaxed mb-6">
            {t.qurbonlikSubtitle}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-emerald-900/80 border border-emerald-700/60 p-3 rounded-xl">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 mb-1" />
              <strong className="block text-white">Shariatga Muvofiq</strong>
              <span className="text-stone-300 text-[11px]">Yoshi toʻlgan va tish yorganligi tekshirilgan</span>
            </div>
            <div className="bg-emerald-900/80 border border-emerald-700/60 p-3 rounded-xl">
              <ShieldCheck className="w-4 h-4 text-emerald-400 mb-1" />
              <strong className="block text-white">Sogʻlom va Semiz</strong>
              <span className="text-stone-300 text-[11px]">Koʻzi ravshan, oqsoqliksiz, nuqsonsiz</span>
            </div>
            <div className="bg-emerald-900/80 border border-emerald-700/60 p-3 rounded-xl">
              <Truck className="w-4 h-4 text-emerald-400 mb-1" />
              <strong className="block text-white">Eshikkacha Yetkazish</strong>
              <span className="text-stone-300 text-[11px]">Hayit kuni yoki 1 kun oldin uyingizga yetkaziladi</span>
            </div>
          </div>
        </div>
      </div>

      {/* Rules & Reservation Form Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sharia & Quality Rules (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-stone-900 p-5 sm:p-6 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-4 transition-colors">
          <h3 className="text-base font-bold text-stone-900 dark:text-white">
            Qurbonlik Tanlashda ChorvaBozor Kafolatlari
          </h3>

          <div className="space-y-3 text-xs text-stone-700 dark:text-stone-300">
            <div className="p-3 bg-stone-50 dark:bg-stone-850 rounded-xl border border-stone-200 dark:border-stone-750">
              <strong className="text-stone-900 dark:text-white block mb-1 text-sm font-serif">
                1. Yosh chegarasi nazorati:
              </strong>
              <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                {t.qurbonlikRule1} Qoramolning 2 yoshga toʻlgani va qoʻchqorning tish yorgani maxsus video va fermer qasamyodi bilan tasdiqlanadi.
              </p>
            </div>

            <div className="p-3 bg-stone-50 dark:bg-stone-850 rounded-xl border border-stone-200 dark:border-stone-750">
              <strong className="text-stone-900 dark:text-white block mb-1 text-sm font-serif">
                2. Nuqson va ayblardan xoli boʻlish:
              </strong>
              <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                {t.qurbonlikRule2} Hayvon qulogʻi yorilmagan, shoxi sinmagan, dumi kesilmagan boʻlishi qatʼiy nazorat qilinadi.
              </p>
            </div>

            <div className="p-3 bg-stone-50 dark:bg-stone-850 rounded-xl border border-stone-200 dark:border-stone-750">
              <strong className="text-stone-900 dark:text-white block mb-1 text-sm font-serif">
                3. Halol soʻyish va Qassoblik xizmati:
              </strong>
              <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                {t.qurbonlikRule3} Hayvonni xonadoningizga tirik olib borish yoki maxsus sanitariya talablariga mos kushxonada soʻyib, qismlarga boʻlingan holda topshirish varianti mavjud.
              </p>
            </div>
          </div>
        </div>

        {/* Pre-Order Reservation Form (5 cols) */}
        <div className="lg:col-span-5 bg-stone-50 dark:bg-stone-900 p-5 sm:p-6 rounded-2xl border border-stone-200 dark:border-stone-800 flex flex-col justify-between transition-colors">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-stone-900 dark:text-white mb-1">
              Qurbonlikni Oldindan Bron Qilish
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">
              Hayit arafasida narxlar 30-40% oshib ketishi va tirbandlikning oldini oling.
            </p>

            {reservedSuccess ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-center text-xs text-emerald-950 dark:text-emerald-200 space-y-2">
                <div className="w-10 h-10 rounded-full bg-emerald-200 dark:bg-emerald-800 text-emerald-800 dark:text-emerald-200 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6 stroke-[3]" />
                </div>
                <h4 className="font-bold text-sm">Bron Qabul Qilindi!</h4>
                <p>
                  Menejerimiz siz bilan 15 daqiqa ichida bogʻlanib, eng maʼqul qurbonlik hayvoni va yetkazib berish vaqtini kelishadi.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReservation} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Ismingiz:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masalan: Sardorbek"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-stone-800 text-stone-900 dark:text-white border border-stone-300 dark:border-stone-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-700"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Telefon raqamingiz:
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+998 90 123 45 67"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-stone-800 text-stone-900 dark:text-white border border-stone-300 dark:border-stone-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-700"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Chorva turi:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAnimalType('qoy')}
                      className={`p-2 rounded-lg border text-center transition-all cursor-pointer ${
                        animalType === 'qoy'
                          ? 'border-emerald-700 bg-emerald-100/60 dark:bg-emerald-950 dark:border-emerald-600 font-bold text-emerald-950 dark:text-emerald-200'
                          : 'border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      Qoʻy / Qoʻchqor
                    </button>
                    <button
                      type="button"
                      onClick={() => setAnimalType('buqa')}
                      className={`p-2 rounded-lg border text-center transition-all cursor-pointer ${
                        animalType === 'buqa'
                          ? 'border-emerald-700 bg-emerald-100/60 dark:bg-emerald-950 dark:border-emerald-600 font-bold text-emerald-950 dark:text-emerald-200'
                          : 'border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      Qoramol / Buqa
                    </button>
                  </div>
                </div>

                <label className="flex items-center gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={needButcher}
                    onChange={(e) => setNeedButcher(e.target.checked)}
                    className="rounded text-emerald-700 w-4 h-4"
                  />
                  <span className="text-stone-700 dark:text-stone-300">Qassoblik va goʻshtni taqsimlash xizmati kerak</span>
                </label>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition-colors shadow-2xs mt-2 cursor-pointer"
                >
                  Bron Qilish (Bepul)
                </button>
              </form>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-stone-200 dark:border-stone-800 text-[11px] text-stone-500 dark:text-stone-400">
            * Oldindan buyurtma qilingan qurbonlik mollari bozor narxidan kamida 15-20% arzonroq fermer narxida qotirib qoʻyiladi.
          </div>
        </div>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
        <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-4xl w-full shadow-2xl p-4 sm:p-6 max-h-[92vh] overflow-y-auto border border-[#E5ECE7] dark:border-[#0E3D32]">
          <div className="flex justify-end mb-2">
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {content}
        </div>
      </div>
    );
  }

  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {content}
    </section>
  );
};
