import React, { useState, useMemo } from 'react';
import {
  LayoutDashboard,
  ShieldAlert,
  ShieldCheck,
  FileCheck,
  Gavel,
  TrendingUp,
  CreditCard,
  Search,
  Bell,
  Sun,
  Moon,
  ArrowLeft,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Eye,
  Plus,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Users,
  Truck,
  Check,
  X,
  MapPin,
  ChevronRight,
  Filter,
  DollarSign,
  Download,
  Flame,
  Award,
  Stethoscope,
  Info,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Phone,
  Calendar,
  Lock,
  Menu as MenuIcon
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell
} from 'recharts';
import { Language } from '../types';

interface AdminDashboardProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onExit: () => void;
}

type AdminTab =
  | 'overview'
  | 'moderation'
  | 'veterinary'
  | 'auctions'
  | 'analytics'
  | 'escrow';

// Types for Admin State
interface ModerationListing {
  id: string;
  titleUz: string;
  titleRu: string;
  department: 'qoramol' | 'quy' | 'ot';
  breed: string;
  weightKg: number;
  priceUzs: number;
  region: string;
  district: string;
  sellerName: string;
  sellerPhone: string;
  vetPassportNumber: string;
  hasVideo: boolean;
  imageUrl: string;
  submittedAt: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  aiScore: number; // 0 - 100
  aiFlag: 'OK' | 'SUSPICIOUS_PRICE' | 'WRONG_BREED' | 'DOCUMENT_BLURRY' | 'HIGH_DEMAND';
  aiNotesUz: string;
  aiNotesRu: string;
  rejectReason?: string;
}

interface VeterinaryAnimal {
  id: string;
  tagNumber: string; // Birka / chip
  passportId: string;
  animalType: string;
  breed: string;
  ownerName: string;
  region: string;
  district: string;
  clinicName: string;
  vetDoctorName: string;
  lastVaccineDate: string;
  vaccines: { name: string; date: string; status: 'ok' | 'needed' }[];
  isQurbonlikCandidate: boolean;
  qurbonlikStatus: 'CERTIFIED' | 'PENDING_CHECK' | 'DISQUALIFIED';
  qurbonlikChecks: {
    ageValid: boolean; // >= 2 yosh qoramol, >= 1 yosh qo'y
    teethHealthy: boolean;
    hornsAndTailIntact: boolean;
    eyesClear: boolean;
    noLimping: boolean;
  };
  weightKg: number;
  ageMonths: number;
}

interface AdminAuction {
  id: string;
  titleUz: string;
  titleRu: string;
  breed: string;
  startingPrice: number;
  currentBid: number;
  minStep: number;
  bidsCount: number;
  endsAt: string; // ISO
  timeLeftMinutes: number;
  status: 'ACTIVE' | 'PAUSED' | 'COMPLETED';
  imageUrl: string;
  sellerName: string;
  leadingBidder: string;
  bids: { id: string; user: string; region: string; amount: number; time: string }[];
}

interface EscrowTransaction {
  id: string;
  orderNumber: string;
  buyerName: string;
  buyerPhone: string;
  sellerName: string;
  sellerPhone: string;
  animalTitle: string;
  amountUzs: number;
  feeUzs: number; // 1.5%
  sellerPayoutUzs: number;
  status: 'HELD' | 'IN_TRANSIT' | 'DELIVERED' | 'RELEASED' | 'DISPUTED';
  transporter?: string;
  route: string;
  date: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  language,
  onLanguageChange,
  isDarkMode,
  onToggleDarkMode,
  onExit,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Trigger temporary notification
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3200);
  };

  // 1. Initial Moderation Listings
  const [listings, setListings] = useState<ModerationListing[]>([
    {
      id: 'LST-1049',
      titleUz: 'Golshtin Friesian 2-qorin sogʻin sigir (kuniga 28L sut)',
      titleRu: 'Голштинская дойная корова 2-го отела (28л в день)',
      department: 'qoramol',
      breed: 'Golshtin (Holstein)',
      weightKg: 630,
      priceUzs: 32000000,
      region: 'Samarqand',
      district: 'Pastdargʻom',
      sellerName: 'Karimov Shuhrat FM',
      sellerPhone: '+998 90 234-56-78',
      vetPassportNumber: 'UZ-VET-77821-SAM',
      hasVideo: true,
      imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
      submittedAt: 'Bugun, 09:42',
      status: 'PENDING',
      aiScore: 96,
      aiFlag: 'HIGH_DEMAND',
      aiNotesUz: '✅ Rasm va zot tavsifi 98% mos. Narx viloyat oʻrtachasi bilan uygʻun. Video haqiqiy fermada olingan.',
      aiNotesRu: '✅ Описание и фото соответствуют на 98%. Цена адекватна рынку Самарканда. Видео подлинное.'
    },
    {
      id: 'LST-1050',
      titleUz: 'Hisor zotli 1.5 yashar urugʻlik qoʻchqor (125 kg)',
      titleRu: 'Гиссарский племенной баран 1.5 года (125 кг)',
      department: 'quy',
      breed: 'Hisor qoʻylari',
      weightKg: 125,
      priceUzs: 8500000,
      region: 'Qashqadaryo',
      district: 'Dehqonobod',
      sellerName: 'Zokir Chorvador',
      sellerPhone: '+998 97 112-33-44',
      vetPassportNumber: 'UZ-VET-44910-QASH',
      hasVideo: false,
      imageUrl: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
      submittedAt: 'Bugun, 08:15',
      status: 'PENDING',
      aiScore: 92,
      aiFlag: 'OK',
      aiNotesUz: '✅ Zot sifatlari yaxshi. Qurbonlik talablariga mos keladi (yoshi 1 yoshdan katta, sogʻlom).',
      aiNotesRu: '✅ Породные признаки отличные. Подходит под стандарты Курбанлык (возраст более 1 года).'
    },
    {
      id: 'LST-1051',
      titleUz: 'Shveysar (Shvis) zotli goʻshtdor buqa (semiz)',
      titleRu: 'Швиц мясной откормленный бык',
      department: 'qoramol',
      breed: 'Shvis (Brown Swiss)',
      weightKg: 580,
      priceUzs: 16000000,
      region: 'Andijon',
      district: 'Asaka',
      sellerName: 'Bekzod Aliyev',
      sellerPhone: '+998 93 456-78-90',
      vetPassportNumber: 'UZ-VET-11204-AND',
      hasVideo: true,
      imageUrl: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=800&q=80',
      submittedAt: 'Kecha, 22:30',
      status: 'PENDING',
      aiScore: 54,
      aiFlag: 'SUSPICIOUS_PRICE',
      aiNotesUz: '⚠️ Diqqat: 580 kg vazn uchun 16,000,000 soʻm nihoyatda past (bozordan -45%). Dallol yoki notoʻgʻri vazn shubhasi!',
      aiNotesRu: '⚠️ Внимание: Для 580 кг цена 16 млн слишком занижена (-45% от рынка). Возможно мошенничество или ошибка!'
    },
    {
      id: 'LST-1052',
      titleUz: 'Qorabayir zotli toʻrt yashar koʻpkari aygʻiri',
      titleRu: 'Карабаирский 4-летний жеребец для кокпари',
      department: 'ot',
      breed: 'Qorabayir oti',
      weightKg: 490,
      priceUzs: 55000000,
      region: 'Jizzax',
      district: 'Baxmal',
      sellerName: 'Rustam Polvon',
      sellerPhone: '+998 91 789-01-23',
      vetPassportNumber: 'UZ-VET-99012-JIZ',
      hasVideo: true,
      imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
      submittedAt: 'Kecha, 18:20',
      status: 'APPROVED',
      aiScore: 98,
      aiFlag: 'OK',
      aiNotesUz: '✅ Pasport toʻliq tekshirilgan. Zotdorligi tasdiqlangan.',
      aiNotesRu: '✅ Паспорт проверен. Породность подтверждена.'
    }
  ]);

  // Moderation Reject Modal State
  const [rejectingListing, setRejectingListing] = useState<ModerationListing | null>(null);
  const [customRejectReason, setCustomRejectReason] = useState<string>('Rasm sifati past yoki boshqa manbadan olingan');
  const [inspectingListing, setInspectingListing] = useState<ModerationListing | null>(null);

  // 2. Initial Veterinary Registry
  const [vetAnimals, setVetAnimals] = useState<VeterinaryAnimal[]>([
    {
      id: 'VET-8801',
      tagNumber: 'UZ-BIRKA-980124',
      passportId: 'UZ-VET-77821-SAM',
      animalType: 'Qoramol (Sogʻin)',
      breed: 'Golshtin Friesian',
      ownerName: 'Shuhrat Karimov',
      region: 'Samarqand',
      district: 'Pastdargʻom',
      clinicName: 'Pastdargʻom tuman davlat vet laboratoriyasi',
      vetDoctorName: 'Dr. Alisher Rasulov',
      lastVaccineDate: '2026-03-15',
      vaccines: [
        { name: 'Kuydirgi (Sibirskaya yazva)', date: '2026-03-15', status: 'ok' },
        { name: 'Oqsil (Yashur)', date: '2026-02-10', status: 'ok' },
        { name: 'Brutsellyoz', date: '2025-11-20', status: 'ok' },
      ],
      isQurbonlikCandidate: true,
      qurbonlikStatus: 'CERTIFIED',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: true,
        eyesClear: true,
        noLimping: true,
      },
      weightKg: 630,
      ageMonths: 28,
    },
    {
      id: 'VET-8802',
      tagNumber: 'UZ-BIRKA-334102',
      passportId: 'UZ-VET-44910-QASH',
      animalType: 'Qoʻchqor',
      breed: 'Hisor qoʻylari',
      ownerName: 'Zokir Chorvador',
      region: 'Qashqadaryo',
      district: 'Dehqonobod',
      clinicName: 'Dehqonobod hududiy veterinariya boʻlimi',
      vetDoctorName: 'Dr. Ilhom Normatov',
      lastVaccineDate: '2026-03-01',
      vaccines: [
        { name: 'Kuydirgi (Sibirskaya yazva)', date: '2026-03-01', status: 'ok' },
        { name: 'Brutsellyoz', date: '2026-01-18', status: 'ok' },
        { name: 'Enterotoksemiya', date: '2026-02-25', status: 'ok' },
      ],
      isQurbonlikCandidate: true,
      qurbonlikStatus: 'CERTIFIED',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: true,
        eyesClear: true,
        noLimping: true,
      },
      weightKg: 125,
      ageMonths: 18,
    },
    {
      id: 'VET-8803',
      tagNumber: 'UZ-BIRKA-771923',
      passportId: 'UZ-VET-11204-AND',
      animalType: 'Buqa',
      breed: 'Brown Swiss (Shvis)',
      ownerName: 'Bekzod Aliyev',
      region: 'Andijon',
      district: 'Asaka',
      clinicName: 'Asaka tuman vet dispanseri',
      vetDoctorName: 'Dr. Dilshodbek Qodirov',
      lastVaccineDate: '2026-01-10',
      vaccines: [
        { name: 'Kuydirgi', date: '2025-06-12', status: 'needed' },
        { name: 'Oqsil', date: '2026-01-10', status: 'ok' },
      ],
      isQurbonlikCandidate: true,
      qurbonlikStatus: 'PENDING_CHECK',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: false, // nuqson
        eyesClear: true,
        noLimping: true,
      },
      weightKg: 580,
      ageMonths: 22,
    },
    {
      id: 'VET-8804',
      tagNumber: 'UZ-BIRKA-550912',
      passportId: 'UZ-VET-99012-JIZ',
      animalType: 'Ot (Aygʻir)',
      breed: 'Qorabayir oti',
      ownerName: 'Rustam Polvon',
      region: 'Jizzax',
      district: 'Baxmal',
      clinicName: 'Jizzax viloyat otchilik veterinariya stansiyasi',
      vetDoctorName: 'Dr. Sardor Boboyev',
      lastVaccineDate: '2026-02-28',
      vaccines: [
        { name: 'Gripp otlar', date: '2026-02-28', status: 'ok' },
        { name: 'Sibirskaya yazva', date: '2025-09-14', status: 'ok' },
      ],
      isQurbonlikCandidate: false,
      qurbonlikStatus: 'DISQUALIFIED',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: true,
        eyesClear: true,
        noLimping: true,
      },
      weightKg: 490,
      ageMonths: 48,
    }
  ]);

  // Selected Vet Animal for Inspection
  const [selectedVetAnimal, setSelectedVetAnimal] = useState<VeterinaryAnimal | null>(null);

  // 3. Initial Live Auctions
  const [auctions, setAuctions] = useState<AdminAuction[]>([
    {
      id: 'AUC-201',
      titleUz: 'Golshtin zotli 8 oylik urugʻlik elita buqacha',
      titleRu: 'Племенной 8-месячный бычок Голштин (Элита)',
      breed: 'Golshtin (Holstein)',
      startingPrice: 11000000,
      currentBid: 13400000,
      minStep: 300000,
      bidsCount: 8,
      endsAt: '2026-10-10T18:00:00Z',
      timeLeftMinutes: 42,
      status: 'ACTIVE',
      imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
      sellerName: 'Toshkent Agro Sut FM',
      leadingBidder: 'Akmal R. (+998 90 ***-88-21)',
      bids: [
        { id: 'b8', user: 'Akmal R.', region: 'Toshkent', amount: 13400000, time: '2 daqiqa oldin' },
        { id: 'b7', user: 'Shoxrux T.', region: 'Samarqand', amount: 13100000, time: '8 daqiqa oldin' },
        { id: 'b6', user: 'Farhod N.', region: 'Andijon', amount: 12800000, time: '22 daqiqa oldin' },
      ]
    },
    {
      id: 'AUC-202',
      titleUz: 'Hisor rekord qoʻchqori (150 kg tirik vazn)',
      titleRu: 'Гиссарский баран-великан (150 кг живой вес)',
      breed: 'Hisor qoʻylari',
      startingPrice: 7500000,
      currentBid: 9200000,
      minStep: 200000,
      bidsCount: 11,
      endsAt: '2026-10-10T20:30:00Z',
      timeLeftMinutes: 195,
      status: 'ACTIVE',
      imageUrl: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
      sellerName: 'Hisor Nasl Buloq FM',
      leadingBidder: 'Mansurxon (+998 93 ***-11-09)',
      bids: [
        { id: 'h11', user: 'Mansurxon', region: 'Buxoro', amount: 9200000, time: '6 daqiqa oldin' },
        { id: 'h10', user: 'Ulugʻbek B.', region: 'Navoiy', amount: 9000000, time: '14 daqiqa oldin' },
      ]
    },
    {
      id: 'AUC-203',
      titleUz: 'Qorabayir 4 yoshli uloqchi zotdor aygʻir',
      titleRu: 'Карабаирский 4-летний жеребец (линия улок)',
      breed: 'Qorabayir oti',
      startingPrice: 42000000,
      currentBid: 48000000,
      minStep: 1000000,
      bidsCount: 6,
      endsAt: '2026-10-11T12:00:00Z',
      timeLeftMinutes: 840,
      status: 'ACTIVE',
      imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
      sellerName: 'Samarqand Qorabayir Majmuasi',
      leadingBidder: 'Botir Polvon (+998 98 ***-44-55)',
      bids: [
        { id: 'q6', user: 'Botir Polvon', region: 'Qashqadaryo', amount: 48000000, time: '12 daqiqa oldin' },
        { id: 'q5', user: 'Jamshidbek', region: 'Jizzax', amount: 47000000, time: '40 daqiqa oldin' },
      ]
    }
  ]);

  // Create Auction Modal State
  const [isCreateAuctionOpen, setIsCreateAuctionOpen] = useState(false);
  const [newAuctionForm, setNewAuctionForm] = useState({
    titleUz: '',
    breed: 'Golshtin (Holstein)',
    startingPrice: 10000000,
    minStep: 300000,
    sellerName: 'ChorvaBozor Rasmiy Rezervi',
    hours: 24,
    imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80'
  });

  // 4. Initial Escrow Transactions
  const [escrowList, setEscrowList] = useState<EscrowTransaction[]>([
    {
      id: 'ESC-9081',
      orderNumber: '#ORD-2026-441',
      buyerName: 'Javohir Toshmatov',
      buyerPhone: '+998 90 123-45-67',
      sellerName: 'Toshkent Agro Sut FM',
      sellerPhone: '+998 91 234-56-78',
      animalTitle: 'Golshtin 2-qorin sigir (28L sut)',
      amountUzs: 32000000,
      feeUzs: 480000, // 1.5%
      sellerPayoutUzs: 31520000,
      status: 'DELIVERED',
      transporter: 'Isuzu Chorvavoz (Haydovchi: Bobur Mirzayev)',
      route: 'Toshkent ➔ Samarqand (310 km)',
      date: 'Bugun, 10:15'
    },
    {
      id: 'ESC-9082',
      orderNumber: '#ORD-2026-442',
      buyerName: 'Olimxon Rahimov',
      buyerPhone: '+998 93 345-67-89',
      sellerName: 'Hisor Nasl Buloq FM',
      sellerPhone: '+998 94 456-78-90',
      animalTitle: '2 bosh Hisor qoʻchqori (Qurbonlik)',
      amountUzs: 16500000,
      feeUzs: 247500, // 1.5%
      sellerPayoutUzs: 16252500,
      status: 'IN_TRANSIT',
      transporter: 'Maxsus 2 qavatli Fura #UZ-774-AA',
      route: 'Qashqadaryo ➔ Buxoro (190 km)',
      date: 'Bugun, 08:30'
    },
    {
      id: 'ESC-9083',
      orderNumber: '#ORD-2026-440',
      buyerName: 'Sherzod Qobilov',
      buyerPhone: '+998 99 987-65-43',
      sellerName: 'Samarqand Otchilik Majmuasi',
      sellerPhone: '+998 97 876-54-32',
      animalTitle: 'Qorabayir aygʻir (Uloqchi)',
      amountUzs: 45000000,
      feeUzs: 675000, // 1.5%
      sellerPayoutUzs: 44325000,
      status: 'RELEASED',
      transporter: 'Maxsus furgon (Haydovchi: Zoirbek)',
      route: 'Samarqand ➔ Toshkent (310 km)',
      date: 'Kecha, 16:40'
    },
    {
      id: 'ESC-9084',
      orderNumber: '#ORD-2026-439',
      buyerName: 'Rustambek Eshmatov',
      buyerPhone: '+998 90 555-11-22',
      sellerName: 'Vodiy Agro Nasl',
      sellerPhone: '+998 91 666-33-44',
      animalTitle: 'Angus zotli buqacha (Semiz)',
      amountUzs: 22000000,
      feeUzs: 330000,
      sellerPayoutUzs: 21670000,
      status: 'HELD',
      transporter: 'Kutilmoqda (Transport tasdiqlanyapti)',
      route: 'Fargʻona ➔ Andijon (85 km)',
      date: 'Bugun, 11:00'
    }
  ]);

  // Moderation Handlers
  const handleApproveListing = (id: string) => {
    setListings((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'APPROVED' } : item))
    );
    triggerToast(
      language === 'uz'
        ? `✅ Eʼlon #${id} tasdiqlandi va platformada faollashtirildi!`
        : `✅ Объявление #${id} одобрено и опубликовано!`
    );
  };

  const handleOpenRejectModal = (item: ModerationListing) => {
    setRejectingListing(item);
  };

  const handleConfirmReject = () => {
    if (!rejectingListing) return;
    setListings((prev) =>
      prev.map((it) =>
        it.id === rejectingListing.id
          ? { ...it, status: 'REJECTED', rejectReason: customRejectReason }
          : it
      )
    );
    triggerToast(
      language === 'uz'
        ? `❌ Eʼlon #${rejectingListing.id} rad etildi. Sababi fermerga SMS/Bot orqali yuborildi.`
        : `❌ Объявление #${rejectingListing.id} отклонено с указанием причины.`
    );
    setRejectingListing(null);
  };

  // Veterinary Certification Handlers
  const handleToggleQurbonlikStatus = (animalId: string) => {
    setVetAnimals((prev) =>
      prev.map((a) => {
        if (a.id === animalId) {
          const nextStatus =
            a.qurbonlikStatus === 'CERTIFIED'
              ? 'DISQUALIFIED'
              : a.qurbonlikStatus === 'DISQUALIFIED'
              ? 'PENDING_CHECK'
              : 'CERTIFIED';
          return { ...a, qurbonlikStatus: nextStatus };
        }
        return a;
      })
    );
    triggerToast(
      language === 'uz'
        ? '🩺 Qurbonlik 2026 holati yangilandi!'
        : '🩺 Статус Курбанлык 2026 обновлен!'
    );
  };

  // Auction Controls Handlers
  const handleExtendAuction = (aucId: string) => {
    setAuctions((prev) =>
      prev.map((a) =>
        a.id === aucId
          ? {
              ...a,
              timeLeftMinutes: a.timeLeftMinutes + 15,
            }
          : a
      )
    );
    triggerToast(
      language === 'uz'
        ? `⏱️ Auksion #${aucId} vaqti +15 daqiqaga uzaytirildi!`
        : `⏱️ Время аукциона #${aucId} продлено на 15 минут!`
    );
  };

  const handleSimulateBid = (aucId: string) => {
    setAuctions((prev) =>
      prev.map((a) => {
        if (a.id === aucId) {
          const nextBid = a.currentBid + a.minStep;
          const newBidEntry = {
            id: `bid-${Date.now()}`,
            user: 'Admin Test Stavkasi (Tizim)',
            region: 'Toshkent',
            amount: nextBid,
            time: 'Hozirgina'
          };
          return {
            ...a,
            currentBid: nextBid,
            bidsCount: a.bidsCount + 1,
            leadingBidder: 'Admin Test Stavkasi',
            bids: [newBidEntry, ...a.bids]
          };
        }
        return a;
      })
    );
    triggerToast(
      language === 'uz'
        ? `🔨 Yangi stavka kiritildi va tekshirildi!`
        : `🔨 Новая ставка зафиксирована!`
    );
  };

  const handleToggleAuctionPause = (aucId: string) => {
    setAuctions((prev) =>
      prev.map((a) =>
        a.id === aucId
          ? {
              ...a,
              status: a.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE',
            }
          : a
      )
    );
    triggerToast(
      language === 'uz' ? `Auksion holati oʻzgartirildi!` : `Статус аукциона изменен!`
    );
  };

  const handleCreateAuctionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuctionForm.titleUz.trim()) return;

    const newAuc: AdminAuction = {
      id: `AUC-${Math.floor(200 + Math.random() * 800)}`,
      titleUz: newAuctionForm.titleUz,
      titleRu: newAuctionForm.titleUz,
      breed: newAuctionForm.breed,
      startingPrice: Number(newAuctionForm.startingPrice),
      currentBid: Number(newAuctionForm.startingPrice),
      minStep: Number(newAuctionForm.minStep),
      bidsCount: 0,
      endsAt: new Date(Date.now() + newAuctionForm.hours * 3600000).toISOString(),
      timeLeftMinutes: newAuctionForm.hours * 60,
      status: 'ACTIVE',
      imageUrl: newAuctionForm.imageUrl,
      sellerName: newAuctionForm.sellerName,
      leadingBidder: 'Hali stavka yoʻq',
      bids: []
    };

    setAuctions([newAuc, ...auctions]);
    setIsCreateAuctionOpen(false);
    triggerToast(
      language === 'uz'
        ? `🎉 Yangi jonli auksion muvaffaqiyatli ishga tushirildi!`
        : `🎉 Новый живой аукцион успешно запущен!`
    );
  };

  // Escrow Release Handler
  const handleReleaseEscrow = (id: string) => {
    setEscrowList((prev) =>
      prev.map((it) => (it.id === id ? { ...it, status: 'RELEASED' } : it))
    );
    triggerToast(
      language === 'uz'
        ? `💰 Mablagʻ sotuvchining hisobiga muvaffaqiyatli oʻtkazildi (1.5% komissiya yechildi)!`
        : `💰 Средства успешно переведены продавцу (комиссия 1.5% удержана)!`
    );
  };

  // Analytics Chart Datasets (14 regions live weight & Breed dynamics)
  const regionLiveWeightData = useMemo(() => [
    { region: 'Toshkent sh.', beef: 52500, sheep: 54000, avg: 53250 },
    { region: 'Toshkent vil.', beef: 50000, sheep: 52000, avg: 51000 },
    { region: 'Andijon', beef: 49500, sheep: 51000, avg: 50250 },
    { region: 'Fargʻona', beef: 49000, sheep: 50000, avg: 49500 },
    { region: 'Namangan', beef: 48800, sheep: 50200, avg: 49500 },
    { region: 'Samarqand', beef: 48500, sheep: 50500, avg: 49500 },
    { region: 'Buxoro', beef: 48000, sheep: 49800, avg: 48900 },
    { region: 'Jizzax', beef: 47800, sheep: 49500, avg: 48650 },
    { region: 'Navoiy', beef: 47500, sheep: 49200, avg: 48350 },
    { region: 'Sirdaryo', beef: 47200, sheep: 49000, avg: 48100 },
    { region: 'Qashqadaryo', beef: 47000, sheep: 49000, avg: 48000 },
    { region: 'Surxondaryo', beef: 46800, sheep: 48800, avg: 47800 },
    { region: 'Xorazm', beef: 46500, sheep: 48500, avg: 47500 },
    { region: 'Qoraqalpogʻ.', beef: 46000, sheep: 48000, avg: 47000 },
  ], []);

  const breedPriceDynamicsData = useMemo(() => [
    { month: 'Noy', golshtin: 29.5, hisor: 7.2, angus: 24.0, qorabayir: 40.0 },
    { month: 'Dek', golshtin: 30.2, hisor: 7.6, angus: 24.8, qorabayir: 41.5 },
    { month: 'Yan', golshtin: 30.8, hisor: 7.9, angus: 25.2, qorabayir: 42.0 },
    { month: 'Fev', golshtin: 31.4, hisor: 8.2, angus: 25.8, qorabayir: 43.5 },
    { month: 'Mar', golshtin: 32.0, hisor: 8.5, angus: 26.5, qorabayir: 45.0 },
    { month: 'Apr (Hozir)', golshtin: 32.6, hisor: 8.8, angus: 27.2, qorabayir: 46.5 },
  ], []);

  // Filtered Moderation Listings based on search query
  const filteredListings = useMemo(() => {
    return listings.filter((item) => {
      const q = searchQuery.toLowerCase();
      return (
        item.titleUz.toLowerCase().includes(q) ||
        item.titleRu.toLowerCase().includes(q) ||
        item.breed.toLowerCase().includes(q) ||
        item.region.toLowerCase().includes(q) ||
        item.sellerName.toLowerCase().includes(q) ||
        item.id.toLowerCase().includes(q)
      );
    });
  }, [listings, searchQuery]);

  return (
    <div className="min-h-screen bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] flex flex-col font-sans transition-colors">
      {/* Toast Alert Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-[#047857] text-white px-5 py-3 rounded-2xl shadow-2xl border border-[#10B981] text-xs sm:text-sm font-semibold flex items-center gap-3 animate-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-5 h-5 text-[#10B981] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Admin Header Bar */}
      <header className="sticky top-0 z-30 bg-[#F7F9F6]/95 dark:bg-[#041C16]/95 backdrop-blur-md border-b border-[#E5ECE7] dark:border-[#0E3D32] transition-colors">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Left: Mobile hamburger & Brand */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
              className="lg:hidden p-2 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-[#072D24] rounded-xl cursor-pointer"
            >
              <MenuIcon className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-800 via-emerald-900 to-stone-900 text-white flex items-center justify-center font-black text-base shadow-sm">
                CH
              </div>
              <div className="leading-tight">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-base tracking-tight font-serif text-stone-950 dark:text-white">
                    ChorvaBozor
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-700 text-white text-[9px] font-black uppercase tracking-wider">
                    ADMIN
                  </span>
                </div>
                <span className="text-[11px] text-emerald-800 dark:text-emerald-400 font-semibold block">
                  {language === 'uz' ? 'Boshqaruv & Nazorat Markazi' : 'Центр Управления и Контроля'}
                </span>
              </div>
            </div>
          </div>

          {/* Center: Quick Search */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                placeholder={
                  language === 'uz'
                    ? 'Eʼlonlar, fermerlar, pasport ID yoki auksionlarni qidirish...'
                    : 'Поиск по объявлениям, фермерам, паспортам ID...'
                }
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-750 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-700 transition-all text-stone-900 dark:text-white"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Right: Actions, Language, Theme, Exit */}
          <div className="flex items-center gap-2">
            {/* Live System Indicator */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{language === 'uz' ? 'Onlayn tizim' : 'Система онлайн'}</span>
            </div>

            {/* Language Switcher */}
            <div className="inline-flex rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-850 p-0.5 text-xs font-bold">
              <button
                type="button"
                onClick={() => onLanguageChange('uz')}
                className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  language === 'uz'
                    ? 'bg-white dark:bg-stone-900 text-emerald-900 dark:text-emerald-400 shadow-xs'
                    : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                UZ
              </button>
              <button
                type="button"
                onClick={() => onLanguageChange('ru')}
                className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  language === 'ru'
                    ? 'bg-white dark:bg-stone-900 text-emerald-900 dark:text-emerald-400 shadow-xs'
                    : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                RU
              </button>
            </div>

            {/* Dark / Light Toggle */}
            <button
              type="button"
              onClick={onToggleDarkMode}
              title={isDarkMode ? 'Yorugʻ rejim' : 'Qorongʻu rejim'}
              className="p-2 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors cursor-pointer border border-stone-200 dark:border-stone-750"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-stone-600" />}
            </button>

            {/* Exit to Marketplace Button */}
            <button
              type="button"
              onClick={onExit}
              className="py-1.5 px-3 sm:px-4 bg-stone-900 hover:bg-stone-800 dark:bg-stone-800 dark:hover:bg-stone-700 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shadow-sm cursor-pointer ml-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">
                {language === 'uz' ? 'Bozorga qaytish' : 'В маркетплейс'}
              </span>
              <span className="sm:hidden">{language === 'uz' ? 'Chiqish' : 'Выход'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Body with Sidebar + Content */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex">
        {/* SIDEBAR NAVIGATION (Desktop permanent, Mobile drawer) */}
        <aside
          className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#EBEFEA] dark:bg-[#02100C] border-r border-[#E5ECE7] dark:border-[#0E3D32] p-4 flex flex-col justify-between transition-transform duration-200 lg:static lg:translate-x-0 ${
            isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="space-y-4">
            {/* Mobile close button */}
            <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800 lg:hidden">
              <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                {language === 'uz' ? 'Boshqaruv menyusi' : 'Меню управления'}
              </span>
              <button
                onClick={() => setIsMobileSidebarOpen(false)}
                className="p-1 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Navigation Tabs */}
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('overview');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-between transition-all cursor-pointer ${
                  activeTab === 'overview'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-850'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <LayoutDashboard className="w-4 h-4" />
                  <span>{language === 'uz' ? '1. Asosiy Statistika' : '1. Главная статистика'}</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('moderation');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-between transition-all cursor-pointer ${
                  activeTab === 'moderation'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-850'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>{language === 'uz' ? '2. AI Moderatsiya' : '2. ИИ Модерация'}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-400 text-stone-950 font-black">
                  {listings.filter((l) => l.status === 'PENDING').length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('veterinary');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-between transition-all cursor-pointer ${
                  activeTab === 'veterinary'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-850'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileCheck className="w-4 h-4" />
                  <span>{language === 'uz' ? '3. Vet & Qurbonlik' : '3. Вет и Курбанлык'}</span>
                </div>
                <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                  2026
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('auctions');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-between transition-all cursor-pointer ${
                  activeTab === 'auctions'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-850'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Gavel className="w-4 h-4" />
                  <span>{language === 'uz' ? '4. Jonli Auksionlar' : '4. Живые аукционы'}</span>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('analytics');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-between transition-all cursor-pointer ${
                  activeTab === 'analytics'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-850'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <TrendingUp className="w-4 h-4" />
                  <span>{language === 'uz' ? '5. Viloyat Indeksi' : '5. Индекс регионов'}</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('escrow');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-between transition-all cursor-pointer ${
                  activeTab === 'escrow'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-850'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <CreditCard className="w-4 h-4" />
                  <span>{language === 'uz' ? '6. Moliya & Eskrou' : '6. Финансы и Эскроу'}</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                  1.5%
                </span>
              </button>
            </div>
          </div>

          {/* Admin User Card / Footer */}
          <div className="pt-4 border-t border-stone-200 dark:border-stone-800 text-xs">
            <div className="p-3 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-xs">
                  OA
                </div>
                <div className="overflow-hidden">
                  <div className="font-bold text-stone-900 dark:text-white truncate">
                    Oybekjon Adashev
                  </div>
                  <div className="text-[10px] text-stone-500 dark:text-stone-400">
                    Bosh Administrator
                  </div>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Backdrop for mobile sidebar */}
        {isMobileSidebarOpen && (
          <div
            onClick={() => setIsMobileSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-30 lg:hidden backdrop-blur-xs"
          />
        )}

        {/* MAIN CONTENT AREA */}
        <main className="flex-1 p-3.5 sm:p-6 lg:p-8 space-y-6 overflow-x-hidden">
          {/* TAB 1: ASOSIY STATISTIKA (KPI CARDS & SUMMARY) */}
          {activeTab === 'overview' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              {/* Header Banner */}
              <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-950 via-emerald-900 to-stone-950 text-white relative overflow-hidden shadow-lg border border-emerald-800/40">
                <div className="relative z-10 max-w-2xl space-y-2">
                  <span className="px-3 py-1 rounded-full bg-amber-400 text-stone-950 text-xs font-black uppercase tracking-wider inline-flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    ChorvaBozor Ekotizim Boshqaruvi
                  </span>
                  <h1 className="text-2xl sm:text-3xl font-black font-serif tracking-tight">
                    {language === 'uz'
                      ? 'Xush kelibsiz, Bosh Administrator!'
                      : 'Добро пожаловать в Панель Управления!'}
                  </h1>
                  <p className="text-xs sm:text-sm text-emerald-200/90 leading-relaxed">
                    {language === 'uz'
                      ? 'Bugungi barcha eʼlonlar, AI moderatsiyasi, xavfsiz eskrou toʻlovlari va viloyatlararo fura marshrutlari nazorati toʻliq qoʻlingizda.'
                      : 'Полный контроль над объявлениями, ИИ-модерацией, безопасными сделками эскроу и фурами по Узбекистану.'}
                  </p>
                </div>
                <div className="absolute right-4 -bottom-6 opacity-10 text-[140px] font-black select-none pointer-events-none font-serif">
                  CHB
                </div>
              </div>

              {/* 4 Core KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Jami faol e'lonlar */}
                <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-stone-500 dark:text-stone-400">
                        {language === 'uz' ? 'JAMI FAOL EʼLONLAR' : 'АКТИВНЫЕ ОБЪЯВЛЕНИЯ'}
                      </span>
                      <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-400 flex items-center justify-center">
                        <Layers className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-stone-900 dark:text-white font-mono">
                      1,482 ta
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>+12.4% bu haftada</span>
                    </div>
                  </div>
                  {/* Category Breakdown */}
                  <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>🐂 Qoramol:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">890 ta (60%)</span>
                    </div>
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>🐑 Qoʻy / Qoʻchqor:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">442 ta (30%)</span>
                    </div>
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>🐎 Otlar:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">150 ta (10%)</span>
                    </div>
                  </div>
                </div>

                {/* 2. Bugungi Eskrou Bitimlari & Komissiya */}
                <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-stone-500 dark:text-stone-400">
                        {language === 'uz' ? 'BUGUNGI ESKROU BITIMLARI' : 'СДЕЛКИ ЭСКРОУ СЕГОДНЯ'}
                      </span>
                      <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-400 flex items-center justify-center">
                        <CreditCard className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-stone-900 dark:text-white font-mono">
                      485 mln soʻm
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400 font-bold mt-1">
                      <span>18 ta xavfsiz bitim nazoratda</span>
                    </div>
                  </div>
                  {/* Platform Fee info */}
                  <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>Platforma daromadi (1.5%):</span>
                      <span className="font-mono font-black text-emerald-700 dark:text-emerald-400">
                        7,275,000 soʻm
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-[11px]">
                      <span>Kafolat holati:</span>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">100% Sugʻurtalangan</span>
                    </div>
                  </div>
                </div>

                {/* 3. Fermerlar & Vet vrachlar */}
                <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-stone-500 dark:text-stone-400">
                        {language === 'uz' ? 'VERIFIKATSIYADAN OʻTGANLAR' : 'ВЕРИФИЦИРОВАНЫ'}
                      </span>
                      <div className="w-8 h-8 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-400 flex items-center justify-center">
                        <Users className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-stone-900 dark:text-white font-mono">
                      3,982 nafar
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-teal-600 dark:text-teal-400 font-bold mt-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>98.6% ishonchlilik reytingi</span>
                    </div>
                  </div>
                  {/* Breakdown */}
                  <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>👨‍🌾 Tasdiqlangan fermerlar:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">3,840 ta</span>
                    </div>
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>🩺 Vet vrachlar reyestri:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">142 nafar</span>
                    </div>
                  </div>
                </div>

                {/* 4. Faol Logistika & Fura buyurtmalari */}
                <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-stone-500 dark:text-stone-400">
                        {language === 'uz' ? 'VILOYATLARARO LOGISTIKA' : 'МЕЖОБЛАСТНАЯ ЛОГИСТИКА'}
                      </span>
                      <div className="w-8 h-8 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-400 flex items-center justify-center">
                        <Truck className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-stone-900 dark:text-white font-mono">
                      38 ta Fura
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                      <span>14 viloyat oʻrtasida harakatda</span>
                    </div>
                  </div>
                  {/* Status */}
                  <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>2 qavatli chorvavozlar:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">19 ta</span>
                    </div>
                    <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                      <span>Isuzu / Gazel furgonlar:</span>
                      <span className="font-mono font-bold text-stone-900 dark:text-white">19 ta</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Actions & Pending Moderation Preview */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* 2 Cols: Pending Moderation Quick List */}
                <div className="lg:col-span-2 p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-bold text-stone-900 dark:text-white flex items-center gap-2">
                        <ShieldAlert className="w-4 h-4 text-amber-500" />
                        <span>{language === 'uz' ? 'Tasdiqlash kutilayotgan eʼlonlar' : 'Ожидают модерации'}</span>
                      </h3>
                      <p className="text-xs text-stone-500 dark:text-stone-400">
                        AI filtri tekshiruvidan oʻtgan soʻnggi arizalar
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab('moderation')}
                      className="text-xs font-bold text-emerald-800 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>Barchasini koʻrish</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="divide-y divide-stone-100 dark:divide-stone-800">
                    {listings
                      .filter((l) => l.status === 'PENDING')
                      .slice(0, 3)
                      .map((item) => (
                        <div key={item.id} className="py-3 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <img
                              src={item.imageUrl}
                              alt={item.titleUz}
                              className="w-12 h-12 rounded-xl object-cover"
                            />
                            <div>
                              <div className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white line-clamp-1">
                                {item.titleUz}
                              </div>
                              <div className="text-[11px] text-stone-500 dark:text-stone-400 flex items-center gap-2">
                                <span>{item.breed}</span>
                                <span>·</span>
                                <span>{item.weightKg} kg</span>
                                <span>·</span>
                                <span className="font-mono font-bold text-emerald-800 dark:text-emerald-400">
                                  {new Intl.NumberFormat('uz-UZ').format(item.priceUzs)} soʻm
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => handleApproveListing(item.id)}
                              className="p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Tasdiqlash</span>
                            </button>
                            <button
                              onClick={() => handleOpenRejectModal(item)}
                              className="p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Rad etish</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* 1 Col: Quick Control Shortcuts */}
                <div className="p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base font-bold text-stone-900 dark:text-white mb-1">
                      {language === 'uz' ? 'Tezkor Amallar' : 'Быстрые действия'}
                    </h3>
                    <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">
                      Tizim boʻyicha eng koʻp qoʻllaniladigan boshqaruv vositalari
                    </p>

                    <div className="space-y-2.5">
                      <button
                        onClick={() => {
                          setActiveTab('auctions');
                          setIsCreateAuctionOpen(true);
                        }}
                        className="w-full p-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 text-emerald-900 dark:text-emerald-300 font-bold text-xs flex items-center justify-between cursor-pointer transition-colors border border-emerald-200 dark:border-emerald-800/60"
                      >
                        <div className="flex items-center gap-2">
                          <Gavel className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                          <span>Yangi Jonli Auksion eʼlon qilish</span>
                        </div>
                        <Plus className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setActiveTab('veterinary')}
                        className="w-full p-3 rounded-2xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 text-amber-950 dark:text-amber-300 font-bold text-xs flex items-center justify-between cursor-pointer transition-colors border border-amber-200 dark:border-amber-800/60"
                      >
                        <div className="flex items-center gap-2">
                          <Award className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                          <span>Qurbonlik 2026 sertifikatlarini tekshirish</span>
                        </div>
                        <ChevronRight className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setActiveTab('escrow')}
                        className="w-full p-3 rounded-2xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-750 text-stone-800 dark:text-stone-200 font-bold text-xs flex items-center justify-between cursor-pointer transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-4 h-4 text-stone-600 dark:text-stone-400" />
                          <span>Kafolatlangan toʻlovlarni chiqarish</span>
                        </div>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-850 text-[11px] text-stone-500 dark:text-stone-400 flex items-center gap-2">
                    <Info className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Barcha maʼlumotlar har 60 soniyada avtomatik ravishda yangilanadi.</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: REAL-VAQT MODERATSIYA MARKAZI (AI Moderation & Listings) */}
          {activeTab === 'moderation' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-stone-900 dark:text-white flex items-center gap-2 font-serif">
                    <ShieldCheck className="w-5 h-5 text-emerald-700" />
                    <span>{language === 'uz' ? 'AI Moderatsiya va Eʼlonlar Nazorati' : 'ИИ Модерация и Контроль Объявлений'}</span>
                  </h2>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    {language === 'uz'
                      ? 'Fermerlar yuklagan foto, video, narx va davlat veterinariya pasportlarini real vaqtda tasdiqlash'
                      : 'Проверка фото, видео, цен и ветпаспортов, загруженных фермерами в реальном времени'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-stone-500">
                    Jami koʻrilmoqda: <strong className="text-stone-900 dark:text-white font-mono">{filteredListings.length}</strong>
                  </span>
                </div>
              </div>

              {/* Listings Table / Cards */}
              <div className="space-y-4">
                {filteredListings.map((item) => (
                  <div
                    key={item.id}
                    className="p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4 transition-all"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      {/* Left: Animal Image & Identity */}
                      <div className="flex items-start gap-4">
                        <div className="relative shrink-0">
                          <img
                            src={item.imageUrl}
                            alt={item.titleUz}
                            className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shadow-xs"
                          />
                          {item.hasVideo && (
                            <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/80 text-white text-[9px] font-bold flex items-center gap-1">
                              <Play className="w-2.5 h-2.5 fill-current" />
                              Video
                            </span>
                          )}
                        </div>

                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-xs font-mono font-bold text-emerald-800 dark:text-emerald-400">
                              {item.id}
                            </span>
                            <span className="text-stone-300 dark:text-stone-700">·</span>
                            <span className="text-xs text-stone-500 dark:text-stone-400 font-semibold">
                              {item.region}, {item.district}
                            </span>
                            <span className="text-stone-300 dark:text-stone-700">·</span>
                            <span className="text-[11px] text-stone-400">{item.submittedAt}</span>
                          </div>

                          <h3 className="font-bold text-sm sm:text-base text-stone-950 dark:text-white">
                            {item.titleUz}
                          </h3>

                          <div className="flex flex-wrap items-center gap-3 text-xs text-stone-600 dark:text-stone-300">
                            <span>
                              Zoti: <strong className="text-stone-900 dark:text-white">{item.breed}</strong>
                            </span>
                            <span>
                              Tirik vazn: <strong className="text-stone-900 dark:text-white font-mono">{item.weightKg} kg</strong>
                            </span>
                            <span>
                              Narx: <strong className="text-emerald-800 dark:text-emerald-400 font-mono font-extrabold text-sm">{new Intl.NumberFormat('uz-UZ').format(item.priceUzs)} soʻm</strong>
                            </span>
                          </div>

                          {/* Seller & Vet ID */}
                          <div className="flex flex-wrap items-center gap-3 text-[11px] text-stone-500 dark:text-stone-400 pt-1">
                            <span className="flex items-center gap-1">
                              <Users className="w-3.5 h-3.5" />
                              {item.sellerName} ({item.sellerPhone})
                            </span>
                            <span className="flex items-center gap-1 text-emerald-800 dark:text-emerald-400 font-mono font-bold">
                              <FileCheck className="w-3.5 h-3.5" />
                              Vet Pasport: {item.vetPassportNumber}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right: Actions & Status */}
                      <div className="flex flex-col sm:flex-row lg:flex-col items-end gap-2.5 shrink-0 justify-between">
                        {/* Status badge */}
                        <div className="flex items-center gap-2">
                          {item.status === 'PENDING' && (
                            <span className="px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 text-xs font-black flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              KUTILMOQDA
                            </span>
                          )}
                          {item.status === 'APPROVED' && (
                            <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-300 text-xs font-black flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              TASDIQLANGAN
                            </span>
                          )}
                          {item.status === 'REJECTED' && (
                            <span className="px-2.5 py-1 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-900 dark:text-rose-300 text-xs font-black flex items-center gap-1">
                              <XCircle className="w-3 h-3" />
                              RAD ETILGAN
                            </span>
                          )}
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setInspectingListing(item)}
                            className="p-2 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700 cursor-pointer transition-colors"
                            title="Batafsil koʻrish"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleApproveListing(item.id)}
                            disabled={item.status === 'APPROVED'}
                            className="py-2 px-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                          >
                            <Check className="w-4 h-4" />
                            <span>Tasdiqlash</span>
                          </button>
                          <button
                            onClick={() => handleOpenRejectModal(item)}
                            disabled={item.status === 'REJECTED'}
                            className="py-2 px-3.5 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border border-rose-200 dark:border-rose-800"
                          >
                            <X className="w-4 h-4" />
                            <span>Rad etish</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* AI Screening Assessment Box */}
                    <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-start gap-2.5">
                        <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-bold text-stone-900 dark:text-white flex items-center gap-2">
                            <span>AI Moderatsiya & Xavfsizlik Tahlili</span>
                            <span className="font-mono text-[11px] px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                              Ishonch: {item.aiScore}%
                            </span>
                          </div>
                          <p className="text-stone-600 dark:text-stone-300 text-[11px] mt-0.5">
                            {language === 'uz' ? item.aiNotesUz : item.aiNotesRu}
                          </p>
                          {item.rejectReason && (
                            <p className="text-rose-700 dark:text-rose-400 font-semibold text-[11px] mt-1">
                              Rad etish sababi: {item.rejectReason}
                            </p>
                          )}
                        </div>
                      </div>

                      {item.aiFlag === 'SUSPICIOUS_PRICE' && (
                        <div className="px-2.5 py-1 rounded-xl bg-rose-100 text-rose-900 font-extrabold text-[11px] flex items-center gap-1 shrink-0">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Shubhali arzon narx!</span>
                        </div>
                      )}
                      {item.aiFlag === 'HIGH_DEMAND' && (
                        <div className="px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-900 font-extrabold text-[11px] flex items-center gap-1 shrink-0">
                          <Flame className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Yuqori talab zoti</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: VETERINARIYA VA PASPORT NAZORATI (Veterinary & Qurbonlik 2026) */}
          {activeTab === 'veterinary' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-stone-900 dark:text-white flex items-center gap-2 font-serif">
                    <Stethoscope className="w-5 h-5 text-emerald-700" />
                    <span>{language === 'uz' ? 'Davlat Veterinariya Reyestri & Qurbonlik 2026' : 'Госвет Реестр и Курбанлык 2026'}</span>
                  </h2>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    {language === 'uz'
                      ? 'Davlat veterinariya pasportlari, emlash holati va Shariat talablariga mos Qurbonlik sertifikatlari'
                      : 'Госветпаспорта, вакцинация и сертификация жертвенных животных по стандартам'}
                  </p>
                </div>
              </div>

              {/* Veterinary Registry Table */}
              <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
                  <div className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-emerald-700" />
                    <span>Tasdiqlangan Jonivorlar Roʻyxati ({vetAnimals.length})</span>
                  </div>
                  <span className="text-[11px] text-stone-500">
                    Oxirgi yangilanish: bugun 11:20
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-stone-50 dark:bg-stone-850 text-stone-500 dark:text-stone-400 font-semibold border-b border-stone-200 dark:border-stone-800">
                      <tr>
                        <th className="p-3.5">Birka / Pasport ID</th>
                        <th className="p-3.5">Turi & Zoti</th>
                        <th className="p-3.5">Egasi & Manzil</th>
                        <th className="p-3.5">Emlashlar</th>
                        <th className="p-3.5 text-center">Qurbonlik 2026 Holati</th>
                        <th className="p-3.5 text-right">Amal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                      {vetAnimals.map((animal) => (
                        <tr key={animal.id} className="hover:bg-stone-50/60 dark:hover:bg-stone-850/60 transition-colors">
                          <td className="p-3.5">
                            <div className="font-mono font-bold text-stone-900 dark:text-white">
                              {animal.tagNumber}
                            </div>
                            <div className="text-[11px] font-mono text-emerald-800 dark:text-emerald-400">
                              {animal.passportId}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-bold text-stone-900 dark:text-white">
                              {animal.animalType}
                            </div>
                            <div className="text-[11px] text-stone-500">
                              {animal.breed} · {animal.weightKg} kg · {animal.ageMonths} oylik
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-semibold text-stone-900 dark:text-white">
                              {animal.ownerName}
                            </div>
                            <div className="text-[11px] text-stone-500">
                              {animal.region}, {animal.district}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="space-y-0.5">
                              {animal.vaccines.map((v, i) => (
                                <div key={i} className="flex items-center gap-1 text-[11px]">
                                  {v.status === 'ok' ? (
                                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                  ) : (
                                    <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0" />
                                  )}
                                  <span className="text-stone-700 dark:text-stone-300">{v.name}</span>
                                </div>
                              ))}
                            </div>
                          </td>

                          <td className="p-3.5 text-center">
                            {animal.qurbonlikStatus === 'CERTIFIED' && (
                              <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold text-[11px] inline-flex items-center gap-1">
                                <span>🌙 Sertifikatlangan</span>
                              </span>
                            )}
                            {animal.qurbonlikStatus === 'PENDING_CHECK' && (
                              <span className="px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-extrabold text-[11px] inline-flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>Tekshiruvda</span>
                              </span>
                            )}
                            {animal.qurbonlikStatus === 'DISQUALIFIED' && (
                              <span className="px-2.5 py-1 rounded-full bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400 font-bold text-[11px] inline-flex items-center gap-1">
                                <span>Mos kelmaydi</span>
                              </span>
                            )}
                          </td>

                          <td className="p-3.5 text-right">
                            <button
                              type="button"
                              onClick={() => handleToggleQurbonlikStatus(animal.id)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs transition-colors cursor-pointer"
                            >
                              Statusni oʻzgartirish
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: JONLI AUKSIONLARNI BOSHQARISH (Live Auctions Control) */}
          {activeTab === 'auctions' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-stone-900 dark:text-white flex items-center gap-2 font-serif">
                    <Gavel className="w-5 h-5 text-emerald-700" />
                    <span>{language === 'uz' ? 'Jonli Auksionlar Boshqaruv Paneli' : 'Управление Живыми Аукционами'}</span>
                  </h2>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    {language === 'uz'
                      ? 'Aktiv auksionlar taymeri, boshlangʻich narxlar, qadamlar va stavkalar nazorati'
                      : 'Контроль таймеров активных аукционов, шагов ставок и победителей'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsCreateAuctionOpen(true)}
                  className="py-2.5 px-4 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-2xl flex items-center gap-2 cursor-pointer transition-all shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'uz' ? 'Yangi Auksion Boshlash' : 'Создать новый аукцион'}</span>
                </button>
              </div>

              {/* Live Auctions Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {auctions.map((auc) => (
                  <div
                    key={auc.id}
                    className="p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between space-y-4"
                  >
                    <div>
                      {/* Image & Status Tag */}
                      <div className="relative h-44 rounded-2xl overflow-hidden mb-3">
                        <img
                          src={auc.imageUrl}
                          alt={auc.titleUz}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                          <span className="px-2.5 py-1 rounded-full bg-emerald-600 text-white font-bold text-[10px] flex items-center gap-1 shadow-md">
                            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                            JONLI AUKSION
                          </span>
                        </div>
                        <div className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md text-amber-300 font-mono font-bold text-xs flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{auc.timeLeftMinutes} daqiqa qoldi</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                        <span className="font-mono font-bold text-emerald-800 dark:text-emerald-400">
                          {auc.id}
                        </span>
                        <span>{auc.breed}</span>
                      </div>

                      <h3 className="font-bold text-sm text-stone-900 dark:text-white line-clamp-1">
                        {auc.titleUz}
                      </h3>

                      {/* Current Bid & Min Step */}
                      <div className="mt-3 p-3 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-800 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-stone-500">Joriy stavka:</span>
                          <span className="text-base font-black text-emerald-800 dark:text-emerald-400 font-mono">
                            {new Intl.NumberFormat('uz-UZ').format(auc.currentBid)} soʻm
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-stone-500">
                          <span>Boshlangʻich narx:</span>
                          <span className="font-mono">
                            {new Intl.NumberFormat('uz-UZ').format(auc.startingPrice)} soʻm
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-stone-500">
                          <span>Minimal qadam:</span>
                          <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                            +{new Intl.NumberFormat('uz-UZ').format(auc.minStep)} soʻm
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-stone-200/60 dark:border-stone-700">
                          <span className="text-stone-500">Yetakchi xaridor:</span>
                          <span className="font-bold text-stone-900 dark:text-white truncate max-w-[140px]">
                            {auc.leadingBidder}
                          </span>
                        </div>
                      </div>

                      {/* Recent Bids Feed */}
                      <div className="mt-3 space-y-1">
                        <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">
                          Soʻnggi Stavkalar Tarixi:
                        </span>
                        {auc.bids.slice(0, 2).map((b) => (
                          <div
                            key={b.id}
                            className="flex items-center justify-between text-[11px] py-1 border-b border-stone-100 dark:border-stone-800"
                          >
                            <span className="font-semibold text-stone-700 dark:text-stone-300">
                              {b.user} ({b.region})
                            </span>
                            <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
                              {new Intl.NumberFormat('uz-UZ').format(b.amount)} soʻm
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Controls Footer */}
                    <div className="pt-2 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between gap-2">
                      <button
                        onClick={() => handleExtendAuction(auc.id)}
                        className="flex-1 py-2 px-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                        title="Vaqtni uzaytirish"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>+15 daqiqa</span>
                      </button>

                      <button
                        onClick={() => handleSimulateBid(auc.id)}
                        className="flex-1 py-2 px-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Stavka berish</span>
                      </button>

                      <button
                        onClick={() => handleToggleAuctionPause(auc.id)}
                        className={`p-2 rounded-xl transition-colors cursor-pointer ${
                          auc.status === 'ACTIVE'
                            ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                            : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                        }`}
                        title={auc.status === 'ACTIVE' ? 'Toʻxtatib turish' : 'Davom ettirish'}
                      >
                        {auc.status === 'ACTIVE' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: VILOYATLAR NARX INDEKSI & ANALITIKA (Analytics & Charts) */}
          {activeTab === 'analytics' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-stone-900 dark:text-white flex items-center gap-2 font-serif">
                    <TrendingUp className="w-5 h-5 text-emerald-700" />
                    <span>{language === 'uz' ? 'Viloyatlar Narx Indeksi va Zotlar Dinamikasi' : 'Индекс Цен Регионов и Динамика Пород'}</span>
                  </h2>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    Oʻzbekistonning 14 ta hududida tirik vazn narxlari dinamikasi va zotlar tahlili
                  </p>
                </div>
              </div>

              {/* Analytics Key Numbers */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                  <span className="text-xs font-bold text-stone-500 block mb-1">
                    Oʻrtacha Respublika Tirik Vazn:
                  </span>
                  <div className="text-2xl font-black text-emerald-800 dark:text-emerald-400 font-mono">
                    48,800 soʻm/kg
                  </div>
                  <span className="text-[11px] text-emerald-600 font-semibold">+1.8% oʻtgan haftaga nisbatan</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                  <span className="text-xs font-bold text-stone-500 block mb-1">
                    Eng Yuqori Narxli Hudud:
                  </span>
                  <div className="text-2xl font-black text-stone-900 dark:text-white font-mono">
                    Toshkent shahri (52.5k)
                  </div>
                  <span className="text-[11px] text-stone-500">Poytaxtda isteʼmol talabi yuqori</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                  <span className="text-xs font-bold text-stone-500 block mb-1">
                    Eng Hamyonbop Manzil:
                  </span>
                  <div className="text-2xl font-black text-amber-600 dark:text-amber-400 font-mono">
                    Qoraqalpogʻiston (46.0k)
                  </div>
                  <span className="text-[11px] text-stone-500">Yirik boʻrdoqichilik fermalari mavjud</span>
                </div>
              </div>

              {/* Chart 1: 14 Regions Live Weight Comparison (Recharts BarChart) */}
              <div className="p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                    14 ta Hudud Boʻyicha Tirik Vazn Narxlari (soʻm / kg)
                  </h3>
                  <p className="text-xs text-stone-500">
                    Qoramol va Qoʻy tirik vazni narxlari taqqoslash
                  </p>
                </div>

                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={regionLiveWeightData} margin={{ top: 10, right: 10, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" opacity={0.5} />
                      <XAxis
                        dataKey="region"
                        tick={{ fontSize: 10, fill: '#78716c' }}
                        interval={0}
                        angle={-30}
                        textAnchor="end"
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: '#78716c' }}
                        domain={[40000, 56000]}
                        tickFormatter={(v) => `${v / 1000}k`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1c1917',
                          color: '#fff',
                          borderRadius: '12px',
                          border: 'none',
                          fontSize: '12px'
                        }}
                        formatter={(val: any) => [`${new Intl.NumberFormat('uz-UZ').format(val)} soʻm/kg`]}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Bar dataKey="beef" name="Qoramol (soʻm/kg)" fill="#065f46" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="sheep" name="Qoʻy / Qoʻchqor (soʻm/kg)" fill="#d97706" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chart 2: Zotlar Oylik Narx Dinamikasi (Recharts AreaChart) */}
              <div className="p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-stone-900 dark:text-white">
                    Zotlar Boʻyicha Oylik Oʻrtacha Narx Dinamikasi (mln soʻm)
                  </h3>
                  <p className="text-xs text-stone-500">
                    Golshtin, Black Angus, Hisor va Qorabayir narx trendi
                  </p>
                </div>

                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={breedPriceDynamicsData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorGolshtin" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#047857" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#047857" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="colorHisor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#d97706" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#d97706" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" opacity={0.5} />
                      <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#78716c' }} />
                      <YAxis tick={{ fontSize: 11, fill: '#78716c' }} tickFormatter={(v) => `${v}m`} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1c1917',
                          color: '#fff',
                          borderRadius: '12px',
                          border: 'none',
                          fontSize: '12px'
                        }}
                        formatter={(val: any) => [`${val} mln soʻm`]}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Area
                        type="monotone"
                        dataKey="golshtin"
                        name="Golshtin Sigir (mln soʻm)"
                        stroke="#047857"
                        strokeWidth={2.5}
                        fillOpacity={1}
                        fill="url(#colorGolshtin)"
                      />
                      <Area
                        type="monotone"
                        dataKey="hisor"
                        name="Hisor Qoʻchqori (mln soʻm)"
                        stroke="#d97706"
                        strokeWidth={2.5}
                        fillOpacity={1}
                        fill="url(#colorHisor)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: MOLIYA VA ESKROU (Escrow & Transactions) */}
          {activeTab === 'escrow' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-stone-900 dark:text-white flex items-center gap-2 font-serif">
                    <CreditCard className="w-5 h-5 text-emerald-700" />
                    <span>{language === 'uz' ? 'Xavfsiz Toʻlovlar va Eskrou Kafolati' : 'Безопасные Платежи и Гарантия Эскроу'}</span>
                  </h2>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    {language === 'uz'
                      ? 'Xaridor puli saqlangan, mol yetkazilgan va sotuvchiga oʻtkaziladigan bitimlar zanjiri'
                      : 'Цепочка сделок: депозит заблокирован, скот доставлен и расчет с продавцом'}
                  </p>
                </div>
              </div>

              {/* Escrow Balance Metrics */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                  <span className="text-xs font-bold text-stone-500 block mb-1">
                    Eskrouda Muzlatilgan Mablagʻ:
                  </span>
                  <div className="text-2xl font-black text-stone-900 dark:text-white font-mono">
                    115,500,000 soʻm
                  </div>
                  <span className="text-[11px] text-emerald-600 font-semibold">Mol yetkazilishi kutilmoqda</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                  <span className="text-xs font-bold text-stone-500 block mb-1">
                    Sotuvchilarga Toʻlangan (Bugun):
                  </span>
                  <div className="text-2xl font-black text-emerald-800 dark:text-emerald-400 font-mono">
                    369,500,000 soʻm
                  </div>
                  <span className="text-[11px] text-stone-500">14 ta muvaffaqiyatli topshiruv</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                  <span className="text-xs font-bold text-stone-500 block mb-1">
                    Platforma Sof Komissiyasi (1.5%):
                  </span>
                  <div className="text-2xl font-black text-amber-600 dark:text-amber-400 font-mono">
                    7,275,000 soʻm
                  </div>
                  <span className="text-[11px] text-stone-500">Bugungi sof operatsion tushum</span>
                </div>
              </div>

              {/* Transactions List */}
              <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
                  <div className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white flex items-center gap-2">
                    <Lock className="w-4 h-4 text-emerald-700" />
                    <span>Faol Eskrou Tranzaksiyalari Roʻyxati</span>
                  </div>
                  <span className="text-[11px] text-stone-500">
                    Kafolatli bank hisob raqami: #UZ88-CHORVA-ESCROW
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-stone-50 dark:bg-stone-850 text-stone-500 dark:text-stone-400 font-semibold border-b border-stone-200 dark:border-stone-800">
                      <tr>
                        <th className="p-3.5">Bitim / Buyurtma #</th>
                        <th className="p-3.5">Xaridor & Sotuvchi</th>
                        <th className="p-3.5">Chorva Mahsuloti</th>
                        <th className="p-3.5">Summa & 1.5% Fee</th>
                        <th className="p-3.5">Marshrut & Holat</th>
                        <th className="p-3.5 text-right">Amal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                      {escrowList.map((esc) => (
                        <tr key={esc.id} className="hover:bg-stone-50/60 dark:hover:bg-stone-850/60 transition-colors">
                          <td className="p-3.5">
                            <div className="font-mono font-bold text-stone-900 dark:text-white">
                              {esc.id}
                            </div>
                            <div className="text-[11px] text-stone-400 font-mono">
                              {esc.orderNumber}
                            </div>
                            <div className="text-[10px] text-stone-400 mt-0.5">{esc.date}</div>
                          </td>

                          <td className="p-3.5">
                            <div className="text-stone-900 dark:text-white">
                              <span className="text-stone-500 text-[10px] block">Xaridor:</span>
                              <strong>{esc.buyerName}</strong> ({esc.buyerPhone})
                            </div>
                            <div className="text-stone-900 dark:text-white mt-1">
                              <span className="text-stone-500 text-[10px] block">Sotuvchi:</span>
                              <strong>{esc.sellerName}</strong>
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-bold text-stone-900 dark:text-white">
                              {esc.animalTitle}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-mono font-extrabold text-stone-900 dark:text-white">
                              {new Intl.NumberFormat('uz-UZ').format(esc.amountUzs)} soʻm
                            </div>
                            <div className="text-[11px] font-mono text-emerald-800 dark:text-emerald-400">
                              Fee: {new Intl.NumberFormat('uz-UZ').format(esc.feeUzs)} soʻm
                            </div>
                            <div className="text-[10px] text-stone-400">
                              Sotuvchiga: {new Intl.NumberFormat('uz-UZ').format(esc.sellerPayoutUzs)} soʻm
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="text-stone-800 dark:text-stone-200 font-semibold mb-1">
                              {esc.route}
                            </div>
                            {esc.status === 'HELD' && (
                              <span className="px-2 py-0.5 rounded-full bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-bold text-[10px] inline-flex items-center gap-1">
                                <Lock className="w-2.5 h-2.5" />
                                Pul muzlatilgan
                              </span>
                            )}
                            {esc.status === 'IN_TRANSIT' && (
                              <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold text-[10px] inline-flex items-center gap-1">
                                <Truck className="w-2.5 h-2.5" />
                                Fura yoʻlda
                              </span>
                            )}
                            {esc.status === 'DELIVERED' && (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold text-[10px] inline-flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5" />
                                Yetkazildi (Kutilyapti)
                              </span>
                            )}
                            {esc.status === 'RELEASED' && (
                              <span className="px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 font-bold text-[10px] inline-flex items-center gap-1">
                                <Check className="w-2.5 h-2.5" />
                                Sotuvchiga toʻlandi
                              </span>
                            )}
                          </td>

                          <td className="p-3.5 text-right">
                            {esc.status !== 'RELEASED' ? (
                              <button
                                type="button"
                                onClick={() => handleReleaseEscrow(esc.id)}
                                className="px-3 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs transition-colors cursor-pointer whitespace-nowrap shadow-xs"
                              >
                                Pulni chiqarish →
                              </button>
                            ) : (
                              <span className="text-[11px] text-stone-400 font-semibold">Yakunlangan</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL 1: Rad etish sababi modali */}
      {rejectingListing && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-stone-900 rounded-3xl max-w-md w-full border border-stone-200 dark:border-stone-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-stone-900 dark:text-white flex items-center gap-2">
                <XCircle className="w-5 h-5 text-rose-600" />
                <span>Eʼlonni Rad Etish Sababi</span>
              </h3>
              <button
                onClick={() => setRejectingListing(null)}
                className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-500">
              Eʼlon: <strong>{rejectingListing.titleUz}</strong> (#{rejectingListing.id})
            </p>

            <div className="space-y-2 text-xs">
              <label className="block font-semibold text-stone-700 dark:text-stone-300">
                Standart sabablardan birini tanlang:
              </label>
              {[
                'Rasm sifati past yoki boshqa manbadan olingan',
                'Tirik vazn va narx nomutanosib (shubhali arzon)',
                'Davlat vet pasport raqami tasdiqlanmadi',
                'Kategoriya yoki zot notoʻgʻri koʻrsatilgan',
                'Bogʻlanish telefon raqami notoʻgʻri yoki oʻchiq'
              ].map((reason) => (
                <button
                  key={reason}
                  type="button"
                  onClick={() => setCustomRejectReason(reason)}
                  className={`w-full p-2.5 rounded-xl border text-left text-xs transition-colors cursor-pointer ${
                    customRejectReason === reason
                      ? 'border-rose-600 bg-rose-50 dark:bg-rose-950/60 text-rose-950 dark:text-rose-200 font-bold'
                      : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800'
                  }`}
                >
                  {reason}
                </button>
              ))}
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                Yoki qoʻshimcha izoh yozing:
              </label>
              <textarea
                value={customRejectReason}
                onChange={(e) => setCustomRejectReason(e.target.value)}
                rows={2}
                className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-600 text-stone-900 dark:text-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100 dark:border-stone-800">
              <button
                type="button"
                onClick={() => setRejectingListing(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
              >
                Bekor qilish
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white cursor-pointer shadow-sm"
              >
                Rad etishni tasdiqlash
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: E'lonni to'liq ko'rish modali */}
      {inspectingListing && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-stone-900 rounded-3xl max-w-2xl w-full border border-stone-200 dark:border-stone-800 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50 dark:bg-stone-850">
              <div className="font-bold text-sm text-stone-900 dark:text-white">
                Eʼlon Tekshiruvi: {inspectingListing.id}
              </div>
              <button
                onClick={() => setInspectingListing(null)}
                className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <img
                src={inspectingListing.imageUrl}
                alt={inspectingListing.titleUz}
                className="w-full h-56 object-cover rounded-2xl"
              />
              <div className="space-y-1">
                <h3 className="font-bold text-base text-stone-900 dark:text-white">
                  {inspectingListing.titleUz}
                </h3>
                <p className="text-stone-500">
                  {inspectingListing.region}, {inspectingListing.district} · {inspectingListing.submittedAt}
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
                <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800">
                  <span className="text-[10px] text-stone-500 block font-sans">Zoti:</span>
                  <strong className="text-stone-900 dark:text-white font-sans">{inspectingListing.breed}</strong>
                </div>
                <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800">
                  <span className="text-[10px] text-stone-500 block font-sans">Vazni:</span>
                  <strong className="text-stone-900 dark:text-white">{inspectingListing.weightKg} kg</strong>
                </div>
                <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800">
                  <span className="text-[10px] text-stone-500 block font-sans">Narxi:</span>
                  <strong className="text-emerald-700 dark:text-emerald-400">
                    {new Intl.NumberFormat('uz-UZ').format(inspectingListing.priceUzs)} soʻm
                  </strong>
                </div>
                <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800">
                  <span className="text-[10px] text-stone-500 block font-sans">Pasport:</span>
                  <strong className="text-stone-900 dark:text-white text-[11px] truncate block">
                    {inspectingListing.vetPassportNumber}
                  </strong>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800">
                <div className="font-bold text-emerald-950 dark:text-emerald-300 flex items-center gap-1.5 mb-1">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>AI Xulosa va Tavsiya</span>
                </div>
                <p className="text-stone-700 dark:text-stone-300 leading-relaxed">
                  {inspectingListing.aiNotesUz}
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => {
                    handleApproveListing(inspectingListing.id);
                    setInspectingListing(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold cursor-pointer"
                >
                  Tasdiqlash va Chiqarish
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Yangi Auksion Yaratish Modali */}
      {isCreateAuctionOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-stone-900 rounded-3xl max-w-lg w-full border border-stone-200 dark:border-stone-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-stone-900 dark:text-white flex items-center gap-2">
                <Gavel className="w-5 h-5 text-emerald-700" />
                <span>Yangi Jonli Auksion Eʼlon Qilish</span>
              </h3>
              <button
                onClick={() => setIsCreateAuctionOpen(false)}
                className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAuctionSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Auksion Sarlavhasi (Oʻzbekcha):
                </label>
                <input
                  type="text"
                  required
                  placeholder="Masalan: Golshtin elita 8 oylik naslli buqacha"
                  value={newAuctionForm.titleUz}
                  onChange={(e) => setNewAuctionForm({ ...newAuctionForm, titleUz: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-700 text-stone-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Zoti:
                  </label>
                  <select
                    value={newAuctionForm.breed}
                    onChange={(e) => setNewAuctionForm({ ...newAuctionForm, breed: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-stone-900 dark:text-white"
                  >
                    <option value="Golshtin (Holstein)">Golshtin (Holstein)</option>
                    <option value="Black Angus">Black Angus</option>
                    <option value="Hisor qoʻylari">Hisor qoʻylari</option>
                    <option value="Qorabayir oti">Qorabayir oti</option>
                    <option value="Simmental">Simmental</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Davomiyligi (soat):
                  </label>
                  <select
                    value={newAuctionForm.hours}
                    onChange={(e) => setNewAuctionForm({ ...newAuctionForm, hours: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-stone-900 dark:text-white"
                  >
                    <option value={1}>1 soat (Tezkor)</option>
                    <option value={6}>6 soat</option>
                    <option value={24}>24 soat (Standart)</option>
                    <option value={48}>48 soat</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Boshlangʻich narx (soʻm):
                  </label>
                  <input
                    type="number"
                    step="100000"
                    value={newAuctionForm.startingPrice}
                    onChange={(e) => setNewAuctionForm({ ...newAuctionForm, startingPrice: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl font-mono text-stone-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Minimal qadam (soʻm):
                  </label>
                  <input
                    type="number"
                    step="50000"
                    value={newAuctionForm.minStep}
                    onChange={(e) => setNewAuctionForm({ ...newAuctionForm, minStep: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl font-mono text-stone-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Rasm havolasi (URL):
                </label>
                <input
                  type="text"
                  value={newAuctionForm.imageUrl}
                  onChange={(e) => setNewAuctionForm({ ...newAuctionForm, imageUrl: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-stone-900 dark:text-white font-mono text-[11px]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsCreateAuctionOpen(false)}
                  className="px-4 py-2 rounded-xl font-bold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl font-bold bg-emerald-800 hover:bg-emerald-900 text-white cursor-pointer shadow-sm"
                >
                  Auksionni Ishga Tushirish
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export { AdminDashboardModal } from './AdminDashboardModal';
