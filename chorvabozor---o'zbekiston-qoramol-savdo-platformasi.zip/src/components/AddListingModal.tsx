import React, { useState } from 'react';
import { Language, LivestockCategory, LivestockItem, UzbekistanRegion } from '../types';
import { translations } from '../translations';
import { X, Check, Upload, Video, ShieldCheck, FileText, CheckCircle2, Sparkles, Tag, AlertCircle } from 'lucide-react';
import {
  moderateListingText,
  analyzeLivestockImage,
  extractListingTagsAndSeo,
  TextModerationResult,
  ListingSeoExtractionResult,
} from '../services/aiModerator';

interface AddListingModalProps {
  language: Language;
  onClose: () => void;
  onAddListing: (item: LivestockItem) => void;
  onOpenSellerGuide?: () => void;
  initialDepartment?: 'qoramol' | 'quy' | 'ot';
}

const regionsList: UzbekistanRegion[] = [
  'Toshkent shahri',
  'Toshkent viloyati',
  'Samarqand',
  'Andijon',
  'Fargʻona',
  'Namangan',
  'Qashqadaryo',
  'Surxondaryo',
  'Buxoro',
  'Xorazm',
  'Jizzax',
  'Sirdaryo',
  'Navoiy',
  'Qoraqalpogʻiston Respublikasi',
];

export const AddListingModal: React.FC<AddListingModalProps> = ({
  language,
  onClose,
  onAddListing,
  onOpenSellerGuide,
  initialDepartment = 'qoramol',
}) => {
  const t = translations[language];

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);
  const [mainListingType, setMainListingType] = useState<'livestock' | 'equipment'>('livestock');
  
  // Livestock specific fields
  const [department, setDepartment] = useState<'qoramol' | 'quy' | 'ot'>(initialDepartment);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<LivestockCategory>(
    initialDepartment === 'quy' ? 'sheep' : initialDepartment === 'ot' ? 'horses' : 'dairy'
  );
  const [breed, setBreed] = useState(
    initialDepartment === 'quy' ? 'Hisor qoʻylari' : initialDepartment === 'ot' ? 'Qorabayir oti' : 'Golshtin (Holstein)'
  );
  const [gender, setGender] = useState<'buqa' | 'sigir' | 'buzoq' | 'qoʻchqor'>(
    initialDepartment === 'quy' ? 'qoʻchqor' : 'sigir'
  );
  const [ageMonths, setAgeMonths] = useState<number>(30);
  const [weightKg, setWeightKg] = useState<number>(550);
  const [priceUzs, setPriceUzs] = useState<number>(24000000);
  const [milkYield, setMilkYield] = useState<number>(20);

  // Equipment specific fields (Arqon, Yo'g'an, Egar, Yemdon)
  const [equipmentSubcategory, setEquipmentSubcategory] = useState<'arqon' | 'yugan' | 'egar' | 'yemdon' | 'taqa' | 'parvarish'>('arqon');
  const [equipmentMaterial, setEquipmentMaterial] = useState<'charm' | 'neylon' | 'ip' | 'metall' | 'yogoch' | 'boshqa'>('ip');
  const [equipmentSizeOrLength, setEquipmentSizeOrLength] = useState<string>('15 metr');
  const [equipmentCondition, setEquipmentCondition] = useState<'yangi' | 'ishlatilgan'>('yangi');

  const [region, setRegion] = useState<UzbekistanRegion>('Samarqand');
  const [district, setDistrict] = useState('Pastdargʻom tumani');
  const [description, setDescription] = useState('');
  
  // Media
  const [hasVideo, setHasVideo] = useState(true);
  const [videoDuration, setVideoDuration] = useState(30);
  const [imageUrl, setImageUrl] = useState(
    'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80'
  );

  // Vet
  const [hasVetPassport, setHasVetPassport] = useState(true);
  const [passportNumber, setPassportNumber] = useState('UZ-VET-2026-9812');
  const [isEscrowSupported, setIsEscrowSupported] = useState(true);
  const [isQurbonlikFit, setIsQurbonlikFit] = useState(false);

  // Seller info
  const [sellerName, setSellerName] = useState('Siz (Fermer)');
  const [sellerPhone, setSellerPhone] = useState('+998 90 123 45 67');

  const [aiModerationResult, setAiModerationResult] = useState<TextModerationResult | null>(null);
  const [aiSeoResult, setAiSeoResult] = useState<ListingSeoExtractionResult | null>(null);

  const handleRunAiCheck = () => {
    const fullText = `${title || breed}. ${description || 'Sogʻlom zotdor chorva moli.'} ${breed} ${gender}, ${weightKg}kg, ${region} ${district}`;
    const modRes = moderateListingText(fullText);
    const seoRes = extractListingTagsAndSeo(fullText);
    setAiModerationResult(modRes);
    setAiSeoResult(seoRes);
  };

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDone, setIsDone] = useState(false);

  const handleFinish = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const isEq = mainListingType === 'equipment';

    const newItem: LivestockItem = isEq
      ? {
          id: `eq-${Date.now()}`,
          titleUz: title || `${equipmentSubcategory.toUpperCase()}: ${equipmentMaterial} (${equipmentSizeOrLength})`,
          titleRu: `${equipmentSubcategory}: ${equipmentMaterial}`,
          department: 'qoramol',
          category: 'wholesale',
          breed: `Anjom: ${equipmentSubcategory}`,
          gender: 'buqa',
          ageMonths: 1,
          weightKg: 5,
          priceUzs: Number(priceUzs),
          pricePerKg: Number(priceUzs),
          region,
          district,
          descriptionUz: description || `Chorva anjomi: ${equipmentSubcategory}. Material: ${equipmentMaterial}, Holati: ${equipmentCondition}, Oʻlchami: ${equipmentSizeOrLength}.`,
          descriptionRu: `Снаряжение для скота. Состояние: ${equipmentCondition}.`,
          imageUrl: imageUrl || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=800&q=80',
          additionalImages: [],
          hasVideo,
          videoDurationSec: hasVideo ? Number(videoDuration) : undefined,
          videoCaptionUz: 'Anjom koʻrinishi',
          isVerifiedSeller: true,
          vetInfo: {
            id: `vet-none-${Date.now()}`,
            hasVetPassport: false,
            passportNumber: 'ANJOM-KAFOLAT',
            issuedDate: '2026-10-12',
            veterinarianName: 'Sifat Sertifikati',
            districtVetClinic: 'Chorva Anjomlari',
            vaccinatedFor: [],
            healthNotes: 'Yangi/sifatli chorva anjomi va jihozi.',
            status: 'none'
          },
          isEscrowSupported,
          isDeliveryAvailable: true,
          isQurbonlikFit: false,
          viewsCount: 1,
          likesCount: 0,
          createdAt: '2026-10-12',
          seller: {
            id: `seller-${Date.now()}`,
            name: sellerName,
            farmName: 'Chorva Anjomlari Ustaxonasi',
            phone: sellerPhone,
            telegramUsername: 'fermer_uz',
            region,
            district,
            isPassportVerified: true,
            isPhoneVerified: true,
            rating: 5.0,
            dealsCompleted: 1,
            memberSince: '2026-10-12',
            badge: 'Fermer xoʻjaligi'
          }
        }
      : {
          id: `live-${Date.now()}`,
          titleUz: title || `${breed} zotli ${gender}`,
          titleRu: `${breed} ${gender}`,
          department,
          category,
          breed,
          gender: gender as any,
          ageMonths: Number(ageMonths),
          weightKg: Number(weightKg),
          priceUzs: Number(priceUzs),
          pricePerKg: Math.round(Number(priceUzs) / Number(weightKg)),
          dailyMilkYieldLiters: category === 'dairy' ? Number(milkYield) : undefined,
          region,
          district,
          descriptionUz: description || 'Sogʻlom, parvarishlangan, emlashlari toʻliq oʻtkazilgan.',
          descriptionRu: 'Здоровое животное, ухоженное, все прививки по графику.',
          imageUrl,
          additionalImages: [],
          hasVideo,
          videoDurationSec: hasVideo ? Number(videoDuration) : undefined,
          videoCaptionUz: 'Hayvonning harakati va gavdasi',
          isVerifiedSeller: true,
          vetInfo: {
            id: `vet-${Date.now()}`,
            hasVetPassport,
            passportNumber,
            issuedDate: '2026-03-15',
            veterinarianName: 'Davlat Vet Xizmati',
            districtVetClinic: `${district} Veterinariya markazi`,
            vaccinatedFor: [
              { nameUz: 'Kuydirgi', nameRu: 'Сибирская язва', date: '2026-02-10', isImmune: true },
              { nameUz: 'Oqsil', nameRu: 'Ящур', date: '2026-02-25', isImmune: true },
            ],
            healthNotes: 'Tekshiruvdan oʻtgan, toʻliq sogʻlom.',
            status: hasVetPassport ? 'verified' : 'none',
          },
          isEscrowSupported,
          isDeliveryAvailable: true,
          isQurbonlikFit,
          viewsCount: 1,
          likesCount: 0,
          createdAt: '2026-10-04',
          seller: {
            id: `seller-${Date.now()}`,
            name: sellerName,
            farmName: 'Shaxsiy xoʻjalik',
            phone: sellerPhone,
            telegramUsername: 'fermer_uz',
            region,
            district,
            isPassportVerified: true,
            isPhoneVerified: true,
            rating: 5.0,
            dealsCompleted: 1,
            memberSince: '2026-10-04',
            badge: 'Fermer xoʻjaligi',
          },
        };

    setTimeout(() => {
      onAddListing(newItem);
      setIsSubmitting(false);
      setIsDone(true);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-[#E5ECE7] dark:border-[#0E3D32] transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#047857]/40 dark:border-[#0E3D32] bg-gradient-to-r from-[#064E3B] to-[#047857] text-white">
          <div>
            <h3 className="font-bold text-base sm:text-lg text-white">
              {t.addNewListing}
            </h3>
            <p className="text-xs text-emerald-100">
              ChorvaBozor orqali butun Oʻzbekistonga dallolsiz soting
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-emerald-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step indicator */}
        {!isDone && (
          <div className="bg-stone-50 dark:bg-stone-850 border-b border-stone-200 dark:border-stone-800 px-6 py-2.5 flex items-center justify-between text-xs">
            <span className={currentStep === 1 ? 'font-bold text-emerald-900 dark:text-emerald-400' : 'text-stone-500 dark:text-stone-400'}>
              1. Asosiy
            </span>
            <span className="text-stone-300 dark:text-stone-600">→</span>
            <span className={currentStep === 2 ? 'font-bold text-emerald-900 dark:text-emerald-400' : 'text-stone-500 dark:text-stone-400'}>
              2. Foto & Video
            </span>
            <span className="text-stone-300 dark:text-stone-600">→</span>
            <span className={currentStep === 3 ? 'font-bold text-emerald-900 dark:text-emerald-400' : 'text-stone-500 dark:text-stone-400'}>
              3. Vet Pasport
            </span>
            <span className="text-stone-300 dark:text-stone-600">→</span>
            <span className={currentStep === 4 ? 'font-bold text-emerald-900 dark:text-emerald-400' : 'text-stone-500 dark:text-stone-400'}>
              4. Narx & Toʻlov
            </span>
          </div>
        )}

        {/* Form Body */}
        <div className="p-6 overflow-y-auto">
          {isDone ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-800">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-bold text-stone-900">
                Eʼlon Muvaffaqiyatli Joylashtirildi!
              </h4>
              <p className="text-xs text-stone-600 max-w-md mx-auto">
                {t.successListing} Eʼloningiz sayt katalogiga qoʻshildi va @ChorvaBozor_bot orqali xaridorlarga xabar berildi.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-6 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Katalogda koʻrish
              </button>
            </div>
          ) : (
            <form onSubmit={(e) => e.preventDefault()}>
              {/* STEP 1: Basic Info */}
              {currentStep === 1 && (
                <div className="space-y-4 text-xs">
                  {onOpenSellerGuide && (
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-amber-950 font-medium">
                        <span className="text-base">💡</span>
                        <span>Molingizni 20% qimmatroq va tezroq sotmoqchimisiz?</span>
                      </div>
                      <button
                        type="button"
                        onClick={onOpenSellerGuide}
                        className="text-amber-800 hover:text-amber-950 font-bold underline whitespace-nowrap cursor-pointer text-xs"
                      >
                        Oltin Qoʻllanma →
                      </button>
                    </div>
                  )}

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Eʼlon sarlavhasi:
                    </label>
                    <input
                      type="text"
                      placeholder="Masalan: Golshtin zotli 2-qorin yangi tuqqan sigir"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-emerald-700 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Chorva Kabineti (Turi):
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setDepartment('qoramol');
                          setCategory('dairy');
                          setBreed('Qora-ola (Holstein)');
                          setGender('sigir');
                        }}
                        className={`p-2 rounded-lg border text-center font-bold text-xs cursor-pointer transition-colors ${
                          department === 'qoramol'
                            ? 'bg-emerald-800 text-white border-emerald-900 shadow-2xs'
                            : 'bg-stone-50 border-stone-300 text-stone-700 hover:bg-stone-100'
                        }`}
                      >
                        🐂 Qoramol
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setDepartment('quy');
                          setCategory('sheep');
                          setBreed('Hisor qoʻylari');
                          setGender('qoʻchqor');
                        }}
                        className={`p-2 rounded-lg border text-center font-bold text-xs cursor-pointer transition-colors ${
                          department === 'quy'
                            ? 'bg-emerald-800 text-white border-emerald-900 shadow-2xs'
                            : 'bg-stone-50 border-stone-300 text-stone-700 hover:bg-stone-100'
                        }`}
                      >
                        🐑 Qoʻy / Qoʻchqor
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setDepartment('ot');
                          setCategory('horses');
                          setBreed('Qorabayir oti');
                          setGender('buqa' as any);
                        }}
                        className={`p-2 rounded-lg border text-center font-bold text-xs cursor-pointer transition-colors ${
                          department === 'ot'
                            ? 'bg-emerald-800 text-white border-emerald-900 shadow-2xs'
                            : 'bg-stone-50 border-stone-300 text-stone-700 hover:bg-stone-100'
                        }`}
                      >
                        🐎 Otchilik
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Yoʻnalish:
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value as LivestockCategory)}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      >
                        <option value="dairy">Sut yoʻnalishi</option>
                        <option value="beef">Goʻsht yoʻnalishi</option>
                        <option value="calf">Buzoqlar</option>
                        <option value="sheep">Qoʻy / Qoʻchqor</option>
                        <option value="wholesale">Ulgurji partiya</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Zoti (Nasli):
                      </label>
                      <input
                        type="text"
                        placeholder="Masalan: Golshtin, Angus, Shvis, Hisor"
                        value={breed}
                        onChange={(e) => setBreed(e.target.value)}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 font-mono">
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1 font-sans">
                        Tirik vazni (kg):
                      </label>
                      <input
                        type="number"
                        value={weightKg}
                        onChange={(e) => setWeightKg(Number(e.target.value))}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1 font-sans">
                        Yoshi (oylik):
                      </label>
                      <input
                        type="number"
                        value={ageMonths}
                        onChange={(e) => setAgeMonths(Number(e.target.value))}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1 font-sans">
                        Kunlik suti (litr):
                      </label>
                      <input
                        type="number"
                        disabled={category !== 'dairy'}
                        value={milkYield}
                        onChange={(e) => setMilkYield(Number(e.target.value))}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none disabled:opacity-40"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Viloyat:
                      </label>
                      <select
                        value={region}
                        onChange={(e) => setRegion(e.target.value as UzbekistanRegion)}
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      >
                        {regionsList.map((r) => (
                          <option key={r} value={r}>
                            {r}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Tuman / Qishloq:
                      </label>
                      <input
                        type="text"
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        placeholder="Masalan: Pastdargʻom tumani"
                        className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* AI Moderation & SEO Auto-checker */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-stone-850 dark:to-stone-850 border border-emerald-200 dark:border-stone-700 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-emerald-950 dark:text-emerald-300 font-bold text-xs">
                        <Sparkles className="w-4 h-4 text-amber-500 fill-current" />
                        <span>AI Moderatsiya & Avtomatik SEO Teglash</span>
                      </div>
                      <button
                        type="button"
                        onClick={handleRunAiCheck}
                        className="px-3 py-1 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-[11px] cursor-pointer shadow-xs"
                      >
                        Tekshirish
                      </button>
                    </div>

                    {aiModerationResult && (
                      <div className="space-y-2 pt-2 border-t border-emerald-200/60 dark:border-stone-700 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="text-stone-600 dark:text-stone-300">Moderatsiya holati:</span>
                          <span
                            className={`px-2 py-0.5 rounded-md font-black text-[11px] ${
                              aiModerationResult.status === 'APPROVED'
                                ? 'bg-emerald-600 text-white'
                                : 'bg-rose-600 text-white'
                            }`}
                          >
                            {aiModerationResult.status} ({aiModerationResult.category})
                          </span>
                        </div>
                        <p className={`text-[11px] ${aiModerationResult.status === 'APPROVED' ? 'text-emerald-800 dark:text-emerald-300' : 'text-rose-700 dark:text-rose-400 font-bold'}`}>
                          {aiModerationResult.reason}
                        </p>
                        {aiSeoResult && aiSeoResult.teglar.length > 0 && (
                          <div className="flex flex-wrap gap-1 pt-1">
                            {aiSeoResult.teglar.map((t, idx) => (
                              <span key={idx} className="px-2 py-0.5 rounded-md bg-white dark:bg-stone-900 text-emerald-700 dark:text-emerald-400 font-mono text-[10px] border border-emerald-200 dark:border-stone-700">
                                {t}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="pt-3 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(2)}
                      className="py-2.5 px-5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl cursor-pointer"
                    >
                      Keyingi: Foto va Video →
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Media */}
              {currentStep === 2 && (
                <div className="space-y-4 text-xs">
                  {onOpenSellerGuide && (
                    <button
                      type="button"
                      onClick={onOpenSellerGuide}
                      className="w-full p-2.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-300 rounded-xl flex items-center justify-between text-emerald-950 cursor-pointer hover:bg-emerald-100 transition-colors text-left"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">📸</span>
                        <div>
                          <span className="font-bold block">Foto va Video Standarti & AI Foto Studiyasi</span>
                          <span className="text-[11px] text-emerald-800">Uchta rakurs, video talablari va Midjourney/SD promptlari</span>
                        </div>
                      </div>
                      <span className="text-emerald-700 font-bold text-xs underline shrink-0">Qoʻllanma →</span>
                    </button>
                  )}

                  <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl text-sky-950 flex items-start gap-2">
                    <Video className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block">Talab: Kamida 1 ta foto va 1 ta qisqa video koʻrik majburiy!</strong>
                      <span>Bu xaridorga boshqa viloyatga bormasdan hayvonni toʻliq koʻrish va ishonch hosil qilish imkonini beradi.</span>
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Asosiy fotosurat havolasi (yoki kamera orqali):
                    </label>
                    <input
                      type="text"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono text-xs focus:outline-none"
                    />
                  </div>

                  <div className="p-4 border-2 border-dashed border-stone-300 rounded-xl text-center bg-stone-50">
                    <Upload className="w-8 h-8 text-stone-400 mx-auto mb-1" />
                    <span className="font-semibold text-stone-700 block">
                      Video faylni yuklang (15-45 soniya)
                    </span>
                    <span className="text-[11px] text-stone-500">
                      Hayvonning tarozi, quloq birkasi va harakatlanishi koʻrinsin
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={hasVideo}
                        onChange={(e) => setHasVideo(e.target.checked)}
                        className="rounded text-emerald-700 w-4 h-4"
                      />
                      <span className="font-medium text-stone-800">Qisqa video koʻrik tasdiqlandi</span>
                    </label>
                    {hasVideo && (
                      <span className="text-stone-500 font-mono">({videoDuration} soniya)</span>
                    )}
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(1)}
                      className="py-2 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl cursor-pointer"
                    >
                      ← Ortga
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(3)}
                      className="py-2.5 px-5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl cursor-pointer"
                    >
                      Keyingi: Vet Pasport →
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Vet Info */}
              {currentStep === 3 && (
                <div className="space-y-4 text-xs">
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-950 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block">Kasal va soxta eʼlonlarga qarshi nazorat</strong>
                      <span>Davlat veterinariya pasporti mavjud eʼlonlar "Tekshirilgan" nishoni bilan birinchi oʻrinda chiqadi.</span>
                    </div>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <input
                      type="checkbox"
                      checked={hasVetPassport}
                      onChange={(e) => setHasVetPassport(e.target.checked)}
                      className="rounded text-emerald-700 w-4 h-4"
                    />
                    <div>
                      <strong className="text-stone-900 block">Davlat Veterinariya Pasporti mavjud</strong>
                      <span className="text-[11px] text-stone-500">Hayvon qulogʻiga birka taqilgan va bazada roʻyxatda</span>
                    </div>
                  </label>

                  {hasVetPassport && (
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Vet pasport seriya raqami:
                      </label>
                      <input
                        type="text"
                        value={passportNumber}
                        onChange={(e) => setPassportNumber(e.target.value)}
                        placeholder="UZ-VET-2026-..."
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono text-xs focus:outline-none"
                      />
                    </div>
                  )}

                  <label className="flex items-center gap-2 cursor-pointer p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <input
                      type="checkbox"
                      checked={isQurbonlikFit}
                      onChange={(e) => setIsQurbonlikFit(e.target.checked)}
                      className="rounded text-emerald-700 w-4 h-4"
                    />
                    <div>
                      <strong className="text-stone-900 block">Qurbonlik talablariga toʻliq mos</strong>
                      <span className="text-[11px] text-stone-500">Tish yorgan, koʻzi ravshan, oqsoqliksiz</span>
                    </div>
                  </label>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(2)}
                      className="py-2 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl cursor-pointer"
                    >
                      ← Ortga
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(4)}
                      className="py-2.5 px-5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl cursor-pointer"
                    >
                      Keyingi: Narx va Yakun →
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 4: Price & Escrow */}
              {currentStep === 4 && (
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">
                      Sotuv narxi (soʻmda):
                    </label>
                    <input
                      type="number"
                      value={priceUzs}
                      onChange={(e) => setPriceUzs(Number(e.target.value))}
                      className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-mono text-base font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-700"
                    />
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer p-3 bg-emerald-50/70 border border-emerald-300 rounded-xl">
                    <input
                      type="checkbox"
                      checked={isEscrowSupported}
                      onChange={(e) => setIsEscrowSupported(e.target.checked)}
                      className="rounded text-emerald-700 w-4 h-4"
                    />
                    <div>
                      <strong className="text-emerald-950 block">Xavfsiz toʻlov (Eskrou) bilan sotish</strong>
                      <span className="text-[11px] text-stone-600">Xaridor pulni platformaga toʻlaydi, mol yetib borgach pul hisobingizga tushadi.</span>
                    </div>
                  </label>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Fermer ismi:
                      </label>
                      <input
                        type="text"
                        value={sellerName}
                        onChange={(e) => setSellerName(e.target.value)}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-stone-700 mb-1">
                        Telefon raqam:
                      </label>
                      <input
                        type="tel"
                        value={sellerPhone}
                        onChange={(e) => setSellerPhone(e.target.value)}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(3)}
                      className="py-2 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl cursor-pointer"
                    >
                      ← Ortga
                    </button>
                    <button
                      type="button"
                      disabled={isSubmitting}
                      onClick={handleFinish}
                      className="py-2.5 px-6 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? 'Chop etilmoqda...' : t.publishBtn}
                    </button>
                  </div>
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
