import React, { useState } from 'react';
import {
  X,
  TrendingUp,
  Sparkles,
  CheckCircle2,
  Copy,
  Check,
  Camera,
  Sun,
  Scale,
  ShieldCheck,
  DollarSign,
  PhoneCall,
  Video,
  Eye,
  Sliders,
  Award,
  Layers,
  ChevronRight
} from 'lucide-react';
import { Language } from '../types';

interface SellerGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const SellerGuideModal: React.FC<SellerGuideModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<'rules' | 'ai_prompts' | 'checklist'>('rules');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Selected animal for AI prompt generator
  const [selectedAnimal, setSelectedAnimal] = useState<'cattle' | 'sheep' | 'horse' | 'custom'>('cattle');
  const [selectedEngine, setSelectedEngine] = useState<'midjourney' | 'sdxl' | 'dalle'>('midjourney');
  const [customBreed, setCustomBreed] = useState('Golshtin (Holstein Friesian)');

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Technical AI Prompts matching all user specifications:
  // 1. Minimalism: background does not distract, clear farm context
  // 2. Industrial elements: clean metal beams, fresh wooden corrals, polished concrete floor
  // 3. Lighting: natural daylight, professional high-key lighting
  // 4. Aesthetics: shallow depth of field, creamy bokeh
  // 5. Colors: natural pasture green, clean concrete gray, rich timber brown

  const promptCattle = `Award-winning professional livestock photography of a pristine Holstein Friesian dairy cow in a modern farm environment. Standing confidently on a clean brushed-concrete breezeway under an open-sided modern agricultural shelter with architectural clean metal construction and fresh timber corral fencing. In the soft-focus distance, vibrant lush green pastures stretch under gentle atmospheric sunlight. High-key lighting with soft studio-quality diffusion, crisp natural highlights on coat, shallow depth of field, creamy background bokeh (f/1.8, 85mm portrait lens), hyper-realistic skin texture, healthy alert gaze, 8k resolution, photorealistic agricultural photography --ar 16:9 --style raw --v 6.1`;

  const promptSheep = `Award-winning professional livestock photography of a massive pedigreed Gissar (Hisor) ram in a modern farm environment. Positioned majestically on a clean flat paddock with fresh natural wooden corrals and minimal clean metal gates. In the background, a modern timber livestock shed with subtle pasture greenery, softly blurred with extreme shallow depth of field. High-key lighting, bright diffused morning sun, subtle rim light highlighting the ram's fleece texture and muscular build, natural earthy palette of warm wood brown, clean stone gray and fresh pasture greens, masterwork agricultural photography, shot on Hasselblad H6D-100c --ar 16:9 --style raw --v 6.1`;

  const promptHorse = `Award-winning professional livestock photography of a noble black Qorabayir stallion standing proudly in a modern farm environment. Pristine equestrian demonstration paddock with sleek minimalist dark wood railing and polished concrete walkway, surrounded by expansive green meadows and modern Scandinavian-style timber stable architecture softly blurred in the background. High-key lighting, brilliant natural daylight with soft fill, glistening coat sheen, shallow depth of field, cinematic 85mm bokeh, majestic posture, photorealistic fine-art equine photography, 8k --ar 16:9 --style raw --v 6.1`;

  const getCustomPrompt = () => {
    if (selectedAnimal === 'cattle') return promptCattle;
    if (selectedAnimal === 'sheep') return promptSheep;
    if (selectedAnimal === 'horse') return promptHorse;
    return `Award-winning professional livestock photography of a prime pedigreed ${customBreed} in a modern farm environment. Standing proudly on a clean flat agricultural paddock with fresh wooden post-and-rail fences and modern clean metal canopy framework. In the soft-focus background, lush green pasture and contemporary farm architecture create a minimalist setting. High-key lighting, soft diffused daytime sunlight, shallow depth of field, creamy bokeh, natural color harmony of pasture green, concrete light gray and warm cedar wood, 8k resolution, shot on 85mm f/1.8 --ar 16:9 --style raw --v 6.1`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 w-full max-w-4xl rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-stone-900 text-white p-5 sm:p-6 shrink-0 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-stone-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2.5 mb-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-stone-950 text-xs font-black tracking-wide flex items-center gap-1 shadow-sm">
              <TrendingUp className="w-3.5 h-3.5" />
              SOTUVCHI MAHORAT DARSI
            </span>
            <span className="text-emerald-200 text-xs font-semibold">ChorvaBozor Rasmiy Qoʻllanmasi</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black font-serif text-white tracking-tight leading-snug">
            Chorvani Tez va Qimmat Sotish boʻyicha Oltin Qoʻllanma
          </h2>
          <p className="text-emerald-100/90 text-sm mt-1.5 max-w-2xl leading-relaxed">
            Xaridor birinchi navbatda koʻzi va ishonchi bilan sotib oladi. Molingizni boshqalardan ajratib koʻrsatish va 15–25% qimmatroq sotish uchun 5 ta oltin qoida va AI foto studiyasi.
          </p>

          {/* Navigation Sub-Tabs */}
          <div className="flex items-center gap-2 mt-5 border-t border-emerald-700/50 pt-4 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                activeTab === 'rules'
                  ? 'bg-white text-emerald-950 shadow-sm'
                  : 'bg-emerald-950/40 text-emerald-100 hover:bg-emerald-950/60'
              }`}
            >
              <Award className="w-4 h-4 text-amber-500" />
              <span>5 ta Oltin Qoida</span>
            </button>
            <button
              onClick={() => setActiveTab('ai_prompts')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                activeTab === 'ai_prompts'
                  ? 'bg-white text-emerald-950 shadow-sm'
                  : 'bg-emerald-950/40 text-emerald-100 hover:bg-emerald-950/60'
              }`}
            >
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>AI Rasm Prompt Generator (Midjourney / SD / DALL-E)</span>
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                activeTab === 'checklist'
                  ? 'bg-white text-emerald-950 shadow-sm'
                  : 'bg-emerald-950/40 text-emerald-100 hover:bg-emerald-950/60'
              }`}
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Eʼlon Tekshirish Nazorati (Checklist)</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-7 overflow-y-auto space-y-6 flex-1 bg-stone-50/60 dark:bg-stone-900/60">
          {/* TAB 1: 5 Oltin Qoida */}
          {activeTab === 'rules' && (
            <div className="space-y-5">
              <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-4 flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold text-lg shrink-0 shadow-sm">
                  💡
                </div>
                <div>
                  <h4 className="text-sm font-bold text-amber-950 dark:text-amber-200">
                    Nima uchun baʼzi mollar 2 kunda, boshqalari 2 oyda sotilmaydi?
                  </h4>
                  <p className="text-xs text-amber-900/90 dark:text-amber-300/90 mt-0.5 leading-relaxed">
                    Tajribali fermerlar va dallollarning siri shundaki, ular molni qanday taqdim etishni bilishadi. Quyidagi 5 ta qoidaga amal qilgan holda joylashtirilgan eʼlonlar 3 barobar koʻproq koʻriladi va savdolashishda mol narxi tushib ketmaydi.
                  </p>
                </div>
              </div>

              {/* Rule 1 */}
              <div className="bg-white dark:bg-stone-850 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-xs hover:border-emerald-500 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center font-black text-lg shrink-0">
                    1
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                        Koʻrinish va Tozalik (Birinchi taassurot)
                      </h3>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        +20% narx
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Choʻmiltiring yoki tozalang</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Sotuvga chiqarishdan oldin molni choʻmiltiring yoki terisidagi tosh-kesak, quruq kirni yaxshilab tozalang. Toza va parvarish qilingan mol darhol qimmatroq koʻrinadi.
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <Sun className="w-4 h-4 text-amber-500 shrink-0" />
                          <span>Yaxshi vaqtni tanlang</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Rasmni ertalabki yoki kechki quyosh nuri ostida oling. Kunduzgi oʻtkir quyosh nuri yoki kechki qorongʻi molxona rasmni buzib koʻrsatadi.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rule 2 */}
              <div className="bg-white dark:bg-stone-850 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-xs hover:border-emerald-500 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 flex items-center justify-center font-black text-lg shrink-0">
                    2
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                        Toʻgʻri va halol maʼlumot (Ishonch kaliti)
                      </h3>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                        Kafolatlangan xaridor
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <Scale className="w-4 h-4 text-blue-600 shrink-0" />
                          <span>Vazni va yoshini aniq yozing</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          &quot;Taxminan shuncha kg&quot; deyish oʻrniga, agar imkoni boʻlsa taroziga qoʻyib rasmini/videosini qoʻying. Aniq maʼlumot jiddiy xaridorlarni tez jalb qiladi.
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                          <span>Zoti va parvarishi</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Berilgan ozuqasi (masalan: beda, makkajoʻxori, kunjara, toza don) haqida qisqacha yozing. Bu molning goʻshti mazali boʻlishini va sogʻlom oʻsganini koʻrsatadi.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rule 3 */}
              <div className="bg-white dark:bg-stone-850 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-xs hover:border-emerald-500 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 flex items-center justify-center font-black text-lg shrink-0">
                    3
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                        Foto va Video Standarti (Xaridor eʼtiborini tortish)
                      </h3>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                        2x ishonch
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <Camera className="w-4 h-4 text-purple-600 shrink-0" />
                          <span>Toʻliq rakurs (3 ta rasm)</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Molning yon tomonidan (boʻyi va uzunligi toʻliq koʻrinadigan qilib), old tomonidan va orqa qismidan bittadan rasm oling. Hayvon kadrdan chiqib ketmasin.
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <Video className="w-4 h-4 text-purple-600 shrink-0" />
                          <span>Qisqa video shart (10–15 soniya)</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          10-15 soniyalik video oling: molning tinch yurishi, oyoqlari va tishlarini (yoshini koʻrsatish uchun) yaqindan koʻrsating. Video ishonchni 2 barobar oshiradi.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rule 4 */}
              <div className="bg-white dark:bg-stone-850 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-xs hover:border-emerald-500 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center font-black text-lg shrink-0">
                    4
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                        Narx siyosati (Bozor hisob-kitobi)
                      </h3>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        Tezkor bitim
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <DollarSign className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Bozor narxidan kelib chiqing</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Juda past narx qoʻysangiz, xaridor &quot;kasal ekan&quot; deb oʻylashi mumkin. Juda qimmat qoʻysangiz, hech kim qiziqmaydi. Platformamizdagi <span className="font-bold underline text-emerald-700 dark:text-emerald-400">Narx Indeksi</span>ga qarab oʻrtacha va adolatli narx belgilang.
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <Sliders className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Savdolashish uchun imkon qoldiring</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Narxni biroz yuqoriroq qoʻyib, &quot;kelishiladi&quot; deb yozish Oʻzbekiston bozorida doim yaxshi ishlaydi. Xaridor 500 000 – 1 000 000 soʻm yutsa, mamnun boʻladi.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rule 5 */}
              <div className="bg-white dark:bg-stone-850 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-xs hover:border-emerald-500 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 flex items-center justify-center font-black text-lg shrink-0">
                    5
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                        Tezkor muloqot va xushmuomalalik
                      </h3>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                        Fermer obroʻsi
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <PhoneCall className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>Qoʻngʻiroqlarga tayyor turing</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Eʼlon chiqqandan keyin telefoningiz doim yoniq boʻlsin. Qaytarilmagan qoʻngʻiroq — boy berilgan xaridor demakdir.
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700/60">
                        <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-white mb-1">
                          <ShieldCheck className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>Savollarga ochiq javob bering</span>
                        </div>
                        <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                          Xaridor molning kasalligi, emlangani yoki nima yeyishini soʻrasa, ochiq-oydin rostini ayting. Halollik sizning reytingingizni oshiradi va keyingi safar ham sizdan olishadi.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: AI Rasm Generatori Prompt Studiyasi */}
          {activeTab === 'ai_prompts' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl p-4.5">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-emerald-700 text-white shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-emerald-950 dark:text-emerald-200">
                      Professional Fermerlik Foto Studiyasi — AI Prompt Standarti
                    </h3>
                    <p className="text-xs text-emerald-900/90 dark:text-emerald-300/90 mt-1 leading-relaxed">
                      Midjourney v6, Stable Diffusion XL yoki DALL-E 3 orqali fermerlik standartlariga mos yuqori sifatli fotosuratlarni hosil qilish uchun rasmiy promptlar. Ushbu promptlar 5 ta fon talabiga (<span className="font-semibold">minimalizm, toza metall/yogʻoch konstruktsiyalar, tabiiy high-key yoritish, bokeh va tabiiy ranglar</span>) qatʼiy javob beradi.
                    </p>
                  </div>
                </div>
              </div>

              {/* 5 Technical Background Criteria Breakdown */}
              <div className="bg-white dark:bg-stone-850 rounded-xl p-4 border border-stone-200 dark:border-stone-800">
                <h4 className="text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-3">
                  AI Generatorlar Uchun Fon Qoidalari Matritsasi:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/60 dark:border-stone-700">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 block mb-0.5">1. Minimalizm</span>
                    <span className="text-stone-600 dark:text-stone-400 text-[11px]">Fokus faqat hayvonda, fon chalgʻitmaydi.</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/60 dark:border-stone-700">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 block mb-0.5">2. Sanoat elementlari</span>
                    <span className="text-stone-600 dark:text-stone-400 text-[11px]">Toza metall, yangi yogʻoch korallar, silliq beton.</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/60 dark:border-stone-700">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 block mb-0.5">3. Tabiiy yoritish</span>
                    <span className="text-stone-600 dark:text-stone-400 text-[11px]">High-key daylight, yumshoq professional nurlar.</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/60 dark:border-stone-700">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 block mb-0.5">4. Estetika</span>
                    <span className="text-stone-600 dark:text-stone-400 text-[11px]">Shallow depth of field, orqa fonda kremli bokeh.</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-800/80 border border-stone-200/60 dark:border-stone-700">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 block mb-0.5">5. Ranglar uygʻunligi</span>
                    <span className="text-stone-600 dark:text-stone-400 text-[11px]">Tabiiy yashil, och kulrang beton va yogʻoch jilosi.</span>
                  </div>
                </div>
              </div>

              {/* Animal Preset Selection */}
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs font-bold text-stone-700 dark:text-stone-300">
                    Hayvon Turini Tanlang:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      onClick={() => setSelectedAnimal('cattle')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                        selectedAnimal === 'cattle'
                          ? 'bg-emerald-900 text-white shadow-xs'
                          : 'bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300'
                      }`}
                    >
                      <span>🐂</span>
                      <span>Qoramol (Sogʻin / Goʻshtdor)</span>
                    </button>
                    <button
                      onClick={() => setSelectedAnimal('sheep')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                        selectedAnimal === 'sheep'
                          ? 'bg-emerald-900 text-white shadow-xs'
                          : 'bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300'
                      }`}
                    >
                      <span>🐑</span>
                      <span>Qoʻchqor (Hisor zoti)</span>
                    </button>
                    <button
                      onClick={() => setSelectedAnimal('horse')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                        selectedAnimal === 'horse'
                          ? 'bg-emerald-900 text-white shadow-xs'
                          : 'bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300'
                      }`}
                    >
                      <span>🐎</span>
                      <span>Ot (Qorabayir zoti)</span>
                    </button>
                    <button
                      onClick={() => setSelectedAnimal('custom')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                        selectedAnimal === 'custom'
                          ? 'bg-emerald-900 text-white shadow-xs'
                          : 'bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300'
                      }`}
                    >
                      <span>✨</span>
                      <span>Boshqa zot...</span>
                    </button>
                  </div>
                </div>

                {selectedAnimal === 'custom' && (
                  <div className="bg-stone-100 dark:bg-stone-800 p-3 rounded-xl border border-stone-200 dark:border-stone-700 flex items-center gap-3">
                    <label className="text-xs font-bold text-stone-700 dark:text-stone-300 shrink-0">
                      Zot nomini kiriting:
                    </label>
                    <input
                      type="text"
                      value={customBreed}
                      onChange={(e) => setCustomBreed(e.target.value)}
                      placeholder="masalan: Simmental, Edilboy, Axaltaka..."
                      className="flex-1 bg-white dark:bg-stone-900 px-3 py-1.5 rounded-lg text-xs border border-stone-300 dark:border-stone-700 text-stone-900 dark:text-white"
                    />
                  </div>
                )}

                {/* The Generated Ready-to-copy Prompt */}
                <div className="bg-stone-900 text-white rounded-xl p-4 sm:p-5 border border-stone-800 space-y-3 relative group">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                        {selectedAnimal === 'cattle' && '🐂 Qoramol Stsenariysi (Tayyor Prompt)'}
                        {selectedAnimal === 'sheep' && '🐑 Qoʻchqor Stsenariysi (Tayyor Prompt)'}
                        {selectedAnimal === 'horse' && '🐎 Qorabayir Oti Stsenariysi (Tayyor Prompt)'}
                        {selectedAnimal === 'custom' && `✨ ${customBreed} Stsenariysi`}
                      </span>
                    </div>

                    <button
                      onClick={() => copyToClipboard(getCustomPrompt(), 'active-prompt')}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
                    >
                      {copiedKey === 'active-prompt' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-white" />
                          <span>Nusxalandi!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Promptdan nusxa olish</span>
                        </>
                      )}
                    </button>
                  </div>

                  <p className="font-mono text-xs text-stone-200 bg-stone-950/80 p-3.5 rounded-lg border border-stone-800 leading-relaxed break-words select-all">
                    {getCustomPrompt()}
                  </p>

                  <div className="flex flex-wrap items-center justify-between text-[11px] text-stone-400 pt-1 gap-2 border-t border-stone-800">
                    <div className="flex items-center gap-3">
                      <span>✓ professional livestock photography</span>
                      <span>✓ high-key lighting</span>
                      <span>✓ shallow depth of field</span>
                      <span>✓ modern farm environment</span>
                    </div>
                    <span className="text-amber-400">Midjourney v6.1 / SDXL / DALL-E 3 ga mos</span>
                  </div>
                </div>

                {/* 3 Dedicated scenario cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  {/* Scenario 1: Qoramol */}
                  <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-stone-900 dark:text-white flex items-center gap-1.5">
                          <span>🐂</span> Qoramol uchun
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                          Ochiq ayvon
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed">
                        Zamonaviy, ochiq turdagi ferma ayvoni, toza metall ustunlar, beton yoʻlak va orqada toza oʻtloq (yaylov) koʻrinib turibdi.
                      </p>
                    </div>

                    <button
                      onClick={() => copyToClipboard(promptCattle, 'cattle')}
                      className="mt-3 w-full py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-emerald-100 hover:text-emerald-900 dark:hover:bg-emerald-950 dark:hover:text-emerald-300 text-stone-700 dark:text-stone-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {copiedKey === 'cattle' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === 'cattle' ? 'Nusxalandi' : 'Qoramol promptini olish'}</span>
                    </button>
                  </div>

                  {/* Scenario 2: Qo'chqor */}
                  <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-stone-900 dark:text-white flex items-center gap-1.5">
                          <span>🐑</span> Qoʻchqor uchun
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                          Yogʻoch koral
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed">
                        Tekis, toza namoyish maydoni, yangi yogʻochdan yasalgan zamonaviy qiyomxona toʻsiqlari, orqada mayin yaylov manzarasi.
                      </p>
                    </div>

                    <button
                      onClick={() => copyToClipboard(promptSheep, 'sheep')}
                      className="mt-3 w-full py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-emerald-100 hover:text-emerald-900 dark:hover:bg-emerald-950 dark:hover:text-emerald-300 text-stone-700 dark:text-stone-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {copiedKey === 'sheep' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === 'sheep' ? 'Nusxalandi' : 'Qoʻchqor promptini olish'}</span>
                    </button>
                  </div>

                  {/* Scenario 3: Ot */}
                  <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-stone-900 dark:text-white flex items-center gap-1.5">
                          <span>🐎</span> Ot uchun
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                          Zamonoviy otxona
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed">
                        Qorabayir oti, orqada zamonaviy yogʻoch otxona binosi, toza yoʻlak va keng yashil maydon.
                      </p>
                    </div>

                    <button
                      onClick={() => copyToClipboard(promptHorse, 'horse')}
                      className="mt-3 w-full py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-emerald-100 hover:text-emerald-900 dark:hover:bg-emerald-950 dark:hover:text-emerald-300 text-stone-700 dark:text-stone-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {copiedKey === 'horse' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === 'horse' ? 'Nusxalandi' : 'Ot promptini olish'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Checklist */}
          {activeTab === 'checklist' && (
            <div className="space-y-4">
              <div className="bg-white dark:bg-stone-850 rounded-xl p-5 border border-stone-200 dark:border-stone-800 shadow-xs">
                <h3 className="font-extrabold text-base text-stone-900 dark:text-white mb-2 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Eʼlonni Joylashtirishdan Oldin Tekshiruv (7 qadam)</span>
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400 mb-4 leading-relaxed">
                  Har bir bandni koʻrib chiqing va molingiz sotuvga 100% tayyor ekanligiga ishonch hosil qiling.
                </p>

                <div className="space-y-2.5 text-xs">
                  {[
                    {
                      title: '1. Mol choʻmiltirildi va terisi tosh-kesaklardan tozalandi',
                      desc: 'Yaltirab turgan toza jun xaridorga birinchi qarashdayoq yuqori parvarishdan dalolat beradi.',
                    },
                    {
                      title: '2. Ertalabki yoki kechki yumshoq quyosh nurida rasm olindi',
                      desc: 'Toʻgʻridan-toʻgʻri qattiq soya yoʻq, molning haqiqiy tana tuzilishi va ranglari aniq ifodalangan.',
                    },
                    {
                      title: '3. Aniq vazn tarozida oʻlchandi yoki tarozi dalolatnomasi bor',
                      desc: '"Taxminan 500 kg" oʻrniga "518 kg (tarozi videosi mavjud)" deb yozish ishonchni oshiradi.',
                    },
                    {
                      title: '4. Molning zoti, yoshi va ozuqa ratsioni koʻrsatildi',
                      desc: 'Beda, makka sılosı, kunjara va arpa bilan boqilganligi goʻshtning mayinligi haqida maʼlumot beradi.',
                    },
                    {
                      title: '5. Uchta toʻliq rakurs: Yon tomondan, olddan va orqa qismdan',
                      desc: 'Molning boʻyi, koʻkrak aylanasi va son qismining toʻlaligi toʻliq koʻrinishi shart.',
                    },
                    {
                      title: '6. 10–15 soniyalik harakat videosi olindi',
                      desc: 'Oyoqlarining oqsoqlanmasligi, tish yorganligi (yoshi) va erkin harakati tasdiqlandi.',
                    },
                    {
                      title: '7. Telefon doimo yoniq va narxda savdolashish zaxirasi qoldirildi',
                      desc: 'Xaridor qoʻngʻiroq qilganida ochiq va doʻstona javob berishga tayyorsiz.',
                    },
                  ].map((step, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg bg-stone-50 dark:bg-stone-800/60 border border-stone-200/70 dark:border-stone-700/60 flex items-start gap-3"
                    >
                      <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                        ✓
                      </div>
                      <div>
                        <h4 className="font-bold text-stone-900 dark:text-white">{step.title}</h4>
                        <p className="text-stone-600 dark:text-stone-400 mt-0.5 leading-relaxed">{step.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 sm:px-6 bg-white dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>ChorvaBozor sifat va halollik standarti</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
            >
              Tushundim, Rahmat!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
