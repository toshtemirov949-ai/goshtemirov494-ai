import React, { useState } from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Phone,
  Send,
  Truck,
  Lock,
  Play,
  RotateCcw,
  FileCheck,
  Calendar,
  Scale,
  Award,
  Sparkles,
  Stethoscope,
  TrendingUp,
} from 'lucide-react';

interface LivestockDetailModalProps {
  item: LivestockItem | null;
  language: Language;
  isCompared?: boolean;
  onToggleCompare?: (item: LivestockItem) => void;
  onClose: () => void;
  onStartEscrow: (item: LivestockItem) => void;
  onOpenTransportForListing: (item: LivestockItem) => void;
  onOpenVetConsult?: (item: LivestockItem) => void;
  onOpenBreedTrends?: (breedKey: string) => void;
}

export const LivestockDetailModal: React.FC<LivestockDetailModalProps> = ({
  item,
  language,
  isCompared = false,
  onToggleCompare,
  onClose,
  onStartEscrow,
  onOpenTransportForListing,
  onOpenVetConsult,
  onOpenBreedTrends,
}) => {
  if (!item) return null;

  const t = translations[language];
  const [activeMediaTab, setActiveMediaTab] = useState<'photos' | 'video'>('photos');
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<'specs' | 'vet' | 'seller' | 'reviews'>('specs');

  const allImages = [item.imageUrl, ...(item.additionalImages || [])];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ').format(price);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-[#E5ECE7] dark:border-[#0E3D32] transition-colors">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#E5ECE7] dark:border-[#0E3D32] bg-white/80 dark:bg-[#02100C]">
          <div className="flex items-center gap-2 truncate">
            <span className="text-xs font-semibold text-[#047857] dark:text-[#10B981] font-mono">
              ID: {item.id}
            </span>
            <span className="text-stone-300 dark:text-stone-600">·</span>
            <span className="text-xs text-stone-500 dark:text-stone-400 font-medium truncate">
              {item.region}, {item.district}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-200/60 dark:hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Media & Video Showcase (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-3">
            {/* Media Selector Tabs */}
            <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
              <button
                type="button"
                onClick={() => {
                  setActiveMediaTab('photos');
                  setIsVideoPlaying(false);
                }}
                className={`text-xs font-semibold px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                  activeMediaTab === 'photos'
                    ? 'bg-stone-900 text-white'
                    : 'text-stone-600 hover:text-stone-900 bg-stone-100'
                }`}
              >
                Fotosuratlar ({allImages.length})
              </button>
              {item.hasVideo && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveMediaTab('video');
                    setIsVideoPlaying(true);
                  }}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
                    activeMediaTab === 'video'
                      ? 'bg-sky-700 text-white'
                      : 'text-stone-600 hover:text-stone-900 bg-stone-100'
                  }`}
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>360° Video Koʻrik ({item.videoDurationSec}s)</span>
                </button>
              )}
            </div>

            {/* Main Stage */}
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-stone-900 border border-stone-200">
              {activeMediaTab === 'photos' ? (
                <img
                  src={allImages[activeImageIndex] || item.imageUrl}
                  alt={item.titleUz}
                  className="w-full h-full object-cover object-center"
                />
              ) : (
                // Interactive Video Reel Simulator
                <div className="w-full h-full flex flex-col justify-between p-4 bg-gradient-to-t from-black/90 via-black/40 to-black/70 text-white relative">
                  <div className="flex items-center justify-between text-xs">
                    <span className="bg-sky-600/80 px-2 py-0.5 rounded text-[11px] font-semibold">
                      Jonli Video Tekshiruvi
                    </span>
                    <span className="font-mono text-xs">00:{item.videoDurationSec || 30}</span>
                  </div>

                  <div className="text-center my-auto">
                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm border border-white/40 flex items-center justify-center mx-auto mb-3 shadow-lg">
                      <Play className="w-8 h-8 text-white fill-white ml-1" />
                    </div>
                    <p className="text-xs text-stone-200 max-w-sm mx-auto font-medium">
                      {item.videoCaptionUz || 'Hayvonning tarozi, quloq birkasi, tishlari va harakat holati videoda toʻliq aks ettirilgan.'}
                    </p>
                  </div>

                  {/* Simulated playback bar */}
                  <div className="w-full">
                    <div className="w-full bg-white/30 h-1.5 rounded-full overflow-hidden mb-1">
                      <div className="bg-sky-400 h-full w-2/3 animate-pulse" />
                    </div>
                    <div className="flex justify-between text-[10px] text-stone-300">
                      <span>HD 1080p · Tarozi & Harakat</span>
                      <span>Haqiqiy video</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Thumbnail Strip */}
            {activeMediaTab === 'photos' && allImages.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {allImages.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-14 rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                      activeImageIndex === idx
                        ? 'border-emerald-700 ring-2 ring-emerald-600/20'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumb" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Trust highlights banner */}
            <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3 text-xs text-emerald-950 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
                <div>
                  <span className="font-bold">Eskrou Kafolati:</span> Hayvonni koʻrib, vaznini tasdiqlamaguningizcha pul platformada saqlanadi.
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Specs, Vet details & Actions (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              {/* Category & Region */}
              <div className="flex items-center gap-1.5 text-xs text-stone-500 mb-1">
                <span className="font-semibold text-emerald-900">{item.breed}</span>
                <span>·</span>
                <span>{item.gender.toUpperCase()}</span>
                <span>·</span>
                <span>{item.region}</span>
              </div>

              {/* Title */}
              <h2 className="text-xl font-bold text-stone-900 dark:text-white mb-2 leading-snug">
                {language === 'uz' ? item.titleUz : item.titleRu}
              </h2>

              {/* Price Banner */}
              <div className="bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl p-3 mb-4 flex items-baseline justify-between transition-colors">
                <div>
                  <span className="text-2xl font-extrabold text-stone-900 dark:text-white font-mono tabular-nums">
                    {formatPrice(item.priceUzs)}
                  </span>
                  <span className="text-xs text-stone-500 dark:text-stone-400 ml-1.5 font-medium">{t.currency}</span>
                </div>
                {item.pricePerKg && (
                  <span className="text-xs text-stone-600 dark:text-stone-300 font-mono">
                    ~{formatPrice(item.pricePerKg)} soʻm/kg
                  </span>
                )}
              </div>

              {/* Breed Price Trends & Seasonality Link */}
              {onOpenBreedTrends && (
                <button
                  type="button"
                  onClick={() => onOpenBreedTrends(item.breedKey || item.breed)}
                  className="w-full mb-3.5 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/60 dark:to-teal-950/60 hover:from-emerald-100 hover:to-teal-100 dark:hover:from-emerald-900/60 dark:hover:to-teal-900/60 border border-emerald-200/90 dark:border-emerald-800 text-emerald-950 dark:text-emerald-200 text-xs font-bold transition-all cursor-pointer flex items-center justify-between shadow-2xs group"
                >
                  <span className="flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 group-hover:scale-110 transition-transform" />
                    <span>📈 Ushbu zotning yillik narx dinamikasi & mavsumiyligi</span>
                  </span>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-300 font-extrabold">Grafik →</span>
                </button>
              )}

              {/* Detail Navigation Tabs */}
              <div className="flex items-center border-b border-stone-200 dark:border-stone-800 mb-4 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setActiveTab('specs')}
                  className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                    activeTab === 'specs'
                      ? 'border-emerald-800 dark:border-emerald-400 text-emerald-900 dark:text-emerald-300 font-bold'
                      : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
                  }`}
                >
                  Xususiyatlari
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('vet')}
                  className={`pb-2 px-3 border-b-2 transition-colors flex items-center gap-1 cursor-pointer ${
                    activeTab === 'vet'
                      ? 'border-emerald-800 text-emerald-900'
                      : 'border-transparent text-stone-500 hover:text-stone-800'
                  }`}
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>Vet Pasport</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('seller')}
                  className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                    activeTab === 'seller'
                      ? 'border-emerald-800 text-emerald-900 font-bold'
                      : 'border-transparent text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Fermer ({item.seller.rating}★)
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                    activeTab === 'reviews'
                      ? 'border-emerald-800 text-emerald-900 font-bold'
                      : 'border-transparent text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Sharhlar (14)
                </button>
              </div>

              {/* Tab 1: Specifications */}
              {activeTab === 'specs' && (
                <div className="space-y-3 text-xs text-stone-700 dark:text-stone-300">
                  <div className="grid grid-cols-2 gap-2 bg-stone-50 dark:bg-stone-850 p-3 rounded-lg border border-stone-200/80 dark:border-stone-800 font-mono transition-colors">
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase font-sans">Tirik vazni</span>
                      <strong className="text-stone-900 dark:text-white">{item.weightKg} kg</strong>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase font-sans">Yoshi</span>
                      <strong className="text-stone-900 dark:text-white">
                        {item.ageMonths >= 12
                          ? `${(item.ageMonths / 12).toFixed(1)} yosh (${item.ageMonths} oy)`
                          : `${item.ageMonths} oylik`}
                      </strong>
                    </div>
                    {item.dailyMilkYieldLiters && (
                      <div>
                        <span className="text-stone-400 block text-[10px] uppercase font-sans">Kunlik suti</span>
                        <strong className="text-emerald-800 dark:text-emerald-400">{item.dailyMilkYieldLiters} litr</strong>
                      </div>
                    )}
                    {item.lactationNumber && (
                      <div>
                        <span className="text-stone-400 block text-[10px] uppercase font-sans">Qorini</span>
                        <strong className="text-stone-900 dark:text-white">{item.lactationNumber}-qorin</strong>
                      </div>
                    )}
                    {item.isPregnant !== undefined && (
                      <div>
                        <span className="text-stone-400 block text-[10px] uppercase font-sans">Boʻgʻozlik</span>
                        <strong className="text-stone-900 dark:text-white">
                          {item.isPregnant ? `${item.pregnancyMonths} oylik boʻgʻoz` : 'Boʻgʻoz emas'}
                        </strong>
                      </div>
                    )}
                  </div>

                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed pt-1">
                    {language === 'uz' ? item.descriptionUz : item.descriptionRu}
                  </p>

                  {item.isQurbonlikFit && (
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5 text-xs text-amber-950 flex items-start gap-2">
                      <Award className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">Qurbonlikka toʻliq mos:</span> Tish yorgan, koʻzi ravshan, oqsoqlik va nuqsonsiz ekanligi tekshiruvdan oʻtkazilgan.
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Tab 2: Veterinary Information */}
              {activeTab === 'vet' && (
                <div className="space-y-3 text-xs">
                  <div className="bg-emerald-50/70 border border-emerald-300 rounded-xl p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-700" />
                        Davlat Veterinariya Pasporti
                      </span>
                      <span className="font-mono text-emerald-800 font-bold bg-white px-2 py-0.5 rounded border border-emerald-200">
                        {item.vetInfo.passportNumber}
                      </span>
                    </div>

                    <div className="space-y-1 text-stone-600 mb-2">
                      <div><strong className="text-stone-800">Muassasa:</strong> {item.vetInfo.districtVetClinic}</div>
                      <div><strong className="text-stone-800">Vrach:</strong> {item.vetInfo.veterinarianName}</div>
                      <div><strong className="text-stone-800">Sana:</strong> {item.vetInfo.issuedDate}</div>
                    </div>

                    <div className="pt-2 border-t border-emerald-200/80">
                      <span className="font-semibold text-stone-800 block mb-1.5">Emlashlar tarixi (Vaksinatsiya):</span>
                      <div className="space-y-1">
                        {item.vetInfo.vaccinatedFor.map((vac, i) => (
                          <div key={i} className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-emerald-100">
                            <span className="text-stone-800 font-medium">
                              {language === 'uz' ? vac.nameUz : vac.nameRu}
                            </span>
                            <span className="font-mono text-[11px] text-stone-500">
                              {vac.date} · <span className="text-emerald-700 font-bold">Himoyalangan ✓</span>
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {onOpenVetConsult && (
                    <button
                      type="button"
                      onClick={() => onOpenVetConsult(item)}
                      className="w-full py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
                    >
                      <Stethoscope className="w-4 h-4 text-sky-200" />
                      <span>{language === 'uz' ? 'Veterinar Vrach bilan Chat (Savol berish)' : 'Онлайн консультация с ветеринаром (Чат)'}</span>
                    </button>
                  )}

                  <p className="text-stone-500 text-[11px] italic">
                    * Ushbu hujjat Davlat Veterinariya qoʻmitasining yagona elektron bazasidan tekshirilgan.
                  </p>
                </div>
              )}

              {/* Tab 3: Seller Profile */}
              {activeTab === 'seller' && (
                <div className="space-y-3 text-xs text-stone-700">
                  <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="font-bold text-stone-900 text-sm">{item.seller.name}</h4>
                        <span className="text-stone-500">{item.seller.farmName}</span>
                      </div>
                      <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded">
                        {item.seller.badge}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 py-2 border-y border-stone-200/60 my-2 text-stone-600 font-mono">
                      <div>
                        <span className="text-stone-400 block text-[10px] font-sans">Reyting</span>
                        <strong className="text-amber-700">★ {item.seller.rating.toFixed(2)} / 5.0</strong>
                      </div>
                      <div>
                        <span className="text-stone-400 block text-[10px] font-sans">Muvaffaqiyatli bitimlar</span>
                        <strong className="text-stone-900">{item.seller.dealsCompleted} ta</strong>
                      </div>
                    </div>

                    <div className="space-y-1 text-stone-600 pt-1">
                      <div className="flex items-center gap-1.5 text-emerald-800 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Pasport maʼlumotlari tasdiqlangan</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-emerald-800 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Telefon raqam tekshirilgan</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Verified Buyer Reviews */}
              {activeTab === 'reviews' && (
                <div className="space-y-2.5 text-xs text-stone-700 max-h-60 overflow-y-auto pr-1">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-stone-900">Abdurahmon M. (Toshkent)</span>
                      <span className="text-amber-600 font-bold font-mono">★★★★★ 5.0</span>
                    </div>
                    <p className="text-stone-600 leading-relaxed text-[11px]">
                      "2 oy oldin shu fermerdan 1 bosh golshtin sigir xarid qildik. Aytilganidek 3 mahal sogʻimda 26 litr sut berdi, tarozi vazni toʻliq toʻgʻri chiqdi. Rahmat!"
                    </p>
                    <span className="text-[10px] text-stone-400 mt-1 block">Tasdiqlangan xarid · 14 mart</span>
                  </div>

                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-stone-900">Sanjarbek (Samarqand)</span>
                      <span className="text-amber-600 font-bold font-mono">★★★★★ 5.0</span>
                    </div>
                    <p className="text-stone-600 leading-relaxed text-[11px]">
                      "Xavfsiz toʻlov (eskrou) orqali oldik. Pul mol yetib kelib, quloq birkasi va vaznini tekshirganimizdan keyin oʻtkazildi. Judayam ishonchli."
                    </p>
                    <span className="text-[10px] text-stone-400 mt-1 block">Tasdiqlangan xarid · 28 fevral</span>
                  </div>

                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-stone-900">Sherzod K. (Jizzax)</span>
                      <span className="text-amber-600 font-bold font-mono">★★★★☆ 4.8</span>
                    </div>
                    <p className="text-stone-600 leading-relaxed text-[11px]">
                      "Qoʻchqorlar juda baquvvat va toza zotli. Yetkazib berish ham oʻz vaqtida boʻldi."
                    </p>
                    <span className="text-[10px] text-stone-400 mt-1 block">Tasdiqlangan xarid · 10 fevral</span>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-stone-200 dark:border-stone-800 mt-4 space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {/* Safe Escrow Purchase Button */}
                <button
                  type="button"
                  onClick={() => onStartEscrow(item)}
                  className="sm:col-span-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-[#F59E0B]/20 transition-all cursor-pointer"
                >
                  <Lock className="w-4 h-4 text-white" />
                  <span>{t.buyWithEscrow}</span>
                </button>

                {/* Compare Toggle Button */}
                {onToggleCompare && (
                  <button
                    type="button"
                    onClick={() => onToggleCompare(item)}
                    className={`py-3 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      isCompared
                        ? 'bg-emerald-800 text-white border-emerald-900 shadow-2xs'
                        : 'bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-750 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700'
                    }`}
                  >
                    <Scale className="w-4 h-4" />
                    <span>{isCompared ? `✓ ${t.compareSelected}` : t.compare}</span>
                  </button>
                )}
              </div>

              {/* Secondary Actions: Call, Telegram, Transport & Vet Consult */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <a
                  href={`tel:${item.seller.phone}`}
                  className="py-2 px-2 rounded-lg border border-stone-300 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                  <span>Qoʻngʻiroq</span>
                </a>

                <a
                  href={`https://t.me/${item.seller.telegramUsername}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2 px-2 rounded-lg border border-sky-300 dark:border-sky-800 bg-sky-50/50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/50 text-sky-900 dark:text-sky-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Send className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                  <span>Telegram</span>
                </a>

                <button
                  type="button"
                  onClick={() => onOpenTransportForListing(item)}
                  className="py-2 px-2 rounded-lg border border-stone-300 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Truck className="w-3.5 h-3.5 text-stone-600 dark:text-stone-400" />
                  <span>Transport</span>
                </button>

                {onOpenVetConsult && (
                  <button
                    type="button"
                    onClick={() => onOpenVetConsult(item)}
                    className="py-2 px-2 rounded-lg border border-sky-300 dark:border-sky-800 bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/50 text-sky-900 dark:text-sky-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                    title="Veterinar vrach bilan onlayn chat"
                  >
                    <Stethoscope className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                    <span>Vet Chat</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
