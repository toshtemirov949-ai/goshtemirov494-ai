import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileText,
  Image as ImageIcon,
  Tag,
  Headphones,
  Copy,
  Check,
  Sparkles,
  ArrowRight,
  Code2,
  RefreshCw,
  Eye,
  Sliders,
  Filter
} from 'lucide-react';
import {
  moderateListingText,
  analyzeLivestockImage,
  extractListingTagsAndSeo,
  generateSupportResponse,
  TextModerationResult,
  ImageModerationResult,
  ListingSeoExtractionResult,
  SupportResponseResult
} from '../services/aiModerator';
import { Language } from '../types';

interface AdminAiModerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const AdminAiModerationModal: React.FC<AdminAiModerationModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const [activeTab, setActiveTab] = useState<'text' | 'image' | 'seo' | 'support'>('text');
  const [copiedJson, setCopiedJson] = useState(false);

  // Tab 1: Text Moderation State
  const [inputText, setInputText] = useState(
    'Golshtin Friesian zotli ikkinchi qorin sogʻin sigir. Kuniga 28 litr sut beradi, vazni 620 kg. Samarqand viloyati Pastdargʻom tumani. Davlat veterinariya emlashlari toʻliq, sogʻlom.'
  );
  const [textResult, setTextResult] = useState<TextModerationResult>(() =>
    moderateListingText(
      'Golshtin Friesian zotli ikkinchi qorin sogʻin sigir. Kuniga 28 litr sut beradi, vazni 620 kg. Samarqand viloyati Pastdargʻom tumani. Davlat veterinariya emlashlari toʻliq, sogʻlom.'
    )
  );

  // Tab 2: Image Screening State
  const [selectedImage, setSelectedImage] = useState<string>(
    'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80'
  );
  const [imageTitleHint, setImageTitleHint] = useState('Golshtin sigir');
  const [imageQualityCondition, setImageQualityCondition] = useState<'normal' | 'blurry' | 'unethical' | 'non-livestock'>('normal');
  const [imageResult, setImageResult] = useState<ImageModerationResult>(() =>
    analyzeLivestockImage(
      'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
      { title: 'Golshtin sigir' }
    )
  );

  // Tab 3: SEO Tagging State
  const [seoInputText, setSeoInputText] = useState(
    'Hisor zotli bahaybat rekord qoʻchqor, yoshi 3 yosh, tirik vazni 145 kg. Qashqadaryo viloyati Qarshi tumani. Qurbonlikka toʻliq tayyor, tish yorgan, semiz.'
  );
  const [seoResult, setSeoResult] = useState<ListingSeoExtractionResult>(() =>
    extractListingTagsAndSeo(
      'Hisor zotli bahaybat rekord qoʻchqor, yoshi 3 yosh, tirik vazni 145 kg. Qashqadaryo viloyati Qarshi tumani. Qurbonlikka toʻliq tayyor, tish yorgan, semiz.'
    )
  );

  // Tab 4: Support FAQ State
  const [supportQuestion, setSupportQuestion] = useState(
    'Eskrou orqali toʻlov qildim, pul sotuvchiga qachon oʻtadi va hayvon yoqmasa pulimni qanday qaytarib olaman?'
  );
  const [supportResult, setSupportResult] = useState<SupportResponseResult>(() =>
    generateSupportResponse(
      'Eskrou orqali toʻlov qildim, pul sotuvchiga qachon oʻtadi va hayvon yoqmasa pulimni qanday qaytarib olaman?'
    )
  );

  if (!isOpen) return null;

  // Handlers
  const handleModerateText = (text: string) => {
    setInputText(text);
    setTextResult(moderateListingText(text));
  };

  const handleRunImageCheck = (imgUrl: string, condition: 'normal' | 'blurry' | 'unethical' | 'non-livestock', title: string) => {
    setSelectedImage(imgUrl);
    setImageQualityCondition(condition);
    setImageTitleHint(title);
    setImageResult(
      analyzeLivestockImage(imgUrl, {
        title,
        isBlurry: condition === 'blurry',
        isUnethical: condition === 'unethical',
        forceReject: condition === 'non-livestock',
      })
    );
  };

  const handleRunSeoExtraction = (text: string) => {
    setSeoInputText(text);
    setSeoResult(extractListingTagsAndSeo(text));
  };

  const handleRunSupportGen = (q: string) => {
    setSupportQuestion(q);
    setSupportResult(generateSupportResponse(q));
  };

  const jsonOutput = JSON.stringify(
    {
      status: textResult.status,
      reason: textResult.reason,
      category: textResult.category,
    },
    null,
    2
  );

  const handleCopyJson = () => {
    navigator.clipboard.writeText(jsonOutput);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] w-full max-w-4xl rounded-3xl shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#041C16] via-[#072D24] to-[#041C16] text-white p-5 sm:p-6 shrink-0 relative border-b border-[#0E3D32]">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 text-stone-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-all cursor-pointer"
            title="Yopish"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] text-white flex items-center justify-center shadow-lg font-black">
              <ShieldCheck className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black font-serif text-white">
                  AI Admin & Moderatsiya Markazi
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-[#10B981]/20 text-[#10B981] text-xs font-bold border border-[#10B981]/30">
                  Avtomatik Tekshiruv
                </span>
              </div>
              <p className="text-xs text-emerald-100/80 mt-0.5">
                Eʼlon matnlarini tekshirish, rasm saralash, SEO teglash va mijozlar xizmati generatori
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-5 border-t border-emerald-800/60 pt-4 overflow-x-auto no-scrollbar">
            {[
              { id: 'text', label: '1. Matn Moderatsiyasi (JSON)', icon: FileText },
              { id: 'image', label: '2. Rasm Saralash & Filtrlash', icon: ImageIcon },
              { id: 'seo', label: '3. Avtomatik Teglash & SEO', icon: Tag },
              { id: 'support', label: '4. Qoʻllab-quvvatlash (Support)', icon: Headphones },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
                    isActive
                      ? 'bg-amber-400 text-stone-950 shadow-md font-black'
                      : 'bg-emerald-950/70 text-emerald-100 hover:bg-emerald-900 border border-emerald-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-7 overflow-y-auto space-y-6 flex-1 bg-stone-50 dark:bg-stone-900/60 text-stone-900 dark:text-stone-100">
          {/* TAB 1: E'lon matnini tahlil qilish va JSON qaytarish */}
          {activeTab === 'text' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-extrabold text-base text-stone-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span>1. Eʼlon Matnini Moderatsiya Qilish va JSON Chiqarish</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Matn tahlil qilinadi, haqoratli yoki spam belgilar tekshiriladi va talabga binoan JSON formati qaytariladi.
                </p>
              </div>

              {/* Sample Quick Chips */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
                  Sinov uchun tayyor namunalar:
                </span>
                <div className="flex flex-wrap gap-2 text-xs">
                  <button
                    onClick={() =>
                      handleModerateText(
                        'Golshtin Friesian sogʻin sigir, kuniga 28 litr sut, vazni 620 kg. Samarqand Pastdargʻom tumani, barcha emlashlari oʻtkazilgan.'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-semibold cursor-pointer border border-emerald-300"
                  >
                    ✓ Toza qoramol eʼloni (APPROVED)
                  </button>
                  <button
                    onClick={() =>
                      handleModerateText(
                        'Hisor zotli 145 kg bahaybat qoʻchqor, Qashqadaryo. Qurbonlikka tish yorgan, semiz.'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-sky-100 hover:bg-sky-200 text-sky-900 font-semibold cursor-pointer border border-sky-300"
                  >
                    ✓ Toza qoʻy eʼloni (APPROVED)
                  </button>
                  <button
                    onClick={() =>
                      handleModerateText(
                        'Kriptovalyuta va onlayn kazino orqali kuniga 500$ pul ishlash sirlari. Telegram kanalimizga obuna boʻling!'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-900 font-semibold cursor-pointer border border-rose-300"
                  >
                    ✗ Spam / Begona mavzu (REJECTED)
                  </button>
                  <button
                    onClick={() =>
                      handleModerateText(
                        'Mol sotiladi lekin bu narxga bermayman, ahmoq boʻlsang olasan padariga laʼnat.'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 font-semibold cursor-pointer border border-amber-300"
                  >
                    ✗ Odobsiz soʻzlar (REJECTED)
                  </button>
                </div>
              </div>

              {/* Text Input Area */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block">
                  Tahlil qilinadigan foydalanuvchi matni:
                </label>
                <textarea
                  rows={4}
                  value={inputText}
                  onChange={(e) => handleModerateText(e.target.value)}
                  placeholder="Eʼlon matnini kiriting..."
                  className="w-full p-3 text-xs bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none font-sans leading-relaxed shadow-inner"
                />
              </div>

              {/* Result Grid: Visual Summary + Raw JSON */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Visual Verdict Card */}
                <div className="p-4 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                      Moderatsiya Natijasi
                    </span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-black tracking-wider flex items-center gap-1.5 shadow-xs ${
                        textResult.status === 'APPROVED'
                          ? 'bg-emerald-500 text-white'
                          : 'bg-rose-500 text-white'
                      }`}
                    >
                      {textResult.status === 'APPROVED' ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>APPROVED</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>REJECTED</span>
                        </>
                      )}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="text-stone-500 text-[11px] block">Toifa (Category):</span>
                      <strong className="text-sm font-bold text-stone-900 dark:text-white font-serif">
                        {textResult.category}
                      </strong>
                    </div>

                    <div>
                      <span className="text-stone-500 text-[11px] block">Xulosa / Sabab (Reason):</span>
                      <p
                        className={`font-medium leading-relaxed ${
                          textResult.status === 'APPROVED' ? 'text-emerald-700 dark:text-emerald-300' : 'text-rose-700 dark:text-rose-300'
                        }`}
                      >
                        {textResult.reason}
                      </p>
                    </div>

                    {textResult.details && textResult.details.length > 0 && (
                      <div className="pt-2 border-t border-stone-100 dark:border-stone-800">
                        <span className="text-stone-400 text-[10px] uppercase font-bold block mb-1">
                          Detallar:
                        </span>
                        <ul className="list-disc list-inside text-[11px] text-stone-600 dark:text-stone-400 space-y-0.5">
                          {textResult.details.map((d, i) => (
                            <li key={i}>{d}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>

                {/* Exact Target JSON Output Card */}
                <div className="p-4 rounded-2xl bg-stone-900 text-white border border-stone-800 shadow-md space-y-2 font-mono flex flex-col justify-between">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                    <span className="text-xs text-amber-300 font-bold flex items-center gap-1.5 font-sans">
                      <Code2 className="w-4 h-4" />
                      <span>Standart JSON Chiqishi</span>
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyJson}
                      className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs flex items-center gap-1 cursor-pointer transition-colors"
                      title="Nusxalash"
                    >
                      {copiedJson ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Nusxalandi</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Nusxalash</span>
                        </>
                      )}
                    </button>
                  </div>

                  <pre className="text-xs text-emerald-400 p-2 rounded-xl bg-black/40 overflow-x-auto leading-relaxed">
                    {jsonOutput}
                  </pre>

                  <div className="text-[10px] text-stone-400 font-sans">
                    ✓ format: status ("APPROVED" | "REJECTED"), reason, category
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Chorva rasmlarini avtomatik saralash va filtrlash */}
          {activeTab === 'image' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-extrabold text-base text-stone-900 dark:text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-sky-600" />
                  <span>2. Chorva Rasmlarini Avtomatik Saralash va Sifatini Baholash</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Yuklangan rasm haqiqatan ham chorva moli yoki fermerlikka tegishli ekanligini hamda sifati yetarliligini tekshirish.
                </p>
              </div>

              {/* Sample Photo Options */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
                  Sinov uchun rasm ssenariylari:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    onClick={() =>
                      handleRunImageCheck(
                        'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
                        'normal',
                        'Golshtin zotli sigir'
                      )
                    }
                    className={`p-2 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedImage.includes('1546445317') && imageQualityCondition === 'normal'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 ring-2 ring-emerald-500'
                        : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-850'
                    }`}
                  >
                    <img
                      src="https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=300&q=80"
                      alt="Qoramol"
                      className="w-full h-16 object-cover rounded-lg mb-1.5"
                    />
                    <strong className="text-[11px] text-stone-900 dark:text-white block truncate">Qoramol (Sogʻin)</strong>
                    <span className="text-[10px] text-emerald-600 font-bold">Mos / Yuqori sifat</span>
                  </button>

                  <button
                    onClick={() =>
                      handleRunImageCheck(
                        'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
                        'normal',
                        'Hisor qoʻchqor'
                      )
                    }
                    className={`p-2 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedImage.includes('1484557052') && imageQualityCondition === 'normal'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 ring-2 ring-emerald-500'
                        : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-850'
                    }`}
                  >
                    <img
                      src="https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=300&q=80"
                      alt="Qo'y"
                      className="w-full h-16 object-cover rounded-lg mb-1.5"
                    />
                    <strong className="text-[11px] text-stone-900 dark:text-white block truncate">Hisor Qoʻy</strong>
                    <span className="text-[10px] text-emerald-600 font-bold">Mos / Yuqori sifat</span>
                  </button>

                  <button
                    onClick={() =>
                      handleRunImageCheck(
                        'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&q=80',
                        'normal',
                        'Chorvavoz fura'
                      )
                    }
                    className={`p-2 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedImage.includes('1601584115') && imageQualityCondition === 'normal'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 ring-2 ring-emerald-500'
                        : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-850'
                    }`}
                  >
                    <img
                      src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=300&q=80"
                      alt="Fura"
                      className="w-full h-16 object-cover rounded-lg mb-1.5"
                    />
                    <strong className="text-[11px] text-stone-900 dark:text-white block truncate">Chorvavoz Fura</strong>
                    <span className="text-[10px] text-emerald-600 font-bold">Mos / Logistika</span>
                  </button>

                  <button
                    onClick={() =>
                      handleRunImageCheck(
                        'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
                        'blurry',
                        'Xira olingan surat'
                      )
                    }
                    className={`p-2 rounded-xl border text-left cursor-pointer transition-all ${
                      imageQualityCondition === 'blurry'
                        ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 ring-2 ring-rose-500'
                        : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-850'
                    }`}
                  >
                    <div className="w-full h-16 bg-stone-300 dark:bg-stone-700 blur-[2px] rounded-lg mb-1.5 flex items-center justify-center text-[10px] text-stone-600">
                      [Xira surat]
                    </div>
                    <strong className="text-[11px] text-stone-900 dark:text-white block truncate">Xira surat</strong>
                    <span className="text-[10px] text-rose-600 font-bold">Rad etiladi (Sifatsiz)</span>
                  </button>
                </div>
              </div>

              {/* Analysis Result Display */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                {/* Image Preview (5 cols) */}
                <div className="md:col-span-5 relative rounded-2xl overflow-hidden border border-stone-300 dark:border-stone-700 shadow-md">
                  <img
                    src={selectedImage}
                    alt="Tanlangan rasm"
                    className={`w-full h-56 object-cover ${imageQualityCondition === 'blurry' ? 'blur-xs' : ''}`}
                  />
                  <div className="absolute bottom-2 left-2 right-2 bg-black/70 backdrop-blur-md p-2 rounded-xl text-white text-[11px] flex items-center justify-between">
                    <span>{imageTitleHint}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        imageResult.qaror === 'Qabul qilindi' ? 'bg-emerald-600' : 'bg-rose-600'
                      }`}
                    >
                      {imageResult.qaror}
                    </span>
                  </div>
                </div>

                {/* Formatted Output Box (7 cols) */}
                <div className="md:col-span-7 p-4 sm:p-5 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 shadow-xs space-y-3 font-sans">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800">
                    <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                      Rasm Moderatsiya Xulosasi
                    </span>
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-black ${
                        imageResult.qaror === 'Qabul qilindi'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      }`}
                    >
                      {imageResult.qaror}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between py-1 border-b border-stone-100 dark:border-stone-800">
                      <span className="text-stone-500 font-medium">Moslik:</span>
                      <strong className={`font-black ${imageResult.moslik === 'Ha' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        [{imageResult.moslik}]
                      </strong>
                    </div>

                    <div className="py-1 border-b border-stone-100 dark:border-stone-800">
                      <span className="text-stone-500 font-medium block">Rasmda nima tasvirlangan:</span>
                      <strong className="text-stone-900 dark:text-white font-semibold">
                        [{imageResult.nimaTasvirlangan}]
                      </strong>
                    </div>

                    <div className="flex items-center justify-between py-1 border-b border-stone-100 dark:border-stone-800">
                      <span className="text-stone-500 font-medium">Sifat bahosi:</span>
                      <span
                        className={`font-bold px-2 py-0.5 rounded ${
                          imageResult.sifatBahosi === 'Yuqori'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : imageResult.sifatBahosi === 'Oʻrta'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        [{imageResult.sifatBahosi}]
                      </span>
                    </div>

                    <div className="flex items-center justify-between py-1">
                      <span className="text-stone-500 font-medium">Qaror:</span>
                      <strong
                        className={`text-sm font-black ${
                          imageResult.qaror === 'Qabul qilindi' ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        [{imageResult.qaror}]
                      </strong>
                    </div>

                    {imageResult.radEtishSabablari.length > 0 && (
                      <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900 text-[11px] text-rose-800 dark:text-rose-300">
                        <strong className="block font-bold mb-0.5">Rad etish sababi:</strong>
                        {imageResult.radEtishSabablari.map((s, i) => (
                          <div key={i}>{s}</div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: E'lonlar uchun avtomatik teglash va SEO ajratish */}
          {activeTab === 'seo' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-extrabold text-base text-stone-900 dark:text-white flex items-center gap-2">
                  <Tag className="w-4 h-4 text-amber-600" />
                  <span>3. Eʼlonlar Uchun Avtomatik Teglash va Kategoriyalarga Ajratish</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Qidiruv tizimi va admin kabineti uchun matndan hayvon turi, yoshi, vazni, hudud va 5-8 ta SEO teglarini ajratib olish.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block">
                  Eʼlon matni:
                </label>
                <textarea
                  rows={3}
                  value={seoInputText}
                  onChange={(e) => handleRunSeoExtraction(e.target.value)}
                  placeholder="Eʼlon matnini kiriting..."
                  className="w-full p-3 text-xs bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-2xl focus:ring-2 focus:ring-amber-500 outline-none font-sans"
                />
              </div>

              {/* Extraction Output Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div className="p-3.5 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 shadow-xs">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                    1. Hayvon Turi
                  </span>
                  <strong className="text-sm font-bold text-stone-900 dark:text-white block font-serif">
                    {seoResult.hayvonTuri}
                  </strong>
                </div>

                <div className="p-3.5 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 shadow-xs">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                    2. Yoshi va Vazni
                  </span>
                  <strong className="text-sm font-bold text-stone-900 dark:text-white block font-mono">
                    {seoResult.yoshiVaVazni}
                  </strong>
                </div>

                <div className="p-3.5 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 shadow-xs">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                    3. Joylashuv / Hudud
                  </span>
                  <strong className="text-sm font-bold text-emerald-700 dark:text-emerald-400 block font-serif">
                    {seoResult.hudud}
                  </strong>
                </div>
              </div>

              {/* Generated SEO Tag List */}
              <div className="p-4 rounded-2xl bg-stone-900 text-white border border-stone-800 shadow-sm space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5 font-sans">
                    <Tag className="w-3.5 h-3.5" />
                    <span>4. SEO Teglar Roʻyxati ({seoResult.teglar.length} ta kalit soʻz)</span>
                  </span>
                  <span className="text-[10px] text-stone-400 font-mono">Avtomatik qidiruv indeksi</span>
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  {seoResult.teglar.map((tag, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded-xl bg-stone-800 hover:bg-stone-700 text-emerald-300 font-mono font-semibold text-xs border border-stone-700 transition-colors"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Qo'llab-quvvatlash xizmati (Support) uchun javoblar shabloni */}
          {activeTab === 'support' && (
            <div className="space-y-5">
              <div>
                <h3 className="font-extrabold text-base text-stone-900 dark:text-white flex items-center gap-2">
                  <Headphones className="w-4 h-4 text-purple-600" />
                  <span>4. Qoʻllab-quvvatlash Xizmati (Support) Uchun Javoblar Generatori</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Foydalanuvchilar beradigan murojaat va koʻp beriladigan savollarga (FAQ) xushmuomala, aniq va bosqichma-bosqich javob tayyorlash.
                </p>
              </div>

              {/* Sample Quick FAQ Question Chips */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
                  Mijozlarning eng koʻp soʻraydigan savollari:
                </span>
                <div className="flex flex-wrap gap-2 text-xs">
                  <button
                    onClick={() =>
                      handleRunSupportGen(
                        'Eskrou orqali toʻlov qildim, pul sotuvchiga qachon oʻtadi va hayvon yoqmasa pulimni qanday qaytarib olaman?'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 cursor-pointer text-left"
                  >
                    💬 Xavfsiz toʻlov & pulni qaytarish tartibi
                  </button>
                  <button
                    onClick={() =>
                      handleRunSupportGen(
                        'Viloyatga yetkazib berish qancha turadi va 100 km bepul fura aksiyasi qanday ishlaydi?'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 cursor-pointer text-left"
                  >
                    💬 Fura va 100 km bepul yetkazish
                  </button>
                  <button
                    onClick={() =>
                      handleRunSupportGen(
                        'Hayvonning emlanganligi va rasmiy veterinariya pasportini qanday tekshirsam boʻladi?'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 cursor-pointer text-left"
                  >
                    💬 Davlat vet pasporti va emlashlar
                  </button>
                  <button
                    onClick={() =>
                      handleRunSupportGen(
                        'Jonli auksionda qanday qatnashaman va stavkam gʻolib boʻlsa nima qilishim kerak?'
                      )
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 cursor-pointer text-left"
                  >
                    💬 Jonli auksion stavkalari
                  </button>
                </div>
              </div>

              {/* User Question Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300 block">
                  Foydalanuvchi murojaati / savoli:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={supportQuestion}
                    onChange={(e) => setSupportQuestion(e.target.value)}
                    placeholder="Mijoz savolini yozing..."
                    className="flex-1 p-2.5 text-xs bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <button
                    onClick={() => handleRunSupportGen(supportQuestion)}
                    className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all cursor-pointer shadow-xs"
                  >
                    Javob Yaratish
                  </button>
                </div>
              </div>

              {/* Generated Support Response Card */}
              <div className="p-5 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
                  <span className="text-xs font-black text-purple-700 dark:text-purple-400 uppercase tracking-wider">
                    Mavzu: {supportResult.mavzu}
                  </span>
                  <span className="text-[10px] text-stone-400">
                    Rasmiy Qoʻllab-quvvatlash Shablon
                  </span>
                </div>

                <div className="whitespace-pre-wrap text-xs text-stone-800 dark:text-stone-200 leading-relaxed font-sans bg-stone-50 dark:bg-stone-900/60 p-4 rounded-xl border border-stone-200/80 dark:border-stone-800">
                  {supportResult.javob}
                </div>

                {/* Steps Highlights */}
                <div>
                  <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block mb-2">
                    Muammoni hal qilish bosqichlari:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {supportResult.bosqichlar.map((b, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 text-xs border border-emerald-200/60 dark:border-emerald-800/60"
                      >
                        <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                          {i + 1}
                        </span>
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-100 dark:bg-stone-950 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between text-xs text-stone-500 shrink-0">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>AI Moderatsiya & Xavfsizlik Qoidalari (ChorvaBozor Standard v2.6)</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white dark:bg-stone-800 dark:hover:bg-stone-700 font-bold text-xs cursor-pointer"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
