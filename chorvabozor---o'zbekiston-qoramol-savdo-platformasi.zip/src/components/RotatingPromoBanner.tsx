import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Zap,
  Truck,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { promoSlides } from './ModernWelcomePromoModal';

interface RotatingPromoBannerProps {
  onOpenPromo: () => void;
  onOpenQurbonlik: () => void;
  onOpenAddListing: () => void;
}

export const RotatingPromoBanner: React.FC<RotatingPromoBannerProps> = ({
  onOpenPromo,
  onOpenQurbonlik,
  onOpenAddListing,
}) => {
  const [slideIndex, setSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto rotate dynamically every 4 seconds through all 6 varied ads
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setSlideIndex((prev) => (prev + 1) % promoSlides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [isPaused]);

  const slide = promoSlides[slideIndex];

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSlideIndex((prev) => (prev + 1) % promoSlides.length);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSlideIndex((prev) => (prev - 1 + promoSlides.length) % promoSlides.length);
  };

  return (
    <div
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="bg-stone-900 dark:bg-stone-950 border-y border-stone-800 py-2 px-3 sm:px-4 text-xs shadow-inner relative transition-colors"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2.5">
        {/* Left: Thumbnail & Animated Badge */}
        <div
          onClick={onOpenPromo}
          className="flex items-center gap-2.5 overflow-hidden flex-1 min-w-0 cursor-pointer group"
        >
          {/* Mini Thumbnail (shows real Fura on delivery slide, sheep on qurbonlik, etc.) */}
          <div className="w-10 h-7 sm:w-12 sm:h-8 rounded-lg overflow-hidden shrink-0 border border-stone-700/80 shadow-xs relative bg-black hidden xs:block">
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            />
            {slide.id === 'slide-transport-fura' && (
              <div className="absolute inset-0 bg-emerald-950/30 flex items-center justify-center">
                <Truck className="w-3.5 h-3.5 text-amber-300 drop-shadow-md" />
              </div>
            )}
          </div>

          {/* Dynamic Badge */}
          <span
            className={`px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-black tracking-wider uppercase shrink-0 flex items-center gap-1 shadow-xs animate-pulse ${slide.badgeColor}`}
          >
            <Zap className="w-2.5 h-2.5 fill-current" />
            <span className="hidden sm:inline">{slide.badge}</span>
            <span className="sm:hidden">AKSIYA {slideIndex + 1}/{promoSlides.length}</span>
          </span>

          {/* Dynamic Content (Title + Tariff) */}
          <div
            key={slide.id}
            className="flex items-center gap-2 overflow-hidden min-w-0 animate-in fade-in slide-in-from-right-3 duration-300"
          >
            <span className="font-extrabold text-white truncate text-xs group-hover:text-amber-300 transition-colors">
              {slide.title}
            </span>
            <span className="hidden md:inline text-emerald-300 text-xs font-semibold shrink-0">
              — {slide.tariffTitle}: <strong className="text-amber-300 font-mono font-bold">{slide.newPrice}</strong>
            </span>
          </div>
        </div>

        {/* Right: Slide Controls & CTA Button */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Prev/Next arrows */}
          <button
            type="button"
            onClick={handlePrev}
            className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer hidden sm:block"
            title="Oldingi aksiya"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1 hidden md:flex">
            {promoSlides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setSlideIndex(idx)}
                className={`h-1.5 rounded-full transition-all cursor-pointer ${
                  slideIndex === idx ? 'w-4 bg-amber-400' : 'w-1.5 bg-stone-700 hover:bg-stone-500'
                }`}
                title={`Aksiya ${idx + 1}`}
              />
            ))}
          </div>

          <button
            type="button"
            onClick={handleNext}
            className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer hidden sm:block"
            title="Keyingi aksiya"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Open Full Tariff CTA */}
          <button
            type="button"
            onClick={onOpenPromo}
            className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 font-black text-[10px] sm:text-[11px] flex items-center gap-1 transition-all cursor-pointer shadow-md whitespace-nowrap active:scale-95 ml-1"
          >
            <span>Tarif</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
