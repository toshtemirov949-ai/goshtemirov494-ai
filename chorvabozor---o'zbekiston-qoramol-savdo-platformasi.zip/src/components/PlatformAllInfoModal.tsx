import React, { useState } from 'react';
import {
  X,
  Building2,
  ShieldCheck,
  TrendingUp,
  Truck,
  Zap,
  Play,
  BookOpen,
  Scale,
  Award,
  Phone,
  Send,
  Mail,
  MapPin,
  CheckCircle2,
  FileText,
  DollarSign,
  HeartHandshake,
  Search,
  ExternalLink,
  ChevronRight,
  Layers,
  Sparkles
} from 'lucide-react';
import { Language } from '../types';

interface PlatformAllInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onOpenPriceIndex?: () => void;
  onOpenTransport?: () => void;
  onOpenAuctions?: () => void;
  onOpenReels?: () => void;
  onOpenBreedGuide?: () => void;
  onOpenSellerGuide?: () => void;
  onOpenQurbonlik?: () => void;
  onOpenTelegram?: () => void;
  onOpenBusinessModel?: () => void;
  onOpenStrategy?: () => void;
}

export const PlatformAllInfoModal: React.FC<PlatformAllInfoModalProps> = ({
  isOpen,
  onClose,
  language,
  onOpenPriceIndex,
  onOpenTransport,
  onOpenAuctions,
  onOpenReels,
  onOpenBreedGuide,
  onOpenSellerGuide,
  onOpenQurbonlik,
  onOpenTelegram,
  onOpenBusinessModel,
  onOpenStrategy,
}) => {
  const [activeTab, setActiveTab] = useState<
    'general' | 'services' | 'security' | 'stats' | 'business' | 'contacts'
  >('general');
  const [searchFilter, setSearchFilter] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 w-full max-w-5xl rounded-3xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-stone-950 text-white p-6 shrink-0 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 text-stone-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-all cursor-pointer"
            title="Yopish"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5" />
              RASMIY PLATFORMA PASPORTI
            </span>
            <span className="text-emerald-200/70 text-xs">Versiya 2.4 (2026)</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black font-serif tracking-tight text-white">
            ChorvaBozor Platformasining Barcha Maʼlumotlari
          </h2>
          <p className="text-emerald-100/80 text-xs sm:text-sm mt-1 max-w-3xl leading-relaxed">
            Oʻzbekistonda chorva mollari savdosini raqamlashtirish, dallolsiz toza narxlar, davlat veterinariya nazorati, kafolatlangan xavfsiz toʻlov (eskrou) va viloyatlararo logistika boʻyicha toʻliq maʼlumotlar toʻplami.
          </p>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-5 border-t border-emerald-800/60 pt-4 overflow-x-auto no-scrollbar">
            {[
              { id: 'general', label: 'Umumiy & Missiya', icon: Building2 },
              { id: 'services', label: 'Barcha Xizmatlar (12 ta)', icon: Layers },
              { id: 'security', label: 'Kafolatlar & Eskrou', icon: ShieldCheck },
              { id: 'stats', label: 'Raqamlar & Qamrov', icon: TrendingUp },
              { id: 'business', label: 'Biznes & Monetizatsiya', icon: DollarSign },
              { id: 'contacts', label: 'Bogʻlanish & Rekvizitlar', icon: Phone },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                    isActive
                      ? 'bg-amber-400 text-stone-950 shadow-md font-black'
                      : 'bg-emerald-950/60 text-emerald-100 hover:bg-emerald-900 border border-emerald-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-7 overflow-y-auto space-y-6 flex-1 bg-stone-50 dark:bg-stone-900/60">
          {/* TAB 1: Umumiy Ma'lumot & Missiya */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              {/* Highlight Card */}
              <div className="bg-white dark:bg-stone-850 rounded-2xl p-5 sm:p-6 border border-stone-200 dark:border-stone-800 shadow-xs">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-800 text-white font-serif font-black text-2xl flex items-center justify-center shrink-0 shadow-md">
                    CH
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg sm:text-xl font-black text-stone-900 dark:text-white">
                      ChorvaBozor — Oʻzbekistonda 1-Raqamli Kafolatlangan Chorva Savdosi Ekotizimi
                    </h3>
                    <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 leading-relaxed">
                      ChorvaBozor — anʼanaviy jismoniy chorva bozorlaridagi oʻrtakashlik (dallolchilik), noaniq tarozi vaznlari, kasallik yuqtirish xavfi va uzoq masofaga qatnash xarajatlarini toʻliq bartaraf etish uchun yaratilgan birinchi mustaqil agro-texnologik platformadir.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 pt-5 border-t border-stone-100 dark:border-stone-800 text-xs">
                  <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                    <div className="font-bold text-emerald-950 dark:text-emerald-300 mb-1 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>Dallolsiz Toza Narx</span>
                    </div>
                    <p className="text-stone-600 dark:text-stone-300 text-[11px] leading-relaxed">
                      Oʻrtakashlarning 15–20% lik sunʼiy ustamasisiz toʻgʻridan-toʻgʻri nasldor fermerlar va xususiy mol egalari bilan bitim.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800">
                    <div className="font-bold text-blue-950 dark:text-blue-300 mb-1 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-blue-600" />
                      <span>Davlat Veterinariya Pasporti</span>
                    </div>
                    <p className="text-stone-600 dark:text-stone-300 text-[11px] leading-relaxed">
                      Kasal yoki emlanmagan hayvonlar joylashtirilmaydi. Har bir eʼlonda emlash va qon tahlili maʼlumotlari koʻrsatiladi.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
                    <div className="font-bold text-amber-950 dark:text-amber-300 mb-1 flex items-center gap-1.5">
                      <HeartHandshake className="w-4 h-4 text-amber-600" />
                      <span>Xavfsiz Toʻlov (Eskrou)</span>
                    </div>
                    <p className="text-stone-600 dark:text-stone-300 text-[11px] leading-relaxed">
                      Xaridor molni oʻz koʻzi bilan koʻrib, qabul qilib olmagunicha toʻlov platformada xavfsiz muzlatiladi.
                    </p>
                  </div>
                </div>
              </div>

              {/* Solved Problems */}
              <div className="bg-white dark:bg-stone-850 rounded-2xl p-5 border border-stone-200 dark:border-stone-800">
                <h4 className="text-sm font-extrabold text-stone-900 dark:text-white uppercase tracking-wider mb-3">
                  Anʼanaviy Bozor va ChorvaBozor Taqqoslanishi
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900">
                    <span className="font-bold text-rose-800 dark:text-rose-300 block mb-2">❌ Anʼanaviy Bozor Muammolari:</span>
                    <ul className="space-y-1.5 text-stone-600 dark:text-stone-400">
                      <li>• Bozorga borish uchun butun kun va 300,000+ soʻm yoʻl xarajati</li>
                      <li>• Dallollar narxni 15–20% ga asossiz koʻtarib sotadi</li>
                      <li>• Quloq birkasi va soxta tarozi bilan aldash xavfi yuqori</li>
                      <li>• Mol olib kelganda transportda jarohatlanish xavfi</li>
                      <li>• Naqd pulni koʻtarib yurish va xavfsizlik muammolari</li>
                    </ul>
                  </div>

                  <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                    <span className="font-bold text-emerald-800 dark:text-emerald-300 block mb-2">✅ ChorvaBozor Yechimi:</span>
                    <ul className="space-y-1.5 text-stone-600 dark:text-stone-400">
                      <li>• Uyda oʻtirib 360° video va tarozi dalolatnomasini koʻrish</li>
                      <li>• Fermerning oʻzi bilan toʻgʻridan-toʻgʻri adolatli savdo</li>
                      <li>• Davlat veterinariya tizimi orqali tekshirilgan pasport</li>
                      <li>• Maxsus moslashtirilgan furgonlarda sugʻurtalangan yetkazish</li>
                      <li>• Eskrou xavfsiz toʻlov kafolati bilan 100% himoya</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Barcha Xizmatlar */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-extrabold text-stone-900 dark:text-white">
                  Platformada Mavjud 12 Ta Asosiy Xizmat va Funksiyalar
                </h4>
                <span className="text-xs text-stone-500">Ixtiyoriy xizmatni bitta tugmada oching</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {[
                  {
                    title: '1. Qoramol Kabineti (5 ta zot)',
                    desc: 'Golshtin, Qizil choʻl, Simmental, Angus/Hereford va Jaydari qoramollar boʻlimi.',
                    icon: '🐂',
                    action: () => {
                      onClose();
                      const el = document.getElementById('catalog');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    },
                  },
                  {
                    title: '2. Qoʻy va Qoʻchqorlar Kabineti (4 ta zot)',
                    desc: 'Hisor (180 kg gacha bahaybat), Edilboy, Merinos va Jaydari qoʻylar boʻlimi.',
                    icon: '🐑',
                    action: () => {
                      onClose();
                      const el = document.getElementById('catalog');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    },
                  },
                  {
                    title: '3. Otchilik Kabineti (4 ta zot)',
                    desc: 'Qorabayir (koʻpkari/uloq), Axaltaka (elita husndor), Rus ogʻir yuki va Sport otlari.',
                    icon: '🐎',
                    action: () => {
                      onClose();
                      const el = document.getElementById('catalog');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    },
                  },
                  {
                    title: '4. Rasmiy Zotlar Qomusi (13 ta zot)',
                    desc: 'Har bir zotning kelib chiqishi, sut/goʻsht koʻrsatkichi, vazni va boqish tavsiyalari.',
                    icon: '📖',
                    action: () => {
                      onClose();
                      onOpenBreedGuide?.();
                    },
                  },
                  {
                    title: '5. Oltin Sotuvchi Qoʻllanmasi & AI Promptlar',
                    desc: '5 ta oltin qoida va Midjourney v6 / SDXL uchun professional fotostudiya prompt generatori.',
                    icon: '📈',
                    action: () => {
                      onClose();
                      onOpenSellerGuide?.();
                    },
                  },
                  {
                    title: '6. Jonli Auksion Tizimi',
                    desc: 'Haqiqiy raqobat va shaffof narx: eng yuqori stavka qoʻygan xaridorga taqdim etiladi.',
                    icon: '⚡',
                    action: () => {
                      onClose();
                      onOpenAuctions?.();
                    },
                  },
                  {
                    title: '7. Dinamik Video Reels',
                    desc: 'Instagram-uslubidagi toʻliq ekranli vertikal video koʻrik va bitta tugmada xarid.',
                    icon: '🎬',
                    action: () => {
                      onClose();
                      onOpenReels?.();
                    },
                  },
                  {
                    title: '8. Viloyatlar Narx Indeksi',
                    desc: '12 ta viloyat boʻyicha tirik vazn (soʻm/kg) va goʻsht bozorining haftalik dinamikasi.',
                    icon: '📊',
                    action: () => {
                      onClose();
                      onOpenPriceIndex?.();
                    },
                  },
                  {
                    title: '9. Viloyatlararo Transport Kalkulyatori',
                    desc: 'Masofani aniqlash, mashina turi (Isuzu, Gazel, Furgon) va sugʻurtalangan yetkazish hisobi.',
                    icon: '🚚',
                    action: () => {
                      onClose();
                      onOpenTransport?.();
                    },
                  },
                  {
                    title: '10. Qurbonlik Hayiti 2026 Maxsus Dasturi',
                    desc: 'Shariat talablariga mos yosh/tish koʻrigi, kushxona va uyga yetkazib berish bilan bron qilish.',
                    icon: '🌙',
                    action: () => {
                      onClose();
                      onOpenQurbonlik?.();
                    },
                  },
                  {
                    title: '11. 3 Ta Molni Yonma-yon Taqqoslash',
                    desc: 'Vazn, narx, zot, emlash va narx/kg koʻrsatkichlarini bitta jadvalda solishtirish.',
                    icon: '⚖️',
                    action: () => {
                      onClose();
                      const el = document.getElementById('catalog');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    },
                  },
                  {
                    title: '12. Telegram Bot & Mini-App Ekotizimi',
                    desc: '@ChorvaBozor_bot orqali yangi eʼlonlar, auksion bildirishnomalari va buyurtma holati.',
                    icon: '🤖',
                    action: () => {
                      onClose();
                      onOpenTelegram?.();
                    },
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 flex items-start justify-between gap-3 shadow-xs hover:border-emerald-500 transition-colors"
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="text-2xl shrink-0">{item.icon}</span>
                      <div>
                        <h5 className="font-extrabold text-stone-900 dark:text-white">{item.title}</h5>
                        <p className="text-stone-500 dark:text-stone-400 text-[11px] mt-0.5 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={item.action}
                      className="px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-emerald-800 hover:text-white text-stone-700 dark:text-stone-300 text-[11px] font-bold shrink-0 transition-colors cursor-pointer"
                    >
                      Ochish →
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Xavfsizlik & Kafolatlar */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              <div className="bg-emerald-950 text-white rounded-2xl p-6 border border-emerald-800">
                <div className="flex items-center gap-2 mb-2">
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                  <h3 className="text-lg font-black">ChorvaBozor 4 Bosqichli Xavfsizlik Konsepsiyasi</h3>
                </div>
                <p className="text-emerald-200/80 text-xs leading-relaxed">
                  Har bir tranzaksiya foydalanuvchilarning moliyaviy va huquqiy xavfsizligini 100% kafolatlaydi.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800">
                  <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-400 font-extrabold text-sm mb-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    <span>1. Davlat Veterinariya Tizimi Integratsiyasi</span>
                  </div>
                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                    Veterinariya pasporti, kuydirgi, oqsil va brutsellyozga qarshi emlash sertifikatlari rasmiy davlat inspektori tomonidan tekshirilib tasdiqlanadi.
                  </p>
                </div>

                <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800">
                  <div className="flex items-center gap-2 text-blue-800 dark:text-blue-400 font-extrabold text-sm mb-1.5">
                    <Scale className="w-4 h-4" />
                    <span>2. Tarozi Dalolatnomasi va Video Fiksatsiya</span>
                  </div>
                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                    Hayvon yuklanishidan oldin elektron taroziga chiqariladi va video yozuv orqali xaridorga aniq tirik vazni koʻrsatiladi. Soxta vazn istisno etiladi.
                  </p>
                </div>

                <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800">
                  <div className="flex items-center gap-2 text-amber-800 dark:text-amber-400 font-extrabold text-sm mb-1.5">
                    <HeartHandshake className="w-4 h-4" />
                    <span>3. Eskrou Xavfsiz Toʻlov Tizimi</span>
                  </div>
                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                    Xaridor toʻlagan pul hayvon yetkazib berilib, koʻzdan kechirilgandan soʻnggina fermerning hisobiga oʻtkaziladi. Agar mol mos kelmasa, pul toʻliq qaytariladi.
                  </p>
                </div>

                <div className="bg-white dark:bg-stone-850 p-4 rounded-xl border border-stone-200 dark:border-stone-800">
                  <div className="flex items-center gap-2 text-purple-800 dark:text-purple-400 font-extrabold text-sm mb-1.5">
                    <Truck className="w-4 h-4" />
                    <span>4. Sugʻurtalangan Maxsus Logistika</span>
                  </div>
                  <p className="text-stone-600 dark:text-stone-300 leading-relaxed">
                    Viloyatlararo yetkazish faqat shamollatish va sirpanmaydigan polga ega maxsus furgonlarda amalga oshiriladi. Yoʻlda yuzaga keladigan har qanday xatar sugʻurtalangan.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Raqamlar & Qamrov */}
          {activeTab === 'stats' && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="bg-white dark:bg-stone-850 p-4 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xs">
                  <div className="text-2xl sm:text-3xl font-black text-emerald-800 dark:text-emerald-400 font-mono">
                    280+
                  </div>
                  <div className="text-stone-500 text-xs mt-1 font-medium">Tasdiqlangan fermerlar</div>
                </div>

                <div className="bg-white dark:bg-stone-850 p-4 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xs">
                  <div className="text-2xl sm:text-3xl font-black text-blue-800 dark:text-blue-400 font-mono">
                    1,250+
                  </div>
                  <div className="text-stone-500 text-xs mt-1 font-medium">Faol chorva eʼlonlari</div>
                </div>

                <div className="bg-white dark:bg-stone-850 p-4 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xs">
                  <div className="text-2xl sm:text-3xl font-black text-amber-700 dark:text-amber-400 font-mono">
                    8,400+
                  </div>
                  <div className="text-stone-500 text-xs mt-1 font-medium">Yakunlangan xavfsiz bitim</div>
                </div>

                <div className="bg-white dark:bg-stone-850 p-4 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xs">
                  <div className="text-2xl sm:text-3xl font-black text-purple-700 dark:text-purple-400 font-mono">
                    100%
                  </div>
                  <div className="text-stone-500 text-xs mt-1 font-medium">Vet koʻrigidan oʻtgan</div>
                </div>
              </div>

              {/* Geographic Coverage */}
              <div className="bg-white dark:bg-stone-850 p-5 rounded-2xl border border-stone-200 dark:border-stone-800 text-xs">
                <h4 className="font-extrabold text-stone-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>Respublika Boʻyicha Qamrov Hududlari:</span>
                </h4>
                <div className="flex flex-wrap gap-2 text-stone-700 dark:text-stone-300">
                  {[
                    'Toshkent shahri',
                    'Toshkent viloyati',
                    'Samarqand',
                    'Andijon',
                    'Fargʻona',
                    'Namangan',
                    'Qashqadaryo',
                    'Surxondaryo',
                    'Buxoro',
                    'Xorazm',
                    'Jizzax',
                    'Sirdaryo',
                    'Navoiy',
                    'Qoraqalpogʻiston Respublikasi',
                  ].map((region, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 font-medium"
                    >
                      ✓ {region}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: Biznes & Monetizatsiya */}
          {activeTab === 'business' && (
            <div className="space-y-4">
              <div className="bg-white dark:bg-stone-850 p-5 rounded-2xl border border-stone-200 dark:border-stone-800 text-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-extrabold text-sm text-stone-900 dark:text-white">
                      Platforma Monetizatsiyasi va Daromad Manbalari
                    </h4>
                    <p className="text-stone-500 mt-0.5">
                      Fermerlar va xaridorlarga bepul xizmat koʻrsatiladi, daromad qoʻshimcha kafolatlar orqali shakllanadi.
                    </p>
                  </div>
                  {onOpenBusinessModel && (
                    <button
                      onClick={() => {
                        onClose();
                        onOpenBusinessModel();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-800 text-white font-bold text-xs cursor-pointer hover:bg-emerald-900"
                    >
                      Toʻliq Biznes Model →
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                  <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700">
                    <span className="font-bold text-stone-900 dark:text-white block mb-1">
                      1. Xavfsiz Toʻlov (1–2%)
                    </span>
                    <p className="text-stone-600 dark:text-stone-400 text-[11px] leading-relaxed">
                      Muvaffaqiyatli yakunlangan eskrou bitimlaridan xavfsizlik va bank kafolati uchun ushlanadigan minimal komissiya.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700">
                    <span className="font-bold text-stone-900 dark:text-white block mb-1">
                      2. VIP Joylashtirish & Reels
                    </span>
                    <p className="text-stone-600 dark:text-stone-400 text-[11px] leading-relaxed">
                      Eʼlonni birinchi oʻrinda koʻrsatish, Telegram kanalda reklama qilish va video montaj xizmatlari.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700">
                    <span className="font-bold text-stone-900 dark:text-white block mb-1">
                      3. Logistika & Kushxona
                    </span>
                    <p className="text-stone-600 dark:text-stone-400 text-[11px] leading-relaxed">
                      Hamkor yuk tashuvchilar furgoni va sanitariya talablariga mos goʻsht kushxonasi xizmatlari bilan integratsiya.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: Bog'lanish & Rekvizitlar */}
          {activeTab === 'contacts' && (
            <div className="space-y-4">
              <div className="bg-white dark:bg-stone-850 p-6 rounded-2xl border border-stone-200 dark:border-stone-800 text-xs space-y-5">
                <h4 className="font-extrabold text-sm text-stone-900 dark:text-white uppercase tracking-wider">
                  Rasmiy Aloqa Maʼlumotlari va Call-Markaz
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700">
                      <div className="p-2 rounded-lg bg-emerald-800 text-white shrink-0">
                        <Phone className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[11px] text-stone-400 block">Yagona Call-markaz (24/7):</span>
                        <a href="tel:+998712004545" className="font-bold text-stone-900 dark:text-white text-sm hover:underline">
                          +998 71 200 45 45
                        </a>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700">
                      <div className="p-2 rounded-lg bg-sky-600 text-white shrink-0">
                        <Send className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[11px] text-stone-400 block">Telegram Qoʻllab-quvvatlash:</span>
                        <span className="font-bold text-sky-700 dark:text-sky-400 text-sm">
                          @ChorvaBozor_Aloqa / @ChorvaBozor_bot
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700">
                      <div className="p-2 rounded-lg bg-amber-600 text-white shrink-0">
                        <Mail className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[11px] text-stone-400 block">Hamkorlik va Fermerlar Boʻlimi:</span>
                        <span className="font-bold text-stone-900 dark:text-white text-sm">
                          hamkorlik@chorvabozor.uz
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-700">
                      <div className="p-2 rounded-lg bg-stone-700 text-white shrink-0">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[11px] text-stone-400 block">Bosh Ofis:</span>
                        <span className="font-bold text-stone-900 dark:text-white text-sm">
                          Toshkent shahri, Yunusobod tumani, Amir Temur shoh koʻchasi, 107-B
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-[11px] text-emerald-950 dark:text-emerald-300 leading-relaxed">
                  <strong>Ish tartibi:</strong> Onlayn platforma va serverlar uzluksiz 24/7 rejimda ishlaydi. Operatorlar va Call-markaz har kuni soat 08:00 dan 21:00 gacha qoʻngʻiroqlarni qabul qiladi.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Actions */}
        <div className="p-4 sm:px-6 bg-white dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-stone-500">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Davlat reyestridan oʻtgan rasmiy maʼlumotnoma</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
          >
            Tushundim, Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
