import React, { useState } from 'react';
import { breedCatalog } from '../data/breedCatalog';
import { AnimalDepartment, BreedInfo, Language } from '../types';
import { X, CheckCircle2, Scale, Target, Sparkles, ArrowRight, Search, BookOpen, TrendingUp } from 'lucide-react';

interface BreedEncyclopediaModalProps {
  language: Language;
  onClose: () => void;
  onFilterByBreed: (breedKey: string, department: AnimalDepartment) => void;
  onOpenBreedTrends?: (breedKey: string) => void;
}

export const BreedEncyclopediaModal: React.FC<BreedEncyclopediaModalProps> = ({
  language,
  onClose,
  onFilterByBreed,
  onOpenBreedTrends,
}) => {
  const [activeTab, setActiveTab] = useState<'qoramol' | 'quy' | 'ot'>('qoramol');
  const [search, setSearch] = useState('');

  const filteredBreeds = breedCatalog
    .filter((b) => b.department === activeTab)
    .filter((b) => {
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return (
        b.nameUz.toLowerCase().includes(q) ||
        b.nameRu.toLowerCase().includes(q) ||
        b.descriptionUz.toLowerCase().includes(q) ||
        b.descriptionRu.toLowerCase().includes(q)
      );
    });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white dark:bg-stone-900 rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-stone-200 dark:border-stone-800 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4.5 border-b border-stone-200 dark:border-stone-800 bg-emerald-950 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800 flex items-center justify-center text-xl shadow-xs">
              📖
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {language === 'uz' ? 'Chorva Zotlari Qomusi & Rasmiy Qoʻllanma' : 'Энциклопедия пород скота и руководство'}
              </h3>
              <p className="text-xs text-emerald-300">
                {language === 'uz'
                  ? 'Qoramol, qoʻy va otlarning Oʻzbekistondagi 13 ta asosiy naslli zoti haqida toʻliq maʼlumot'
                  : 'Полный справочник по 13 ключевым породам КРС, овец и лошадей в Узбекистане'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-emerald-300 hover:text-white rounded-lg hover:bg-emerald-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Department Switcher Tabs & Search */}
        <div className="border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-850 px-6 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1 overflow-x-auto text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('qoramol')}
              className={`py-2 px-3.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'qoramol'
                  ? 'bg-emerald-900 text-white font-bold shadow-xs'
                  : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-stone-900'
              }`}
            >
              <span>🐂</span>
              <span>{language === 'uz' ? 'Qoramol zotlari (5 ta)' : 'Породы КРС (5)'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('quy')}
              className={`py-2 px-3.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'quy'
                  ? 'bg-emerald-900 text-white font-bold shadow-xs'
                  : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-stone-900'
              }`}
            >
              <span>🐑</span>
              <span>{language === 'uz' ? 'Qoʻy zotlari (4 ta)' : 'Породы овец (4)'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('ot')}
              className={`py-2 px-3.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'ot'
                  ? 'bg-emerald-900 text-white font-bold shadow-xs'
                  : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-stone-900'
              }`}
            >
              <span>🐎</span>
              <span>{language === 'uz' ? 'Ot zotlari (4 ta)' : 'Породы лошадей (4)'}</span>
            </button>
          </div>

          {/* Quick breed search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={language === 'uz' ? 'Zot nomidan qidirish...' : 'Поиск по названию...'}
              className="pl-8 pr-3 py-1.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200 rounded-xl text-xs w-full sm:w-48 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Breeds Grid Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {filteredBreeds.length === 0 ? (
            <div className="text-center py-10 text-stone-500 text-xs">
              {language === 'uz' ? 'Ushbu boʻlimda zot topilmadi' : 'Породы не найдены'}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredBreeds.map((breed) => (
                <div
                  key={breed.id}
                  className="bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-2xl p-4.5 flex flex-col justify-between space-y-3 hover:border-emerald-600/50 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{breed.icon}</span>
                        <h4 className="font-extrabold text-stone-900 dark:text-stone-100 text-sm sm:text-base">
                          {language === 'uz' ? breed.nameUz : breed.nameRu}
                        </h4>
                      </div>
                      <span className="font-mono text-xs font-bold bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 px-2.5 py-0.5 rounded-lg text-emerald-800 dark:text-emerald-400">
                        {breed.weightRange}
                      </span>
                    </div>

                    {/* Exact User Breed Description */}
                    <div className="p-2.5 bg-white dark:bg-stone-900 rounded-xl border border-stone-200/80 dark:border-stone-700/80 mb-3">
                      <p className="text-xs text-stone-700 dark:text-stone-200 leading-relaxed font-medium">
                        {language === 'uz' ? breed.descriptionUz : breed.descriptionRu}
                      </p>
                    </div>

                    <div className="space-y-1.5 mb-3">
                      <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">
                        {language === 'uz' ? 'Asosiy xususiyatlari:' : 'Ключевые особенности:'}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {(language === 'uz' ? breed.featuresUz : breed.featuresRu).map((feat, idx) => (
                          <span
                            key={idx}
                            className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 text-[11px] px-2 py-0.5 rounded-md font-medium"
                          >
                            ✓ {feat}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="text-[11px] text-stone-500 dark:text-stone-400 pt-2 border-t border-stone-200/60 dark:border-stone-700/60">
                      <strong className="text-stone-800 dark:text-stone-200">
                        {language === 'uz' ? 'Tavsiya etiladi:' : 'Рекомендуется:'}
                      </strong>{' '}
                      {language === 'uz' ? breed.recommendedForUz : breed.recommendedForRu}
                    </div>
                  </div>

                  {onOpenBreedTrends && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenBreedTrends(breed.id);
                      }}
                      className="w-full py-2 px-3 bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 border border-stone-200 dark:border-stone-700 mt-2"
                    >
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span>
                        {language === 'uz'
                          ? `📈 2024-2026 Narx Grafigi & Mavsumiylik`
                          : `📈 График цен и сезонность`}
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onFilterByBreed(breed.id, breed.department);
                    }}
                    className="w-full py-2.5 px-3 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs mt-1.5"
                  >
                    <span>
                      {language === 'uz'
                        ? `Shu zotdagi eʼlonlarni koʻrish (${breed.nameUz.split('(')[0].trim()})`
                        : `Смотреть объявления этой породы`}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
