import React, { useState, useMemo } from 'react';
import { LivestockItem, EquipmentItem, Language, UserCabinetAdItem } from '../types';
import { mockEquipment } from '../data/mockData';
import {
  User,
  LayoutGrid,
  Bookmark,
  MessageSquare,
  Settings,
  Plus,
  Edit3,
  Trash2,
  CheckCircle,
  X,
  Phone,
  MapPin,
  ShieldCheck,
  Package,
  Layers,
  Sparkles,
  CreditCard,
  Eye,
  Check,
  Clock,
  Send,
  AlertTriangle,
  RefreshCw,
  Award
} from 'lucide-react';

interface UserCabinetModalProps {
  language: Language;
  onClose: () => void;
  livestockItems: LivestockItem[];
  onUpdateLivestockItems: React.Dispatch<React.SetStateAction<LivestockItem[]>>;
  onOpenAddListing: () => void;
  isDarkMode?: boolean;
}

export const UserCabinetModal: React.FC<UserCabinetModalProps> = ({
  language,
  onClose,
  livestockItems,
  onUpdateLivestockItems,
  onOpenAddListing,
  isDarkMode = false
}) => {
  const isUz = language === 'uz';

  // Navigation tabs
  type CabinetTab = 'profile' | 'my_ads' | 'saved' | 'messages' | 'settings';
  const [activeTab, setActiveTab] = useState<CabinetTab>('my_ads');

  // Sub-filter for "Mening e'lonlarim": Chorva mollari vs Anjomlar
  const [adsFilter, setAdsFilter] = useState<'all' | 'livestock' | 'equipment'>('livestock');

  // Status sub-filter: all, active, sold, pending
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'sold' | 'pending'>('all');

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // State for user equipment items
  const [equipmentList, setEquipmentList] = useState<EquipmentItem[]>(mockEquipment);

  // User profile state
  const [userProfile, setUserProfile] = useState({
    name: 'Akmaljon Rahimov',
    farmName: 'Zomin Nasldor Chorva FM',
    phone: '+998 90 321-45-67',
    region: 'Jizzax viloyati',
    district: 'Zomin tumani',
    role: 'Tasdiqlangan Fermer',
    rating: 4.96,
    completedDeals: 48,
    balanceUzs: 14250000,
    memberSince: '2024-yil mart'
  });

  // Saved items IDs
  const [savedLivestockIds, setSavedLivestockIds] = useState<string[]>(['breed-qora_ola-1', 'breed-hisor-1']);

  // Messages state (Simulated chats with buyers)
  const [messages, setMessages] = useState([
    {
      id: 'msg-1',
      buyerName: 'Farhodbek (Toshkent)',
      buyerPhone: '+998 97 123-45-67',
      listingTitle: 'Golshtin 2-qorin sigir',
      lastMessage: 'Assalomu alaykum, sigir kuniga necha litr sut beryapti? Narxini kelishsak boʻladimi?',
      time: '12:35',
      unread: true
    },
    {
      id: 'msg-2',
      buyerName: 'Otabek Chorvador (Samarqand)',
      buyerPhone: '+998 93 456-78-90',
      listingTitle: 'Qoʻlda toʻqilgan pishiq arqon',
      lastMessage: '5 ta arqon buyurtma qilsam, Samarqand shahriga yetkazib berasizmi?',
      time: 'Kecha',
      unread: false
    }
  ]);
  const [activeChatId, setActiveChatId] = useState<string>('msg-1');
  const [chatReplyText, setChatReplyText] = useState('');

  // Editing Ad modal state
  const [editingItem, setEditingItem] = useState<UserCabinetAdItem | null>(null);
  const [editPriceInput, setEditPriceInput] = useState<number>(0);
  const [editTitleInput, setEditTitleInput] = useState<string>('');

  // Construct combined user ad items
  const userAds: UserCabinetAdItem[] = useMemo(() => {
    // Current user's livestock (first 3-4 items or marked as seller's)
    const livestockAds: UserCabinetAdItem[] = livestockItems.slice(0, 5).map((item, idx) => ({
      id: item.id,
      itemType: 'livestock',
      title: item.titleUz,
      categoryLabel: item.department === 'qoramol' ? 'Qoramol' : item.department === 'quy' ? 'Qoʻy/Echki' : 'Ot',
      priceUzs: item.priceUzs,
      imageUrl: item.imageUrl,
      status: idx === 3 ? 'sold' : idx === 4 ? 'pending' : 'active',
      viewsCount: item.viewsCount || 120 + idx * 45,
      createdAt: '2026-10-06',
      region: item.region,
      details: `${item.weightKg} kg · ${item.breed}`,
      livestockRef: item
    }));

    const equipmentAds: UserCabinetAdItem[] = equipmentList.map((eq, idx) => ({
      id: eq.id,
      itemType: 'equipment',
      title: eq.titleUz,
      categoryLabel: `Anjom (${eq.subcategory.toUpperCase()})`,
      priceUzs: eq.priceUzs,
      imageUrl: eq.imageUrl,
      status: eq.status,
      viewsCount: eq.viewsCount,
      createdAt: eq.createdAt,
      region: eq.region,
      details: `${eq.material} · ${eq.sizeOrLength} · ${eq.condition}`,
      equipmentRef: eq
    }));

    return [...livestockAds, ...equipmentAds];
  }, [livestockItems, equipmentList]);

  // Filtered Ads by type (Chorva mollari vs Anjomlar) and status
  const filteredAds = useMemo(() => {
    return userAds.filter((ad) => {
      if (adsFilter !== 'all' && ad.itemType !== adsFilter) return false;
      if (statusFilter !== 'all' && ad.status !== statusFilter) return false;
      return true;
    });
  }, [userAds, adsFilter, statusFilter]);

  // Mark as Sold Handler
  const handleToggleSold = (ad: UserCabinetAdItem) => {
    const nextStatus = ad.status === 'sold' ? 'active' : 'sold';
    if (ad.itemType === 'livestock') {
      showToast(
        nextStatus === 'sold'
          ? (isUz ? 'Eʼlon "Sotildi" deb belgilandi!' : 'Объявление помечено как продано!')
          : (isUz ? 'Eʼlon qayta faollashtirildi!' : 'Объявление снова активно!')
      );
    } else {
      setEquipmentList((prev) =>
        prev.map((eq) => (eq.id === ad.id ? { ...eq, status: nextStatus } : eq))
      );
      showToast(
        nextStatus === 'sold'
          ? (isUz ? 'Anjom eʼloni "Sotildi" deb belgilandi!' : 'Товар помечен как продан!')
          : (isUz ? 'Anjom eʼloni faollashtirildi!' : 'Товар снова активен!')
      );
    }
  };

  // Delete Ad Handler
  const handleDeleteAd = (ad: UserCabinetAdItem) => {
    if (ad.itemType === 'livestock') {
      onUpdateLivestockItems((prev) => prev.filter((i) => i.id !== ad.id));
    } else {
      setEquipmentList((prev) => prev.filter((i) => i.id !== ad.id));
    }
    showToast(isUz ? 'Eʼlon muvaffaqiyatli oʻchirildi!' : 'Объявление успешно удалено!');
  };

  // Edit Ad Handler
  const handleOpenEdit = (ad: UserCabinetAdItem) => {
    setEditingItem(ad);
    setEditTitleInput(ad.title);
    setEditPriceInput(ad.priceUzs);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    if (editingItem.itemType === 'livestock') {
      onUpdateLivestockItems((prev) =>
        prev.map((item) =>
          item.id === editingItem.id
            ? { ...item, titleUz: editTitleInput, priceUzs: editPriceInput }
            : item
        )
      );
    } else {
      setEquipmentList((prev) =>
        prev.map((eq) =>
          eq.id === editingItem.id
            ? { ...eq, titleUz: editTitleInput, priceUzs: editPriceInput }
            : eq
        )
      );
    }

    setEditingItem(null);
    showToast(isUz ? 'Eʼlon maʼlumotlari yangilandi!' : 'Данные объявления обновлены!');
  };

  // Send message reply
  const handleSendChatReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatReplyText.trim()) return;
    showToast(isUz ? 'Xabaringiz xaridorga yetkazildi!' : 'Сообщение отправлено покупателю!');
    setChatReplyText('');
  };

  const formatPrice = (p: number) => new Intl.NumberFormat('uz-UZ').format(p);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-6xl w-full h-[92vh] shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] flex flex-col overflow-hidden font-sans transition-colors duration-200">
        
        {/* Toast Notification */}
        {toastMessage && (
          <div className="absolute top-4 right-4 z-50 bg-[#047857] text-white px-4 py-2.5 rounded-2xl shadow-xl text-xs sm:text-sm font-bold flex items-center gap-2 border border-[#10B981] animate-in slide-in-from-top-2 duration-200">
            <CheckCircle className="w-4 h-4 text-[#10B981] shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 bg-[#F0F4F1] dark:bg-[#02100C] border-b border-[#E5ECE7] dark:border-[#0E3D32] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#064E3B] to-[#047857] flex items-center justify-center text-white shadow-md shadow-[#064E3B]/30 border border-[#10B981]/30">
              <User className="w-5 h-5 text-[#10B981]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-extrabold text-base sm:text-lg tracking-tight text-[#1C2A23] dark:text-white">
                  {isUz ? 'Shaxsiy Kabinet' : 'Личный кабинет'}
                </h2>
                <span className="px-2 py-0.5 rounded-md bg-[#047857]/15 dark:bg-[#10B981]/20 text-[#047857] dark:text-[#10B981] font-mono text-[10px] font-bold border border-[#047857]/30">
                  {userProfile.farmName}
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-[#D97706] dark:text-[#F59E0B] font-bold">
                  ★ {userProfile.rating} (48 bitim)
                </span>
              </div>
              <p className="text-xs text-stone-600 dark:text-stone-400 hidden sm:block">
                {isUz ? 'Eʼlonlar boshqaruvi, savdo-sotiq statistikasi va xaridorlar bilan aloqa' : 'Управление объявлениями и сделки'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Add Listing CTA */}
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenAddListing();
              }}
              className="py-1.5 px-3 sm:px-4 bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-sm shadow-[#F59E0B]/30 flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span className="hidden sm:inline">{isUz ? 'Yangi Eʼlon' : 'Подать объявление'}</span>
              <span className="sm:hidden text-xs">{isUz ? 'Eʼlon' : 'Подать'}</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white dark:bg-[#072D24] text-stone-500 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer transition-colors"
              title="Yopish"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Workspace Layout: Sidebar + Main Content */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Sidebar Navigation */}
          <aside className="w-56 sm:w-64 bg-[#EBEFEA] dark:bg-[#02100C] border-r border-[#E5ECE7] dark:border-[#0E3D32] p-3 sm:p-4 flex flex-col justify-between shrink-0 overflow-y-auto">
            <div className="space-y-4">
              {/* User Mini Card */}
              <div className="p-3 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32]">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#064E3B] to-[#047857] text-white flex items-center justify-center font-bold text-sm">
                    {userProfile.name.charAt(0)}
                  </div>
                  <div className="overflow-hidden">
                    <h4 className="text-xs font-bold text-[#1C2A23] dark:text-white truncate">
                      {userProfile.name}
                    </h4>
                    <span className="text-[10px] text-stone-500 dark:text-stone-400 block truncate">
                      {userProfile.phone}
                    </span>
                  </div>
                </div>

                <div className="mt-2.5 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32] flex items-center justify-between text-[10px]">
                  <span className="text-stone-500 dark:text-stone-400">{isUz ? 'Eskrou Balansi:' : 'Баланс:'}</span>
                  <span className="font-bold text-[#047857] dark:text-[#10B981] font-mono">
                    {formatPrice(userProfile.balanceUzs)} soʻm
                  </span>
                </div>
              </div>

              {/* Navigation Items */}
              <div className="space-y-1">
                {[
                  {
                    key: 'my_ads',
                    label: isUz ? 'Mening Eʼlonlarim' : 'Мои объявления',
                    icon: LayoutGrid,
                    count: userAds.length
                  },
                  {
                    key: 'profile',
                    label: isUz ? 'Profil & Ferma' : 'Профиль и ферма',
                    icon: User,
                    count: undefined
                  },
                  {
                    key: 'saved',
                    label: isUz ? 'Tanlanganlar' : 'Избранное',
                    icon: Bookmark,
                    count: savedLivestockIds.length
                  },
                  {
                    key: 'messages',
                    label: isUz ? 'Xabarlar' : 'Сообщения',
                    icon: MessageSquare,
                    count: messages.filter(m => m.unread).length || undefined
                  },
                  {
                    key: 'settings',
                    label: isUz ? 'Sozlamalar' : 'Настройки',
                    icon: Settings,
                    count: undefined
                  }
                ].map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setActiveTab(item.key as CabinetTab)}
                      className={`w-full p-2.5 sm:p-3 rounded-2xl text-left transition-all cursor-pointer flex items-center justify-between group ${
                        isActive
                          ? 'bg-[#047857] text-white font-bold shadow-md shadow-[#047857]/30'
                          : 'hover:bg-[#DFE6E1] dark:hover:bg-[#072D24] text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-500 dark:text-stone-400'}`} />
                        <span className="text-xs">{item.label}</span>
                      </div>
                      {item.count !== undefined && (
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                          isActive
                            ? 'bg-white/20 text-white font-bold'
                            : 'bg-white dark:bg-[#072D24] text-stone-600 dark:text-stone-300 border border-[#E5ECE7] dark:border-[#0E3D32]'
                        }`}>
                          {item.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Trust badge */}
            <div className="p-3 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] text-[10px] space-y-1">
              <div className="flex items-center gap-1.5 text-[#047857] dark:text-[#10B981] font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Davlat Vet Nazorati</span>
              </div>
              <p className="text-stone-500 dark:text-stone-400 leading-tight">
                Chorva mollari va anjomlar rasmiy savdo kafolatiga ega.
              </p>
            </div>
          </aside>

          {/* Main Content Body */}
          <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#F7F9F6] dark:bg-[#041C16]">
            
            {/* TAB 1: MENING E'LONLARIM (My Ads) */}
            {activeTab === 'my_ads' && (
              <div className="space-y-5">
                
                {/* Header Filter Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32]">
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base text-[#1C2A23] dark:text-white">
                      {isUz ? 'Mening Savdoga Qoʻyilgan Eʼlonlarim' : 'Мои объявления на продаже'}
                    </h3>
                    <p className="text-xs text-stone-500 dark:text-stone-400">
                      {isUz ? 'Kategoriya boʻyicha ajratilgan: Chorva mollari va anjomlar' : 'Разделено по категориям: Скот и Снаряжение'}
                    </p>
                  </div>

                  {/* Dual Category Filter: Chorva Mollari vs Anjomlar */}
                  <div className="flex items-center gap-1 p-1 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-xs font-bold">
                    <button
                      type="button"
                      onClick={() => setAdsFilter('livestock')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        adsFilter === 'livestock'
                          ? 'bg-[#047857] text-white shadow-xs'
                          : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      <span>🐂</span>
                      <span>{isUz ? 'Chorva Mollari' : 'Скот'}</span>
                      <span className="text-[10px] opacity-80">({userAds.filter(a => a.itemType === 'livestock').length})</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setAdsFilter('equipment')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        adsFilter === 'equipment'
                          ? 'bg-[#047857] text-white shadow-xs'
                          : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      <span>🪢</span>
                      <span>{isUz ? 'Anjomlar & Jihozlar' : 'Снаряжение'}</span>
                      <span className="text-[10px] opacity-80">({userAds.filter(a => a.itemType === 'equipment').length})</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setAdsFilter('all')}
                      className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                        adsFilter === 'all'
                          ? 'bg-[#047857] text-white shadow-xs'
                          : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      {isUz ? 'Hammasi' : 'Все'}
                    </button>
                  </div>
                </div>

                {/* Status sub-tabs: All, Active, Sold, Pending */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                  {[
                    { key: 'all', label: isUz ? 'Barcha holatlar' : 'Все статусы' },
                    { key: 'active', label: isUz ? 'Faol eʼlonlar' : 'Активные' },
                    { key: 'sold', label: isUz ? 'Sotilganlar' : 'Проданные' },
                    { key: 'pending', label: isUz ? 'Moderatsiyada' : 'На модерации' }
                  ].map((st) => (
                    <button
                      key={st.key}
                      type="button"
                      onClick={() => setStatusFilter(st.key as any)}
                      className={`px-3 py-1 rounded-xl transition-all cursor-pointer ${
                        statusFilter === st.key
                          ? 'bg-[#D97706] text-white font-bold shadow-xs'
                          : 'bg-white dark:bg-[#072D24] text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-[#0E3D32] border border-[#E5ECE7] dark:border-[#0E3D32]'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>

                {/* Ads Card Grid */}
                {filteredAds.length === 0 ? (
                  <div className="p-10 text-center rounded-3xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32]">
                    <Package className="w-10 h-10 mx-auto text-stone-400 mb-2" />
                    <h4 className="font-bold text-sm text-[#1C2A23] dark:text-white">
                      {isUz ? 'Ushbu boʻlimda hozircha eʼlon mavjud emas' : 'В этом разделе пока нет объявлений'}
                    </h4>
                    <p className="text-xs text-stone-500 mt-1 mb-4">
                      {isUz ? 'Yangi chorva moli yoki anjom (arqon, yugan, egar) eʼlonini joylashtiring' : 'Подайте новое объявление скота или снаряжения'}
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenAddListing();
                      }}
                      className="px-4 py-2 rounded-xl bg-[#047857] text-white font-bold text-xs cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isUz ? 'Eʼlon Joylashtirish' : 'Подать объявление'}</span>
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredAds.map((ad) => {
                      const isSold = ad.status === 'sold';
                      const isPending = ad.status === 'pending';

                      return (
                        <div
                          key={ad.id}
                          className={`p-4 rounded-2xl bg-white dark:bg-[#072D24] border transition-all flex flex-col justify-between gap-3 shadow-xs ${
                            isSold
                              ? 'border-stone-300 dark:border-[#0E3D32] opacity-75'
                              : 'border-[#E5ECE7] dark:border-[#0E3D32] hover:border-[#047857]'
                          }`}
                        >
                          <div className="flex gap-3">
                            {/* Thumbnail image */}
                            <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-stone-100 dark:bg-[#02100C] shrink-0 border border-[#E5ECE7] dark:border-[#0E3D32]">
                              <img
                                src={ad.imageUrl}
                                alt={ad.title}
                                className="w-full h-full object-cover"
                              />
                              {/* Status Ribbon */}
                              <span className={`absolute top-1 left-1 text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                isSold
                                  ? 'bg-stone-800 text-stone-200'
                                  : isPending
                                  ? 'bg-[#F59E0B] text-black font-extrabold'
                                  : 'bg-[#047857] text-white'
                              }`}>
                                {isSold ? (isUz ? 'Sotildi' : 'Продано') : isPending ? (isUz ? 'Kutilmoqda' : 'Модерация') : (isUz ? 'Faol' : 'Активно')}
                              </span>
                            </div>

                            {/* Details */}
                            <div className="flex-1 overflow-hidden">
                              <div className="flex items-center justify-between text-[10px] text-stone-500 dark:text-stone-400 mb-1">
                                <span className="font-bold text-[#047857] dark:text-[#10B981] truncate">
                                  {ad.categoryLabel}
                                </span>
                                <span className="font-mono flex items-center gap-1 shrink-0">
                                  <Eye className="w-3 h-3" />
                                  {ad.viewsCount}
                                </span>
                              </div>

                              <h4 className="text-xs sm:text-sm font-bold text-[#1C2A23] dark:text-white line-clamp-2 leading-snug mb-1">
                                {ad.title}
                              </h4>

                              <p className="text-[11px] text-stone-500 dark:text-stone-400 line-clamp-1 mb-2 font-mono">
                                {ad.details}
                              </p>

                              <div className="text-sm font-black text-[#D97706] dark:text-[#F59E0B] font-mono">
                                {formatPrice(ad.priceUzs)} soʻm
                              </div>
                            </div>
                          </div>

                          {/* Quick Action Buttons (Edit, Mark as Sold, Delete) */}
                          <div className="pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32] flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5">
                              {/* Mark as sold toggle */}
                              <button
                                type="button"
                                onClick={() => handleToggleSold(ad)}
                                className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                                  isSold
                                    ? 'bg-[#047857]/15 text-[#047857] dark:text-[#10B981] hover:bg-[#047857]/30'
                                    : 'bg-stone-100 dark:bg-[#02100C] text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                                }`}
                                title={isSold ? "Faol qilish" : "Sotildi deb belgilash"}
                              >
                                <CheckCircle className="w-3.5 h-3.5" />
                                <span>{isSold ? (isUz ? 'Qayta faollashtirish' : 'Активировать') : (isUz ? 'Sotildi' : 'Продано')}</span>
                              </button>

                              {/* Edit button */}
                              <button
                                type="button"
                                onClick={() => handleOpenEdit(ad)}
                                className="p-1.5 rounded-lg bg-stone-100 dark:bg-[#02100C] text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-stone-200 cursor-pointer transition-colors"
                                title="Tahrirlash"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Delete button */}
                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm(isUz ? "Ushbu eʼlonni rostdan ham oʻchirmoqchimisiz?" : "Удалить объявление?")) {
                                  handleDeleteAd(ad);
                                }
                              }}
                              className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer transition-colors"
                              title="Oʻchirish"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: PROFIL & FERMA (Profile) */}
            {activeTab === 'profile' && (
              <div className="space-y-5 max-w-2xl">
                <div className="p-5 rounded-3xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] space-y-4">
                  <h3 className="font-extrabold text-base text-[#1C2A23] dark:text-white flex items-center gap-2">
                    <User className="w-5 h-5 text-[#047857] dark:text-[#10B981]" />
                    <span>{isUz ? 'Fermer Maʼlumotlari & Hisob Holati' : 'Профиль фермера и данные'}</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-stone-500 dark:text-stone-400 block mb-1">{isUz ? 'Fermer Ismi' : 'ФИО'}</label>
                      <input
                        type="text"
                        value={userProfile.name}
                        onChange={(e) => setUserProfile({ ...userProfile, name: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-white font-semibold"
                      />
                    </div>

                    <div>
                      <label className="text-stone-500 dark:text-stone-400 block mb-1">{isUz ? 'Xoʻjalik / Ferma Nomi' : 'Название фермы'}</label>
                      <input
                        type="text"
                        value={userProfile.farmName}
                        onChange={(e) => setUserProfile({ ...userProfile, farmName: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-white font-semibold"
                      />
                    </div>

                    <div>
                      <label className="text-stone-500 dark:text-stone-400 block mb-1">{isUz ? 'Telefon Raqami' : 'Телефон'}</label>
                      <input
                        type="text"
                        value={userProfile.phone}
                        onChange={(e) => setUserProfile({ ...userProfile, phone: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-white font-semibold"
                      />
                    </div>

                    <div>
                      <label className="text-stone-500 dark:text-stone-400 block mb-1">{isUz ? 'Hudud / Viloyat' : 'Регион'}</label>
                      <input
                        type="text"
                        value={`${userProfile.region}, ${userProfile.district}`}
                        disabled
                        className="w-full px-3 py-2 rounded-xl bg-stone-100 dark:bg-[#041C16] border border-[#E5ECE7] dark:border-[#0E3D32] text-stone-500 font-semibold cursor-not-allowed"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => showToast(isUz ? "Profil maʼlumotlari muvaffaqiyatli saqlandi!" : "Профиль сохранен!")}
                      className="px-4 py-2 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white text-xs font-bold cursor-pointer transition-all"
                    >
                      {isUz ? 'Oʻzgarishlarni Saqlash' : 'Сохранить изменения'}
                    </button>
                  </div>
                </div>

                {/* Account stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] text-center">
                    <span className="text-[11px] text-stone-500 block">{isUz ? 'Yakunlangan bitimlar' : 'Сделки'}</span>
                    <strong className="text-lg font-black text-[#047857] dark:text-[#10B981] font-mono">{userProfile.completedDeals} ta</strong>
                  </div>
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] text-center">
                    <span className="text-[11px] text-stone-500 block">{isUz ? 'Fermer reytingi' : 'Рейтинг'}</span>
                    <strong className="text-lg font-black text-[#D97706] dark:text-[#F59E0B] font-mono">★ {userProfile.rating}</strong>
                  </div>
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] text-center">
                    <span className="text-[11px] text-stone-500 block">{isUz ? 'Eʼlonlar soni' : 'Объявлений'}</span>
                    <strong className="text-lg font-black text-[#1C2A23] dark:text-white font-mono">{userAds.length} ta</strong>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: TANLANGANLAR (Saved Ads) */}
            {activeTab === 'saved' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-base text-[#1C2A23] dark:text-white">
                  {isUz ? 'Saqlangan va Kuzatuvdagi Eʼlonlar' : 'Избранные объявления'}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {livestockItems.slice(0, 2).map((item) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-2xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] flex gap-3 items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={item.imageUrl}
                          alt={item.titleUz}
                          className="w-16 h-16 rounded-xl object-cover shrink-0"
                        />
                        <div>
                          <h4 className="text-xs font-bold text-[#1C2A23] dark:text-white line-clamp-1">
                            {item.titleUz}
                          </h4>
                          <span className="text-[11px] text-stone-500 font-mono block">
                            {item.weightKg} kg · {item.region}
                          </span>
                          <span className="text-xs font-black text-[#D97706] dark:text-[#F59E0B] font-mono">
                            {formatPrice(item.priceUzs)} soʻm
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          showToast(isUz ? "Eʼlon tanlanganlardan oʻchirildi" : "Удалено из избранного");
                        }}
                        className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl cursor-pointer"
                        title="Oʻchirish"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: XABARLAR & CHAT (Messages) */}
            {activeTab === 'messages' && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-[70vh]">
                {/* Chat list */}
                <div className="md:col-span-5 space-y-2 overflow-y-auto">
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      onClick={() => setActiveChatId(m.id)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                        activeChatId === m.id
                          ? 'bg-[#047857]/10 dark:bg-[#072D24] border-[#047857]'
                          : 'bg-white dark:bg-[#02100C] border-[#E5ECE7] dark:border-[#0E3D32]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-[#1C2A23] dark:text-white">{m.buyerName}</span>
                        <span className="text-[10px] text-stone-400 font-mono">{m.time}</span>
                      </div>
                      <span className="text-[10px] text-[#047857] dark:text-[#10B981] font-semibold block mb-1">
                        {m.listingTitle}
                      </span>
                      <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-1">
                        {m.lastMessage}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Active chat window */}
                <div className="md:col-span-7 flex flex-col justify-between p-4 rounded-3xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32]">
                  <div className="space-y-3 overflow-y-auto pb-4">
                    <div className="p-3 rounded-2xl bg-[#F0F4F1] dark:bg-[#02100C] text-xs">
                      <span className="font-bold text-[#047857] dark:text-[#10B981] block mb-1">
                        Farhodbek (Toshkent):
                      </span>
                      <p className="text-[#1C2A23] dark:text-stone-200">
                        Assalomu alaykum, sigir kuniga necha litr sut beryapti? Narxini kelishsak boʻladimi?
                      </p>
                    </div>

                    <div className="p-3 rounded-2xl bg-[#047857] text-white text-xs ml-auto max-w-[85%]">
                      <span className="font-bold text-emerald-200 block mb-1">
                        Siz (Fermer):
                      </span>
                      <p>
                        Va alaykum assalom! Kuniga 28 litr kafolatlangan sut beryapti. Davlat vet pasporti bor. Keling, koʻring, ozroq oʻtib beraman.
                      </p>
                    </div>
                  </div>

                  <form onSubmit={handleSendChatReply} className="flex gap-2 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32]">
                    <input
                      type="text"
                      value={chatReplyText}
                      onChange={(e) => setChatReplyText(e.target.value)}
                      placeholder={isUz ? "Xabar yozing..." : "Напишите ответ..."}
                      className="flex-1 px-3 py-2 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-xs text-[#1C2A23] dark:text-white focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="p-2 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* TAB 5: SOZLAMALAR (Settings) */}
            {activeTab === 'settings' && (
              <div className="p-5 rounded-3xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] space-y-4 max-w-xl">
                <h3 className="font-extrabold text-base text-[#1C2A23] dark:text-white">
                  {isUz ? 'Xabarnomalar va Xavfsizlik' : 'Настройки аккаунта'}
                </h3>

                <div className="space-y-3 text-xs">
                  <label className="flex items-center justify-between p-3 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer">
                    <span>{isUz ? 'SMS orqali yangi stavkalar va qoʻngʻiroqlar haqida bildirishnoma' : 'SMS уведомления о ставках'}</span>
                    <input type="checkbox" defaultChecked className="accent-[#047857] w-4 h-4" />
                  </label>

                  <label className="flex items-center justify-between p-3 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer">
                    <span>{isUz ? 'Telegram Bot bilan hisobni ulash (@ChorvaBozor_Bot)' : 'Привязка к Telegram боту'}</span>
                    <input type="checkbox" defaultChecked className="accent-[#047857] w-4 h-4" />
                  </label>

                  <label className="flex items-center justify-between p-3 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer">
                    <span>{isUz ? 'Xavfsiz eskrou toʻlovlari uchun avtomatik tasdiq' : 'Авто-подтверждение сделок'}</span>
                    <input type="checkbox" className="accent-[#047857] w-4 h-4" />
                  </label>
                </div>
              </div>
            )}
          </main>
        </div>

        {/* Edit Item Modal (Sub-modal) */}
        {editingItem && (
          <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white dark:bg-[#072D24] text-[#1C2A23] dark:text-white p-5 rounded-3xl max-w-md w-full border border-[#E5ECE7] dark:border-[#0E3D32] shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm">
                  {isUz ? 'Eʼlonni Tahrirlash' : 'Редактировать объявление'}
                </h4>
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
                <div>
                  <label className="block text-stone-500 mb-1">{isUz ? 'Sarlavha' : 'Название'}</label>
                  <input
                    type="text"
                    value={editTitleInput}
                    onChange={(e) => setEditTitleInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-stone-500 mb-1">{isUz ? 'Narx (soʻmda)' : 'Цена (сум)'}</label>
                  <input
                    type="number"
                    value={editPriceInput}
                    onChange={(e) => setEditPriceInput(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#F7F9F6] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] font-mono font-bold"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingItem(null)}
                    className="px-3 py-1.5 rounded-xl border border-stone-300 dark:border-[#0E3D32] text-stone-600 dark:text-stone-300"
                  >
                    Bekor qilish
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-[#047857] text-white font-bold"
                  >
                    Saqlash
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
