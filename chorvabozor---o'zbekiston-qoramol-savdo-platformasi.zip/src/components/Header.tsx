import React, { useState, useRef, useEffect } from 'react';
import { AnimalDepartment, Language } from '../types';
import { translations } from '../translations';
import {
  PlusCircle,
  ShieldCheck,
  Wifi,
  WifiOff,
  Play,
  Sun,
  Moon,
  BookOpen,
  Scale,
  TrendingUp,
  Sparkles,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Search,
  Check,
  Menu,
  X,
  Gavel,
  Truck,
  Send,
  Calendar,
  Layers,
  ArrowLeft
} from 'lucide-react';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  liteMode: boolean;
  onToggleLiteMode: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  selectedDepartment?: AnimalDepartment;
  onSelectDepartment?: (dept: AnimalDepartment) => void;
  onOpenBreedGuide?: () => void;
  onOpenSellerGuide?: () => void;
  onOpenPromo?: () => void;
  comparedCount?: number;
  onOpenComparison?: () => void;
  onOpenReels: () => void;
  onOpenAddListing: () => void;
  onOpenPriceIndex: () => void;
  onOpenTransport: () => void;
  onOpenTelegram: () => void;
  onOpenAuctions: () => void;
  onOpenQurbonlik: () => void;
  onOpenBreedTrends?: () => void;
  onOpenAdmin?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  liteMode,
  onToggleLiteMode,
  isDarkMode,
  onToggleDarkMode,
  selectedDepartment,
  onSelectDepartment,
  onOpenBreedGuide,
  onOpenSellerGuide,
  onOpenPromo,
  comparedCount = 0,
  onOpenComparison,
  onOpenReels,
  onOpenAddListing,
  onOpenPriceIndex,
  onOpenTransport,
  onOpenTelegram,
  onOpenAuctions,
  onOpenQurbonlik,
  onOpenBreedTrends,
  onOpenAdmin,
}) => {
  const t = translations[language];

  // Dropdown states
  const [isDeptDropdownOpen, setIsDeptDropdownOpen] = useState(false);
  const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Section-by-section menu state (Bo'lim-bo'lim ochilish tizimi: null = bo'limlar tanlovi)
  type MenuSectionKey = 'departments' | 'auctions' | 'market' | 'services' | 'settings';
  const [activeMenuSection, setActiveMenuSection] = useState<MenuSectionKey | null>(null);
  const [menuSearchQuery, setMenuSearchQuery] = useState<string>('');

  const deptDropdownRef = useRef<HTMLDivElement>(null);
  const servicesDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        deptDropdownRef.current &&
        !deptDropdownRef.current.contains(event.target as Node)
      ) {
        setIsDeptDropdownOpen(false);
      }
      if (
        servicesDropdownRef.current &&
        !servicesDropdownRef.current.contains(event.target as Node)
      ) {
        setIsServicesDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectDept = (dept: AnimalDepartment) => {
    onSelectDepartment?.(dept);
    setIsDeptDropdownOpen(false);
    setIsMobileMenuOpen(false);
    const el = document.getElementById('catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#F7F9F6]/95 dark:bg-[#061210]/95 backdrop-blur-md border-b border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2">
          {/* Left: Brand Identity */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <a href="#" className="flex items-center gap-2 group">
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-[#064E3B] to-[#047857] text-white flex items-center justify-center font-black text-sm shadow-md shadow-[#064E3B]/30 group-hover:scale-105 transition-transform border border-[#10B981]/30">
                CH
              </div>
              <div className="leading-tight">
                <span className="font-extrabold text-sm sm:text-base tracking-tight text-[#1C2A23] dark:text-white font-serif block">
                  ChorvaBozor
                </span>
                <span className="text-[10px] text-[#047857] dark:text-[#10B981] font-semibold tracking-wider uppercase block">
                  UZBEKISTAN
                </span>
              </div>
            </a>
          </div>

          {/* Center: Clean, Compact Navigation (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-semibold text-stone-700 dark:text-stone-300">
            {/* Bo'limlar Dropdown */}
            <div className="relative" ref={deptDropdownRef}>
              <button
                type="button"
                onClick={() => {
                  setIsDeptDropdownOpen(!isDeptDropdownOpen);
                  setIsServicesDropdownOpen(false);
                }}
                className={`px-2.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
                  isDeptDropdownOpen || (selectedDepartment && selectedDepartment !== 'all')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-300 font-bold'
                    : 'hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                <span>
                  {selectedDepartment === 'qoramol'
                    ? '🐂 Qoramol'
                    : selectedDepartment === 'quy'
                    ? '🐑 Qoʻylar'
                    : selectedDepartment === 'ot'
                    ? '🐎 Otlar'
                    : language === 'uz'
                    ? 'Boʻlimlar'
                    : 'Разделы'}
                </span>
                <ChevronDown className={`w-3 h-3 transition-transform ${isDeptDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {isDeptDropdownOpen && (
                <div className="absolute top-full left-0 mt-1.5 w-48 bg-white dark:bg-stone-900 rounded-2xl shadow-xl border border-stone-200 dark:border-stone-800 p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <button
                    onClick={() => handleSelectDept('all')}
                    className={`w-full px-3 py-2 rounded-xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer ${
                      selectedDepartment === 'all'
                        ? 'bg-emerald-800 text-white font-bold'
                        : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                    }`}
                  >
                    <span>Barcha boʻlimlar</span>
                    <span className="text-[10px] opacity-75">Hammasi</span>
                  </button>
                  <button
                    onClick={() => handleSelectDept('qoramol')}
                    className={`w-full px-3 py-2 rounded-xl text-left text-xs font-semibold flex items-center gap-2 cursor-pointer ${
                      selectedDepartment === 'qoramol'
                        ? 'bg-emerald-800 text-white font-bold'
                        : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                    }`}
                  >
                    <span>🐂</span>
                    <span>Qoramol Kabineti</span>
                  </button>
                  <button
                    onClick={() => handleSelectDept('quy')}
                    className={`w-full px-3 py-2 rounded-xl text-left text-xs font-semibold flex items-center gap-2 cursor-pointer ${
                      selectedDepartment === 'quy'
                        ? 'bg-emerald-800 text-white font-bold'
                        : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                    }`}
                  >
                    <span>🐑</span>
                    <span>Qoʻylar Kabineti</span>
                  </button>
                  <button
                    onClick={() => handleSelectDept('ot')}
                    className={`w-full px-3 py-2 rounded-xl text-left text-xs font-semibold flex items-center gap-2 cursor-pointer ${
                      selectedDepartment === 'ot'
                        ? 'bg-emerald-800 text-white font-bold'
                        : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                    }`}
                  >
                    <span>🐎</span>
                    <span>Otlar Kabineti</span>
                  </button>
                  {onOpenBreedGuide && (
                    <div className="pt-1 mt-1 border-t border-stone-100 dark:border-stone-800">
                      <button
                        onClick={() => {
                          setIsDeptDropdownOpen(false);
                          onOpenBreedGuide();
                        }}
                        className="w-full px-3 py-2 rounded-xl text-left text-xs font-bold text-emerald-800 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 flex items-center gap-2 cursor-pointer"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>Zotlar Qomusi</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Direct Core Highlights */}
            <button
              onClick={onOpenReels}
              className="px-2.5 py-1.5 rounded-xl hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Play className="w-3 h-3 text-emerald-600 fill-current" />
              <span>Reels</span>
            </button>

            <button
              onClick={onOpenQurbonlik}
              className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-300 font-bold transition-colors cursor-pointer flex items-center gap-1 border border-amber-200/80 dark:border-amber-800/60"
            >
              <span>🌙</span>
              <span>{t.navQurbonlik}</span>
            </button>

            {onOpenPromo && (
              <button
                onClick={onOpenPromo}
                className="px-2 py-1.5 rounded-xl text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer flex items-center gap-1 font-black"
                title="Katta Bahorgi Aksiya va Reklama"
              >
                <Sparkles className="w-3 h-3 fill-current text-amber-500 animate-pulse" />
                <span>Aksiya</span>
              </button>
            )}

            {/* Xizmatlar Dropdown */}
            <div className="relative" ref={servicesDropdownRef}>
              <button
                type="button"
                onClick={() => {
                  setIsServicesDropdownOpen(!isServicesDropdownOpen);
                  setIsDeptDropdownOpen(false);
                }}
                className={`px-2.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
                  isServicesDropdownOpen
                    ? 'bg-stone-100 dark:bg-stone-800 text-stone-900 dark:text-white font-bold'
                    : 'hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                <span>{language === 'uz' ? 'Xizmatlar' : 'Сервисы'}</span>
                <ChevronDown className={`w-3 h-3 transition-transform ${isServicesDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {isServicesDropdownOpen && (
                <div className="absolute top-full left-0 mt-1.5 w-52 bg-white dark:bg-stone-900 rounded-2xl shadow-xl border border-stone-200 dark:border-stone-800 p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-0.5">
                  <button
                    onClick={() => {
                      setIsServicesDropdownOpen(false);
                      onOpenAuctions();
                    }}
                    className="w-full px-3 py-2 rounded-xl text-left text-xs font-medium hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 flex items-center gap-2 cursor-pointer"
                  >
                    <Gavel className="w-3.5 h-3.5 text-amber-600" />
                    <span>{t.navAuctions}</span>
                  </button>
                  <button
                    onClick={() => {
                      setIsServicesDropdownOpen(false);
                      onOpenPriceIndex();
                    }}
                    className="w-full px-3 py-2 rounded-xl text-left text-xs font-medium hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 flex items-center gap-2 cursor-pointer"
                  >
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.navPriceIndex}</span>
                  </button>
                  {onOpenBreedTrends && (
                    <button
                      onClick={() => {
                        setIsServicesDropdownOpen(false);
                        onOpenBreedTrends();
                      }}
                      className="w-full px-3 py-2 rounded-xl text-left text-xs font-semibold bg-emerald-50/70 hover:bg-emerald-100/70 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/60 text-emerald-900 dark:text-emerald-300 flex items-center gap-2 cursor-pointer"
                    >
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{language === 'uz' ? '📈 Zotlar Narx Dinamikasi' : '📈 Динамика цен пород'}</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setIsServicesDropdownOpen(false);
                      onOpenTransport();
                    }}
                    className="w-full px-3 py-2 rounded-xl text-left text-xs font-medium hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 flex items-center gap-2 cursor-pointer"
                  >
                    <Truck className="w-3.5 h-3.5 text-blue-600" />
                    <span>{t.navTransport}</span>
                  </button>
                  {onOpenSellerGuide && (
                    <button
                      onClick={() => {
                        setIsServicesDropdownOpen(false);
                        onOpenSellerGuide();
                      }}
                      className="w-full px-3 py-2 rounded-xl text-left text-xs font-medium hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 flex items-center gap-2 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>Oltin Qoʻllanma</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setIsServicesDropdownOpen(false);
                      onOpenTelegram();
                    }}
                    className="w-full px-3 py-2 rounded-xl text-left text-xs font-medium hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 flex items-center gap-2 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 text-sky-500" />
                    <span>{t.navTelegram}</span>
                  </button>
                </div>
              )}
            </div>
          </nav>

          {/* Right: Actions, Switchers & User Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Dark / Light Toggle (Visible on all screens) */}
            <button
              type="button"
              onClick={onToggleDarkMode}
              title={isDarkMode ? 'Yorugʻ rejimga oʻtish' : 'Qorongʻu rejimga oʻtish'}
              aria-label={isDarkMode ? 'Yorugʻ rejim' : 'Qorongʻu rejim'}
              className="p-1.5 sm:p-2 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors cursor-pointer flex items-center justify-center border border-stone-200/80 dark:border-stone-750"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-stone-600" />}
            </button>

            {/* Lite Mode Toggle (Visible on sm+) */}
            <button
              type="button"
              onClick={onToggleLiteMode}
              title={liteMode ? t.liteModeOn : t.liteModeDesc}
              className={`hidden sm:flex p-1.5 sm:p-2 rounded-xl border transition-colors cursor-pointer ${
                liteMode
                  ? 'bg-amber-100 border-amber-300 text-amber-900 dark:bg-amber-950 dark:border-amber-700 dark:text-amber-200'
                  : 'bg-stone-50 dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-500 dark:text-stone-300 hover:bg-stone-100'
              }`}
            >
              {liteMode ? <WifiOff className="w-4 h-4 text-amber-600 dark:text-amber-400" /> : <Wifi className="w-4 h-4" />}
            </button>

            {/* Language Switcher (Visible on sm+) */}
            <div className="hidden sm:inline-flex rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-850 p-0.5 text-xs font-semibold">
              <button
                type="button"
                onClick={() => onLanguageChange('uz')}
                className={`px-1.5 sm:px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  language === 'uz'
                    ? 'bg-white dark:bg-stone-900 text-emerald-900 dark:text-emerald-400 shadow-xs font-bold'
                    : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                UZ
              </button>
              <button
                type="button"
                onClick={() => onLanguageChange('ru')}
                className={`px-1.5 sm:px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  language === 'ru'
                    ? 'bg-white dark:bg-stone-900 text-emerald-900 dark:text-emerald-400 shadow-xs font-bold'
                    : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                RU
              </button>
            </div>

            {/* Comparison Badge */}
            {comparedCount > 0 && onOpenComparison && (
              <button
                type="button"
                onClick={onOpenComparison}
                className="py-1.5 px-2 bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1 cursor-pointer animate-in zoom-in-95 duration-150"
                title={t.compareModalTitle}
              >
                <Scale className="w-3.5 h-3.5 text-emerald-300" />
                <span className="w-4 h-4 rounded-full bg-emerald-600 flex items-center justify-center text-[10px] font-mono">
                  {comparedCount}
                </span>
              </button>
            )}

            {/* Admin Dashboard Entry Button */}
            {onOpenAdmin && (
              <button
                type="button"
                onClick={onOpenAdmin}
                className="py-1.5 px-2.5 sm:px-3 bg-[#041C16] hover:bg-[#072D24] text-[#10B981] rounded-xl text-xs font-bold transition-all shadow-md shadow-[#041C16]/40 flex items-center gap-1.5 cursor-pointer border border-[#0E3D32] shrink-0"
                title="ChorvaBozor Admin Boshqaruv Markazi"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}

            {/* Primary Action Button: Add Listing (Accent Gold) */}
            <button
              type="button"
              onClick={onOpenAddListing}
              className="py-1.5 px-3 sm:px-4 bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-sm shadow-[#F59E0B]/30 active:scale-95 cursor-pointer flex items-center gap-1.5 shrink-0"
            >
              <PlusCircle className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">{t.navAddListing}</span>
              <span className="sm:hidden text-xs">Eʼlon</span>
            </button>

            {/* Menu Button (Section-by-Section) */}
            <button
              type="button"
              onClick={() => {
                if (isMobileMenuOpen) {
                  setIsMobileMenuOpen(false);
                  setActiveMenuSection(null);
                  setMenuSearchQuery('');
                } else {
                  setIsMobileMenuOpen(true);
                  setActiveMenuSection(null);
                  setMenuSearchQuery('');
                }
              }}
              className={`p-1.5 sm:px-2.5 sm:py-1.5 text-stone-700 dark:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl cursor-pointer flex items-center gap-1.5 border transition-all ${
                isMobileMenuOpen
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300 font-bold'
                  : 'border-stone-200/60 dark:border-stone-800 hover:border-stone-300'
              }`}
              title="Boʻlim-boʻlim menyuni ochish"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
              <span className="text-xs font-bold hidden sm:inline">Menyu</span>
            </button>
          </div>
        </div>

        {/* Section-by-Section (Bo'lim-bo'lim) Menu Drawer */}
        {isMobileMenuOpen && (
          <div className="border-t border-[#E5ECE7] dark:border-[#0E3D32] py-3.5 px-2.5 sm:px-4 bg-[#F7F9F6] dark:bg-[#061210] shadow-2xl rounded-b-2xl animate-in slide-in-from-top-2 duration-200 space-y-3 max-h-[85vh] overflow-y-auto">
            {/* SEARCH VIEW (If search text is active) */}
            {menuSearchQuery.trim() !== '' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800">
                  <div className="flex items-center gap-2">
                    <Search className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold text-stone-900 dark:text-white">
                      {language === 'uz' ? 'Qidiruv natijalari' : 'Результаты поиска'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setMenuSearchQuery('')}
                    className="text-xs text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer font-bold"
                  >
                    {language === 'uz' ? 'Tozalash' : 'Очистить'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {/* Department matches */}
                  {('qoramol sigir buqa novvos boʻlim'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => handleSelectDept('qoramol')}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">🐂</span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Qoramol Boʻlimi</div>
                          <div className="text-[10px] text-stone-500">Chorva Boʻlimi • Sigir, buqa, novvos</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {('qoʻy qoy qoʻchqor hisor edilboy boʻlim'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => handleSelectDept('quy')}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">🐑</span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Qoʻylar Boʻlimi</div>
                          <div className="text-[10px] text-stone-500">Chorva Boʻlimi • Hisor, Edilboy, qoʻchqor</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {('ot qorabayir axaltaka chopqir poyga boʻlim'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => handleSelectDept('ot')}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">🐎</span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Otlar Boʻlimi</div>
                          <div className="text-[10px] text-stone-500">Chorva Boʻlimi • Qorabayir, Axaltaka</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {/* Auction matches */}
                  {('auksion stavka savdo taklif'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenAuctions();
                      }}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <Gavel className="w-4 h-4 text-amber-600" />
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Jonli Auksionlar</div>
                          <div className="text-[10px] text-stone-500">Auksion Boʻlimi • Real-vaqt stavkalari</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {/* Qurbonlik matches */}
                  {('qurbonlik hayit bayram mol qoʻy'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenQurbonlik();
                      }}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">🌙</span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Qurbonlik 2026</div>
                          <div className="text-[10px] text-stone-500">Auksion & Qurbonlik • Shariat talablariga mos</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {/* Price Index matches */}
                  {('narx indeks viloyat bozor tahlil'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenPriceIndex();
                      }}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <TrendingUp className="w-4 h-4 text-emerald-600" />
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Viloyatlar Narx Indeksi</div>
                          <div className="text-[10px] text-stone-500">Bozor Tahlili • 14 viloyat tirik vazn narxi</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {/* Transport matches */}
                  {('fura transport yuk yetkaz mashina km'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenTransport();
                      }}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <Truck className="w-4 h-4 text-blue-600" />
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Viloyatlararo Fura & Transport</div>
                          <div className="text-[10px] text-stone-500">Xizmatlar • Yuk yetkazish kalkulyatori</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                  {/* Reels matches */}
                  {('reels video lenta qisqa rolik'.includes(menuSearchQuery.toLowerCase())) && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenReels();
                      }}
                      className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between text-left cursor-pointer hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <Play className="w-4 h-4 text-emerald-600 fill-current" />
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Reels Qisqa Videolar</div>
                          <div className="text-[10px] text-stone-500">Xizmatlar • Chorva videolari</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </button>
                  )}
                </div>
              </div>
            ) : activeMenuSection === null ? (
              /* ======================================================== */
              /* LEVEL 1: BO'LIMLAR TANLOVI (BOSHQACHA AYTGANDA: BO'LIM-BO'LIM) */
              /* ======================================================== */
              <div className="space-y-3 animate-in fade-in duration-150">
                {/* Header info */}
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center font-bold text-xs shadow-2xs">
                      <Layers className="w-4 h-4" />
                    </span>
                    <div>
                      <h3 className="text-xs sm:text-sm font-black text-stone-900 dark:text-white">
                        {language === 'uz' ? 'Menyu: Kerakli boʻlimni tanlang' : 'Меню: Выберите раздел'}
                      </h3>
                      <p className="text-[11px] text-stone-500 dark:text-stone-400">
                        {language === 'uz'
                          ? 'Boʻlim ustiga bosing — faqat oʻsha boʻlimning xizmatlari ochiladi'
                          : 'Нажмите на раздел — откроются сервисы только этого раздела'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      setActiveMenuSection(null);
                    }}
                    className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
                    title="Yopish"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick Search */}
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
                  <input
                    type="text"
                    value={menuSearchQuery}
                    onChange={(e) => setMenuSearchQuery(e.target.value)}
                    placeholder={language === 'uz' ? 'Xizmat yoki boʻlimni qidirish...' : 'Поиск раздела или сервиса...'}
                    className="w-full pl-9 pr-8 py-2 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-750 rounded-xl text-xs font-medium text-stone-900 dark:text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
                  />
                  {menuSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setMenuSearchQuery('')}
                      className="absolute right-2.5 top-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* 5 Distinct Department Cards (Drilldown buttons) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* 1. Chorva Bo'limi */}
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('departments')}
                    className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50/70 to-emerald-100/40 dark:from-emerald-950/40 dark:to-emerald-900/30 border border-emerald-200/80 dark:border-emerald-800 text-left cursor-pointer hover:shadow-md hover:border-emerald-400 dark:hover:border-emerald-700 transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                        🐂
                      </span>
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-xs sm:text-sm text-stone-900 dark:text-white">
                            1. Chorva Boʻlimlari
                          </h4>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-emerald-200/80 dark:bg-emerald-800 text-emerald-900 dark:text-emerald-100 font-bold">
                            4 tur
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 dark:text-stone-400 truncate">
                          Qoramol, qoʻylar, otlar va zotlar ensiklopediyasi
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-emerald-700 dark:text-emerald-300 text-xs font-bold shrink-0 ml-2">
                      <span className="hidden sm:inline">Ochish</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>

                  {/* 2. Auksion & Qurbonlik */}
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('auctions')}
                    className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-50/70 to-amber-100/40 dark:from-amber-950/40 dark:to-amber-900/30 border border-amber-200/80 dark:border-amber-800 text-left cursor-pointer hover:shadow-md hover:border-amber-400 dark:hover:border-amber-700 transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center text-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform font-bold">
                        ⚖️
                      </span>
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-xs sm:text-sm text-stone-900 dark:text-white">
                            2. Auksion & Qurbonlik
                          </h4>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-200/80 dark:bg-amber-800 text-amber-900 dark:text-amber-100 font-bold">
                            Jonli
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 dark:text-stone-400 truncate">
                          Jonli savdolar, stavkalar, Qurbonlik 2026 va aksiya
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-amber-700 dark:text-amber-300 text-xs font-bold shrink-0 ml-2">
                      <span className="hidden sm:inline">Ochish</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>

                  {/* 3. Bozor Narxlari & Tahlil */}
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('market')}
                    className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50/70 to-teal-100/40 dark:from-emerald-950/40 dark:to-teal-900/30 border border-emerald-200/80 dark:border-emerald-800 text-left cursor-pointer hover:shadow-md hover:border-emerald-400 dark:hover:border-emerald-700 transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center text-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform font-bold">
                        📈
                      </span>
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-xs sm:text-sm text-stone-900 dark:text-white">
                            3. Bozor & Narxlar Tahlili
                          </h4>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-teal-200/80 dark:bg-teal-800 text-teal-900 dark:text-teal-100 font-bold">
                            14 viloyat
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 dark:text-stone-400 truncate">
                          Tirik vazn narx indeksi va zotlar oylik dinamikasi
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-teal-700 dark:text-teal-300 text-xs font-bold shrink-0 ml-2">
                      <span className="hidden sm:inline">Ochish</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>

                  {/* 4. Xizmatlar & Imkoniyatlar */}
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('services')}
                    className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-50/70 to-blue-100/40 dark:from-blue-950/40 dark:to-blue-900/30 border border-blue-200/80 dark:border-blue-800 text-left cursor-pointer hover:shadow-md hover:border-blue-400 dark:hover:border-blue-700 transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center text-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform font-bold">
                        🚚
                      </span>
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-xs sm:text-sm text-stone-900 dark:text-white">
                            4. Xizmatlar & Imkoniyatlar
                          </h4>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-blue-200/80 dark:bg-blue-800 text-blue-900 dark:text-blue-100 font-bold">
                            Fura & Video
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 dark:text-stone-400 truncate">
                          Fura kalkulyatori, Reels videolar va Telegram bot
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-blue-700 dark:text-blue-300 text-xs font-bold shrink-0 ml-2">
                      <span className="hidden sm:inline">Ochish</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>

                  {/* 5. Sozlamalar & Interfeys */}
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('settings')}
                    className="p-3.5 rounded-2xl bg-gradient-to-r from-stone-100/70 to-stone-200/40 dark:from-stone-850 dark:to-stone-800 border border-stone-200/80 dark:border-stone-750 text-left cursor-pointer hover:shadow-md hover:border-stone-400 dark:hover:border-stone-600 transition-all flex items-center justify-between group sm:col-span-2"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-stone-700 text-white flex items-center justify-center text-xl shrink-0 shadow-xs group-hover:scale-105 transition-transform font-bold">
                        ⚙️
                      </span>
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-xs sm:text-sm text-stone-900 dark:text-white">
                            5. Sozlamalar & Interfeys
                          </h4>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-stone-200 dark:bg-stone-700 text-stone-800 dark:text-stone-200 font-bold">
                            Mavzu & Til
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 dark:text-stone-400 truncate">
                          Tungi/yorugʻ rejim, internet tejamkor rejim va tilni almashtirish
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-stone-700 dark:text-stone-300 text-xs font-bold shrink-0 ml-2">
                      <span className="hidden sm:inline">Ochish</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                </div>

                {/* Quick Add Listing Bar */}
                <div className="pt-2 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
                  <span className="text-[11px] text-stone-500 dark:text-stone-400">
                    Chorva sotmoqchimisiz?
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onOpenAddListing();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer transition-colors flex items-center gap-1 shadow-xs"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>+ Yangi Eʼlon Berish</span>
                  </button>
                </div>
              </div>
            ) : (
              /* ======================================================== */
              /* LEVEL 2: TANLANGAN BO'LIM (FAKAT VA FAKAT SHU BO'LIM OCHILADI) */
              /* ======================================================== */
              <div className="space-y-3 animate-in fade-in slide-in-from-right-3 duration-200">
                {/* Back to all sections bar */}
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800">
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection(null)}
                    className="px-2.5 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-750 text-stone-800 dark:text-stone-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                  >
                    <ArrowLeft className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'uz' ? '← Barcha boʻlimlar' : '← Все разделы'}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold text-stone-900 dark:text-white">
                      {activeMenuSection === 'departments' && '🐂 Chorva Boʻlimlari'}
                      {activeMenuSection === 'auctions' && '⚖️ Auksion & Qurbonlik'}
                      {activeMenuSection === 'market' && '📈 Bozor Narxlari & Tahlil'}
                      {activeMenuSection === 'services' && '🚚 Xizmatlar & Imkoniyatlar'}
                      {activeMenuSection === 'settings' && '⚙️ Sozlamalar & Interfeys'}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        setActiveMenuSection(null);
                      }}
                      className="p-1 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
                      title="Yopish"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Horizontal Quick Switcher between sections without going back */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] font-bold no-scrollbar">
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('departments')}
                    className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                      activeMenuSection === 'departments'
                        ? 'bg-emerald-800 text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                    }`}
                  >
                    🐂 1. Chorva
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('auctions')}
                    className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                      activeMenuSection === 'auctions'
                        ? 'bg-amber-500 text-stone-950 font-black shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                    }`}
                  >
                    ⚖️ 2. Auksion
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('market')}
                    className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                      activeMenuSection === 'market'
                        ? 'bg-teal-700 text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                    }`}
                  >
                    📈 3. Bozor
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('services')}
                    className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                      activeMenuSection === 'services'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                    }`}
                  >
                    🚚 4. Xizmatlar
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveMenuSection('settings')}
                    className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                      activeMenuSection === 'settings'
                        ? 'bg-stone-700 text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200'
                    }`}
                  >
                    ⚙️ 5. Sozlamalar
                  </button>
                </div>

                {/* --- 1-BO'LIM: CHORVA BO'LIMLARI --- */}
                {activeMenuSection === 'departments' && (
                  <div className="space-y-2.5">
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      Chorva turini tanlang — katalog sahifasi saralangan holda ochiladi:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleSelectDept('all')}
                        className={`p-3 rounded-xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors ${
                          selectedDepartment === 'all'
                            ? 'bg-emerald-800 text-white shadow-xs'
                            : 'bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">🌐</span>
                          <div>
                            <div className="font-bold">Barcha boʻlimlar</div>
                            <div className="text-[10px] opacity-75">Qoramol, qoʻy va otlar birgalikda</div>
                          </div>
                        </div>
                        {selectedDepartment === 'all' && <Check className="w-4 h-4" />}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectDept('qoramol')}
                        className={`p-3 rounded-xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors ${
                          selectedDepartment === 'qoramol'
                            ? 'bg-emerald-800 text-white shadow-xs'
                            : 'bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">🐂</span>
                          <div>
                            <div className="font-bold">Qoramol Boʻlimi</div>
                            <div className="text-[10px] opacity-75">Sigir, buqa, novvos, buzoq</div>
                          </div>
                        </div>
                        {selectedDepartment === 'qoramol' && <Check className="w-4 h-4" />}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectDept('quy')}
                        className={`p-3 rounded-xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors ${
                          selectedDepartment === 'quy'
                            ? 'bg-emerald-800 text-white shadow-xs'
                            : 'bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">🐑</span>
                          <div>
                            <div className="font-bold">Qoʻylar Boʻlimi</div>
                            <div className="text-[10px] opacity-75">Hisor, Edilboy, qoʻchqor, sovliq</div>
                          </div>
                        </div>
                        {selectedDepartment === 'quy' && <Check className="w-4 h-4" />}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectDept('ot')}
                        className={`p-3 rounded-xl text-left text-xs font-semibold flex items-center justify-between cursor-pointer transition-colors ${
                          selectedDepartment === 'ot'
                            ? 'bg-emerald-800 text-white shadow-xs'
                            : 'bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">🐎</span>
                          <div>
                            <div className="font-bold">Otlar Boʻlimi</div>
                            <div className="text-[10px] opacity-75">Qorabayir, Axaltaka, chopqir tulpor</div>
                          </div>
                        </div>
                        {selectedDepartment === 'ot' && <Check className="w-4 h-4" />}
                      </button>

                      {onOpenBreedGuide && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            onOpenBreedGuide();
                          }}
                          className="p-3 rounded-xl text-left text-xs font-bold text-emerald-900 dark:text-emerald-300 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 flex items-center gap-3 cursor-pointer transition-colors sm:col-span-2 border border-emerald-200 dark:border-emerald-900"
                        >
                          <BookOpen className="w-5 h-5 text-emerald-600 shrink-0" />
                          <div>
                            <div className="font-extrabold text-xs sm:text-sm">13 Zot Qomusi (Ensiklopediyasi)</div>
                            <div className="text-[10px] text-emerald-700/90 dark:text-emerald-300/80 font-normal">
                              Mahsuldorlik, vazn, sut va goʻsht berish koʻrsatkichlari
                            </div>
                          </div>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* --- 2-BO'LIM: AUKSION & QURBONLIK --- */}
                {activeMenuSection === 'auctions' && (
                  <div className="space-y-2.5">
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      Jonli savdolar, auksionlar va maxsus mavsumiy loyihalar:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          onOpenAuctions();
                        }}
                        className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex flex-col gap-1.5 text-left cursor-pointer transition-colors shadow-2xs group"
                      >
                        <div className="flex items-center gap-2 font-bold text-xs text-stone-900 dark:text-white">
                          <Gavel className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
                          <span>Jonli Auksionlar</span>
                        </div>
                        <div className="text-[10px] text-stone-500 dark:text-stone-400">
                          Real-vaqt stavkalari va 0% mablagʻ qaytarish kafolati
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          onOpenQurbonlik();
                        }}
                        className="p-3 rounded-xl bg-amber-50/70 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-200 border border-amber-200/80 dark:border-amber-800 flex flex-col gap-1.5 text-left cursor-pointer transition-colors shadow-2xs group"
                      >
                        <div className="flex items-center gap-2 font-bold text-xs">
                          <span className="text-base leading-none">🌙</span>
                          <span>Qurbonlik 2026</span>
                        </div>
                        <div className="text-[10px] text-amber-800/80 dark:text-amber-300/80">
                          Shariat talablariga mos belgilangan semiz chorvalar
                        </div>
                      </button>

                      {onOpenPromo && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            onOpenPromo();
                          }}
                          className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex flex-col gap-1.5 text-left cursor-pointer transition-colors shadow-2xs group"
                        >
                          <div className="flex items-center gap-2 font-bold text-xs text-amber-800 dark:text-amber-300">
                            <Sparkles className="w-4 h-4 text-amber-500 fill-current animate-pulse" />
                            <span>Katta Bahorgi Aksiya</span>
                          </div>
                          <div className="text-[10px] text-stone-500 dark:text-stone-400">
                            Maxsus chegirmalar, VIP eʼlonlar va bonuslar
                          </div>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* --- 3-BO'LIM: BOZOR NARXLARI & TAHLIL --- */}
                {activeMenuSection === 'market' && (
                  <div className="space-y-2.5">
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      Oʻzbekiston bozorlaridagi tirik vazn narx indekslari va tendensiyalar:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          onOpenPriceIndex();
                        }}
                        className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex flex-col gap-1.5 text-left cursor-pointer transition-colors shadow-2xs group"
                      >
                        <div className="flex items-center gap-2 font-bold text-xs text-stone-900 dark:text-white">
                          <TrendingUp className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
                          <span>Viloyatlar Narx Indeksi</span>
                        </div>
                        <div className="text-[10px] text-stone-500 dark:text-stone-400">
                          14 ta viloyat bozorlaridagi tirik vazn narxlari
                        </div>
                      </button>

                      {onOpenBreedTrends && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            onOpenBreedTrends();
                          }}
                          className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex flex-col gap-1.5 text-left cursor-pointer transition-colors shadow-2xs group"
                        >
                          <div className="flex items-center gap-2 font-bold text-xs text-emerald-800 dark:text-emerald-300">
                            <TrendingUp className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
                            <span>Zotlar Narx Dinamikasi</span>
                          </div>
                          <div className="text-[10px] text-stone-500 dark:text-stone-400">
                            2024–2026 yillardagi oylik narx tendensiyalari
                          </div>
                        </button>
                      )}

                      {onOpenBreedGuide && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            onOpenBreedGuide();
                          }}
                          className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex flex-col gap-1.5 text-left cursor-pointer transition-colors shadow-2xs group"
                        >
                          <div className="flex items-center gap-2 font-bold text-xs text-stone-900 dark:text-white">
                            <BookOpen className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
                            <span>Zotlar Qomusi</span>
                          </div>
                          <div className="text-[10px] text-stone-500 dark:text-stone-400">
                            13 ta eng xaridorgir zotlar katalogi
                          </div>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* --- 4-BO'LIM: XIZMATLAR & IMKONIATLAR --- */}
                {activeMenuSection === 'services' && (
                  <div className="space-y-2.5">
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      Transport, videolar va qulay qoʻllanmalar:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          onOpenReels();
                        }}
                        className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex items-center gap-3 text-left cursor-pointer transition-colors shadow-2xs group"
                      >
                        <span className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
                          <Play className="w-4 h-4 fill-current" />
                        </span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Reels Qisqa Videolar</div>
                          <div className="text-[10px] text-stone-500 dark:text-stone-400">Chorvalarni videoda harakatini koʻring</div>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          onOpenTransport();
                        }}
                        className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex items-center gap-3 text-left cursor-pointer transition-colors shadow-2xs group"
                      >
                        <span className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center shrink-0">
                          <Truck className="w-4 h-4" />
                        </span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Viloyatlararo Fura & Transport</div>
                          <div className="text-[10px] text-stone-500 dark:text-stone-400">Yuk yetkazish masofasi va narx kalkulyatori</div>
                        </div>
                      </button>

                      {onOpenSellerGuide && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            onOpenSellerGuide();
                          }}
                          className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex items-center gap-3 text-left cursor-pointer transition-colors shadow-2xs group"
                        >
                          <span className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                            <Sparkles className="w-4 h-4" />
                          </span>
                          <div>
                            <div className="font-bold text-xs text-stone-900 dark:text-white">Sotuvchiga Oltin Qoʻllanma</div>
                            <div className="text-[10px] text-stone-500 dark:text-stone-400">Tez va qimmatroq sotishning 5 siri</div>
                          </div>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          onOpenTelegram();
                        }}
                        className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 hover:bg-sky-50 dark:hover:bg-sky-950/40 text-stone-800 dark:text-stone-200 border border-stone-200/60 dark:border-stone-750 flex items-center gap-3 text-left cursor-pointer transition-colors shadow-2xs group"
                      >
                        <span className="w-9 h-9 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 flex items-center justify-center shrink-0">
                          <Send className="w-4 h-4" />
                        </span>
                        <div>
                          <div className="font-bold text-xs text-stone-900 dark:text-white">Telegram Bot & Kanal</div>
                          <div className="text-[10px] text-stone-500 dark:text-stone-400">Xabarlar, bot simulyatori va kanal eʼlonlari</div>
                        </div>
                      </button>
                    </div>
                  </div>
                )}

                {/* --- 5-BO'LIM: SOZLAMALAR & INTERFEYS --- */}
                {activeMenuSection === 'settings' && (
                  <div className="space-y-2.5">
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      Tizim va interfeys moslamalari:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {/* Mavzu toggle: Yorug' va Qorong'u rejim */}
                      <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                          {language === 'uz' ? 'Rejim (Mavzu):' : 'Тема оформления:'}
                        </span>
                        <div className="inline-flex rounded-lg border border-stone-200 dark:border-stone-700 p-0.5 bg-white dark:bg-stone-850 text-xs font-bold shadow-2xs">
                          <button
                            type="button"
                            onClick={() => {
                              if (isDarkMode) onToggleDarkMode();
                            }}
                            className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 cursor-pointer ${
                              !isDarkMode
                                ? 'bg-amber-100 text-amber-950 dark:bg-amber-950 dark:text-amber-200 font-extrabold shadow-xs'
                                : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                            }`}
                          >
                            <Sun className="w-3.5 h-3.5 text-amber-500" />
                            <span>Yorugʻ</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (!isDarkMode) onToggleDarkMode();
                            }}
                            className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 cursor-pointer ${
                              isDarkMode
                                ? 'bg-stone-800 text-white font-extrabold shadow-xs'
                                : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                            }`}
                          >
                            <Moon className="w-3.5 h-3.5 text-stone-400" />
                            <span>Qorongʻu</span>
                          </button>
                        </div>
                      </div>

                      {/* Tejamkor rejim toggle */}
                      <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between">
                        <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                          {language === 'uz' ? 'Tejamkor rejim:' : 'Экономный режим:'}
                        </span>
                        <button
                          type="button"
                          onClick={onToggleLiteMode}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors border shadow-2xs ${
                            liteMode
                              ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border-amber-300'
                              : 'bg-white dark:bg-stone-700 text-stone-800 dark:text-stone-200 border-stone-200 dark:border-stone-600'
                          }`}
                        >
                          {liteMode ? <WifiOff className="w-3.5 h-3.5 text-amber-600" /> : <Wifi className="w-3.5 h-3.5 text-stone-500" />}
                          <span>{liteMode ? 'Yoqilgan' : 'Oʻchiq'}</span>
                        </button>
                      </div>

                      {/* Til switcher */}
                      <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200/80 dark:border-stone-750 flex items-center justify-between">
                        <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                          {language === 'uz' ? 'Til:' : 'Язык:'}
                        </span>
                        <div className="inline-flex rounded-lg border border-stone-200 dark:border-stone-700 p-0.5 bg-white dark:bg-stone-850 text-xs font-black shadow-2xs">
                          <button
                            type="button"
                            onClick={() => onLanguageChange('uz')}
                            className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                              language === 'uz' ? 'bg-emerald-800 text-white shadow-xs' : 'text-stone-500'
                            }`}
                          >
                            UZ
                          </button>
                          <button
                            type="button"
                            onClick={() => onLanguageChange('ru')}
                            className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                              language === 'ru' ? 'bg-emerald-800 text-white shadow-xs' : 'text-stone-500'
                            }`}
                          >
                            RU
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Admin Dashboard Navigation */}
                    {onOpenAdmin && (
                      <div className="pt-3 border-t border-stone-200/80 dark:border-stone-750 flex items-center justify-between">
                        <div>
                          <span className="text-xs font-bold text-stone-900 dark:text-white block">
                            {language === 'uz' ? 'Administrator Markazi' : 'Панель Администратора'}
                          </span>
                          <span className="text-[11px] text-stone-500">
                            {language === 'uz'
                              ? 'KPI, AI moderatsiya, auksionlar va eskrou boshqaruvi'
                              : 'KPI, ИИ модерация, аукционы и эскроу'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            onOpenAdmin();
                          }}
                          className="px-3.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-850 dark:bg-stone-800 dark:hover:bg-stone-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{language === 'uz' ? 'Admin Kabineti →' : 'Войти в панель →'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
