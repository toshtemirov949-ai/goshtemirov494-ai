import React from 'react';
import { Language } from '../types';
import { Plus, ShieldCheck, Zap, BookOpen, Sparkles } from 'lucide-react';

interface QuickAddLivestockBarProps {
  language: Language;
  onOpenAddListingWithDept: (dept: 'qoramol' | 'quy' | 'ot') => void;
  onOpenBreedGuide?: () => void;
}

export const QuickAddLivestockBar: React.FC<QuickAddLivestockBarProps> = ({
  language,
  onOpenAddListingWithDept,
  onOpenBreedGuide,
}) => {
  return (
    <section className="bg-white dark:bg-stone-900 border-y border-stone-200 dark:border-stone-800 transition-colors shadow-2xs py-5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold mb-1">
              <Zap className="w-3.5 h-3.5 text-emerald-600 fill-current" />
              <span>Dallolsiz Toʻgʻridan-Toʻgʻri Savdo Tizimi</span>
            </div>
            <h2 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100 font-serif">
              {language === 'uz'
                ? 'Chorva molingiz bormi? 1 daqiqada bepul sotuvga chiqaring:'
                : 'Есть скот на продажу? Разместите бесплатно за 1 минуту:'}
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {language === 'uz'
                ? 'Mol, qoʻy yoki ot turini tanlang va rasm, video, narxini belgilab xaridorlarga taklif qiling'
                : 'Выберите КРС, овец или лошадей и разместите объявление без посредников'}
            </p>
          </div>

          {onOpenBreedGuide && (
            <button
              type="button"
              onClick={onOpenBreedGuide}
              className="self-start md:self-center px-3 py-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-750 text-stone-700 dark:text-stone-300 text-xs font-bold flex items-center gap-1.5 border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer shrink-0"
            >
              <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
              <span>13 Zot Qomusi</span>
            </button>
          )}
        </div>

        {/* 3 Prominent Add Buttons (10% Emerald Accent) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          {/* 1. MOL QO'SHISH */}
          <button
            type="button"
            onClick={() => onOpenAddListingWithDept('qoramol')}
            className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white shadow-sm shadow-emerald-700/20 text-left transition-all cursor-pointer flex items-center justify-between group"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <span className="text-3xl sm:text-4xl group-hover:scale-110 transition-transform shrink-0">
                🐂
              </span>
              <div className="overflow-hidden">
                <div className="font-black text-sm sm:text-base flex items-center gap-1">
                  <span>Mol qoʻshish</span>
                  <Plus className="w-4 h-4 text-emerald-200 group-hover:rotate-90 transition-transform" />
                </div>
                <div className="text-[11px] text-emerald-100 truncate mt-0.5">
                  Sigir, buqa, buzoq, naslli golshtin
                </div>
              </div>
            </div>
            <span className="text-xs bg-emerald-700/60 group-hover:bg-emerald-800/80 px-2 py-1 rounded-lg font-bold shrink-0 hidden lg:inline">
              Eʼlon berish →
            </span>
          </button>

          {/* 2. QO'Y QO'SHISH */}
          <button
            type="button"
            onClick={() => onOpenAddListingWithDept('quy')}
            className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white shadow-sm shadow-emerald-700/20 text-left transition-all cursor-pointer flex items-center justify-between group"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <span className="text-3xl sm:text-4xl group-hover:scale-110 transition-transform shrink-0">
                🐑
              </span>
              <div className="overflow-hidden">
                <div className="font-black text-sm sm:text-base flex items-center gap-1">
                  <span>Qoʻy qoʻshish</span>
                  <Plus className="w-4 h-4 text-emerald-200 group-hover:rotate-90 transition-transform" />
                </div>
                <div className="text-[11px] text-emerald-100 truncate mt-0.5">
                  Hisor, qoʻchqor, sovliq, qurbonlik
                </div>
              </div>
            </div>
            <span className="text-xs bg-emerald-700/60 group-hover:bg-emerald-800/80 px-2 py-1 rounded-lg font-bold shrink-0 hidden lg:inline">
              Eʼlon berish →
            </span>
          </button>

          {/* 3. OT QO'SHISH */}
          <button
            type="button"
            onClick={() => onOpenAddListingWithDept('ot')}
            className="p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white shadow-sm shadow-emerald-700/20 text-left transition-all cursor-pointer flex items-center justify-between group"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <span className="text-3xl sm:text-4xl group-hover:scale-110 transition-transform shrink-0">
                🐎
              </span>
              <div className="overflow-hidden">
                <div className="font-black text-sm sm:text-base flex items-center gap-1">
                  <span>Ot qoʻshish</span>
                  <Plus className="w-4 h-4 text-emerald-200 group-hover:rotate-90 transition-transform" />
                </div>
                <div className="text-[11px] text-emerald-100 truncate mt-0.5">
                  Qorabayir, Axaltaka, poyga tulpor
                </div>
              </div>
            </div>
            <span className="text-xs bg-emerald-700/60 group-hover:bg-emerald-800/80 px-2 py-1 rounded-lg font-bold shrink-0 hidden lg:inline">
              Eʼlon berish →
            </span>
          </button>
        </div>

        {/* Quiet Trust Bar */}
        <div className="flex items-center justify-center gap-4 text-[11px] text-stone-500 dark:text-stone-400 mt-3 flex-wrap">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            0% Dallol komissiyasi
          </span>
          <span>·</span>
          <span>Bepul video yuklash (Reels)</span>
          <span>·</span>
          <span>Eskrou xavfsiz toʻlov kafolati</span>
          <span>·</span>
          <span>Viloyatlararo maxsus fura xizmati</span>
        </div>
      </div>
    </section>
  );
};
