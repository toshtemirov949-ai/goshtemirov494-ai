import React from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import { Play, ShieldCheck, Heart, Eye, ArrowUpRight, Scale, Stethoscope } from 'lucide-react';

interface InstagramGridProps {
  items: LivestockItem[];
  language: Language;
  comparedItemIds?: string[];
  onToggleCompare?: (item: LivestockItem) => void;
  onSelect: (item: LivestockItem) => void;
  onOpenReelsForListing: (item: LivestockItem) => void;
  onOpenVetConsult?: (item: LivestockItem) => void;
}

export const InstagramGrid: React.FC<InstagramGridProps> = ({
  items,
  language,
  comparedItemIds = [],
  onToggleCompare,
  onSelect,
  onOpenReelsForListing,
  onOpenVetConsult,
}) => {
  const t = translations[language];

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('uz-UZ').format(p);
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
      {items.map((item) => {
        const isCompared = comparedItemIds.includes(item.id);

        return (
          <div
            key={item.id}
            className="group relative aspect-square bg-stone-900 rounded-2xl overflow-hidden cursor-pointer shadow-xs hover:shadow-lg transition-all border border-stone-200 dark:border-stone-800"
            onClick={() => onSelect(item)}
          >
            {/* Base Image */}
            <img
              src={item.imageUrl}
              alt={item.titleUz}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />

            {/* Consistent Instagram Template Brand Bar (Top) */}
            <div className="absolute top-0 inset-x-0 p-2.5 bg-gradient-to-b from-black/70 to-transparent flex items-center justify-between text-white text-[11px] pointer-events-none">
              <span className="font-extrabold tracking-tight font-serif text-emerald-300 drop-shadow">
                ChorvaBozor
              </span>
              {item.hasVideo && (
                <span className="bg-black/60 backdrop-blur-xs px-1.5 py-0.5 rounded text-[10px] font-mono flex items-center gap-1">
                  <Play className="w-2.5 h-2.5 fill-sky-400 text-sky-400" />
                  <span>Reels</span>
                </span>
              )}
            </div>

            {/* Persistent Bottom Specs Tag (Clean uniform brand style) */}
            <div className="absolute bottom-0 inset-x-0 p-2.5 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-white">
              <div className="text-xs font-bold truncate drop-shadow">
                {item.breed}
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-stone-200 mt-0.5">
                <span className="text-amber-300 font-bold">
                  {formatPrice(item.priceUzs)} soʻm
                </span>
                <span>{item.weightKg} kg</span>
              </div>
            </div>

            {/* Hover Overlay with Action Buttons */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-3 text-white text-center gap-2">
              <span className="text-xs font-bold line-clamp-2 max-w-[90%]">
                {language === 'uz' ? item.titleUz : item.titleRu}
              </span>

              <div className="flex items-center gap-2 text-xs font-mono text-emerald-300">
                {item.vetInfo?.hasVetPassport && (
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Vet Pasport</span>
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 mt-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelect(item);
                  }}
                  className="py-1.5 px-3 bg-white text-stone-900 rounded-lg text-xs font-bold hover:bg-stone-100 cursor-pointer shadow-sm"
                >
                  Koʻrish
                </button>

                {onToggleCompare && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleCompare(item);
                    }}
                    className={`py-1.5 px-2.5 rounded-lg text-xs font-bold cursor-pointer shadow-sm flex items-center gap-1 ${
                      isCompared
                        ? 'bg-emerald-600 text-white'
                        : 'bg-black/60 hover:bg-black/80 text-stone-200 border border-stone-600'
                    }`}
                    title={t.compare}
                  >
                    <Scale className="w-3 h-3" />
                    <span>{isCompared ? '✓' : t.compare}</span>
                  </button>
                )}

                {onOpenVetConsult && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenVetConsult(item);
                    }}
                    className="py-1.5 px-2 bg-sky-600/90 hover:bg-sky-500 text-white rounded-lg text-xs font-bold cursor-pointer shadow-sm flex items-center gap-1"
                    title={language === 'uz' ? 'Veterinar maslahati' : 'Консультация ветеринара'}
                  >
                    <Stethoscope className="w-3.5 h-3.5" />
                  </button>
                )}

                {item.hasVideo && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenReelsForListing(item);
                    }}
                    className="py-1.5 px-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold cursor-pointer shadow-sm flex items-center gap-1"
                  >
                    <Play className="w-3 h-3 fill-current" />
                  </button>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
