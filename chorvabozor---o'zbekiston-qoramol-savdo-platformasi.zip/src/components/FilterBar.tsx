import React from 'react';
import { Language, UzbekistanRegion } from '../types';
import { translations } from '../translations';
import { Check, RotateCcw, LayoutGrid, Grid3X3, Play } from 'lucide-react';

interface FilterBarProps {
  language: Language;
  selectedRegion: string;
  onSelectRegion: (reg: string) => void;
  onlyVerified: boolean;
  onToggleOnlyVerified: () => void;
  onlyVet: boolean;
  onToggleOnlyVet: () => void;
  onlyVideo: boolean;
  onToggleOnlyVideo: () => void;
  onResetFilters: () => void;
  totalCount: number;
  viewMode: 'cards' | 'instagram' | 'reels';
  onViewModeChange: (mode: 'cards' | 'instagram' | 'reels') => void;
}

const regionsList: UzbekistanRegion[] = [
  'Toshkent shahri',
  'Toshkent viloyati',
  'Samarqand',
  'Andijon',
  'Fargʻona',
  'Namangan',
  'Qashqadaryo',
  'Surxondaryo',
  'Buxoro',
  'Xorazm',
  'Jizzax',
  'Sirdaryo',
  'Navoiy',
  'Qoraqalpogʻiston Respublikasi',
];

export const FilterBar: React.FC<FilterBarProps> = ({
  language,
  selectedRegion,
  onSelectRegion,
  onlyVerified,
  onToggleOnlyVerified,
  onlyVet,
  onToggleOnlyVet,
  onlyVideo,
  onToggleOnlyVideo,
  onResetFilters,
  totalCount,
  viewMode,
  onViewModeChange,
}) => {
  const t = translations[language];

  const hasActiveFilters =
    selectedRegion !== 'all' || onlyVerified || onlyVet || onlyVideo;

  return (
    <div className="bg-[#F7F9F6] dark:bg-[#061210] border-b border-[#E5ECE7] dark:border-[#0E3D32] py-3.5 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Left: Region Select & Checkbox toggles */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs sm:text-sm">
          {/* Region selector */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-xl px-2.5 py-1.5">
            <span className="text-stone-500 dark:text-stone-400 font-medium">{t.filterRegion}:</span>
            <select
              value={selectedRegion}
              onChange={(e) => onSelectRegion(e.target.value)}
              className="bg-transparent text-[#1C2A23] dark:text-white font-semibold focus:outline-none cursor-pointer"
            >
              <option value="all" className="dark:bg-[#041C16]">{t.filterAllRegions}</option>
              {regionsList.map((reg) => (
                <option key={reg} value={reg} className="dark:bg-[#041C16]">
                  {reg}
                </option>
              ))}
            </select>
          </div>

          {/* Quick filter checkboxes / buttons */}
          <button
            type="button"
            onClick={onToggleOnlyVerified}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              onlyVerified
                ? 'bg-[#064E3B]/10 dark:bg-[#072D24] border-[#047857] text-[#064E3B] dark:text-[#10B981] font-semibold'
                : 'bg-white dark:bg-[#072D24] border-[#E5ECE7] dark:border-[#0E3D32] text-stone-600 dark:text-stone-300 hover:border-[#047857]'
            }`}
          >
            <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${onlyVerified ? 'bg-[#047857] border-[#047857] text-white' : 'border-stone-400'}`}>
              {onlyVerified && <Check className="w-2.5 h-2.5 stroke-[3]" />}
            </span>
            <span>{t.filterOnlyVerified}</span>
          </button>

          <button
            type="button"
            onClick={onToggleOnlyVet}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              onlyVet
                ? 'bg-[#F59E0B]/10 dark:bg-[#072D24] border-[#F59E0B] text-[#D97706] dark:text-[#F59E0B] font-semibold'
                : 'bg-white dark:bg-[#072D24] border-[#E5ECE7] dark:border-[#0E3D32] text-stone-600 dark:text-stone-300 hover:border-[#F59E0B]'
            }`}
          >
            <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${onlyVet ? 'bg-[#F59E0B] border-[#F59E0B] text-white' : 'border-stone-400'}`}>
              {onlyVet && <Check className="w-2.5 h-2.5 stroke-[3]" />}
            </span>
            <span>{t.filterOnlyVet}</span>
          </button>

          <button
            type="button"
            onClick={onToggleOnlyVideo}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              onlyVideo
                ? 'bg-sky-50 dark:bg-[#072D24] border-sky-500 text-sky-900 dark:text-sky-300 font-semibold'
                : 'bg-white dark:bg-[#072D24] border-[#E5ECE7] dark:border-[#0E3D32] text-stone-600 dark:text-stone-300 hover:border-sky-400'
            }`}
          >
            <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${onlyVideo ? 'bg-sky-600 border-sky-600 text-white' : 'border-stone-400'}`}>
              {onlyVideo && <Check className="w-2.5 h-2.5 stroke-[3]" />}
            </span>
            <span>{t.filterOnlyVideo}</span>
          </button>
        </div>

        {/* Right: View Mode Switcher & Results Count */}
        <div className="flex items-center justify-between md:justify-end gap-3 text-xs text-stone-500 dark:text-stone-400">
          {/* View Mode Toggle: Cards vs Instagram Grid vs Reels */}
          <div className="inline-flex rounded-xl border border-[#E5ECE7] dark:border-[#0E3D32] bg-white dark:bg-[#072D24] p-0.5">
            <button
              type="button"
              onClick={() => onViewModeChange('cards')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
                viewMode === 'cards'
                  ? 'bg-[#047857] text-white shadow-xs font-bold'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
              title="Kardlar koʻrinishi"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Kardlar</span>
            </button>

            <button
              type="button"
              onClick={() => onViewModeChange('instagram')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
                viewMode === 'instagram'
                  ? 'bg-[#047857] text-white shadow-xs font-bold'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
              title="Instagram Grid koʻrinishi"
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Instagram Grid</span>
            </button>

            <button
              type="button"
              onClick={() => onViewModeChange('reels')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
                viewMode === 'reels'
                  ? 'bg-[#047857] text-white shadow-xs font-bold'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
              title="Dinamik Reels koʻrinishi"
            >
              <Play className="w-3.5 h-3.5 fill-current text-sky-400" />
              <span className="hidden sm:inline text-[11px]">Reels</span>
            </button>
          </div>

          <span className="font-medium text-stone-700 dark:text-stone-300">
            <strong className="text-emerald-900 dark:text-emerald-400 font-bold">{totalCount}</strong> {t.resultsCount}
          </span>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={onResetFilters}
              className="text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 flex items-center gap-1 cursor-pointer underline text-xs"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{t.filterReset}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
