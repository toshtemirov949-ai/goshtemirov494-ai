import React from 'react';
import { Home, Play, Plus, Sparkles, Gavel } from 'lucide-react';
import { Language } from '../types';

interface MobileBottomNavProps {
  language: Language;
  onGoHome: () => void;
  onOpenReels: () => void;
  onOpenAddListing: () => void;
  onOpenQurbonlik: () => void;
  onOpenAuctions: () => void;
  onOpenPromo?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  language,
  onGoHome,
  onOpenReels,
  onOpenAddListing,
  onOpenQurbonlik,
  onOpenAuctions,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-[#F7F9F6]/95 dark:bg-[#061210]/95 backdrop-blur-lg border-t border-[#E5ECE7] dark:border-[#0E3D32] shadow-2xl px-2 py-1.5 transition-colors">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* 1. Katalog / Asosiy */}
        <button
          type="button"
          onClick={onGoHome}
          className="flex flex-col items-center justify-center p-1 text-[#1C2A23] dark:text-stone-300 hover:text-[#047857] dark:hover:text-[#10B981] cursor-pointer transition-colors"
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-bold">
            {language === 'uz' ? 'Asosiy' : 'Главная'}
          </span>
        </button>

        {/* 2. Reels Video */}
        <button
          type="button"
          onClick={onOpenReels}
          className="flex flex-col items-center justify-center p-1 text-[#1C2A23] dark:text-stone-300 hover:text-[#047857] dark:hover:text-[#10B981] cursor-pointer transition-colors"
        >
          <Play className="w-5 h-5 mb-0.5 fill-current text-[#047857] dark:text-[#10B981]" />
          <span className="text-[10px] font-bold">Reels</span>
        </button>

        {/* 3. Markaziy Katta Tugma: + E'lon (Accent Gold) */}
        <button
          type="button"
          onClick={onOpenAddListing}
          className="flex flex-col items-center justify-center -mt-4 cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#D97706] to-[#F59E0B] group-hover:from-[#B45309] group-hover:to-[#D97706] text-white flex items-center justify-center shadow-lg shadow-[#F59E0B]/30 ring-4 ring-[#F7F9F6] dark:ring-[#061210] transition-transform active:scale-95">
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </div>
          <span className="text-[10px] font-black text-[#D97706] dark:text-[#F59E0B] mt-0.5">
            {language === 'uz' ? 'Eʼlon' : 'Подать'}
          </span>
        </button>

        {/* 4. Qurbonlik 2026 */}
        <button
          type="button"
          onClick={onOpenQurbonlik}
          className="flex flex-col items-center justify-center p-1 text-amber-700 dark:text-amber-400 cursor-pointer transition-colors"
        >
          <span className="text-lg leading-none mb-0.5">🌙</span>
          <span className="text-[10px] font-bold">Qurbonlik</span>
        </button>

        {/* 5. Jonli Auksion */}
        <button
          type="button"
          onClick={onOpenAuctions}
          className="flex flex-col items-center justify-center p-1 text-stone-600 dark:text-stone-300 hover:text-emerald-800 dark:hover:text-emerald-400 cursor-pointer transition-colors"
        >
          <Gavel className="w-5 h-5 mb-0.5 text-amber-500" />
          <span className="text-[10px] font-bold">
            {language === 'uz' ? 'Auksion' : 'Аукцион'}
          </span>
        </button>
      </div>
    </nav>
  );
};
