import React, { useState, useMemo } from 'react';
import { LivestockItem, Language } from '../types';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  LayoutDashboard,
  FileCheck,
  Gavel,
  Truck,
  Users,
  TrendingUp,
  CreditCard,
  Settings,
  LogOut,
  Plus,
  CheckCircle2,
  XCircle,
  Search,
  RefreshCw,
  Download,
  Activity,
  Server,
  AlertTriangle,
  Clock,
  Eye,
  Trash2,
  Sparkles,
  Award,
  Stethoscope,
  ChevronRight,
  Filter,
  DollarSign,
  Flame,
  Layers,
  Sun,
  Moon,
  Play,
  Pause,
  RotateCcw,
  MapPin,
  Phone,
  FileText,
  Check,
  X,
  ExternalLink
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';

export interface AdminDashboardModalProps {
  language: Language;
  onClose: () => void;
  items: LivestockItem[];
  onUpdateItems: React.Dispatch<React.SetStateAction<LivestockItem[]>>;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  onLanguageChange?: (lang: Language) => void;
}

// Moderatsiya uchun navbatdagi fermer e'lonlari
interface PendingModeration {
  id: string;
  titleUz: string;
  titleRu: string;
  department: 'qoramol' | 'quy' | 'ot';
  breed: string;
  weightKg: number;
  priceUzs: number;
  region: string;
  district: string;
  sellerName: string;
  sellerPhone: string;
  vetPassportNumber: string;
  imageUrl: string;
  hasVideo: boolean;
  submittedAt: string;
  aiScore: number;
  aiFlag: 'OK' | 'SUSPICIOUS_PRICE' | 'WRONG_BREED' | 'DOCUMENT_BLURRY' | 'HIGH_DEMAND';
  aiNotesUz: string;
  aiNotesRu: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  rejectReason?: string;
}

// Veterinariya & Qurbonlik reyestri
interface VetRegistryItem {
  id: string;
  tagNumber: string;
  passportId: string;
  animalType: string;
  breed: string;
  ownerName: string;
  region: string;
  district: string;
  vetDoctorName: string;
  lastVaccineDate: string;
  vaccines: { name: string; date: string; status: 'ok' | 'needed' }[];
  isQurbonlikCandidate: boolean;
  qurbonlikStatus: 'CERTIFIED' | 'PENDING_CHECK' | 'DISQUALIFIED';
  qurbonlikChecks: {
    ageValid: boolean;
    teethHealthy: boolean;
    hornsAndTailIntact: boolean;
    eyesClear: boolean;
    noLimping: boolean;
  };
  weightKg: number;
  ageMonths: number;
}

// Auksion boshqaruvi
interface AdminAuctionControl {
  id: string;
  titleUz: string;
  titleRu: string;
  breed: string;
  startingPrice: number;
  currentBid: number;
  minStep: number;
  bidsCount: number;
  timeLeftMinutes: number;
  status: 'ACTIVE' | 'PAUSED' | 'COMPLETED';
  imageUrl: string;
  sellerName: string;
  leadingBidder: string;
  bids: { id: string; user: string; region: string; amount: number; time: string }[];
}

// Fura va transport buyurtmalari
interface TransportOrder {
  id: string;
  driverName: string;
  driverPhone: string;
  vehicleType: string; // Isuzu, Gazel, MAN
  capacityHeads: number;
  fromRegion: string;
  toRegion: string;
  distanceKm: number;
  priceUzs: number;
  status: 'ASSIGNED' | 'IN_TRANSIT' | 'DELIVERED';
  animalCount: number;
  cargoDescription: string;
  clientName: string;
}

// Eskrou bitimlari
interface EscrowDeal {
  id: string;
  orderNumber: string;
  buyerName: string;
  buyerPhone: string;
  sellerName: string;
  sellerPhone: string;
  animalTitle: string;
  amountUzs: number;
  feeUzs: number;
  sellerPayoutUzs: number;
  status: 'HELD' | 'IN_TRANSIT' | 'DELIVERED' | 'RELEASED' | 'DISPUTED';
  route: string;
  date: string;
}

// Fermer va foydalanuvchilar
interface PlatformUser {
  id: string;
  name: string;
  role: 'Fermer' | 'Veterinar' | 'Yirik Xaridor' | 'Logist';
  region: string;
  phone: string;
  dealsCount: number;
  rating: number;
  verified: boolean;
  status: 'ACTIVE' | 'BLOCKED' | 'PENDING_VERIFY';
  registeredDate: string;
  farmName?: string;
}

// Fermer xoʻjaliklari (Fermalar)
export interface PlatformFarm {
  id: string;
  name: string;
  ownerName: string;
  region: string;
  district: string;
  livestockCount: number;
  specialization: 'Sut yoʻnalishi' | 'Goʻsht yoʻnalishi' | 'Naslchilik' | 'Qoʻychilik' | 'Yilqichilik';
  phone: string;
  vetSupervision: boolean;
  status: 'ACTIVE' | 'PENDING' | 'SUSPENDED';
  registeredDate: string;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  language,
  onClose,
  items,
  onUpdateItems,
  isDarkMode = false,
  onToggleDarkMode,
  onLanguageChange
}) => {
  const [activeMenu, setActiveMenu] = useState<'dashboard' | 'listings' | 'vet' | 'auctions' | 'transport' | 'users' | 'analytics' | 'escrow'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [internalDarkMode, setInternalDarkMode] = useState(isDarkMode);
  const [internalLang, setInternalLang] = useState<Language>(language);
  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  // Sub-tab for listings moderation
  const [listingsSubTab, setListingsSubTab] = useState<'pending' | 'active_marketplace' | 'rejected'>('pending');

  // Trigger brief alert
  const showToast = (msg: string) => {
    setNotificationToast(msg);
    setTimeout(() => setNotificationToast(null), 3000);
  };

  // Switch dark mode locally and propagate
  const handleToggleTheme = () => {
    if (onToggleDarkMode) {
      onToggleDarkMode();
    } else {
      setInternalDarkMode(!internalDarkMode);
    }
  };

  const currentThemeDark = onToggleDarkMode ? isDarkMode : internalDarkMode;

  // Language switch
  const handleSwitchLanguage = (lang: Language) => {
    setInternalLang(lang);
    if (onLanguageChange) {
      onLanguageChange(lang);
    }
  };

  const isUz = internalLang === 'uz';

  // 1. Pending Moderation Listings Data
  const [pendingListings, setPendingListings] = useState<PendingModeration[]>([
    {
      id: 'MOD-8801',
      titleUz: 'Golshtin Friesian 2-qorin sogʻin sigir (kuniga 28L sut)',
      titleRu: 'Голштинская корова 2-го отела (28 л молока в день)',
      department: 'qoramol',
      breed: 'Golshtin (Holstein)',
      weightKg: 620,
      priceUzs: 32000000,
      region: 'Samarqand',
      district: 'Pastdargʻom',
      sellerName: 'Karimov Shuhrat FM',
      sellerPhone: '+998 90 234-56-78',
      vetPassportNumber: 'UZ-VET-77821-SAM',
      imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
      hasVideo: true,
      submittedAt: 'Bugun, 09:42',
      aiScore: 96,
      aiFlag: 'HIGH_DEMAND',
      aiNotesUz: '✅ Rasm va zot tavsifi 98% mos. Narx Samarqand bozori bilan uygʻun. Video haqiqiy fermada olingan.',
      aiNotesRu: '✅ Описание и фото соответствуют на 98%. Цена адекватна рынку. Видео подлинное.',
      status: 'PENDING'
    },
    {
      id: 'MOD-8802',
      titleUz: 'Hisor zotli 1.5 yashar urugʻlik qoʻchqor (125 kg)',
      titleRu: 'Гиссарский 1.5-годовалый племенной баран (125 кг)',
      department: 'quy',
      breed: 'Hisor qoʻylari',
      weightKg: 125,
      priceUzs: 8500000,
      region: 'Qashqadaryo',
      district: 'Dehqonobod',
      sellerName: 'Zokir Chorvador',
      sellerPhone: '+998 97 112-33-44',
      vetPassportNumber: 'UZ-VET-44910-QASH',
      imageUrl: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
      hasVideo: false,
      submittedAt: 'Bugun, 08:15',
      aiScore: 92,
      aiFlag: 'OK',
      aiNotesUz: '✅ Zot sifatlari aʼlo. Qurbonlik talablariga mos (yoshi 1 yoshdan katta, tishlari sogʻlom).',
      aiNotesRu: '✅ Признаки отличные. Подходит под Курбанлык (возраст более 1 года, здоров).',
      status: 'PENDING'
    },
    {
      id: 'MOD-8803',
      titleUz: 'Shveysar (Shvis) zotli goʻshtdor buqa (semiz)',
      titleRu: 'Швиц мясной откормленный бык (упитанный)',
      department: 'qoramol',
      breed: 'Shvis (Brown Swiss)',
      weightKg: 580,
      priceUzs: 16000000,
      region: 'Andijon',
      district: 'Asaka',
      sellerName: 'Bekzod Aliyev',
      sellerPhone: '+998 93 456-78-90',
      vetPassportNumber: 'UZ-VET-11204-AND',
      imageUrl: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&w=800&q=80',
      hasVideo: true,
      submittedAt: 'Kecha, 22:30',
      aiScore: 54,
      aiFlag: 'SUSPICIOUS_PRICE',
      aiNotesUz: '⚠️ Diqqat: 580 kg vazn uchun 16,000,000 soʻm nihoyatda past (bozordan -45%). Dallol yoki notoʻgʻri vazn shubhasi!',
      aiNotesRu: '⚠️ Внимание: Для 580 кг цена 16 млн слишком занижена (-45% от рынка). Возможно мошенничество!',
      status: 'PENDING'
    },
    {
      id: 'MOD-8804',
      titleUz: 'Qorabayir zotli 4 yoshli uloqchi chopqir aygʻir',
      titleRu: 'Карабаирский 4-летний жеребец (скакун)',
      department: 'ot',
      breed: 'Qorabayir oti',
      weightKg: 490,
      priceUzs: 45000000,
      region: 'Jizzax',
      district: 'Baxmal',
      sellerName: 'Umar Polvon',
      sellerPhone: '+998 94 332-11-00',
      vetPassportNumber: 'UZ-VET-99321-JIZ',
      imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
      hasVideo: true,
      submittedAt: 'Bugun, 07:10',
      aiScore: 98,
      aiFlag: 'HIGH_DEMAND',
      aiNotesUz: '✅ Pasport tekshirildi: Uloqchi zot sertifikati tasdiqlangan. Emlashlar toʻliq.',
      aiNotesRu: '✅ Паспорт проверен: Сертификат породы подтвержден. Все прививки пройдены.',
      status: 'PENDING'
    }
  ]);

  // Reject reason modal state
  const [rejectModalItem, setRejectModalItem] = useState<PendingModeration | null>(null);
  const [rejectReasonText, setRejectReasonText] = useState('Shubhali narx yoki notoʻgʻri parametrlar');

  // 2. Veterinary Registry State
  const [vetRegistry, setVetRegistry] = useState<VetRegistryItem[]>([
    {
      id: 'VET-001',
      tagNumber: 'UZ-TAG-99214',
      passportId: 'UZ-VET-77821-SAM',
      animalType: 'Qoramol (Sigir)',
      breed: 'Golshtin',
      ownerName: 'Karimov Shuhrat',
      region: 'Samarqand',
      district: 'Pastdargʻom',
      vetDoctorName: 'Dr. Ahmadillo Raximov',
      lastVaccineDate: '2026-03-12',
      vaccines: [
        { name: 'Kuydirgi (Sibirskaya yazva)', date: '2026-03-12', status: 'ok' },
        { name: 'Oqsil (Yashshur)', date: '2026-02-18', status: 'ok' },
        { name: 'Qorason (Emkar)', date: '2026-01-10', status: 'ok' },
        { name: 'Brutsellyoz', date: '2025-11-05', status: 'ok' }
      ],
      isQurbonlikCandidate: true,
      qurbonlikStatus: 'CERTIFIED',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: true,
        eyesClear: true,
        noLimping: true
      },
      weightKg: 620,
      ageMonths: 28
    },
    {
      id: 'VET-002',
      tagNumber: 'UZ-TAG-44102',
      passportId: 'UZ-VET-44910-QASH',
      animalType: 'Qoʻy (Qoʻchqor)',
      breed: 'Hisor',
      ownerName: 'Zokir Chorvador',
      region: 'Qashqadaryo',
      district: 'Dehqonobod',
      vetDoctorName: 'Dr. Otabek Nazarov',
      lastVaccineDate: '2026-03-25',
      vaccines: [
        { name: 'Kuydirgi', date: '2026-03-25', status: 'ok' },
        { name: 'Oqsil', date: '2026-02-10', status: 'ok' },
        { name: 'Chechak (Ospa ovet)', date: '2026-01-15', status: 'ok' }
      ],
      isQurbonlikCandidate: true,
      qurbonlikStatus: 'CERTIFIED',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: true,
        eyesClear: true,
        noLimping: true
      },
      weightKg: 125,
      ageMonths: 18
    },
    {
      id: 'VET-003',
      tagNumber: 'UZ-TAG-11983',
      passportId: 'UZ-VET-11204-AND',
      animalType: 'Qoramol (Buqa)',
      breed: 'Shvis',
      ownerName: 'Bekzod Aliyev',
      region: 'Andijon',
      district: 'Asaka',
      vetDoctorName: 'Dr. Murod Xolmatov',
      lastVaccineDate: '2025-10-14',
      vaccines: [
        { name: 'Kuydirgi', date: '2025-10-14', status: 'needed' },
        { name: 'Oqsil', date: '2026-02-01', status: 'ok' }
      ],
      isQurbonlikCandidate: false,
      qurbonlikStatus: 'PENDING_CHECK',
      qurbonlikChecks: {
        ageValid: true,
        teethHealthy: true,
        hornsAndTailIntact: false,
        eyesClear: true,
        noLimping: true
      },
      weightKg: 580,
      ageMonths: 24
    },
    {
      id: 'VET-004',
      tagNumber: 'UZ-TAG-88231',
      passportId: 'UZ-VET-88310-BUX',
      animalType: 'Qoʻy (Qoʻzi)',
      breed: 'Qorakoʻl',
      ownerName: 'Erkin Rahmonov',
      region: 'Buxoro',
      district: 'Gʻijduvon',
      vetDoctorName: 'Dr. Sanjar Saidov',
      lastVaccineDate: '2026-03-01',
      vaccines: [
        { name: 'Kuydirgi', date: '2026-03-01', status: 'ok' },
        { name: 'Oqsil', date: '2026-02-15', status: 'ok' }
      ],
      isQurbonlikCandidate: false,
      qurbonlikStatus: 'DISQUALIFIED',
      qurbonlikChecks: {
        ageValid: false, // Yoshi 8 oylik - qurbonlik talabiga yetmagan
        teethHealthy: true,
        hornsAndTailIntact: true,
        eyesClear: true,
        noLimping: true
      },
      weightKg: 42,
      ageMonths: 8
    }
  ]);

  // 3. Live Auctions Control State
  const [auctions, setAuctions] = useState<AdminAuctionControl[]>([
    {
      id: 'AUC-101',
      titleUz: 'Golshtin zotli 8 oylik urugʻlik buqacha (Elita nasl)',
      titleRu: 'Племенной бычок породы Голштин 8 месяцев (Элита)',
      breed: 'Golshtin Friesian',
      startingPrice: 11000000,
      currentBid: 13200000,
      minStep: 300000,
      bidsCount: 7,
      timeLeftMinutes: 24,
      status: 'ACTIVE',
      imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
      sellerName: 'Toshkent Agro Sut FM',
      leadingBidder: 'Shuxrat B. (Samarqand)',
      bids: [
        { id: 'b1', user: 'Shuxrat B.', region: 'Samarqand', amount: 13200000, time: '2 daq oldin' },
        { id: 'b2', user: 'Farrux A.', region: 'Fargʻona', amount: 12900000, time: '14 daq oldin' },
        { id: 'b3', user: 'Nodirbek', region: 'Toshkent', amount: 12600000, time: '40 daq oldin' }
      ]
    },
    {
      id: 'AUC-102',
      titleUz: 'Hisor zotli bahaybat rekord qoʻchqor (150 kg)',
      titleRu: 'Гиссарский баран-великан (150 кг)',
      breed: 'Hisor qoʻylari',
      startingPrice: 7500000,
      currentBid: 8900000,
      minStep: 200000,
      bidsCount: 9,
      timeLeftMinutes: 12,
      status: 'ACTIVE',
      imageUrl: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
      sellerName: 'Hisor Nasl Buloq FM',
      leadingBidder: 'Umarxon K. (Buxoro)',
      bids: [
        { id: 'b21', user: 'Umarxon K.', region: 'Buxoro', amount: 8900000, time: '5 daq oldin' },
        { id: 'b22', user: 'Jahongir', region: 'Navoiy', amount: 8700000, time: '21 daq oldin' }
      ]
    },
    {
      id: 'AUC-103',
      titleUz: 'Qorabayir zotli 4 yoshli uloqchi chopqir aygʻir',
      titleRu: 'Карабаирский 4-летний скаковой жеребец',
      breed: 'Qorabayir oti',
      startingPrice: 35000000,
      currentBid: 42000000,
      minStep: 500000,
      bidsCount: 14,
      timeLeftMinutes: 45,
      status: 'ACTIVE',
      imageUrl: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
      sellerName: 'Baxmal Naslli Otlar',
      leadingBidder: 'Sobir Polvon (Toshkent)',
      bids: [
        { id: 'b31', user: 'Sobir Polvon', region: 'Toshkent', amount: 42000000, time: '1 daq oldin' },
        { id: 'b32', user: 'Anvarjon', region: 'Surxondaryo', amount: 41500000, time: '8 daq oldin' }
      ]
    }
  ]);

  // 4. Transport & Logistics Orders
  const [transportOrders, setTransportOrders] = useState<TransportOrder[]>([
    {
      id: 'TR-701',
      driverName: 'Rustam Qodirov',
      driverPhone: '+998 90 123-45-67',
      vehicleType: 'Isuzu Qoramol tashuvchi (2 yarus)',
      capacityHeads: 8,
      fromRegion: 'Samarqand (Pastdargʻom)',
      toRegion: 'Toshkent viloyati (Zangiota)',
      distanceKm: 310,
      priceUzs: 2450000,
      status: 'IN_TRANSIT',
      animalCount: 6,
      cargoDescription: '6 bosh Golshtin sigirlar (Eskrou #ESK-901)',
      clientName: 'Shuxrat Karimov'
    },
    {
      id: 'TR-702',
      driverName: 'Ilhom Joʻrayev',
      driverPhone: '+998 93 987-65-43',
      vehicleType: 'Gazel NEXT Qoʻy tashuvchi',
      capacityHeads: 25,
      fromRegion: 'Qashqadaryo (Dehqonobod)',
      toRegion: 'Buxoro (Gʻijduvon)',
      distanceKm: 270,
      priceUzs: 1850000,
      status: 'IN_TRANSIT',
      animalCount: 18,
      cargoDescription: '18 bosh Hisor sovliq va qoʻchqorlar',
      clientName: 'Zokir Chorvador'
    },
    {
      id: 'TR-703',
      driverName: 'Mansur Aliyev',
      driverPhone: '+998 94 444-22-11',
      vehicleType: 'MAN 3-yarusli Chorva Fura',
      capacityHeads: 40,
      fromRegion: 'Surxondaryo (Denov)',
      toRegion: 'Toshkent shahar (Sergeli)',
      distanceKm: 680,
      priceUzs: 6200000,
      status: 'ASSIGNED',
      animalCount: 32,
      cargoDescription: '32 bosh Shvis buqalar (Bordiq)',
      clientName: 'Agro Savdo Eksport MCHJ'
    }
  ]);

  // 5. Escrow Transactions
  const [escrowDeals, setEscrowDeals] = useState<EscrowDeal[]>([
    {
      id: 'ESK-901',
      orderNumber: 'CB-ESC-2026-0901',
      buyerName: 'Jamshid Toʻxtayev',
      buyerPhone: '+998 90 555-44-33',
      sellerName: 'Karimov Shuhrat FM',
      sellerPhone: '+998 90 234-56-78',
      animalTitle: 'Golshtin Friesian 2-qorin sigir',
      amountUzs: 32000000,
      feeUzs: 480000, // 1.5%
      sellerPayoutUzs: 31520000,
      status: 'IN_TRANSIT',
      route: 'Samarqand -> Toshkent',
      date: '2026-03-29'
    },
    {
      id: 'ESK-902',
      orderNumber: 'CB-ESC-2026-0902',
      buyerName: 'Alisher Qodirov',
      buyerPhone: '+998 91 111-22-33',
      sellerName: 'Zokir Chorvador',
      sellerPhone: '+998 97 112-33-44',
      animalTitle: 'Hisor zotli urugʻlik qoʻchqor (125 kg)',
      amountUzs: 8500000,
      feeUzs: 127500, // 1.5%
      sellerPayoutUzs: 8372500,
      status: 'DELIVERED',
      route: 'Qashqadaryo -> Toshkent',
      date: '2026-03-28'
    },
    {
      id: 'ESK-903',
      orderNumber: 'CB-ESC-2026-0903',
      buyerName: 'Botir Rahimov',
      buyerPhone: '+998 93 777-88-99',
      sellerName: 'Baxmal Naslli Otlar',
      sellerPhone: '+998 94 332-11-00',
      animalTitle: 'Qorabayir 4 yoshli uloqchi chopqir',
      amountUzs: 42000000,
      feeUzs: 630000, // 1.5%
      sellerPayoutUzs: 41370000,
      status: 'HELD',
      route: 'Jizzax -> Fargʻona',
      date: '2026-03-29'
    },
    {
      id: 'ESK-904',
      orderNumber: 'CB-ESC-2026-0904',
      buyerName: 'Murodbek Umarov',
      buyerPhone: '+998 99 333-22-11',
      sellerName: 'Bekzod Aliyev',
      sellerPhone: '+998 93 456-78-90',
      animalTitle: 'Shvis zotli goʻshtdor buqa',
      amountUzs: 24000000,
      feeUzs: 360000,
      sellerPayoutUzs: 23640000,
      status: 'RELEASED',
      route: 'Andijon -> Namangan',
      date: '2026-03-27'
    }
  ]);

  // 6. Platform Users
  const [platformUsers, setPlatformUsers] = useState<PlatformUser[]>([
    {
      id: 'USR-101',
      name: 'Karimov Shuhrat',
      role: 'Fermer',
      region: 'Samarqand viloyati',
      phone: '+998 90 234-56-78',
      dealsCount: 42,
      rating: 4.95,
      verified: true,
      status: 'ACTIVE',
      registeredDate: '2024-11-10'
    },
    {
      id: 'USR-102',
      name: 'Dr. Ahmadillo Raximov',
      role: 'Veterinar',
      region: 'Samarqand viloyati',
      phone: '+998 91 888-99-00',
      dealsCount: 168,
      rating: 5.0,
      verified: true,
      status: 'ACTIVE',
      registeredDate: '2024-08-15'
    },
    {
      id: 'USR-103',
      name: 'Zokir Chorvador',
      role: 'Fermer',
      region: 'Qashqadaryo viloyati',
      phone: '+998 97 112-33-44',
      dealsCount: 65,
      rating: 4.88,
      verified: true,
      status: 'ACTIVE',
      registeredDate: '2025-01-20'
    },
    {
      id: 'USR-104',
      name: 'Rustam Qodirov',
      role: 'Logist',
      region: 'Toshkent viloyati',
      phone: '+998 90 123-45-67',
      dealsCount: 92,
      rating: 4.92,
      verified: true,
      status: 'ACTIVE',
      registeredDate: '2025-02-01'
    },
    {
      id: 'USR-105',
      name: 'Dallolbek Shubhali',
      role: 'Yirik Xaridor',
      region: 'Andijon viloyati',
      phone: '+998 90 000-00-00',
      dealsCount: 1,
      rating: 2.1,
      verified: false,
      status: 'BLOCKED',
      registeredDate: '2026-03-10'
    }
  ]);

  // 7. Platform Farms (Fermer xoʻjaliklari)
  const [farms, setFarms] = useState<PlatformFarm[]>([
    {
      id: 'FRM-201',
      name: 'Toshkent Agro Sut FM',
      ownerName: 'Shuxrat Karimov',
      region: 'Toshkent viloyati',
      district: 'Zangiota tumani',
      livestockCount: 145,
      specialization: 'Sut yoʻnalishi',
      phone: '+998 90 234-56-78',
      vetSupervision: true,
      status: 'ACTIVE',
      registeredDate: '2024-05-12'
    },
    {
      id: 'FRM-202',
      name: 'Hisor Nasl Buloq FM',
      ownerName: 'Zokir Chorvador',
      region: 'Qashqadaryo',
      district: 'Dehqonobod tumani',
      livestockCount: 520,
      specialization: 'Qoʻychilik',
      phone: '+998 97 112-33-44',
      vetSupervision: true,
      status: 'ACTIVE',
      registeredDate: '2024-09-18'
    },
    {
      id: 'FRM-203',
      name: 'Baxmal Naslli Otlar FM',
      ownerName: 'Mansur Polvon',
      region: 'Jizzax',
      district: 'Baxmal tumani',
      livestockCount: 48,
      specialization: 'Yilqichilik',
      phone: '+998 94 332-11-00',
      vetSupervision: true,
      status: 'ACTIVE',
      registeredDate: '2025-01-15'
    },
    {
      id: 'FRM-204',
      name: 'Samarqand Goʻshtdor Qoramol MCHJ',
      ownerName: 'Farrux Aliyev',
      region: 'Samarqand',
      district: 'Pastdargʻom tumani',
      livestockCount: 280,
      specialization: 'Goʻsht yoʻnalishi',
      phone: '+998 93 789-01-23',
      vetSupervision: true,
      status: 'ACTIVE',
      registeredDate: '2025-03-01'
    },
    {
      id: 'FRM-205',
      name: 'Vodiy Nasl Zoti FM',
      ownerName: 'Akromjon Saidov',
      region: 'Fargʻona',
      district: 'Quva tumani',
      livestockCount: 190,
      specialization: 'Naslchilik',
      phone: '+998 91 654-32-10',
      vetSupervision: true,
      status: 'ACTIVE',
      registeredDate: '2025-06-20'
    }
  ]);

  // Subtab for 06. Fermerlar & Fermalar
  const [usersSubTab, setUsersSubTab] = useState<'farmers' | 'farms'>('farmers');

  // Admin interactive management modals
  const [isAddListingOpen, setIsAddListingOpen] = useState(false);
  const [isAddFarmOpen, setIsAddFarmOpen] = useState(false);
  const [isAddFarmerOpen, setIsAddFarmerOpen] = useState(false);

  // Forms state
  const [adminListingForm, setAdminListingForm] = useState({
    titleUz: '',
    titleRu: '',
    department: 'qoramol' as 'qoramol' | 'quy' | 'ot',
    breed: 'Golshtin (Holstein)',
    gender: 'sigir' as any,
    weightKg: 520,
    priceUzs: 25000000,
    region: 'Samarqand',
    district: 'Pastdargʻom tumani',
    sellerName: 'Karimov Shuhrat FM',
    sellerPhone: '+998 90 234-56-78',
    hasVetPassport: true,
    passportNumber: 'UZ-VET-2026-9011',
    imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80'
  });

  const [adminFarmForm, setAdminFarmForm] = useState({
    name: '',
    ownerName: '',
    region: 'Samarqand',
    district: 'Pastdargʻom tumani',
    livestockCount: 60,
    specialization: 'Sut yoʻnalishi' as 'Sut yoʻnalishi' | 'Goʻsht yoʻnalishi' | 'Naslchilik' | 'Qoʻychilik' | 'Yilqichilik',
    phone: '+998 90 123-45-67',
    vetSupervision: true
  });

  const [adminFarmerForm, setAdminFarmerForm] = useState({
    name: '',
    phone: '+998 90 123-45-67',
    region: 'Samarqand',
    district: 'Pastdargʻom tumani',
    role: 'Fermer' as 'Fermer' | 'Veterinar' | 'Yirik Xaridor' | 'Logist',
    farmName: 'Samarqand Chorva FM',
    verified: true
  });

  // Regional Price Index Data (14 Regions of Uzbekistan)
  const regionPriceIndex = useMemo(() => [
    { region: 'Toshkent sh.', qoramolKg: 56500, quyKg: 64000, change: '+2.1%' },
    { region: 'Toshkent v.', qoramolKg: 55000, quyKg: 62500, change: '+1.8%' },
    { region: 'Samarqand', qoramolKg: 53500, quyKg: 63000, change: '+2.4%' },
    { region: 'Fargʻona', qoramolKg: 54000, quyKg: 61000, change: '+1.5%' },
    { region: 'Andijon', qoramolKg: 54500, quyKg: 62000, change: '+1.9%' },
    { region: 'Namangan', qoramolKg: 53000, quyKg: 60500, change: '+1.2%' },
    { region: 'Qashqadaryo', qoramolKg: 51500, quyKg: 65000, change: '+3.1%' },
    { region: 'Surxondaryo', qoramolKg: 51000, quyKg: 63500, change: '+2.0%' },
    { region: 'Buxoro', qoramolKg: 52000, quyKg: 62000, change: '+1.6%' },
    { region: 'Xorazm', qoramolKg: 50500, quyKg: 59000, change: '+0.9%' },
    { region: 'Navoiy', qoramolKg: 51200, quyKg: 61500, change: '+1.4%' },
    { region: 'Jizzax', qoramolKg: 52500, quyKg: 62800, change: '+2.2%' },
    { region: 'Sirdaryo', qoramolKg: 53000, quyKg: 61200, change: '+1.7%' },
    { region: 'Qoraqalpogʻiston', qoramolKg: 48500, quyKg: 57500, change: '+0.8%' },
  ], []);

  // 6-Month Breed Price Dynamic Data
  const breedMonthlyData = useMemo(() => [
    { month: 'Okt', golshtin: 48, hisor: 56, qorabayir: 42, shvis: 46 },
    { month: 'Noy', golshtin: 49, hisor: 58, qorabayir: 43, shvis: 47 },
    { month: 'Dek', golshtin: 51, hisor: 60, qorabayir: 44, shvis: 49 },
    { month: 'Yan', golshtin: 52, hisor: 61, qorabayir: 45, shvis: 50 },
    { month: 'Fev', golshtin: 53, hisor: 63, qorabayir: 46, shvis: 52 },
    { month: 'Mar', golshtin: 54.5, hisor: 65, qorabayir: 48, shvis: 53.5 }
  ], []);

  // Real-time KPI Calculations
  const totalMarketplaceListings = items.length;
  const qoramolCount = items.filter(i => i.department === 'qoramol').length;
  const quyCount = items.filter(i => i.department === 'quy').length;
  const otCount = items.filter(i => i.department === 'ot').length;

  const verifiedVetCount = items.filter((i) => i.vetInfo?.hasVetPassport).length || vetRegistry.length;
  const totalEscrowVolume = escrowDeals.reduce((acc, curr) => acc + curr.amountUzs, 0);
  const platformCommission1_5 = Math.round(totalEscrowVolume * 0.015);
  const activeTransportCount = transportOrders.filter(t => t.status === 'IN_TRANSIT').length;
  const certifiedQurbonlikCount = vetRegistry.filter(v => v.qurbonlikStatus === 'CERTIFIED').length;
  const pendingModerationCount = pendingListings.filter(l => l.status === 'PENDING').length;

  // Moderation: Approve Action
  const handleApproveListing = (listing: PendingModeration) => {
    // 1. Update pending status
    setPendingListings(prev =>
      prev.map(item => item.id === listing.id ? { ...item, status: 'APPROVED' } : item)
    );

    // 2. Add into active marketplace items
    const newMarketplaceItem: LivestockItem = {
      id: `live-${listing.id}-${Date.now()}`,
      department: listing.department,
      category: listing.department === 'qoramol' ? 'beef' : listing.department === 'quy' ? 'sheep' : 'horses',
      breed: listing.breed,
      breedKey: listing.breed.toLowerCase().replace(/[^a-z]/g, '_') || 'golshtin',
      gender: listing.department === 'qoramol' ? 'sigir' : listing.department === 'quy' ? 'qoʻchqor' : 'aygʻir',
      titleUz: listing.titleUz,
      titleRu: listing.titleRu,
      descriptionUz: `${listing.breed} zotli sogʻlom chorva moli. AI Moderatsiyadan 96% muvaffaqiyatli oʻtgan. Davlat vet pasporti mavjud.`,
      descriptionRu: `${listing.breed}. Проверен AI Модерацией на 96%. Имеется ветпаспорт.`,
      priceUzs: listing.priceUzs,
      weightKg: listing.weightKg,
      ageMonths: 24,
      region: (listing.region as any) || 'Samarqand',
      district: listing.district,
      imageUrl: listing.imageUrl,
      additionalImages: [],
      hasVideo: listing.hasVideo,
      isVerifiedSeller: true,
      isEscrowSupported: true,
      isDeliveryAvailable: true,
      isQurbonlikFit: listing.department !== 'ot',
      qurbonlikConditionsMet: listing.department !== 'ot',
      viewsCount: 142,
      likesCount: 18,
      createdAt: new Date().toISOString(),
      seller: {
        id: `sel-${listing.id}`,
        name: listing.sellerName,
        farmName: `${listing.sellerName} FM`,
        phone: listing.sellerPhone,
        telegramUsername: '@chorvabozor_admin',
        region: (listing.region as any) || 'Samarqand',
        district: listing.district,
        isPassportVerified: true,
        isPhoneVerified: true,
        rating: 4.9,
        dealsCompleted: 15,
        memberSince: '2025-01-10',
        badge: 'Fermer xoʻjaligi'
      },
      vetInfo: {
        id: `vet-${listing.id}`,
        hasVetPassport: true,
        passportNumber: listing.vetPassportNumber,
        issuedDate: new Date().toISOString().split('T')[0],
        veterinarianName: 'Davlat Veterinariya Xizmati',
        districtVetClinic: `${listing.district} Vet Markazi`,
        vaccinatedFor: [
          { nameUz: 'Kuydirgi', nameRu: 'Сибирская язва', date: '2026-03-01', isImmune: true },
          { nameUz: 'Oqsil', nameRu: 'Ящур', date: '2026-02-15', isImmune: true }
        ],
        healthNotes: 'Sogʻlom, AI va shifokor tomonidan tekshirilgan',
        status: 'verified'
      }
    };

    onUpdateItems(prev => [newMarketplaceItem, ...prev]);
    showToast(isUz ? `✅ "${listing.titleUz}" tasdiqlandi va platformaga joylandi!` : `✅ Объявление одобрено и опубликовано!`);
  };

  // Moderation: Open Reject Dialog
  const handleOpenRejectModal = (listing: PendingModeration) => {
    setRejectModalItem(listing);
    setRejectReasonText('Shubhali narx yoki notoʻgʻri parametrlar');
  };

  // Moderation: Confirm Reject
  const handleConfirmReject = () => {
    if (!rejectModalItem) return;
    setPendingListings(prev =>
      prev.map(item =>
        item.id === rejectModalItem.id
          ? { ...item, status: 'REJECTED', rejectReason: rejectReasonText }
          : item
      )
    );
    showToast(isUz ? `❌ Eʼlon rad etildi: ${rejectReasonText}` : `❌ Объявление отклонено: ${rejectReasonText}`);
    setRejectModalItem(null);
  };

  // Delete live item from marketplace
  const handleDeleteMarketplaceItem = (id: string, title: string) => {
    onUpdateItems(prev => prev.filter(item => item.id !== id));
    showToast(isUz ? `🗑️ "${title}" eʼloni oʻchirildi!` : `🗑️ Объявление "${title}" удалено!`);
  };

  // Admin: Create listing directly
  const handleAdminCreateListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminListingForm.titleUz) {
      showToast(isUz ? 'Iltimos, eʼlon nomini kiriting!' : 'Пожалуйста, введите название!');
      return;
    }

    const newId = `live-adm-${Date.now()}`;
    const newItem: LivestockItem = {
      id: newId,
      department: adminListingForm.department,
      category: adminListingForm.department === 'qoramol' ? 'dairy' : adminListingForm.department === 'quy' ? 'sheep' : 'horses',
      breed: adminListingForm.breed,
      breedKey: adminListingForm.breed.toLowerCase().replace(/[^a-z]/g, '_') || 'golshtin',
      gender: adminListingForm.gender,
      titleUz: adminListingForm.titleUz,
      titleRu: adminListingForm.titleRu || adminListingForm.titleUz,
      descriptionUz: `${adminListingForm.breed} zotli sogʻlom chorva moli. Admin tomonidan toʻgʻridan-toʻgʻri tasdiqlangan.`,
      descriptionRu: `${adminListingForm.breed}. Проверено и одобрено администрацией.`,
      priceUzs: Number(adminListingForm.priceUzs),
      weightKg: Number(adminListingForm.weightKg),
      ageMonths: 24,
      region: adminListingForm.region as any,
      district: adminListingForm.district,
      imageUrl: adminListingForm.imageUrl,
      additionalImages: [],
      hasVideo: false,
      isVerifiedSeller: true,
      isEscrowSupported: true,
      isDeliveryAvailable: true,
      isQurbonlikFit: adminListingForm.department !== 'ot',
      viewsCount: 1,
      likesCount: 0,
      createdAt: new Date().toISOString(),
      seller: {
        id: `sel-${Date.now()}`,
        name: adminListingForm.sellerName,
        farmName: adminListingForm.sellerName,
        phone: adminListingForm.sellerPhone,
        telegramUsername: '@chorvabozor_admin',
        region: adminListingForm.region as any,
        district: adminListingForm.district,
        isPassportVerified: true,
        isPhoneVerified: true,
        rating: 5.0,
        dealsCompleted: 10,
        memberSince: '2025-01-01',
        badge: 'Fermer xoʻjaligi'
      },
      vetInfo: {
        id: `vet-${Date.now()}`,
        hasVetPassport: adminListingForm.hasVetPassport,
        passportNumber: adminListingForm.passportNumber,
        issuedDate: new Date().toISOString().split('T')[0],
        veterinarianName: 'Davlat Veterinariya Markazi',
        districtVetClinic: `${adminListingForm.district} Vet Markazi`,
        vaccinatedFor: [
          { nameUz: 'Kuydirgi', nameRu: 'Сибирская язва', date: '2026-03-01', isImmune: true },
          { nameUz: 'Oqsil', nameRu: 'Ящур', date: '2026-02-15', isImmune: true }
        ],
        healthNotes: 'Veterinar koʻrigidan oʻtgan va sogʻlom',
        status: 'verified'
      }
    };

    onUpdateItems(prev => [newItem, ...prev]);
    setIsAddListingOpen(false);
    setAdminListingForm({
      titleUz: '',
      titleRu: '',
      department: 'qoramol',
      breed: 'Golshtin (Holstein)',
      gender: 'sigir',
      weightKg: 520,
      priceUzs: 25000000,
      region: 'Samarqand',
      district: 'Pastdargʻom tumani',
      sellerName: 'Karimov Shuhrat FM',
      sellerPhone: '+998 90 234-56-78',
      hasVetPassport: true,
      passportNumber: 'UZ-VET-2026-9011',
      imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80'
    });
    showToast(isUz ? `✅ Yangi eʼlon muvaffaqiyatli joylandi!` : `✅ Объявление успешно опубликовано!`);
  };

  // Admin: Create Farm
  const handleAdminCreateFarm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminFarmForm.name || !adminFarmForm.ownerName) {
      showToast(isUz ? 'Iltimos, ferma nomi va rahbarini kiriting!' : 'Пожалуйста, введите название и имя руководителя!');
      return;
    }

    const newFarm: PlatformFarm = {
      id: `FRM-${Math.floor(100 + Math.random() * 900)}`,
      name: adminFarmForm.name,
      ownerName: adminFarmForm.ownerName,
      region: adminFarmForm.region,
      district: adminFarmForm.district || 'Markaziy tuman',
      livestockCount: Number(adminFarmForm.livestockCount),
      specialization: adminFarmForm.specialization,
      phone: adminFarmForm.phone,
      vetSupervision: adminFarmForm.vetSupervision,
      status: 'ACTIVE',
      registeredDate: new Date().toISOString().split('T')[0]
    };

    setFarms(prev => [newFarm, ...prev]);
    setIsAddFarmOpen(false);
    setAdminFarmForm({
      name: '',
      ownerName: '',
      region: 'Samarqand',
      district: 'Pastdargʻom tumani',
      livestockCount: 60,
      specialization: 'Sut yoʻnalishi',
      phone: '+998 90 123-45-67',
      vetSupervision: true
    });
    showToast(isUz ? `🏢 "${newFarm.name}" fermasi muvaffaqiyatli roʻyxatga olindi!` : `🏢 Ферма успешно добавлена!`);
  };

  // Admin: Create Farmer
  const handleAdminCreateFarmer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminFarmerForm.name || !adminFarmerForm.phone) {
      showToast(isUz ? 'Iltimos, ism va telefonni kiriting!' : 'Пожалуйста, введите имя и телефон!');
      return;
    }

    const newFarmer: PlatformUser = {
      id: `USR-${Math.floor(100 + Math.random() * 900)}`,
      name: adminFarmerForm.name,
      role: adminFarmerForm.role,
      region: `${adminFarmerForm.region} viloyati`,
      phone: adminFarmerForm.phone,
      dealsCount: 0,
      rating: 5.0,
      verified: adminFarmerForm.verified,
      status: 'ACTIVE',
      registeredDate: new Date().toISOString().split('T')[0],
      farmName: adminFarmerForm.farmName || undefined
    };

    setPlatformUsers(prev => [newFarmer, ...prev]);
    setIsAddFarmerOpen(false);
    setAdminFarmerForm({
      name: '',
      phone: '+998 90 123-45-67',
      region: 'Samarqand',
      district: 'Pastdargʻom tumani',
      role: 'Fermer',
      farmName: 'Samarqand Chorva FM',
      verified: true
    });
    showToast(isUz ? `👨‍🌾 "${newFarmer.name}" fermer sifatida roʻyxatdan oʻtkazildi!` : `👨‍🌾 Фермер успешно зарегистрирован!`);
  };

  // Delete farm
  const handleDeleteFarm = (farmId: string, farmName: string) => {
    setFarms(prev => prev.filter(f => f.id !== farmId));
    showToast(isUz ? `🗑️ "${farmName}" fermasi oʻchirildi!` : `🗑️ Ферма удалена!`);
  };

  // Delete farmer
  const handleDeleteFarmer = (userId: string, userName: string) => {
    setPlatformUsers(prev => prev.filter(u => u.id !== userId));
    showToast(isUz ? `🗑️ "${userName}" foydalanuvchisi oʻchirildi!` : `🗑️ Пользователь удален!`);
  };

  // Vet: Toggle Qurbonlik Certification
  const handleToggleQurbonlikStatus = (vetId: string) => {
    setVetRegistry(prev =>
      prev.map(item => {
        if (item.id === vetId) {
          const nextStatus = item.qurbonlikStatus === 'CERTIFIED' ? 'DISQUALIFIED' : 'CERTIFIED';
          return {
            ...item,
            qurbonlikStatus: nextStatus,
            isQurbonlikCandidate: nextStatus === 'CERTIFIED'
          };
        }
        return item;
      })
    );
    showToast(isUz ? '📋 Qurbonlik 2026 statusi yangilandi!' : '📋 Статус Курбанлык 2026 обновлен!');
  };

  // Auction: Adjust Min Step or Timer
  const handleAuctionAddTimer = (auctionId: string, minutes: number) => {
    setAuctions(prev =>
      prev.map(auc =>
        auc.id === auctionId
          ? { ...auc, timeLeftMinutes: Math.max(1, auc.timeLeftMinutes + minutes) }
          : auc
      )
    );
    showToast(isUz ? `⏱️ Auksion taymeriga ${minutes > 0 ? '+' : ''}${minutes} daqiqa qoʻshildi` : `⏱️ Добавлено ${minutes} мин к аукциону`);
  };

  const handleAuctionToggleStatus = (auctionId: string) => {
    setAuctions(prev =>
      prev.map(auc => {
        if (auc.id === auctionId) {
          const nextStatus = auc.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
          return { ...auc, status: nextStatus };
        }
        return auc;
      })
    );
    showToast(isUz ? 'Auksion holati oʻzgartirildi' : 'Статус аукциона изменен');
  };

  const handleAuctionFinalizeWinner = (auction: AdminAuctionControl) => {
    setAuctions(prev =>
      prev.map(auc =>
        auc.id === auction.id ? { ...auc, status: 'COMPLETED' } : auc
      )
    );
    showToast(
      isUz
        ? `🏆 Gʻolib tasdiqlandi: ${auction.leadingBidder} (${auction.currentBid.toLocaleString('uz-UZ')} soʻm)!`
        : `🏆 Победитель утвержден: ${auction.leadingBidder}!`
    );
  };

  // Escrow: Release funds
  const handleReleaseEscrow = (dealId: string) => {
    setEscrowDeals(prev =>
      prev.map(d => (d.id === dealId ? { ...d, status: 'RELEASED' } : d))
    );
    showToast(
      isUz
        ? `💰 Xavfsiz toʻlov sotuvchiga muvaffaqiyatli oʻtkazib berildi (1.5% komissiya yechildi)!`
        : `💰 Средства эскроу успешно переведены продавцу!`
    );
  };

  // Transport: Update order status
  const handleUpdateTransportStatus = (orderId: string, nextStatus: 'ASSIGNED' | 'IN_TRANSIT' | 'DELIVERED') => {
    setTransportOrders(prev =>
      prev.map(t => (t.id === orderId ? { ...t, status: nextStatus } : t))
    );
    showToast(isUz ? `🚛 Transport holati yangilandi: ${nextStatus}` : `🚛 Статус рейса обновлен!`);
  };

  // Filtered live marketplace items
  const filteredLiveItems = useMemo(() => {
    if (!searchQuery.trim()) return items;
    const q = searchQuery.toLowerCase();
    return items.filter(
      it =>
        it.titleUz.toLowerCase().includes(q) ||
        it.region.toLowerCase().includes(q) ||
        (it.breed && it.breed.toLowerCase().includes(q)) ||
        (it.seller?.name && it.seller.name.toLowerCase().includes(q))
    );
  }, [items, searchQuery]);

  return (
    <div className={`fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 ${currentThemeDark ? 'dark' : ''}`}>
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-7xl w-full h-[95vh] shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] flex flex-col overflow-hidden font-sans transition-colors duration-200">
        
        {/* Toast Alert */}
        {notificationToast && (
          <div className="absolute top-4 right-4 z-50 bg-[#047857] text-white px-4 py-2.5 rounded-2xl shadow-xl text-xs sm:text-sm font-bold flex items-center gap-2 animate-in slide-in-from-top-2 duration-200 border border-[#10B981]">
            <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
            <span>{notificationToast}</span>
          </div>
        )}

        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 bg-[#F0F4F1] dark:bg-[#031510] border-b border-[#E5ECE7] dark:border-[#0E3D32] shrink-0 transition-colors">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#064E3B] to-[#047857] flex items-center justify-center shadow-lg shadow-[#064E3B]/40 text-white shrink-0 border border-[#10B981]/30">
              <Shield className="w-5 h-5 text-[#10B981]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-extrabold text-base sm:text-lg tracking-tight text-[#1C2A23] dark:text-white">
                  ChorvaBozor Admin Kabineti
                </h2>
                <span className="px-2 py-0.5 rounded-md bg-[#10B981]/20 border border-[#10B981]/40 text-[#064E3B] dark:text-[#10B981] font-mono text-[10px] font-bold">
                  ROOT ADMIN (LOGIN: 1)
                </span>
                <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#F59E0B]/15 text-[#D97706] dark:text-[#F59E0B] border border-[#F59E0B]/30 text-[10px] font-medium">
                  <Activity className="w-3 h-3 animate-spin text-[#F59E0B]" />
                  SLA: 99.98%
                </span>
              </div>
              <p className="text-xs text-stone-600 dark:text-stone-400 hidden sm:block">
                {isUz
                  ? 'Boshqaruv paneli, chorva parametrlari va moliyaviy oqimlar nazorati'
                  : 'Панель управления, реестр скота и контроль финансовых потоков'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Theme Toggle Button (Light / Dark) */}
            <button
              type="button"
              onClick={handleToggleTheme}
              className="p-2 rounded-xl bg-white dark:bg-[#072D24] text-stone-700 dark:text-stone-300 hover:text-[#F59E0B] dark:hover:text-[#F59E0B] transition-colors cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32] flex items-center gap-1.5 text-xs font-semibold"
              title={currentThemeDark ? "Yorugʻ rejimga oʻtish" : "Qorongʻu rejimga oʻtish"}
            >
              {currentThemeDark ? <Sun className="w-4 h-4 text-[#F59E0B]" /> : <Moon className="w-4 h-4 text-stone-700" />}
              <span className="hidden md:inline">{currentThemeDark ? 'Yorugʻ' : 'Qorongʻu'}</span>
            </button>

            {/* Language Switcher */}
            <div className="flex items-center rounded-xl bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] p-0.5 text-xs font-bold">
              <button
                type="button"
                onClick={() => handleSwitchLanguage('uz')}
                className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  isUz
                    ? 'bg-[#047857] text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                UZ
              </button>
              <button
                type="button"
                onClick={() => handleSwitchLanguage('ru')}
                className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  !isUz
                    ? 'bg-[#047857] text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                RU
              </button>
            </div>

            {/* Active section badge */}
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#064E3B]/10 dark:bg-[#072D24] border border-[#047857]/30 dark:border-[#0E3D32] text-xs text-[#064E3B] dark:text-[#10B981] font-medium">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-ping" />
              <span>
                {isUz ? 'Faol Boʻlim:' : 'Активно:'}{' '}
                <strong>
                  {activeMenu === 'dashboard' && '01. Asosiy Panel'}
                  {activeMenu === 'listings' && '02. Eʼlonlar'}
                  {activeMenu === 'vet' && '03. Vet Pasport'}
                  {activeMenu === 'auctions' && '04. Auksionlar'}
                  {activeMenu === 'transport' && '05. Transport'}
                  {activeMenu === 'users' && '06. Fermerlar'}
                  {activeMenu === 'analytics' && '07. Narx Indeksi'}
                  {activeMenu === 'escrow' && '08. Eskrou'}
                </strong>
              </span>
            </div>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 dark:bg-[#072D24] dark:hover:bg-rose-950/60 text-rose-700 dark:text-rose-300 transition-colors cursor-pointer border border-rose-300 dark:border-[#0E3D32] text-xs font-bold flex items-center gap-1"
              title="Panelni yopish"
            >
              <span>✕</span>
              <span className="hidden sm:inline">{isUz ? 'Yopish' : 'Закрыть'}</span>
            </button>
          </div>
        </div>

        {/* Main Workspace Body */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Sidebar Menu */}
          <div className="w-64 sm:w-72 bg-[#EBEFEA] dark:bg-[#02100C] border-r border-[#E5ECE7] dark:border-[#0E3D32] p-3 sm:p-4 flex flex-col justify-between shrink-0 overflow-y-auto transition-colors">
            <div className="space-y-4">
              <div className="px-3 text-[11px] font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider">
                {isUz ? '1. CHORVA, VET & SAVDO' : '1. СКОТ, ВЕТ И ТОРГОВЛЯ'}
              </div>

              <div className="space-y-1.5">
                {[
                  {
                    key: 'dashboard',
                    label: isUz ? 'Asosiy Panel' : 'Главная панель',
                    icon: LayoutDashboard,
                    desc: isUz ? 'Statistika & monitoring' : 'Статистика и KPI',
                    badge: 'Online'
                  },
                  {
                    key: 'listings',
                    label: isUz ? 'Eʼlonlar Boshqaruvi' : 'Модерация объявлений',
                    icon: FileCheck,
                    desc: isUz ? 'Tasdiqlash & AI moderatsiya' : 'Проверка и фильтрация',
                    badge: `${pendingModerationCount} yangi`
                  },
                  {
                    key: 'vet',
                    label: isUz ? 'Veterinariya Nazorati' : 'Вет-контроль & Паспорта',
                    icon: Shield,
                    desc: isUz ? 'Vet pasportlar & Qurbonlik' : 'Реестр и Курбанлык',
                    badge: `${certifiedQurbonlikCount} sert.`
                  },
                  {
                    key: 'auctions',
                    label: isUz ? 'Jonli Auksionlar' : 'Живые аукционы',
                    icon: Gavel,
                    desc: isUz ? 'Stavkalar & gʻoliblar' : 'Ставки и таймер',
                    badge: `${auctions.filter(a => a.status === 'ACTIVE').length} faol`
                  },
                  {
                    key: 'transport',
                    label: isUz ? 'Fura & Transport' : 'Транспорт и фуры',
                    icon: Truck,
                    desc: isUz ? 'Viloyatlararo yuklar' : 'Междугородние рейсы',
                    badge: `${activeTransportCount} yoʻlda`
                  },
                  {
                    key: 'users',
                    label: isUz ? 'Fermerlar & Xaridorlar' : 'Фермеры и покупатели',
                    icon: Users,
                    desc: isUz ? 'Profil va reytinglar' : 'Профили и рейтинг',
                    badge: '1,480+'
                  },
                ].map((item, idx) => {
                  const Icon = item.icon;
                  const isActive = activeMenu === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setActiveMenu(item.key as any)}
                      className={`w-full p-2.5 sm:p-3 rounded-2xl text-left transition-all cursor-pointer flex items-center justify-between group ${
                        isActive
                          ? 'bg-gradient-to-r from-[#064E3B] to-[#047857] text-white shadow-lg shadow-[#064E3B]/40 font-bold border border-[#10B981]/30'
                          : 'hover:bg-[#DFE6E1] dark:hover:bg-[#072D24] text-stone-700 dark:text-stone-300 hover:text-[#1C2A23] dark:hover:text-white border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 sm:gap-3">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${isActive ? 'bg-[#02100C]/60 text-[#F59E0B]' : 'bg-stone-200 dark:bg-[#072D24] text-stone-600 dark:text-stone-400'}`}>
                          0{idx + 1}
                        </span>
                        <div>
                          <div className="text-xs font-bold flex items-center gap-1.5">
                            <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-[#10B981]' : 'text-stone-500'}`} />
                            <span className="truncate max-w-[120px] sm:max-w-[140px]">{item.label}</span>
                          </div>
                          <div className={`text-[10px] truncate max-w-[130px] ${isActive ? 'text-emerald-100' : 'text-stone-500'}`}>
                            {item.desc}
                          </div>
                        </div>
                      </div>
                      <span className={`text-[9px] font-mono px-1.5 sm:px-2 py-0.5 rounded-full shrink-0 ${isActive ? 'bg-white/20 text-white' : 'bg-white dark:bg-[#072D24] text-stone-600 dark:text-stone-400 border border-stone-300 dark:border-[#0E3D32]'}`}>
                        {item.badge}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="pt-2">
                <div className="px-3 text-[11px] font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-2">
                  {isUz ? '2. MOLIYA & ANALITIKA' : '2. ФИНАНСЫ И АНАЛИТИКА'}
                </div>
                <div className="space-y-1.5">
                  <button
                    type="button"
                    onClick={() => setActiveMenu('analytics')}
                    className={`w-full p-2.5 sm:p-3 rounded-2xl text-left transition-all cursor-pointer flex items-center justify-between group ${
                      activeMenu === 'analytics'
                        ? 'bg-gradient-to-r from-[#064E3B] to-[#047857] text-white shadow-lg shadow-[#064E3B]/40 font-bold border border-[#10B981]/30'
                        : 'hover:bg-[#DFE6E1] dark:hover:bg-[#072D24] text-stone-700 dark:text-stone-300 hover:text-[#1C2A23] dark:hover:text-white border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${activeMenu === 'analytics' ? 'bg-[#02100C]/60 text-[#F59E0B]' : 'bg-stone-200 dark:bg-[#072D24] text-stone-600 dark:text-stone-400'}`}>
                        07
                      </span>
                      <div>
                        <div className="text-xs font-bold flex items-center gap-1.5">
                          <TrendingUp className="w-3.5 h-3.5 text-[#F59E0B]" />
                          <span>{isUz ? 'Narx Indeksi' : 'Индекс цен'}</span>
                        </div>
                        <div className={`text-[10px] ${activeMenu === 'analytics' ? 'text-emerald-100' : 'text-stone-500'}`}>
                          {isUz ? '14 ta viloyat dinamikasi' : 'Графики по регионам'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-[#F59E0B]/20 text-[#D97706] dark:text-[#F59E0B]">
                      Recharts
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveMenu('escrow')}
                    className={`w-full p-2.5 sm:p-3 rounded-2xl text-left transition-all cursor-pointer flex items-center justify-between group ${
                      activeMenu === 'escrow'
                        ? 'bg-gradient-to-r from-[#064E3B] to-[#047857] text-white shadow-lg shadow-[#064E3B]/40 font-bold border border-[#10B981]/30'
                        : 'hover:bg-[#DFE6E1] dark:hover:bg-[#072D24] text-stone-700 dark:text-stone-300 hover:text-[#1C2A23] dark:hover:text-white border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${activeMenu === 'escrow' ? 'bg-[#02100C]/60 text-[#F59E0B]' : 'bg-stone-200 dark:bg-[#072D24] text-stone-600 dark:text-stone-400'}`}>
                        08
                      </span>
                      <div>
                        <div className="text-xs font-bold flex items-center gap-1.5">
                          <CreditCard className="w-3.5 h-3.5 text-[#10B981]" />
                          <span>{isUz ? 'Eskrou & Moliya' : 'Эскроу и Сделки'}</span>
                        </div>
                        <div className={`text-[10px] ${activeMenu === 'escrow' ? 'text-emerald-100' : 'text-stone-500'}`}>
                          {isUz ? '1.5% platforma komissiyasi' : 'Безопасные расчеты'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-[#10B981]/20 text-[#047857] dark:text-[#10B981]">
                      1.5%
                    </span>
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom Profile & Logout */}
            <div className="pt-3 border-t border-[#E5ECE7] dark:border-[#0E3D32] space-y-2.5">
              <div className="flex items-center justify-between text-xs text-stone-600 dark:text-stone-400 px-1">
                <span>{isUz ? 'Bosh Administrator:' : 'Главный админ:'}</span>
                <span className="text-[#047857] dark:text-[#10B981] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
                  ONLINE
                </span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2 px-3 rounded-xl bg-rose-100 hover:bg-rose-200 dark:bg-[#072D24] dark:hover:bg-rose-950/60 border border-rose-300 dark:border-rose-900/60 text-rose-800 dark:text-rose-300 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{isUz ? 'Kabinetdan chiqish' : 'Выход из панели'}</span>
              </button>
            </div>
          </div>

          {/* Main Content Workspace */}
          <div className="flex-1 bg-[#F7F9F6] dark:bg-[#041C16] overflow-y-auto p-4 sm:p-6 transition-colors">
            
            {/* 1. ASOSIY PANEL (Dashboard / KPI Cards) */}
            {activeMenu === 'dashboard' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                {/* Greeting & Quick Notice */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#064E3B]/20 via-[#F0F4F1] dark:via-[#072D24] to-[#047857]/20 border border-[#047857]/40 rounded-3xl p-5 shadow-sm">
                  <div>
                    <h3 className="text-lg sm:text-xl font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <span>Assalomu alaykum, Hurmatli Bosh Administrator!</span>
                      <Sparkles className="w-5 h-5 text-[#F59E0B]" />
                    </h3>
                    <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 mt-1">
                      Oʻzbekiston qoramol savdo va chorva ekotizimi 24/7 rejimida toʻliq xavfsiz ishlamoqda.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveMenu('listings')}
                      className="px-3.5 py-2 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white text-xs font-bold transition-all shadow-md shadow-[#047857]/25 flex items-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <FileCheck className="w-4 h-4 text-[#10B981]" />
                      <span>{pendingModerationCount} ta yangi eʼlonni tekshirish</span>
                    </button>
                  </div>
                </div>

                {/* 1. ASOSIY STATISTIKA (KPI Cards) */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-600 dark:text-stone-400 mb-3 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-[#10B981]" />
                    <span>{isUz ? 'Asosiy Statistika va KPI Koʻrsatkichlari' : 'Ключевые показатели эффективности (KPI)'}</span>
                  </h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* KPI 1: Active Listings & Distribution */}
                    <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs hover:border-[#10B981]/50 transition-all">
                      <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs font-semibold mb-2">
                        <span>{isUz ? 'Jami Faol Eʼlonlar' : 'Всего объявлений'}</span>
                        <span className="p-1.5 rounded-lg bg-[#10B981]/15 text-[#047857] dark:text-[#10B981]">
                          <FileCheck className="w-4 h-4" />
                        </span>
                      </div>
                      <div className="text-2xl sm:text-3xl font-black text-[#1C2A23] dark:text-white">
                        {totalMarketplaceListings} <span className="text-xs font-normal text-stone-500">ta</span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32] grid grid-cols-3 gap-1 text-[11px] text-stone-600 dark:text-stone-400 font-medium">
                        <div>🐄 Qoramol: <strong className="text-[#1C2A23] dark:text-stone-200">{qoramolCount}</strong></div>
                        <div>🐑 Qoʻy: <strong className="text-[#1C2A23] dark:text-stone-200">{quyCount}</strong></div>
                        <div>🐎 Otlar: <strong className="text-[#1C2A23] dark:text-stone-200">{otCount}</strong></div>
                      </div>
                    </div>

                    {/* KPI 2: Escrow Volume & 1.5% Fee */}
                    <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs hover:border-[#10B981]/50 transition-all">
                      <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs font-semibold mb-2">
                        <span>{isUz ? 'Eskrou Bitimlari Hajmi' : 'Объем Эскроу (Гарант)'}</span>
                        <span className="p-1.5 rounded-lg bg-[#047857]/15 text-[#047857] dark:text-[#10B981]">
                          <CreditCard className="w-4 h-4" />
                        </span>
                      </div>
                      <div className="text-xl sm:text-2xl font-black text-[#047857] dark:text-[#10B981] truncate">
                        {totalEscrowVolume.toLocaleString('uz-UZ')} <span className="text-xs font-normal text-stone-500">soʻm</span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32] flex items-center justify-between text-[11px]">
                        <span className="text-stone-500">{isUz ? 'Platforma komissiyasi (1.5%):' : 'Комиссия платформы (1.5%):'}</span>
                        <span className="font-bold text-[#D97706] dark:text-[#F59E0B]">
                          {platformCommission1_5.toLocaleString('uz-UZ')} soʻm
                        </span>
                      </div>
                    </div>

                    {/* KPI 3: Verified Farmers & Vets */}
                    <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs hover:border-[#10B981]/50 transition-all">
                      <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs font-semibold mb-2">
                        <span>{isUz ? 'Fermerlar & Shifokorlar' : 'Фермеры и Врачи'}</span>
                        <span className="p-1.5 rounded-lg bg-[#F59E0B]/15 text-[#D97706] dark:text-[#F59E0B]">
                          <Users className="w-4 h-4" />
                        </span>
                      </div>
                      <div className="text-2xl sm:text-3xl font-black text-[#1C2A23] dark:text-white">
                        1,604 <span className="text-xs font-normal text-stone-500">akkount</span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32] flex items-center justify-between text-[11px] text-stone-600 dark:text-stone-400">
                        <span>👨‍🌾 Fermerlar: <strong className="text-[#1C2A23] dark:text-stone-200">1,480 ta</strong></span>
                        <span>🩺 Vet shifokorlar: <strong className="text-[#047857] dark:text-[#10B981]">124 ta</strong></span>
                      </div>
                    </div>

                    {/* KPI 4: Inter-region Transport / Fura Orders */}
                    <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs hover:border-[#10B981]/50 transition-all">
                      <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs font-semibold mb-2">
                        <span>{isUz ? 'Viloyatlararo Fura & Yuk' : 'Рейсы и Транспорт'}</span>
                        <span className="p-1.5 rounded-lg bg-[#064E3B]/20 text-[#047857] dark:text-[#10B981]">
                          <Truck className="w-4 h-4" />
                        </span>
                      </div>
                      <div className="text-2xl sm:text-3xl font-black text-[#1C2A23] dark:text-white">
                        38 <span className="text-xs font-normal text-stone-500">marshrut</span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32] flex items-center justify-between text-[11px] text-stone-600 dark:text-stone-400">
                        <span>🚛 Hozir yoʻlda: <strong className="text-[#047857] dark:text-[#10B981]">{activeTransportCount} ta fura</strong></span>
                        <span className="text-stone-500">Oʻrtacha: 310 km</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick Shortcuts & Interactive Operations */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Realtime Moderation preview card */}
                  <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs">
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-xs font-bold text-[#1C2A23] dark:text-white flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-[#10B981]" />
                        <span>AI Moderatsiya Markazi</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-[#10B981]/20 text-[#047857] dark:text-[#10B981] text-[10px] font-bold">
                        {pendingModerationCount} ta kutilmoqda
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 dark:text-stone-300 mb-3">
                      Fermerlar yuklagan fotosurat, narx va davlat veterinariya pasportini real vaqtda tahlil qilish.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveMenu('listings')}
                      className="w-full py-2 px-3 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <span>Moderatsiyani ochish</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Qurbonlik 2026 Registry shortcut */}
                  <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs">
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-xs font-bold text-[#1C2A23] dark:text-white flex items-center gap-1.5">
                        <Award className="w-4 h-4 text-[#F59E0B]" />
                        <span>Qurbonlik 2026 Nazorati</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-[#F59E0B]/20 text-[#D97706] dark:text-[#F59E0B] text-[10px] font-bold">
                        {certifiedQurbonlikCount} ta sertifikatlangan
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 dark:text-stone-300 mb-3">
                      Yoshi, tishlari, shoxlari va sogʻlomligi toʻliq tekshirilgan mollar reyestri va sertifikat berish.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveMenu('vet')}
                      className="w-full py-2 px-3 rounded-xl bg-[#D97706] hover:bg-[#B45309] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <span>Veterinariya Reyestrini koʻrish</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Live Auctions Shortcut */}
                  <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-2xl p-4 shadow-xs">
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-xs font-bold text-[#1C2A23] dark:text-white flex items-center gap-1.5">
                        <Gavel className="w-4 h-4 text-[#10B981]" />
                        <span>Jonli Auksionlar Boshqaruvi</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-[#047857]/20 text-[#047857] dark:text-[#10B981] text-[10px] font-bold">
                        {auctions.filter(a => a.status === 'ACTIVE').length} ta aktiv
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 dark:text-stone-300 mb-3">
                      Boshlangʻich narx, min qadam (step), taymer nazorati va gʻoliblarni aniqlash paneli.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveMenu('auctions')}
                      className="w-full py-2 px-3 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <span>Auksionlarni boshqarish</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Regional Live Weight Index Mini BarChart preview */}
                <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-sm font-extrabold text-[#1C2A23] dark:text-white flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-[#10B981]" />
                        <span>Viloyatlar boʻyicha tirik vazn narxlari dinamikasi (1 kg soʻmda)</span>
                      </h4>
                      <p className="text-xs text-stone-500">Oʻzbekistonning 14 ta hududidagi haftalik monitoring</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveMenu('analytics')}
                      className="px-3 py-1.5 rounded-xl bg-[#F0F4F1] dark:bg-[#041C16] hover:bg-stone-200 dark:hover:bg-[#0E3D32] text-xs font-bold text-[#1C2A23] dark:text-stone-200 transition-colors flex items-center gap-1 cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                    >
                      <span>Batafsil grafiklar</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={regionPriceIndex.slice(0, 8)} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke={currentThemeDark ? '#0E3D32' : '#E5ECE7'} vertical={false} />
                        <XAxis dataKey="region" stroke={currentThemeDark ? '#10B981' : '#78716c'} fontSize={10} tickLine={false} interval={0} angle={-15} textAnchor="end" />
                        <YAxis stroke={currentThemeDark ? '#10B981' : '#78716c'} fontSize={10} domain={[45000, 68000]} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: currentThemeDark ? '#072D24' : '#ffffff',
                            borderColor: currentThemeDark ? '#0E3D32' : '#E5ECE7',
                            borderRadius: '12px',
                            fontSize: '12px',
                            color: currentThemeDark ? '#ECFDF5' : '#1C2A23'
                          }}
                          formatter={(value: any) => [`${Number(value).toLocaleString('uz-UZ')} soʻm/kg`, '']}
                        />
                        <Bar dataKey="qoramolKg" name="Qoramol (kg)" fill="#047857" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="quyKg" name="Qoʻy (kg)" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {/* 2. REAL-VAQT MODERATSIYA MARKAZI (AI Moderation & Listings) */}
            {activeMenu === 'listings' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                {/* Header & Sub-Tabs */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-200 dark:border-stone-800 pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-stone-900 dark:text-white flex items-center gap-2">
                      <FileCheck className="w-5 h-5 text-emerald-500" />
                      <span>{isUz ? 'Real-Vaqt Moderatsiya Markazi & Eʼlonlar Boshqaruvi' : 'Центр модерации и управление объявлениями'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      AI foto/matn tekshiruvi, narx monitoringi va tasdiqlangan bozor eʼlonlari
                    </p>
                  </div>

                  {/* Sub-tabs */}
                  <div className="flex items-center gap-1.5 bg-[#F0F4F1] dark:bg-[#072D24] p-1 rounded-xl border border-[#E5ECE7] dark:border-[#0E3D32] text-xs font-bold">
                    <button
                      type="button"
                      onClick={() => setListingsSubTab('pending')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        listingsSubTab === 'pending'
                          ? 'bg-[#047857] text-white shadow-xs'
                          : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#10B981]" />
                      <span>{isUz ? 'AI Moderatsiya' : 'На проверке'}</span>
                      <span className="px-1.5 py-0.2 rounded-full bg-black/25 text-[#F59E0B] text-[10px]">
                        {pendingModerationCount}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setListingsSubTab('active_marketplace')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        listingsSubTab === 'active_marketplace'
                          ? 'bg-[#047857] text-white shadow-xs'
                          : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />
                      <span>{isUz ? 'Faol Bozor Eʼlonlari' : 'Активные на рынке'}</span>
                      <span className="px-1.5 py-0.2 rounded-full bg-black/25 text-[#10B981] text-[10px]">
                        {totalMarketplaceListings}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setListingsSubTab('rejected')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                        listingsSubTab === 'rejected'
                          ? 'bg-[#047857] text-white shadow-xs'
                          : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5 text-rose-400" />
                      <span>{isUz ? 'Rad etilganlar' : 'Отклоненные'}</span>
                    </button>
                  </div>
                </div>

                {/* SubTab 1: PENDING AI MODERATION */}
                {listingsSubTab === 'pending' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs text-stone-500">
                      <span>Fermerlar yuklagan yangi eʼlonlar: <strong>{pendingListings.filter(l => l.status === 'PENDING').length} ta koʻrib chiqish kutilmoqda</strong></span>
                      <span className="text-[#047857] dark:text-[#10B981] font-semibold flex items-center gap-1">
                        <Activity className="w-3.5 h-3.5" />
                        AI Algoritmi: v2.4 (Oʻzbekiston chorva narxlari bazasi bilan sinxron)
                      </span>
                    </div>

                    {pendingListings.filter(l => l.status === 'PENDING').length === 0 ? (
                      <div className="text-center py-16 bg-white dark:bg-[#072D24] rounded-3xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                        <CheckCircle2 className="w-12 h-12 text-[#10B981] mx-auto mb-3" />
                        <h4 className="text-base font-bold text-[#1C2A23] dark:text-white">Barcha eʼlonlar koʻrib chiqilgan!</h4>
                        <p className="text-xs text-stone-500 mt-1">Hozirda moderatsiya navbatida yangi eʼlonlar mavjud emas.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-4">
                        {pendingListings
                          .filter(l => l.status === 'PENDING')
                          .map((listing) => (
                            <div
                              key={listing.id}
                              className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-4 sm:p-5 shadow-xs hover:border-[#10B981]/40 transition-all flex flex-col lg:flex-row gap-5"
                            >
                              {/* Media Thumbnail */}
                              <div className="relative w-full lg:w-60 h-48 lg:h-auto rounded-2xl overflow-hidden shrink-0 border border-[#E5ECE7] dark:border-[#0E3D32] bg-[#02100C]">
                                <img
                                  src={listing.imageUrl}
                                  alt={listing.titleUz}
                                  className="w-full h-full object-cover"
                                />
                                {listing.hasVideo && (
                                  <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-xs text-[#10B981] font-bold text-[10px] flex items-center gap-1">
                                    <Play className="w-3 h-3 fill-[#10B981]" />
                                    Video Mavjud
                                  </span>
                                )}
                                <span className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-xs text-white text-[10px] font-mono">
                                  {listing.submittedAt}
                                </span>
                              </div>

                              {/* Info & Details */}
                              <div className="flex-1 space-y-3">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div>
                                    <span className="text-[10px] font-mono text-stone-500">ID: {listing.id}</span>
                                    <h4 className="text-base font-extrabold text-[#1C2A23] dark:text-white mt-0.5">
                                      {isUz ? listing.titleUz : listing.titleRu}
                                    </h4>
                                  </div>
                                  <div className="text-right">
                                    <div className="text-lg font-black text-[#047857] dark:text-[#10B981]">
                                      {listing.priceUzs.toLocaleString('uz-UZ')} soʻm
                                    </div>
                                    <div className="text-xs text-stone-500">
                                      Vazni: <strong className="text-[#1C2A23] dark:text-stone-300">{listing.weightKg} kg</strong>
                                    </div>
                                  </div>
                                </div>

                                {/* Metadata Grid */}
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-[#F0F4F1] dark:bg-[#041C16] p-3 rounded-2xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                                  <div>
                                    <span className="text-stone-500 block text-[10px]">Hudud:</span>
                                    <span className="font-semibold text-[#1C2A23] dark:text-stone-200">{listing.region}, {listing.district}</span>
                                  </div>
                                  <div>
                                    <span className="text-stone-500 block text-[10px]">Sotuvchi (Fermer):</span>
                                    <span className="font-semibold text-[#1C2A23] dark:text-stone-200">{listing.sellerName}</span>
                                  </div>
                                  <div>
                                    <span className="text-stone-500 block text-[10px]">Telefon:</span>
                                    <span className="font-mono text-[#1C2A23] dark:text-stone-200">{listing.sellerPhone}</span>
                                  </div>
                                  <div>
                                    <span className="text-stone-500 block text-[10px]">Vet Pasport No:</span>
                                    <span className="font-mono text-[#047857] dark:text-[#10B981] font-bold">{listing.vetPassportNumber}</span>
                                  </div>
                                </div>

                                {/* AI Moderation Diagnostic Box */}
                                <div className={`p-3 rounded-2xl text-xs border ${
                                  listing.aiFlag === 'SUSPICIOUS_PRICE'
                                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-700 dark:text-rose-300'
                                    : listing.aiFlag === 'HIGH_DEMAND'
                                    ? 'bg-[#10B981]/15 border-[#10B981]/35 text-[#064E3B] dark:text-[#10B981]'
                                    : 'bg-[#F59E0B]/15 border-[#F59E0B]/35 text-[#D97706] dark:text-[#F59E0B]'
                                }`}>
                                  <div className="flex items-center justify-between font-bold mb-1">
                                    <span className="flex items-center gap-1.5">
                                      <Sparkles className="w-3.5 h-3.5 text-[#10B981]" />
                                      AI Tahlili (Ishonchlilik: {listing.aiScore}%)
                                    </span>
                                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-black/20">
                                      Status: {listing.aiFlag}
                                    </span>
                                  </div>
                                  <p className="text-[11px] leading-relaxed">
                                    {isUz ? listing.aiNotesUz : listing.aiNotesRu}
                                  </p>
                                </div>

                                {/* Actions: Approve vs Reject */}
                                <div className="flex items-center justify-end gap-2.5 pt-2">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenRejectModal(listing)}
                                    className="px-4 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 dark:bg-[#041C16] dark:hover:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-900/60 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                                  >
                                    <X className="w-4 h-4" />
                                    <span>Rad etish</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleApproveListing(listing)}
                                    className="px-5 py-2 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white shadow-md shadow-[#047857]/30 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
                                  >
                                    <Check className="w-4 h-4 text-[#10B981]" />
                                    <span>Tasdiqlash (Bozorga chiqarish)</span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                )}

                {/* SubTab 2: ACTIVE MARKETPLACE ITEMS */}
                {listingsSubTab === 'active_marketplace' && (
                  <div className="space-y-4">
                    {/* Search & Stats Bar with Add Listing CTA */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="relative flex-1 max-w-md">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder={isUz ? "Eʼlon nomi, viloyat yoki zot boʻyicha qidiruv..." : "Поиск по названию или региону..."}
                          className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#041C16] border border-[#E5ECE7] dark:border-[#0E3D32] text-xs text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none focus:border-[#10B981]"
                        />
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-xs text-stone-500">
                          Jami eʼlonlar: <strong>{filteredLiveItems.length} ta</strong>
                        </div>
                        <button
                          type="button"
                          onClick={() => setIsAddListingOpen(true)}
                          className="py-2 px-3.5 bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold text-xs rounded-xl transition-all shadow-sm shadow-[#F59E0B]/30 flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0"
                        >
                          <Plus className="w-4 h-4" />
                          <span>{isUz ? 'Yangi Eʼlon Joylash' : 'Добавить объявление'}</span>
                        </button>
                      </div>
                    </div>

                    {filteredLiveItems.length === 0 ? (
                      <div className="text-center py-12 bg-white dark:bg-[#072D24] rounded-3xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                        <p className="text-xs text-stone-500">Hech qanday eʼlon topilmadi.</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto rounded-2xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-[#F0F4F1] dark:bg-[#031510] text-stone-600 dark:text-stone-400 uppercase text-[10px] font-bold border-b border-[#E5ECE7] dark:border-[#0E3D32]">
                            <tr>
                              <th className="p-3">Foto / Nomi</th>
                              <th className="p-3">Kategoriya</th>
                              <th className="p-3">Narxi</th>
                              <th className="p-3">Vazni</th>
                              <th className="p-3">Viloyat</th>
                              <th className="p-3">Vet Pasport</th>
                              <th className="p-3">Sotuvchi</th>
                              <th className="p-3 text-right">Amal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#E5ECE7] dark:divide-[#0E3D32]">
                            {filteredLiveItems.map((item) => (
                              <tr key={item.id} className="hover:bg-[#F0F4F1] dark:hover:bg-[#041C16]/60 transition-colors">
                                <td className="p-3">
                                  <div className="flex items-center gap-2.5">
                                    <img
                                      src={item.imageUrl}
                                      alt={item.titleUz}
                                      className="w-10 h-10 rounded-xl object-cover shrink-0 border border-[#E5ECE7] dark:border-[#0E3D32]"
                                    />
                                    <div>
                                      <div className="font-bold text-[#1C2A23] dark:text-white line-clamp-1">{item.titleUz}</div>
                                      <div className="text-[10px] text-stone-500 font-mono">{item.id}</div>
                                    </div>
                                  </div>
                                </td>
                                <td className="p-3 capitalize font-medium text-stone-700 dark:text-stone-300">
                                  {item.department} ({item.breed})
                                </td>
                                <td className="p-3 font-bold text-[#047857] dark:text-[#10B981]">
                                  {item.priceUzs.toLocaleString('uz-UZ')} soʻm
                                </td>
                                <td className="p-3 font-semibold text-[#1C2A23] dark:text-stone-200">
                                  {item.weightKg} kg
                                </td>
                                <td className="p-3 text-stone-600 dark:text-stone-400">
                                  {item.region}
                                </td>
                                <td className="p-3">
                                  {item.vetInfo?.hasVetPassport ? (
                                    <span className="px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#047857] dark:text-[#10B981] text-[10px] font-bold flex items-center gap-1 w-fit">
                                      <CheckCircle2 className="w-3 h-3 text-[#10B981]" />
                                      {item.vetInfo.passportNumber || 'Mavjud'}
                                    </span>
                                  ) : (
                                    <span className="text-stone-400 text-[10px]">Yoʻq</span>
                                  )}
                                </td>
                                <td className="p-3">
                                  <div className="font-medium text-[#1C2A23] dark:text-stone-200">{item.seller?.name || 'Fermer'}</div>
                                  <div className="text-[10px] text-stone-500 font-mono">{item.seller?.phone || '+998 -- --- -- --'}</div>
                                </td>
                                <td className="p-3 text-right">
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteMarketplaceItem(item.id, item.titleUz)}
                                    className="p-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-[#041C16] dark:hover:bg-rose-950/60 text-rose-700 dark:text-rose-400 transition-colors cursor-pointer border border-rose-200 dark:border-rose-900/40"
                                    title="Eʼlonni oʻchirish"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

                {/* SubTab 3: REJECTED LISTINGS */}
                {listingsSubTab === 'rejected' && (
                  <div className="space-y-4">
                    {pendingListings.filter(l => l.status === 'REJECTED').length === 0 ? (
                      <div className="text-center py-12 bg-white dark:bg-[#072D24] rounded-3xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                        <p className="text-xs text-stone-500">Rad etilgan eʼlonlar mavjud emas.</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {pendingListings
                          .filter(l => l.status === 'REJECTED')
                          .map((rej) => (
                            <div key={rej.id} className="p-4 rounded-2xl bg-white dark:bg-[#072D24] border border-rose-300 dark:border-rose-900/50 flex items-center justify-between text-xs shadow-xs">
                              <div>
                                <h5 className="font-bold text-[#1C2A23] dark:text-white">{rej.titleUz}</h5>
                                <p className="text-rose-600 dark:text-rose-400 mt-0.5">
                                  Rad sababi: <strong>{rej.rejectReason || 'Shubhali parametrlar'}</strong>
                                </p>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleApproveListing(rej)}
                                className="px-3.5 py-1.5 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white font-bold text-xs cursor-pointer shadow-xs"
                              >
                                Qayta tasdiqlash
                              </button>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* 3. VETERINARIYA VA PASPORT NAZORATI */}
            {activeMenu === 'vet' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <Shield className="w-5 h-5 text-[#10B981]" />
                      <span>{isUz ? 'Davlat Veterinariya Pasporti & Qurbonlik 2026 Nazorati' : 'Ветпаспорта и Сертификация Курбанлык 2026'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      Oʻzbekiston Davlat Veterinariya qoʻmitasi reyestri va Qurbonlik talablari tekshiruvi
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1.5 rounded-xl bg-[#F59E0B]/15 text-[#D97706] dark:text-[#F59E0B] border border-[#F59E0B]/30 text-xs font-bold flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-[#F59E0B]" />
                      <span>Qurbonlik 2026 Sertifikati: <strong>{certifiedQurbonlikCount} ta</strong></span>
                    </span>
                  </div>
                </div>

                {/* Veterinary Registry Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {vetRegistry.map((vet) => (
                    <div
                      key={vet.id}
                      className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs space-y-4"
                    >
                      {/* Top Header of Vet Card */}
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-[10px] font-mono text-stone-500">{vet.tagNumber}</div>
                          <h4 className="text-sm font-extrabold text-[#1C2A23] dark:text-white">
                            {vet.animalType} ({vet.breed})
                          </h4>
                        </div>
                        <div className="text-right">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${
                            vet.qurbonlikStatus === 'CERTIFIED'
                              ? 'bg-[#10B981]/20 text-[#047857] dark:text-[#10B981] border border-[#10B981]/40'
                              : vet.qurbonlikStatus === 'DISQUALIFIED'
                              ? 'bg-rose-500/20 text-rose-700 dark:text-rose-400 border border-rose-500/40'
                              : 'bg-[#F59E0B]/20 text-[#D97706] dark:text-[#F59E0B] border border-[#F59E0B]/40'
                          }`}>
                            {vet.qurbonlikStatus === 'CERTIFIED' && 'Qurbonlik 2026 Sertifikatlangan'}
                            {vet.qurbonlikStatus === 'DISQUALIFIED' && 'Qurbonlikka loyiq emas'}
                            {vet.qurbonlikStatus === 'PENDING_CHECK' && 'Tekshiruv kutilmoqda'}
                          </span>
                        </div>
                      </div>

                      {/* Detail Stats */}
                      <div className="grid grid-cols-2 gap-2 text-xs bg-[#F0F4F1] dark:bg-[#041C16] p-3 rounded-2xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                        <div>
                          <span className="text-stone-500 text-[10px] block">Pasport raqami:</span>
                          <span className="font-mono font-bold text-[#047857] dark:text-[#10B981]">{vet.passportId}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 text-[10px] block">Egasi / Viloyat:</span>
                          <span className="font-semibold text-[#1C2A23] dark:text-stone-200">{vet.ownerName} ({vet.region})</span>
                        </div>
                        <div>
                          <span className="text-stone-500 text-[10px] block">Vazni & Yoshi:</span>
                          <span className="font-semibold text-[#1C2A23] dark:text-stone-200">{vet.weightKg} kg, {vet.ageMonths} oylik</span>
                        </div>
                        <div>
                          <span className="text-stone-500 text-[10px] block">Veterinar shifokor:</span>
                          <span className="font-semibold text-[#1C2A23] dark:text-stone-200">{vet.vetDoctorName}</span>
                        </div>
                      </div>

                      {/* Vaccine List */}
                      <div>
                        <div className="text-[11px] font-bold text-stone-600 dark:text-stone-400 mb-1.5 flex items-center justify-between">
                          <span>Emlashlar holati:</span>
                          <span className="text-[#047857] dark:text-[#10B981] font-mono text-[10px]">Oxirgi emlash: {vet.lastVaccineDate}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-1.5">
                          {vet.vaccines.map((vac, idx) => (
                            <div
                              key={idx}
                              className={`p-1.5 rounded-xl text-[10px] flex items-center justify-between border ${
                                vac.status === 'ok'
                                  ? 'bg-[#10B981]/15 border-[#10B981]/30 text-[#064E3B] dark:text-[#10B981]'
                                  : 'bg-rose-500/10 border-rose-500/20 text-rose-700 dark:text-rose-400'
                              }`}
                            >
                              <span className="truncate">{vac.name}</span>
                              <span className="font-bold shrink-0">{vac.status === 'ok' ? '✓' : 'Kerak'}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Qurbonlik Checklist Criteria */}
                      <div className="p-3 rounded-2xl bg-[#F0F4F1] dark:bg-[#041C16] border border-[#E5ECE7] dark:border-[#0E3D32] space-y-1.5 text-xs">
                        <div className="font-bold text-[11px] text-[#D97706] dark:text-[#F59E0B] flex items-center gap-1">
                          <Award className="w-3.5 h-3.5" />
                          <span>Qurbonlik mezonlari tekshiruvi:</span>
                        </div>
                        <div className="grid grid-cols-2 gap-1 text-[11px]">
                          <div className={vet.qurbonlikChecks.ageValid ? 'text-[#047857] dark:text-[#10B981]' : 'text-rose-500'}>
                            {vet.qurbonlikChecks.ageValid ? '✓ Yoshi yetgan (>= 1-2 yosh)' : '✗ Yoshi yetmagan'}
                          </div>
                          <div className={vet.qurbonlikChecks.teethHealthy ? 'text-[#047857] dark:text-[#10B981]' : 'text-rose-500'}>
                            {vet.qurbonlikChecks.teethHealthy ? '✓ Tishlari butun' : '✗ Tishlari nuqsonli'}
                          </div>
                          <div className={vet.qurbonlikChecks.hornsAndTailIntact ? 'text-[#047857] dark:text-[#10B981]' : 'text-rose-500'}>
                            {vet.qurbonlikChecks.hornsAndTailIntact ? '✓ Shox/quloq butun' : '✗ Shox/quloq shikast'}
                          </div>
                          <div className={vet.qurbonlikChecks.noLimping ? 'text-[#047857] dark:text-[#10B981]' : 'text-rose-500'}>
                            {vet.qurbonlikChecks.noLimping ? '✓ Oqsoqlanmaydi' : '✗ Oqsoqlik bor'}
                          </div>
                        </div>
                      </div>

                      {/* Action Button: Toggle Qurbonlik 2026 status */}
                      <button
                        type="button"
                        onClick={() => handleToggleQurbonlikStatus(vet.id)}
                        className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs ${
                          vet.qurbonlikStatus === 'CERTIFIED'
                            ? 'bg-rose-100 hover:bg-rose-200 dark:bg-[#041C16] text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-900/60'
                            : 'bg-[#047857] hover:bg-[#064E3B] text-white shadow-[#047857]/30'
                        }`}
                      >
                        <Award className="w-4 h-4 text-[#F59E0B]" />
                        <span>
                          {vet.qurbonlikStatus === 'CERTIFIED'
                            ? 'Qurbonlik Sertifikatini bekor qilish'
                            : 'Rasmiy "Qurbonlik 2026" Statusini berish'}
                        </span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 4. JONLI AUKSIONLARNI BOSHQARISH (Live Auctions Control) */}
            {activeMenu === 'auctions' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <Gavel className="w-5 h-5 text-[#10B981]" />
                      <span>{isUz ? 'Jonli Auksionlar Boshqaruvi (Live Auction Control)' : 'Управление живыми аукционами'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      Boshlangʻich narx, qadam (min step), taymer boshqaruvi va gʻoliblarni tasdiqlash
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                  {auctions.map((auc) => (
                    <div
                      key={auc.id}
                      className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs space-y-4 flex flex-col justify-between"
                    >
                      <div className="space-y-3">
                        {/* Auction Image & Badges */}
                        <div className="relative h-44 rounded-2xl overflow-hidden border border-[#E5ECE7] dark:border-[#0E3D32] bg-[#02100C]">
                          <img
                            src={auc.imageUrl}
                            alt={auc.titleUz}
                            className="w-full h-full object-cover"
                          />
                          <span className={`absolute top-2 left-2 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            auc.status === 'ACTIVE'
                              ? 'bg-[#047857] text-white animate-pulse'
                              : auc.status === 'PAUSED'
                              ? 'bg-[#D97706] text-white'
                              : 'bg-stone-700 text-stone-300'
                          }`}>
                            {auc.status}
                          </span>
                          <span className="absolute bottom-2 right-2 px-2.5 py-1 rounded-xl bg-black/80 backdrop-blur-xs text-white font-mono text-xs font-bold flex items-center gap-1 border border-white/10">
                            <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
                            <span>{auc.timeLeftMinutes} daq qoldi</span>
                          </span>
                        </div>

                        {/* Title & Seller */}
                        <div>
                          <div className="text-[10px] font-mono text-stone-500">{auc.id} • {auc.breed}</div>
                          <h4 className="text-sm font-extrabold text-[#1C2A23] dark:text-white mt-0.5 line-clamp-1">
                            {isUz ? auc.titleUz : auc.titleRu}
                          </h4>
                          <div className="text-xs text-stone-500 mt-0.5">Sotuvchi: {auc.sellerName}</div>
                        </div>

                        {/* Prices & Steps */}
                        <div className="bg-[#F0F4F1] dark:bg-[#041C16] p-3 rounded-2xl border border-[#E5ECE7] dark:border-[#0E3D32] space-y-1.5 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="text-stone-500">Boshlangʻich narx:</span>
                            <span className="font-mono text-[#1C2A23] dark:text-stone-300">{auc.startingPrice.toLocaleString('uz-UZ')} soʻm</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-stone-500">Joriy eng baland stavka:</span>
                            <span className="font-mono font-bold text-[#047857] dark:text-[#10B981] text-sm">
                              {auc.currentBid.toLocaleString('uz-UZ')} soʻm
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-stone-500">Min oshirish qadami:</span>
                            <span className="font-mono font-semibold text-[#D97706] dark:text-[#F59E0B]">+{auc.minStep.toLocaleString('uz-UZ')} soʻm</span>
                          </div>
                          <div className="flex items-center justify-between pt-1 border-t border-[#E5ECE7] dark:border-[#0E3D32]">
                            <span className="text-stone-500">Yetakchi xaridor:</span>
                            <span className="font-bold text-[#1C2A23] dark:text-white">{auc.leadingBidder}</span>
                          </div>
                        </div>

                        {/* Recent Bids Feed */}
                        <div>
                          <div className="text-[11px] font-bold text-stone-600 dark:text-stone-400 mb-1.5">Oxirgi stavkalar ({auc.bidsCount} ta):</div>
                          <div className="space-y-1">
                            {auc.bids.slice(0, 3).map((b) => (
                              <div key={b.id} className="flex items-center justify-between text-[11px] px-2 py-1 rounded-lg bg-[#F0F4F1] dark:bg-[#041C16] text-[#1C2A23] dark:text-stone-300 border border-[#E5ECE7] dark:border-[#0E3D32]">
                                <span>{b.user} ({b.region})</span>
                                <span className="font-mono font-bold text-[#047857] dark:text-[#10B981]">{b.amount.toLocaleString('uz-UZ')} soʻm</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Admin Controls for Auction */}
                      <div className="space-y-2 pt-2 border-t border-[#E5ECE7] dark:border-[#0E3D32]">
                        <div className="grid grid-cols-3 gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleAuctionAddTimer(auc.id, 10)}
                            className="py-1.5 rounded-xl bg-[#F0F4F1] dark:bg-[#041C16] hover:bg-stone-200 dark:hover:bg-[#0E3D32] text-[#1C2A23] dark:text-stone-200 text-[11px] font-bold transition-colors cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                          >
                            +10 daq
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAuctionAddTimer(auc.id, -5)}
                            className="py-1.5 rounded-xl bg-[#F0F4F1] dark:bg-[#041C16] hover:bg-stone-200 dark:hover:bg-[#0E3D32] text-[#1C2A23] dark:text-stone-200 text-[11px] font-bold transition-colors cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                          >
                            -5 daq
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAuctionToggleStatus(auc.id)}
                            className="py-1.5 rounded-xl bg-[#F59E0B]/15 text-[#D97706] dark:text-[#F59E0B] text-[11px] font-bold transition-colors cursor-pointer border border-[#F59E0B]/30"
                          >
                            {auc.status === 'ACTIVE' ? 'Pauza' : 'Davom'}
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleAuctionFinalizeWinner(auc)}
                          className="w-full py-2.5 px-3 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-[#047857]/30"
                        >
                          <Award className="w-4 h-4 text-[#F59E0B]" />
                          <span>Gʻolibni tasdiqlash va auksionni yakunlash</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 5. FURA & TRANSPORT */}
            {activeMenu === 'transport' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <Truck className="w-5 h-5 text-[#10B981]" />
                      <span>{isUz ? 'Viloyatlararo Chorva Furasi va Logistika Boshqaruvi' : 'Транспорт и междугородние рейсы скотовозов'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      100 KM tariflari, ixtisoslashgan chorva mashinalari va yoʻldagi yuklar holati
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  {transportOrders.map((order) => (
                    <div
                      key={order.id}
                      className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                    >
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-[#F0F4F1] dark:bg-[#041C16] text-[#1C2A23] dark:text-stone-300 border border-[#E5ECE7] dark:border-[#0E3D32]">
                            {order.id}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                            order.status === 'IN_TRANSIT'
                              ? 'bg-[#10B981]/15 text-[#047857] dark:text-[#10B981] border border-[#10B981]/30'
                              : order.status === 'DELIVERED'
                              ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-400'
                              : 'bg-amber-500/20 text-amber-700 dark:text-amber-400'
                          }`}>
                            {order.status === 'IN_TRANSIT' && 'Yoʻlda (Yuklangan)'}
                            {order.status === 'DELIVERED' && 'Yetkazildi'}
                            {order.status === 'ASSIGNED' && 'Haydovchi tayinlandi'}
                          </span>
                        </div>

                        <div className="text-sm font-extrabold text-[#1C2A23] dark:text-white flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-[#10B981] shrink-0" />
                          <span>{order.fromRegion}</span>
                          <span className="text-stone-400">→</span>
                          <span>{order.toRegion}</span>
                          <span className="text-xs font-mono text-stone-500">({order.distanceKm} km)</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-stone-600 dark:text-stone-400">
                          <div>Haydovchi: <strong className="text-[#1C2A23] dark:text-stone-200">{order.driverName}</strong> ({order.driverPhone})</div>
                          <div>Mashina: <strong className="text-[#1C2A23] dark:text-stone-200">{order.vehicleType}</strong></div>
                          <div>Yuk: <strong className="text-[#1C2A23] dark:text-stone-200">{order.cargoDescription}</strong></div>
                        </div>
                      </div>

                      <div className="text-left md:text-right shrink-0 space-y-2">
                        <div className="text-lg font-black text-[#047857] dark:text-[#10B981]">
                          {order.priceUzs.toLocaleString('uz-UZ')} soʻm
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleUpdateTransportStatus(order.id, 'DELIVERED')}
                            className="px-3 py-1.5 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
                          >
                            Yetkazildi deb belgilash
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 6. FERMERLAR & FERMALAR (Xo'jaliklar va Chorvadorlar) */}
            {activeMenu === 'users' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <Users className="w-5 h-5 text-[#F59E0B]" />
                      <span>{isUz ? 'Fermerlar va Fermer Xoʻjaliklari Boshqaruvi' : 'Фермеры и животноводческие хозяйства'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      Chorvadorlar, fermer xoʻjaliklari reyestri, davlat veterinarlari va akkreditatsiya nazorati
                    </p>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Sub-tabs: Farmers vs Farms */}
                    <div className="flex items-center bg-[#F0F4F1] dark:bg-[#072D24] p-1 rounded-xl border border-[#E5ECE7] dark:border-[#0E3D32] text-xs font-bold">
                      <button
                        type="button"
                        onClick={() => setUsersSubTab('farmers')}
                        className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                          usersSubTab === 'farmers'
                            ? 'bg-[#047857] text-white shadow-xs'
                            : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                        }`}
                      >
                        <Users className="w-3.5 h-3.5" />
                        <span>{isUz ? 'Fermerlar' : 'Фермеры'}</span>
                        <span className="px-1.5 py-0.2 rounded-full bg-black/25 text-[10px] text-[#F59E0B]">
                          {platformUsers.length}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setUsersSubTab('farms')}
                        className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                          usersSubTab === 'farms'
                            ? 'bg-[#047857] text-white shadow-xs'
                            : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                        }`}
                      >
                        <Layers className="w-3.5 h-3.5" />
                        <span>{isUz ? 'Fermalar (Xoʻjaliklar)' : 'Фермы (Хозяйства)'}</span>
                        <span className="px-1.5 py-0.2 rounded-full bg-black/25 text-[10px] text-[#F59E0B]">
                          {farms.length}
                        </span>
                      </button>
                    </div>

                    {/* Action buttons to Add Farmer or Add Farm */}
                    {usersSubTab === 'farmers' ? (
                      <button
                        type="button"
                        onClick={() => setIsAddFarmerOpen(true)}
                        className="py-2 px-3.5 bg-gradient-to-r from-[#047857] to-[#064E3B] hover:from-[#064E3B] hover:to-[#047857] text-white font-bold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <Plus className="w-4 h-4 text-[#10B981]" />
                        <span>{isUz ? 'Yangi Fermer Qoʻshish' : 'Добавить фермера'}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setIsAddFarmOpen(true)}
                        className="py-2 px-3.5 bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <Plus className="w-4 h-4" />
                        <span>{isUz ? 'Yangi Ferma Qoʻshish' : 'Добавить ферму'}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Subtab 1: Farmers List */}
                {usersSubTab === 'farmers' && (
                  <div className="overflow-x-auto rounded-3xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#F0F4F1] dark:bg-[#031510] text-stone-600 dark:text-stone-400 uppercase text-[10px] font-bold border-b border-[#E5ECE7] dark:border-[#0E3D32]">
                        <tr>
                          <th className="p-3.5">F.I.SH / ID</th>
                          <th className="p-3.5">Roli</th>
                          <th className="p-3.5">Viloyat</th>
                          <th className="p-3.5">Telefon</th>
                          <th className="p-3.5">Ferma nomi</th>
                          <th className="p-3.5">Bitimlar</th>
                          <th className="p-3.5">Reyting</th>
                          <th className="p-3.5">Status</th>
                          <th className="p-3.5 text-right">Amal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#E5ECE7] dark:divide-[#0E3D32]">
                        {platformUsers.map((u) => (
                          <tr key={u.id} className="hover:bg-[#F0F4F1] dark:hover:bg-[#041C16]/60 transition-colors">
                            <td className="p-3.5">
                              <div className="font-bold text-[#1C2A23] dark:text-white">{u.name}</div>
                              <div className="text-[10px] text-stone-500 font-mono">{u.id}</div>
                            </td>
                            <td className="p-3.5">
                              <span className="px-2 py-0.5 rounded-md bg-[#F0F4F1] dark:bg-[#041C16] text-[#1C2A23] dark:text-stone-200 font-semibold text-[11px] border border-[#E5ECE7] dark:border-[#0E3D32]">
                                {u.role}
                              </span>
                            </td>
                            <td className="p-3.5 text-stone-600 dark:text-stone-400">{u.region}</td>
                            <td className="p-3.5 font-mono text-stone-700 dark:text-stone-300">{u.phone}</td>
                            <td className="p-3.5 text-stone-700 dark:text-stone-300 font-medium">
                              {u.farmName || '—'}
                            </td>
                            <td className="p-3.5 font-bold text-[#1C2A23] dark:text-white">{u.dealsCount} ta</td>
                            <td className="p-3.5">
                              <span className="font-bold text-[#D97706] dark:text-[#F59E0B]">★ {u.rating}</span>
                            </td>
                            <td className="p-3.5">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                u.status === 'ACTIVE'
                                  ? 'bg-[#10B981]/15 text-[#047857] dark:text-[#10B981]'
                                  : 'bg-rose-500/20 text-rose-700 dark:text-rose-400'
                              }`}>
                                {u.status}
                              </span>
                            </td>
                            <td className="p-3.5 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setPlatformUsers(prev =>
                                      prev.map(item =>
                                        item.id === u.id
                                          ? { ...item, status: item.status === 'ACTIVE' ? 'BLOCKED' : 'ACTIVE' }
                                          : item
                                      )
                                    );
                                    showToast(isUz ? 'Foydalanuvchi statusi yangilandi' : 'Статус пользователя изменен');
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-[#F0F4F1] dark:bg-[#041C16] hover:bg-stone-200 dark:hover:bg-[#0E3D32] text-[11px] font-bold cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                                >
                                  {u.status === 'ACTIVE' ? 'Bloklash' : 'Faollashtirish'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteFarmer(u.id, u.name)}
                                  className="p-1 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-[#041C16] text-rose-600 dark:text-rose-400 cursor-pointer border border-rose-200 dark:border-rose-900/40"
                                  title="Fermerni oʻchirish"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Subtab 2: Farms (Fermer xoʻjaliklari) List */}
                {usersSubTab === 'farms' && (
                  <div className="overflow-x-auto rounded-3xl border border-[#E5ECE7] dark:border-[#0E3D32]">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#F0F4F1] dark:bg-[#031510] text-stone-600 dark:text-stone-400 uppercase text-[10px] font-bold border-b border-[#E5ECE7] dark:border-[#0E3D32]">
                        <tr>
                          <th className="p-3.5">Ferma Nomi / ID</th>
                          <th className="p-3.5">Rahbar (Fermer)</th>
                          <th className="p-3.5">Hudud</th>
                          <th className="p-3.5">Ixtisoslashuv</th>
                          <th className="p-3.5">Chorva soni</th>
                          <th className="p-3.5">Telefon</th>
                          <th className="p-3.5">Davlat Vet Nazorati</th>
                          <th className="p-3.5">Status</th>
                          <th className="p-3.5 text-right">Amal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#E5ECE7] dark:divide-[#0E3D32]">
                        {farms.map((f) => (
                          <tr key={f.id} className="hover:bg-[#F0F4F1] dark:hover:bg-[#041C16]/60 transition-colors">
                            <td className="p-3.5">
                              <div className="font-bold text-[#1C2A23] dark:text-white flex items-center gap-1.5">
                                <Layers className="w-3.5 h-3.5 text-[#10B981]" />
                                <span>{f.name}</span>
                              </div>
                              <div className="text-[10px] text-stone-500 font-mono">{f.id}</div>
                            </td>
                            <td className="p-3.5 font-semibold text-[#1C2A23] dark:text-stone-200">
                              {f.ownerName}
                            </td>
                            <td className="p-3.5 text-stone-600 dark:text-stone-400">
                              {f.region}, {f.district}
                            </td>
                            <td className="p-3.5">
                              <span className="px-2 py-0.5 rounded-md bg-[#047857]/15 text-[#047857] dark:text-[#10B981] font-bold text-[10px] border border-[#047857]/30">
                                {f.specialization}
                              </span>
                            </td>
                            <td className="p-3.5 font-bold text-[#1C2A23] dark:text-white">
                              {f.livestockCount} bosh
                            </td>
                            <td className="p-3.5 font-mono text-stone-700 dark:text-stone-300">
                              {f.phone}
                            </td>
                            <td className="p-3.5">
                              {f.vetSupervision ? (
                                <span className="px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#047857] dark:text-[#10B981] text-[10px] font-bold flex items-center gap-1 w-fit">
                                  <CheckCircle2 className="w-3 h-3 text-[#10B981]" />
                                  Mavjud (Akkreditlangan)
                                </span>
                              ) : (
                                <span className="text-amber-500 text-[10px]">Jarayonda</span>
                              )}
                            </td>
                            <td className="p-3.5">
                              <span className="px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#047857] dark:text-[#10B981] text-[10px] font-bold">
                                {f.status}
                              </span>
                            </td>
                            <td className="p-3.5 text-right">
                              <button
                                type="button"
                                onClick={() => handleDeleteFarm(f.id, f.name)}
                                className="p-1 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-[#041C16] text-rose-600 dark:text-rose-400 cursor-pointer border border-rose-200 dark:border-rose-900/40"
                                title="Fermani oʻchirish"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* 7. VILOYATLAR NARX INDEKSI & ANALITIKA (Analytics & Charts) */}
            {activeMenu === 'analytics' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-[#10B981]" />
                      <span>{isUz ? 'Oʻzbekistonning 14 ta Hududi Narx Indeksi & Bozor Analitikasi' : 'Индекс цен по 14 регионам Узбекистана'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      Tirik vazn narxi dinamikasi, zotlar boʻyicha oylik grafiklar (Recharts)
                    </p>
                  </div>
                </div>

                {/* 14 Regions Bar Chart */}
                <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-extrabold text-[#1C2A23] dark:text-white">
                        Oʻzbekistonning barcha 14 ta hududida tirik vazn 1 kg narxlari
                      </h4>
                      <p className="text-xs text-stone-500">Yashil: Qoramol (soʻm/kg), Sariq: Qoʻy (soʻm/kg)</p>
                    </div>
                  </div>

                  <div className="h-72 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={regionPriceIndex} margin={{ top: 10, right: 10, left: -10, bottom: 25 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke={currentThemeDark ? '#0E3D32' : '#E5ECE7'} vertical={false} />
                        <XAxis dataKey="region" stroke={currentThemeDark ? '#10B981' : '#78716c'} fontSize={10} tickLine={false} interval={0} angle={-25} textAnchor="end" />
                        <YAxis stroke={currentThemeDark ? '#10B981' : '#78716c'} fontSize={10} domain={[45000, 70000]} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: currentThemeDark ? '#072D24' : '#ffffff',
                            borderColor: currentThemeDark ? '#0E3D32' : '#E5ECE7',
                            borderRadius: '12px',
                            fontSize: '12px',
                            color: currentThemeDark ? '#ECFDF5' : '#1C2A23'
                          }}
                          formatter={(value: any) => [`${Number(value).toLocaleString('uz-UZ')} soʻm/kg`, '']}
                        />
                        <Bar dataKey="qoramolKg" name="Qoramol (kg)" fill="#047857" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="quyKg" name="Qoʻy (kg)" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* 6-Month Breed Dynamics Area Chart */}
                <div className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs space-y-3">
                  <div>
                    <h4 className="text-sm font-extrabold text-[#1C2A23] dark:text-white">
                      Zotlar boʻyicha oylik narx oʻzgarishlari tahlili (ming soʻm / kg)
                    </h4>
                    <p className="text-xs text-stone-500">Golshtin, Hisor, Qorabayir va Shvis zotlari soʻnggi 6 oyda</p>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={breedMonthlyData} margin={{ top: 10, right: 10, left: -10, bottom: 10 }}>
                        <defs>
                          <linearGradient id="colorGolshtin" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#047857" stopOpacity={0.5} />
                            <stop offset="95%" stopColor="#047857" stopOpacity={0} />
                          </linearGradient>
                          <linearGradient id="colorHisor" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.5} />
                            <stop offset="95%" stopColor="#F59E0B" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke={currentThemeDark ? '#0E3D32' : '#E5ECE7'} vertical={false} />
                        <XAxis dataKey="month" stroke={currentThemeDark ? '#10B981' : '#78716c'} fontSize={11} />
                        <YAxis stroke={currentThemeDark ? '#10B981' : '#78716c'} fontSize={11} domain={[35, 75]} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: currentThemeDark ? '#072D24' : '#ffffff',
                            borderColor: currentThemeDark ? '#0E3D32' : '#E5ECE7',
                            borderRadius: '12px',
                            fontSize: '12px',
                            color: currentThemeDark ? '#ECFDF5' : '#1C2A23'
                          }}
                          formatter={(val: any) => [`${val} ming soʻm/kg`, '']}
                        />
                        <Area type="monotone" dataKey="hisor" name="Hisor qoʻylari" stroke="#F59E0B" fillOpacity={1} fill="url(#colorHisor)" />
                        <Area type="monotone" dataKey="golshtin" name="Golshtin qoramoli" stroke="#047857" fillOpacity={1} fill="url(#colorGolshtin)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {/* 8. MOLIYA VA ESKROU (Escrow & Transactions) */}
            {activeMenu === 'escrow' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-[#1C2A23] dark:text-white flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-[#10B981]" />
                      <span>{isUz ? 'Xavfsiz Toʻlovlar (Escrow) & 1.5% Komissiya Nazorati' : 'Безопасные платежи Эскроу и комиссия 1.5%'}</span>
                    </h3>
                    <p className="text-xs text-stone-500">
                      Xaridor puli tushgan, mol yoʻlga chiqqan va sotuvchiga pul oʻtkazib berilgan bitimlar
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-stone-500 block">Platforma komissiyasi tushumi:</span>
                    <span className="text-base font-black text-[#047857] dark:text-[#10B981]">
                      {platformCommission1_5.toLocaleString('uz-UZ')} soʻm (1.5%)
                    </span>
                  </div>
                </div>

                <div className="space-y-4">
                  {escrowDeals.map((deal) => (
                    <div
                      key={deal.id}
                      className="bg-white dark:bg-[#072D24] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                    >
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-stone-500">{deal.orderNumber}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                            deal.status === 'RELEASED'
                              ? 'bg-[#10B981]/20 text-[#047857] dark:text-[#10B981]'
                              : deal.status === 'IN_TRANSIT'
                              ? 'bg-indigo-500/20 text-indigo-700 dark:text-indigo-400'
                              : deal.status === 'DELIVERED'
                              ? 'bg-teal-500/20 text-teal-700 dark:text-teal-400'
                              : 'bg-amber-500/20 text-amber-700 dark:text-amber-400'
                          }`}>
                            {deal.status === 'RELEASED' && 'Sotuvchiga toʻlandi'}
                            {deal.status === 'IN_TRANSIT' && 'Chorva yoʻlda'}
                            {deal.status === 'DELIVERED' && 'Mol yetkazildi'}
                            {deal.status === 'HELD' && 'Pul muzlatilgan (Xavfsiz)'}
                          </span>
                        </div>

                        <h4 className="text-sm font-extrabold text-[#1C2A23] dark:text-white">
                          {deal.animalTitle}
                        </h4>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-stone-600 dark:text-stone-400">
                          <div>Xaridor: <strong className="text-[#1C2A23] dark:text-stone-200">{deal.buyerName}</strong></div>
                          <div>Sotuvchi: <strong className="text-[#1C2A23] dark:text-stone-200">{deal.sellerName}</strong></div>
                          <div>Marshrut: <strong className="text-[#1C2A23] dark:text-stone-200">{deal.route}</strong></div>
                        </div>
                      </div>

                      <div className="text-left md:text-right shrink-0 space-y-2">
                        <div>
                          <div className="text-base font-black text-[#1C2A23] dark:text-white">
                            {deal.amountUzs.toLocaleString('uz-UZ')} soʻm
                          </div>
                          <div className="text-[11px] text-stone-500">
                            Komissiya 1.5%: <strong className="text-[#D97706] dark:text-[#F59E0B]">{deal.feeUzs.toLocaleString('uz-UZ')} soʻm</strong>
                          </div>
                        </div>

                        {deal.status !== 'RELEASED' ? (
                          <button
                            type="button"
                            onClick={() => handleReleaseEscrow(deal.id)}
                            className="px-4 py-2 rounded-xl bg-[#047857] hover:bg-[#064E3B] text-white font-bold text-xs transition-colors cursor-pointer shadow-md shadow-[#047857]/30 flex items-center gap-1.5"
                          >
                            <CreditCard className="w-3.5 h-3.5 text-[#10B981]" />
                            <span>Pulni sotuvchiga oʻtkazish</span>
                          </button>
                        ) : (
                          <span className="text-xs text-[#047857] dark:text-[#10B981] font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
                            <span>Toʻlov yakunlangan</span>
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>

        {/* Reject Reason Modal */}
        {rejectModalItem && (
          <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white dark:bg-[#072D24] text-[#1C2A23] dark:text-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-base flex items-center gap-2 text-rose-600 dark:text-rose-400">
                  <XCircle className="w-5 h-5" />
                  <span>Eʼlonni rad etish sababi</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setRejectModalItem(null)}
                  className="p-1 rounded-lg hover:bg-stone-100 dark:hover:bg-[#041C16] text-stone-400 cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <p className="text-xs text-stone-600 dark:text-stone-300">
                Fermerga nima sababdan eʼlon rad etilgani haqida SMS/bildirishnoma yuboriladi:
              </p>

              <div className="space-y-2">
                {[
                  'Shubhali narx yoki notoʻgʻri parametrlar',
                  'Veterinariya pasport raqami tasdiqlanmadi',
                  'Fotosurat sifati yomon yoki internetdan koʻchirilgan',
                  'Notoʻgʻri kategoriya / zot tanlangan'
                ].map((reason) => (
                  <label
                    key={reason}
                    className="flex items-center gap-2 p-2.5 rounded-xl border border-[#E5ECE7] dark:border-[#0E3D32] text-xs font-medium cursor-pointer hover:bg-[#F0F4F1] dark:hover:bg-[#041C16]"
                  >
                    <input
                      type="radio"
                      name="rejectReason"
                      checked={rejectReasonText === reason}
                      onChange={() => setRejectReasonText(reason)}
                      className="accent-[#047857]"
                    />
                    <span>{reason}</span>
                  </label>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectModalItem(null)}
                  className="px-4 py-2 rounded-xl bg-stone-100 dark:bg-[#041C16] text-xs font-bold border border-[#E5ECE7] dark:border-[#0E3D32]"
                >
                  Bekor qilish
                </button>
                <button
                  type="button"
                  onClick={handleConfirmReject}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Rad etishni tasdiqlash
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 2. ADMIN: YANGI E'LON JOYLASHTIRISH MODALI */}
        {isAddListingOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
            <div className="bg-white dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] space-y-4 my-auto">
              <div className="flex items-center justify-between border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#D97706] to-[#F59E0B] flex items-center justify-center text-white shadow-md">
                    <Plus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base text-[#1C2A23] dark:text-white">
                      {isUz ? 'Platformaga Yangi Eʼlon Joylash' : 'Публикация объявления администратором'}
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      {isUz ? 'Admin nomidan bozorga bevosita tasdiqlangan eʼlon qoʻshish' : 'Прямая публикация на маркетплейс'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAddListingOpen(false)}
                  className="p-1.5 rounded-xl bg-[#F0F4F1] dark:bg-[#072D24] text-stone-400 hover:text-stone-900 dark:hover:text-white cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleAdminCreateListing} className="space-y-3.5 text-xs">
                {/* Title */}
                <div>
                  <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">
                    Eʼlon sarlavhasi (Oʻzbekcha)*:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masalan: Golshtin zotli 2-qorin sogʻin sigir (kuniga 26 litr)"
                    value={adminListingForm.titleUz}
                    onChange={(e) => setAdminListingForm({ ...adminListingForm, titleUz: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none focus:border-[#10B981]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Department */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Yoʻnalish:</label>
                    <select
                      value={adminListingForm.department}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, department: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    >
                      <option value="qoramol">Qoramol</option>
                      <option value="quy">Qoʻy / Echki</option>
                      <option value="ot">Ot</option>
                    </select>
                  </div>

                  {/* Breed */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Zoti:</label>
                    <input
                      type="text"
                      value={adminListingForm.breed}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, breed: e.target.value })}
                      placeholder="Golshtin, Hisor, Qorabayir..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>

                  {/* Gender */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Jinsi:</label>
                    <select
                      value={adminListingForm.gender}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, gender: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    >
                      <option value="sigir">Sigir</option>
                      <option value="buqa">Buqa</option>
                      <option value="buzoq">Buzoq</option>
                      <option value="qoʻchqor">Qoʻchqor</option>
                      <option value="sovliq">Sovliq</option>
                      <option value="aygʻir">Aygʻir</option>
                      <option value="biya">Biya</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Price */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Narxi (UZS)*:</label>
                    <input
                      type="number"
                      required
                      value={adminListingForm.priceUzs}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, priceUzs: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>

                  {/* Weight */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Tirik vazni (kg):</label>
                    <input
                      type="number"
                      value={adminListingForm.weightKg}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, weightKg: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>

                  {/* Region */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Viloyat:</label>
                    <input
                      type="text"
                      value={adminListingForm.region}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, region: e.target.value })}
                      placeholder="Samarqand, Toshkent..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Seller name */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Sotuvchi (Fermer) F.I.SH:</label>
                    <input
                      type="text"
                      value={adminListingForm.sellerName}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, sellerName: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>

                  {/* Seller phone */}
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Aloqa telefoni:</label>
                    <input
                      type="text"
                      value={adminListingForm.sellerPhone}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, sellerPhone: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Vet Passport Number */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Davlat Vet Pasport Raqami:</label>
                    <input
                      type="text"
                      value={adminListingForm.passportNumber}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, passportNumber: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Foto Havolasi (Image URL):</label>
                    <input
                      type="text"
                      value={adminListingForm.imageUrl}
                      onChange={(e) => setAdminListingForm({ ...adminListingForm, imageUrl: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none text-[11px]"
                    />
                  </div>
                </div>

                {/* Submit Actions */}
                <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#E5ECE7] dark:border-[#0E3D32]">
                  <button
                    type="button"
                    onClick={() => setIsAddListingOpen(false)}
                    className="px-4 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#072D24] text-[#1C2A23] dark:text-stone-200 font-bold border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer"
                  >
                    Bekor qilish
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#047857] to-[#064E3B] hover:from-[#064E3B] hover:to-[#047857] text-white font-bold shadow-md shadow-[#047857]/30 cursor-pointer flex items-center gap-1.5 active:scale-95"
                  >
                    <Check className="w-4 h-4 text-[#10B981]" />
                    <span>Eʼlonni Platformaga Joylash</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* 3. ADMIN: YANGI FERMA QO'SHISH MODALI */}
        {isAddFarmOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
            <div className="bg-white dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] space-y-4 my-auto">
              <div className="flex items-center justify-between border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#064E3B] to-[#047857] flex items-center justify-center text-white shadow-md">
                    <Layers className="w-5 h-5 text-[#10B981]" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base text-[#1C2A23] dark:text-white">
                      {isUz ? 'Yangi Fermer Xoʻjaligi (Ferma) Qoʻshish' : 'Регистрация животноводческой фермы'}
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      {isUz ? 'Akkreditatsiyadan oʻtgan agrofirmalar reyestri' : 'Добавление хозяйства в реестр'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAddFarmOpen(false)}
                  className="p-1.5 rounded-xl bg-[#F0F4F1] dark:bg-[#072D24] text-stone-400 hover:text-stone-900 dark:hover:text-white cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleAdminCreateFarm} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">
                    Ferma yoki Xoʻjalik Nomi*:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masalan: Samarqand Nasldor Chorva MCHJ"
                    value={adminFarmForm.name}
                    onChange={(e) => setAdminFarmForm({ ...adminFarmForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none focus:border-[#10B981]"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">
                    Rahbar (Bosh fermer) F.I.SH*:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masalan: Erkinjon Karimov"
                    value={adminFarmForm.ownerName}
                    onChange={(e) => setAdminFarmForm({ ...adminFarmForm, ownerName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Viloyat:</label>
                    <input
                      type="text"
                      value={adminFarmForm.region}
                      onChange={(e) => setAdminFarmForm({ ...adminFarmForm, region: e.target.value })}
                      placeholder="Samarqand, Jizzax..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Tuman:</label>
                    <input
                      type="text"
                      value={adminFarmForm.district}
                      onChange={(e) => setAdminFarmForm({ ...adminFarmForm, district: e.target.value })}
                      placeholder="Pastdargʻom tumani..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Ixtisoslashuv:</label>
                    <select
                      value={adminFarmForm.specialization}
                      onChange={(e) => setAdminFarmForm({ ...adminFarmForm, specialization: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    >
                      <option value="Sut yoʻnalishi">Sut yoʻnalishi</option>
                      <option value="Goʻsht yoʻnalishi">Goʻsht yoʻnalishi</option>
                      <option value="Naslchilik">Naslchilik</option>
                      <option value="Qoʻychilik">Qoʻychilik</option>
                      <option value="Yilqichilik">Yilqichilik</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Chorva bosh soni:</label>
                    <input
                      type="number"
                      value={adminFarmForm.livestockCount}
                      onChange={(e) => setAdminFarmForm({ ...adminFarmForm, livestockCount: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Aloqa Telefoni:</label>
                  <input
                    type="text"
                    value={adminFarmForm.phone}
                    onChange={(e) => setAdminFarmForm({ ...adminFarmForm, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="farmVetCheck"
                    checked={adminFarmForm.vetSupervision}
                    onChange={(e) => setAdminFarmForm({ ...adminFarmForm, vetSupervision: e.target.checked })}
                    className="accent-[#047857] w-4 h-4 rounded"
                  />
                  <label htmlFor="farmVetCheck" className="text-xs text-stone-700 dark:text-stone-300 cursor-pointer font-medium">
                    Davlat veterinariya nazorati va vaktsinatsiya shartnomasi mavjud
                  </label>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#E5ECE7] dark:border-[#0E3D32]">
                  <button
                    type="button"
                    onClick={() => setIsAddFarmOpen(false)}
                    className="px-4 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#072D24] text-[#1C2A23] dark:text-stone-200 font-bold border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer"
                  >
                    Bekor qilish
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold shadow-md shadow-[#F59E0B]/30 cursor-pointer flex items-center gap-1.5 active:scale-95"
                  >
                    <Check className="w-4 h-4" />
                    <span>Fermani Roʻyxatdan Oʻtkazish</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* 4. ADMIN: YANGI FERMER QO'SHISH MODALI */}
        {isAddFarmerOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
            <div className="bg-white dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl border border-[#E5ECE7] dark:border-[#0E3D32] space-y-4 my-auto">
              <div className="flex items-center justify-between border-b border-[#E5ECE7] dark:border-[#0E3D32] pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#064E3B] to-[#047857] flex items-center justify-center text-white shadow-md">
                    <Users className="w-5 h-5 text-[#10B981]" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm sm:text-base text-[#1C2A23] dark:text-white">
                      {isUz ? 'Yangi Fermer (Chorvador) Qoʻshish' : 'Регистрация нового фермера'}
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      {isUz ? 'Tasdiqlangan foydalanuvchilar reyestriga fermer qoʻshish' : 'Добавление пользователя в реестр'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAddFarmerOpen(false)}
                  className="p-1.5 rounded-xl bg-[#F0F4F1] dark:bg-[#072D24] text-stone-400 hover:text-stone-900 dark:hover:text-white cursor-pointer border border-[#E5ECE7] dark:border-[#0E3D32]"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleAdminCreateFarmer} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">
                    Fermer F.I.SH*:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masalan: Rustamjon Olimov"
                    value={adminFarmerForm.name}
                    onChange={(e) => setAdminFarmerForm({ ...adminFarmerForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none focus:border-[#10B981]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Telefon Raqami*:</label>
                    <input
                      type="text"
                      required
                      placeholder="+998 90 123-45-67"
                      value={adminFarmerForm.phone}
                      onChange={(e) => setAdminFarmerForm({ ...adminFarmerForm, phone: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Roli:</label>
                    <select
                      value={adminFarmerForm.role}
                      onChange={(e) => setAdminFarmerForm({ ...adminFarmerForm, role: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    >
                      <option value="Fermer">Fermer</option>
                      <option value="Veterinar">Veterinar</option>
                      <option value="Yirik Xaridor">Yirik Xaridor</option>
                      <option value="Logist">Logist</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Viloyat:</label>
                    <input
                      type="text"
                      value={adminFarmerForm.region}
                      onChange={(e) => setAdminFarmerForm({ ...adminFarmerForm, region: e.target.value })}
                      placeholder="Samarqand, Buxoro..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 dark:text-stone-300 block mb-1">Tegishli Ferma Nomi:</label>
                    <input
                      type="text"
                      value={adminFarmerForm.farmName}
                      onChange={(e) => setAdminFarmerForm({ ...adminFarmerForm, farmName: e.target.value })}
                      placeholder="Masalan: Zomin Chorva FM"
                      className="w-full px-3 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#02100C] border border-[#E5ECE7] dark:border-[#0E3D32] text-[#1C2A23] dark:text-[#ECFDF5] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="farmerVerifyCheck"
                    checked={adminFarmerForm.verified}
                    onChange={(e) => setAdminFarmerForm({ ...adminFarmerForm, verified: e.target.checked })}
                    className="accent-[#047857] w-4 h-4 rounded"
                  />
                  <label htmlFor="farmerVerifyCheck" className="text-xs text-stone-700 dark:text-stone-300 cursor-pointer font-medium">
                    Shaxsiy pasport va telefon orqali tasdiqlangan (Koʻk galochka berish)
                  </label>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#E5ECE7] dark:border-[#0E3D32]">
                  <button
                    type="button"
                    onClick={() => setIsAddFarmerOpen(false)}
                    className="px-4 py-2 rounded-xl bg-[#F0F4F1] dark:bg-[#072D24] text-[#1C2A23] dark:text-stone-200 font-bold border border-[#E5ECE7] dark:border-[#0E3D32] cursor-pointer"
                  >
                    Bekor qilish
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#047857] to-[#064E3B] hover:from-[#064E3B] hover:to-[#047857] text-white font-bold shadow-md shadow-[#047857]/30 cursor-pointer flex items-center gap-1.5 active:scale-95"
                  >
                    <Check className="w-4 h-4 text-[#10B981]" />
                    <span>Fermerni Roʻyxatga Qoʻshish</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

