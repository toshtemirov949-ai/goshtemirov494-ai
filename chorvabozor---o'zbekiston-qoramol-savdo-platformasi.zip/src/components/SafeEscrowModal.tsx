import React, { useState } from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import { X, ShieldCheck, Lock, CheckCircle2, AlertCircle, ArrowRight, CreditCard, Check } from 'lucide-react';

interface SafeEscrowModalProps {
  item: LivestockItem | null;
  language: Language;
  onClose: () => void;
}

export const SafeEscrowModal: React.FC<SafeEscrowModalProps> = ({
  item,
  language,
  onClose,
}) => {
  if (!item) return null;

  const t = translations[language];
  const [escrowStage, setEscrowStage] = useState<1 | 2 | 3 | 4>(1);
  const [paymentProvider, setPaymentProvider] = useState<'payme' | 'click' | 'uzum'>('payme');
  const [isProcessing, setIsProcessing] = useState(false);
  const [disputeMessage, setDisputeMessage] = useState<string | null>(null);

  const price = item.priceUzs;
  const escrowFee = Math.round(price * 0.015); // 1.5% platform commission
  const totalAmount = price + escrowFee;

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('uz-UZ').format(p);
  };

  const handleDeposit = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setEscrowStage(2);
    }, 900);
  };

  const handleDeliver = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setEscrowStage(3);
    }, 700);
  };

  const handleFinalConfirm = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setEscrowStage(4);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col border border-[#E5ECE7] dark:border-[#0E3D32] transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#047857]/30 dark:border-[#0E3D32] bg-gradient-to-r from-[#064E3B] to-[#047857] text-white">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#041C16]/50 flex items-center justify-center border border-[#10B981]/30">
              <Lock className="w-4 h-4 text-[#10B981]" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Xavfsiz Toʻlov (Eskrou Kafolati)
              </h3>
              <p className="text-[11px] text-emerald-100">
                Pulingiz siz hayvonni qabul qilmaguningizcha sotuvchiga oʻtmaydi
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-emerald-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Stepper */}
        <div className="bg-white/80 dark:bg-[#02100C] border-b border-[#E5ECE7] dark:border-[#0E3D32] px-5 py-2.5 flex items-center justify-between text-xs transition-colors">
          <div className={`flex items-center gap-1.5 ${escrowStage >= 1 ? 'text-[#064E3B] dark:text-[#10B981] font-bold' : 'text-stone-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${escrowStage >= 1 ? 'bg-[#047857] text-white' : 'bg-stone-200 dark:bg-[#072D24] text-stone-600 dark:text-stone-300'}`}>
              1
            </span>
            <span>Depozit</span>
          </div>
          <span className="text-stone-300 dark:text-stone-600">→</span>
          <div className={`flex items-center gap-1.5 ${escrowStage >= 2 ? 'text-emerald-900 dark:text-emerald-300 font-bold' : 'text-stone-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${escrowStage >= 2 ? 'bg-emerald-800 text-white' : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'}`}>
              2
            </span>
            <span>Yetkazish</span>
          </div>
          <span className="text-stone-300 dark:text-stone-600">→</span>
          <div className={`flex items-center gap-1.5 ${escrowStage >= 3 ? 'text-emerald-900 dark:text-emerald-300 font-bold' : 'text-stone-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${escrowStage >= 3 ? 'bg-emerald-800 text-white' : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'}`}>
              3
            </span>
            <span>Koʻrik</span>
          </div>
          <span className="text-stone-300 dark:text-stone-600">→</span>
          <div className={`flex items-center gap-1.5 ${escrowStage >= 4 ? 'text-emerald-900 dark:text-emerald-300 font-bold' : 'text-stone-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${escrowStage >= 4 ? 'bg-emerald-800 text-white' : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'}`}>
              4
            </span>
            <span>Yakun</span>
          </div>
        </div>

        {/* Stage Content */}
        <div className="p-5 sm:p-6 space-y-4">
          {/* Summary of chosen cattle */}
          <div className="bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl p-3 flex items-center gap-3 transition-colors">
            <img
              src={item.imageUrl}
              alt={item.titleUz}
              className="w-14 h-14 object-cover rounded-lg border border-stone-200 dark:border-stone-700 shrink-0"
            />
            <div className="min-w-0 flex-1">
              <h4 className="text-xs sm:text-sm font-bold text-stone-900 dark:text-white truncate">
                {language === 'uz' ? item.titleUz : item.titleRu}
              </h4>
              <div className="text-[11px] text-stone-500 dark:text-stone-400 font-mono">
                {item.breed} · {item.weightKg} kg · {item.region}
              </div>
              <div className="text-xs font-bold text-emerald-900 dark:text-emerald-400 font-mono mt-0.5">
                {formatPrice(item.priceUzs)} soʻm
              </div>
            </div>
          </div>

          {/* STAGE 1: Deposit */}
          {escrowStage === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-2">
                  Toʻlov tizimini tanlang:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentProvider('payme')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      paymentProvider === 'payme'
                        ? 'border-cyan-600 bg-cyan-50/50 dark:bg-cyan-950/60 text-cyan-950 dark:text-cyan-200 font-bold ring-1 ring-cyan-600'
                        : 'border-stone-200 dark:border-stone-750 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300'
                    }`}
                  >
                    <div className="font-extrabold text-sm text-cyan-700 dark:text-cyan-400">Payme</div>
                    <div className="text-[10px] text-stone-500 dark:text-stone-400">Hamyon / Karta</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentProvider('click')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      paymentProvider === 'click'
                        ? 'border-sky-600 bg-sky-50/50 dark:bg-sky-950/60 text-sky-950 dark:text-sky-200 font-bold ring-1 ring-sky-600'
                        : 'border-stone-200 dark:border-stone-750 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300'
                    }`}
                  >
                    <div className="font-extrabold text-sm text-sky-700 dark:text-sky-400">Click Up</div>
                    <div className="text-[10px] text-stone-500 dark:text-stone-400">Karta / QR-kod</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentProvider('uzum')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      paymentProvider === 'uzum'
                        ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/60 text-purple-950 dark:text-purple-200 font-bold ring-1 ring-purple-600'
                        : 'border-stone-200 dark:border-stone-750 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300'
                    }`}
                  >
                    <div className="font-extrabold text-sm text-purple-700 dark:text-purple-400">Uzum Bank</div>
                    <div className="text-[10px] text-stone-500 dark:text-stone-400">Nasiya / Karta</div>
                  </button>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200 text-xs space-y-2 font-mono">
                <div className="flex justify-between text-stone-600 font-sans">
                  <span>Hayvon narxi:</span>
                  <span className="font-mono font-semibold text-stone-900">{formatPrice(price)} soʻm</span>
                </div>
                <div className="flex justify-between text-stone-600 font-sans">
                  <span>Eskrou xavfsizlik toʻlovi (1.5%):</span>
                  <span className="font-mono font-semibold text-stone-900">{formatPrice(escrowFee)} soʻm</span>
                </div>
                <div className="pt-2 border-t border-stone-200 flex justify-between text-sm font-bold text-stone-900 font-sans">
                  <span>Jami muzlatiladigan depozit:</span>
                  <span className="font-mono text-emerald-900 text-base">{formatPrice(totalAmount)} soʻm</span>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs text-emerald-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <p>
                  Mablagʻingiz ChorvaBozor akkreditiv depozitida xavfsiz muzlatiladi. Fermer pulni koʻradi, lekin faqat siz molni qabul qilib olganingizdan keyin unga yechib beriladi.
                </p>
              </div>

              <button
                type="button"
                disabled={isProcessing}
                onClick={handleDeposit}
                className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? 'Toʻlov bajarilmoqda...' : `Depozit qilish (${formatPrice(totalAmount)} soʻm)`}
              </button>
            </div>
          )}

          {/* STAGE 2: Transport & In Transit */}
          {escrowStage === 2 && (
            <div className="space-y-4 text-center py-2">
              <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-800">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div>
                <h4 className="text-base font-bold text-stone-900">
                  Depozit Muvaffaqiyatli Muzlatildi!
                </h4>
                <p className="text-xs text-stone-600 max-w-sm mx-auto mt-1">
                  Fermer {item.seller.name} ga xabar yuborildi. Hayvon veterinariya guvohnomasi bilan transportga yuklanmoqda.
                </p>
              </div>

              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 text-xs text-left font-mono space-y-1">
                <div className="text-stone-500 font-sans">Eskrou Bitim Raqami:</div>
                <div className="font-bold text-stone-900">#ESC-UZ-{Math.floor(100000 + Math.random() * 900000)}</div>
                <div className="text-stone-500 font-sans pt-1">Yetkazib beruvchi fermer:</div>
                <div className="font-bold text-stone-900 font-sans">{item.seller.name} ({item.seller.phone})</div>
              </div>

              <button
                type="button"
                disabled={isProcessing}
                onClick={handleDeliver}
                className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-sm rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Hayvon manzilga yetib keldi (Koʻrikka oʻtish)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STAGE 3: Inspection & Acceptance */}
          {escrowStage === 3 && (
            <div className="space-y-4">
              <div className="text-center">
                <h4 className="text-base font-bold text-stone-900">
                  Hayvonni Joyida Tekshiring
                </h4>
                <p className="text-xs text-stone-600">
                  Quyidagi parametrlar eʼlondagi maʼlumotlarga toʻliq mos kelishiga ishonch hosil qiling:
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <label className="flex items-center gap-2.5 p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                  <input type="checkbox" defaultChecked className="rounded text-emerald-700 w-4 h-4" />
                  <span className="font-medium text-stone-800">
                    Tarozi vazni tasdiqlandi (~{item.weightKg} kg)
                  </span>
                </label>
                <label className="flex items-center gap-2.5 p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                  <input type="checkbox" defaultChecked className="rounded text-emerald-700 w-4 h-4" />
                  <span className="font-medium text-stone-800">
                    Quloq birkasi va Vet pasport ({item.vetInfo.passportNumber}) asl nusxasi topshirildi
                  </span>
                </label>
                <label className="flex items-center gap-2.5 p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                  <input type="checkbox" defaultChecked className="rounded text-emerald-700 w-4 h-4" />
                  <span className="font-medium text-stone-800">
                    Hayvon sogʻlom, nuqson yoki kasallik alomati yoʻq
                  </span>
                </label>
              </div>

              {disputeMessage && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-semibold">
                  {disputeMessage}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setDisputeMessage('Nizo arizasi qabul qilindi. Operator siz va sotuvchi bilan 15 daqiqada bogʻlanib, mablagʻni qaytaradi.');
                  }}
                  className="py-2.5 px-3 border border-rose-300 bg-rose-50 text-rose-800 text-xs font-bold rounded-xl hover:bg-rose-100 transition-colors cursor-pointer"
                >
                  Muammo bor / Pulni qaytarish
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleFinalConfirm}
                  className="py-2.5 px-3 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow-xs"
                >
                  {isProcessing ? 'Tasdiqlanmoqda...' : 'Qabul qildim (Pulni oʻtkazish)'}
                </button>
              </div>
            </div>
          )}

          {/* STAGE 4: Completion */}
          {escrowStage === 4 && (
            <div className="space-y-4 text-center py-4">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-800 mb-2">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>
              <h4 className="text-lg font-bold text-stone-900">
                Bitim Muvaffaqiyatli Yakunlandi!
              </h4>
              <p className="text-xs text-stone-600 max-w-sm mx-auto">
                Mablagʻ ({formatPrice(item.priceUzs)} soʻm) sotuvchi {item.seller.name} ning hisobiga oʻtkazildi. Davlat veterinariya tizimida hayvon sizning nomingizga rasmiylashtirildi.
              </p>

              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-6 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                {t.close}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
