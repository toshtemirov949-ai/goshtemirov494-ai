import React, { useState, useEffect } from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import {
  X,
  Heart,
  MessageCircle,
  Share2,
  Phone,
  Volume2,
  VolumeX,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Lock,
  Music,
  Send,
  Sparkles,
  Award,
} from 'lucide-react';

interface LivestockReelsModalProps {
  items: LivestockItem[];
  initialIndex?: number;
  language: Language;
  onClose: () => void;
  onStartEscrow: (item: LivestockItem) => void;
}

export const LivestockReelsModal: React.FC<LivestockReelsModalProps> = ({
  items,
  initialIndex = 0,
  language,
  onClose,
  onStartEscrow,
}) => {
  const t = translations[language];
  // Filter items that have video or all items as reel showcases
  const reelItems = items.filter((it) => it.hasVideo).length > 0 ? items.filter((it) => it.hasVideo) : items;

  const [currentIndex, setCurrentIndex] = useState(
    initialIndex < reelItems.length ? initialIndex : 0
  );
  const [isMuted, setIsMuted] = useState(false);
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [likesCountMap, setLikesCountMap] = useState<Record<string, number>>(() => {
    const map: Record<string, number> = {};
    reelItems.forEach((it) => {
      map[it.id] = it.likesCount || 24;
    });
    return map;
  });

  const currentItem = reelItems[currentIndex] || reelItems[0];

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('uz-UZ').format(p);
  };

  const handleNext = () => {
    if (currentIndex < reelItems.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setCurrentIndex(0); // loop
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    } else {
      setCurrentIndex(reelItems.length - 1);
    }
  };

  const toggleLike = (id: string) => {
    setLikedMap((prev) => {
      const isCurrentlyLiked = !!prev[id];
      const nextLiked = !isCurrentlyLiked;
      setLikesCountMap((c) => ({
        ...c,
        [id]: (c[id] || 0) + (nextLiked ? 1 : -1),
      }));
      return { ...prev, [id]: nextLiked };
    });
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') handleNext();
      if (e.key === 'ArrowUp') handlePrev();
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, reelItems.length]);

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-0 sm:p-4 select-none">
      {/* Top Close Button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-50 p-2.5 rounded-full bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm transition-colors cursor-pointer"
        title="Yopish (Esc)"
      >
        <X className="w-5 h-5" />
      </button>

      {/* Reel Container (Instagram / TikTok aspect ratio 9:16) */}
      <div className="relative w-full max-w-[420px] h-[100dvh] sm:h-[88vh] bg-stone-950 sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between border border-stone-800">
        {/* Background Visual Layer */}
        <div className="absolute inset-0 z-0">
          <img
            src={currentItem.imageUrl}
            alt={currentItem.titleUz}
            className="w-full h-full object-cover object-center filter brightness-[0.85]"
          />
          {/* Gradients for readability */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/90 pointer-events-none" />
        </div>

        {/* Top Floating Bar */}
        <div className="relative z-10 p-4 pt-5 flex items-center justify-between text-white text-xs">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-600/90 backdrop-blur-xs text-white px-2.5 py-1 rounded-full font-bold text-[11px] flex items-center gap-1 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span>Dinamik Reels ({currentIndex + 1}/{reelItems.length})</span>
            </span>

            {currentItem.vetInfo?.hasVetPassport && (
              <span className="bg-emerald-950/80 border border-emerald-400/50 text-emerald-300 px-2 py-0.5 rounded-full text-[10px] font-medium flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>Vet Pasport</span>
              </span>
            )}
          </div>

          {/* Sound Toggle */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-full bg-black/50 backdrop-blur-xs hover:bg-black/70 text-white transition-colors cursor-pointer"
            title={isMuted ? 'Ovozni yoqish' : 'Ovozni oʻchirish'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-stone-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>

        {/* Navigation Arrows for Desktop */}
        <div className="hidden sm:flex absolute right-[-56px] top-1/2 -translate-y-1/2 flex-col gap-3 z-30">
          <button
            onClick={handlePrev}
            className="p-3 rounded-full bg-stone-800 hover:bg-stone-700 text-white transition-colors cursor-pointer shadow-lg"
            title="Oldingi video (Tepa strelka)"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="p-3 rounded-full bg-stone-800 hover:bg-stone-700 text-white transition-colors cursor-pointer shadow-lg"
            title="Keyingi video (Pastki strelka)"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        </div>

        {/* Right Side Social Action Column */}
        <div className="absolute right-3 bottom-28 z-20 flex flex-col items-center gap-4 text-white">
          {/* Like */}
          <button
            onClick={() => toggleLike(currentItem.id)}
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md transition-all ${
              likedMap[currentItem.id]
                ? 'bg-rose-600 text-white scale-110'
                : 'bg-black/50 text-white hover:bg-black/70'
            }`}>
              <Heart className={`w-5 h-5 ${likedMap[currentItem.id] ? 'fill-white' : ''}`} />
            </div>
            <span className="text-[11px] font-mono font-bold drop-shadow">
              {likesCountMap[currentItem.id] || 24}
            </span>
          </button>

          {/* Telegram Share */}
          <a
            href={`https://t.me/share/url?url=https://chorvabozor.uz/listing/${currentItem.id}&text=${encodeURIComponent(
              `${currentItem.titleUz} - ${formatPrice(currentItem.priceUzs)} so'm. ChorvaBozor orqali to'g'ridan-to'g'ri fermerdan oling!`
            )}`}
            target="_blank"
            rel="noreferrer"
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className="w-11 h-11 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center backdrop-blur-md transition-all text-sky-400">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-medium drop-shadow">Ulashish</span>
          </a>

          {/* Call Seller */}
          <a
            href={`tel:${currentItem.seller.phone}`}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="w-11 h-11 rounded-full bg-emerald-600 hover:bg-emerald-500 flex items-center justify-center backdrop-blur-md transition-all text-white shadow-lg">
              <Phone className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-medium drop-shadow">Aloqa</span>
          </a>
        </div>

        {/* Bottom Details Overlay */}
        <div className="relative z-10 p-4 pb-6 space-y-3 text-white max-w-[82%]">
          {/* Farmer Info */}
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-bold ring-2 ring-white/50">
              {currentItem.seller.name.charAt(0)}
            </div>
            <div className="truncate">
              <span className="font-bold text-xs flex items-center gap-1 truncate">
                <span>{currentItem.seller.name}</span>
                {currentItem.seller.isPassportVerified && (
                  <span title="Tasdiqlangan fermer" className="text-emerald-400">✓</span>
                )}
              </span>
              <span className="text-[10px] text-stone-300 block truncate">
                {currentItem.seller.farmName} · {currentItem.region}
              </span>
            </div>
          </div>

          {/* Title & Key Specs Badge */}
          <div>
            <h3 className="text-sm font-bold text-white line-clamp-2 drop-shadow leading-snug">
              {language === 'uz' ? currentItem.titleUz : currentItem.titleRu}
            </h3>

            <div className="flex flex-wrap items-center gap-2 text-xs font-mono mt-1.5 text-stone-200">
              <span className="bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-[11px] font-bold text-amber-300">
                {currentItem.weightKg} kg
              </span>
              <span className="bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-[11px]">
                {currentItem.breed}
              </span>
              {currentItem.dailyMilkYieldLiters && (
                <span className="bg-emerald-950/80 text-emerald-300 px-2 py-0.5 rounded text-[11px]">
                  {currentItem.dailyMilkYieldLiters} L sut
                </span>
              )}
            </div>
          </div>

          {/* Trending Music Simulator Track */}
          <div className="flex items-center gap-1.5 text-[10px] text-stone-300 font-mono">
            <Music className="w-3 h-3 text-emerald-400 animate-spin" style={{ animationDuration: '4s' }} />
            <span className="truncate">
              {isMuted ? 'Ovoz oʻchirilgan' : 'Trend musiqasi: Milliy Chorva Ritm (Baxshi & Modern Beat)'}
            </span>
          </div>

          {/* Price & Escrow Buy Bar */}
          <div className="pt-2 flex items-center gap-2.5">
            <div className="bg-black/75 backdrop-blur-md px-3 py-2 rounded-xl font-mono">
              <span className="text-base font-extrabold text-amber-400 tabular-nums">
                {formatPrice(currentItem.priceUzs)}
              </span>
              <span className="text-[10px] text-stone-300 ml-1">soʻm</span>
            </div>

            <button
              onClick={() => {
                onClose();
                onStartEscrow(currentItem);
              }}
              className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg transition-colors cursor-pointer truncate"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-200" />
              <span>Xavfsiz Xarid</span>
            </button>
          </div>
        </div>

        {/* Swipe / Next hint (bottom animated line) */}
        <div
          onClick={handleNext}
          className="absolute bottom-0 inset-x-0 h-3 bg-white/20 hover:bg-white/40 cursor-pointer transition-colors"
          title="Keyingi videoga oʻtish"
        />
      </div>
    </div>
  );
};
