import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Truck,
  ChevronLeft,
  ChevronRight,
  Gift,
  Zap,
  Tag,
  Percent,
  Check,
  Gavel,
  Award
} from 'lucide-react';
import { Language } from '../types';

export interface PromoSlide {
  id: string;
  badge: string;
  badgeColor: string;
  title: string;
  subtitle: string;
  image: string;
  tariffTitle: string;
  oldPrice: string;
  newPrice: string;
  tariffPoints: string[];
  ctaLabel: string;
  ctaAction: 'catalog' | 'qurbonlik' | 'add_listing' | 'reels' | 'transport';
}

export const promoSlides: PromoSlide[] = [
  {
    id: 'slide-transport-fura',
    badge: 'LOGISTIKA & FURA: 100 KM BEPUL',
    badgeColor: 'bg-amber-400 text-stone-950',
    title: 'Maxsus Chorvavoz Fura Bilan Bepul Yetkazib Berish',
    subtitle: 'Velosiped emas! Katta qoramol va qoʻylar uchun 2 qavatli, shamollatish tizimiga ega maxsus ogʻir yuk furasida eshikkacha xavfsiz yetkazish.',
    image: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1200&q=85', // Haqiqiy og'ir yuk fura
    tariffTitle: '«Maxsus Chorvavoz Fura» Tarifi',
    oldPrice: '850 000 soʻm',
    newPrice: '0 soʻm (TEKIN)',
    tariffPoints: [
      '100 km masofagacha professional fura bepul',
      'Maxsus sirpanmaydigan pol va xavfsiz metall toʻsiqlar',
      'Yoʻlda hayvon toʻliq davlat sugʻurtasi bilan himoyalangan',
      'Promokod: #FURA_TEKIN (avtomatik chegiriladi)'
    ],
    ctaLabel: 'Mollarni Tanlash (Katalog)',
    ctaAction: 'catalog'
  },
  {
    id: 'slide-qurbonlik',
    badge: 'QURBONLIK 2026 BRON DASTURI',
    badgeColor: 'bg-emerald-500 text-white',
    title: 'Shariatga Muvofiq Qurbonlik: 30% Arzon Bron Qilish',
    subtitle: 'Hayit kunidagi 30-40% narx oshishi va bozor tirbandligidan xoli boʻling. Tish yorgan, semiz Hisor qoʻylari uyingizgacha yetkaziladi.',
    image: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=1200&q=85',
    tariffTitle: '«Qurbonlik Kafolati & Fura» Tarifi',
    oldPrice: '4 800 000 soʻm',
    newPrice: '3 200 000 soʻmdan',
    tariffPoints: [
      'Yoshi va tishi video bilan tasdiqlangan',
      'Halol kushxona va nimtalash: 0 soʻm (BEPUL)',
      'Hayit kuni tongda maxsus furgonda toza yetkazish',
      'Oldindan toʻlovsiz bepul bron qilish'
    ],
    ctaLabel: 'Qurbonlikni Bron Qilish',
    ctaAction: 'qurbonlik'
  },
  {
    id: 'slide-farmer-vip',
    badge: 'FERMERLARGA 0% VA VIP REKLAMA',
    badgeColor: 'bg-blue-600 text-white',
    title: 'Molingizni 2 Barobar Tez va Qimmat Sotish Paketi',
    subtitle: 'Platformamizga yangi qoʻshilgan har bir chorvador va fermer uchun 1 oy bepul VIP reklama va Telegram bot tarmogʻida eʼlon berish.',
    image: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=1200&q=85',
    tariffTitle: '«Fermer Startap VIP» Tarifi',
    oldPrice: '450 000 soʻm/oy',
    newPrice: '0 soʻm (1 Oy Sovgʻa)',
    tariffPoints: [
      'Cheksiz eʼlon joylashtirish (0% komissiya)',
      'Katalogning eng yuqori pogʻonasida VIP koʻrsatish',
      'Telegram @ChorvaBozor_bot da avtomatik reklama',
      'Oltin sotuvchi qoʻllanmasi va AI yordamchi'
    ],
    ctaLabel: 'Bepul Eʼlon Berish',
    ctaAction: 'add_listing'
  },
  {
    id: 'slide-escrow',
    badge: '100% XAVFSIZ SAVDO (ESKROU)',
    badgeColor: 'bg-purple-600 text-white',
    title: 'Xavfsiz Toʻlov Kafolati: Pul Platformada Muzlatiladi',
    subtitle: 'Hayvon fura bilan manzilingizga kelib, koʻzingiz bilan koʻrib, sogʻlomligini qabul qilib olmaguningizcha pul sotuvchiga oʻtmaydi.',
    image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=1200&q=85', // Yaylovdagi semiz qoramollar
    tariffTitle: '«Eskrou Xavfsizlik Kafolati» Tarifi',
    oldPrice: '3% bank toʻlovi',
    newPrice: 'Atigi 1% (Bitimdan keyin)',
    tariffPoints: [
      'Hayvon mos kelmasa — 100% pulni qaytarish',
      'Davlat veterinariya inspeksiyasi nazorati',
      'Elektron tarozi dalolatnomasi bilan tekshiruv',
      '24/7 yuridik qoʻllab-quvvatlash xizmati'
    ],
    ctaLabel: 'Dinamik Video Koʻrik (Reels)',
    ctaAction: 'reels'
  },
  {
    id: 'slide-auction',
    badge: 'JONLI ONLAYN AUKSION 2026',
    badgeColor: 'bg-rose-600 text-white',
    title: 'Nasldor Elita Mollarni 20% Arzon Yutib Oling',
    subtitle: 'Golshtin buqachalari, Hisor rekord qoʻchqorlari va Qorabayir chopqir otlari shaffof ochiq auksionda eng maʼqul narxda sotiladi.',
    image: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=1200&q=85', // Qorabayir zotli chopqir ayg'ir
    tariffTitle: '«Ochiq Savdo — Start Narx» Tarifi',
    oldPrice: 'Bozor ustamasi: +25%',
    newPrice: 'Start narxdan boshlanadi',
    tariffPoints: [
      'Shaffof elektron stavkalar tizimi',
      'Naslchilik xoʻjaliklarining asl sertifikatlari',
      'Gʻolib boʻlganingizda bepul yetkazish kuponi',
      'Har kuni soat 18:00 da yangi partiyalar'
    ],
    ctaLabel: 'Auksionlarni Koʻrish',
    ctaAction: 'catalog'
  },
  {
    id: 'slide-vet',
    badge: 'DAVLAT VET XIZMATI: BEPUL',
    badgeColor: 'bg-emerald-600 text-white',
    title: '100% Sogʻlom Hayvon: Rasmiy Vet Pasport Sovgʻa',
    subtitle: 'Har bir xarid qilingan hayvon davlat veterinarlari tomonidan toʻliq koʻrikdan oʻtkaziladi, qon tahlillari va vaksinalari tekshiriladi.',
    image: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=1200&q=85', // Veterinariya koʻrigidan oʻtgan sogʻlom qoramol
    tariffTitle: '«Yashil Pasport Kafolati» Tarifi',
    oldPrice: '180 000 soʻm',
    newPrice: '0 soʻm (MUTLAQO BEPUL)',
    tariffPoints: [
      'Kuydirgi, oqsil va brutsellozga qarshi emlash',
      'Quloq birkasi va davlat reyestrida roʻyxatdan oʻtkazish',
      'Elektron tarozi dalolatnomasi beriladi',
      'Yoʻl varaqasi (Veterinariya guvohnomasi №1)'
    ],
    ctaLabel: 'Katalogni Koʻrish',
    ctaAction: 'catalog'
  }
];

interface ModernWelcomePromoModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onOpenQurbonlik: () => void;
  onOpenAddListing: () => void;
  onOpenReels?: () => void;
}

export const ModernWelcomePromoModal: React.FC<ModernWelcomePromoModalProps> = ({
  isOpen,
  onClose,
  language,
  onOpenQurbonlik,
  onOpenAddListing,
  onOpenReels,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [dontShowAgain, setDontShowAgain] = useState(false);

  // Auto-rotate slides every 4.5 seconds unless paused by mouse hover
  useEffect(() => {
    if (!isOpen || isPaused) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % promoSlides.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [isOpen, isPaused]);

  if (!isOpen) return null;

  const currentSlide = promoSlides[currentSlideIndex];

  const handleClose = () => {
    if (dontShowAgain) {
      try {
        localStorage.setItem('chorvabozor_promo_dismissed_date', new Date().toDateString());
      } catch (e) {
        // ignore
      }
    }
    onClose();
  };

  const handleCtaClick = () => {
    handleClose();
    if (currentSlide.ctaAction === 'qurbonlik') {
      onOpenQurbonlik();
    } else if (currentSlide.ctaAction === 'add_listing') {
      onOpenAddListing();
    } else if (currentSlide.ctaAction === 'reels' && onOpenReels) {
      onOpenReels();
    } else {
      const el = document.getElementById('catalog');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-300">
      <div
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        className="bg-white dark:bg-stone-900 w-full max-w-2xl rounded-3xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden my-6 relative flex flex-col"
      >
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-stone-900/60 hover:bg-stone-900 text-white backdrop-blur-md transition-all cursor-pointer shadow-lg"
          title="Yopish"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Carousel Visual Area with Switching Slides */}
        <div className="relative h-60 sm:h-72 w-full overflow-hidden bg-emerald-950">
          <img
            key={currentSlide.id}
            src={currentSlide.image}
            alt={currentSlide.title}
            className="w-full h-full object-cover object-center brightness-[0.75] contrast-[1.05] animate-in fade-in zoom-in-95 duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />

          {/* Top Tag Badges & Auto-Timer Progress */}
          <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2">
            <span
              className={`px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase shadow-md flex items-center gap-1.5 ${currentSlide.badgeColor}`}
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              {currentSlide.badge}
            </span>
            <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/20 text-white backdrop-blur-md border border-white/20">
              {currentSlideIndex + 1} / {promoSlides.length}
            </span>
          </div>

          {/* Overlay Headline on image */}
          <div className="absolute bottom-4 left-4 right-4 z-10 text-white">
            <h2 className="text-xl sm:text-2xl font-black font-serif tracking-tight leading-snug drop-shadow-md">
              {currentSlide.title}
            </h2>
            <p className="text-xs sm:text-sm text-stone-200 line-clamp-2 mt-1 drop-shadow-xs font-normal">
              {currentSlide.subtitle}
            </p>
          </div>

          {/* Arrow navigation buttons */}
          <button
            type="button"
            onClick={() =>
              setCurrentSlideIndex((prev) => (prev - 1 + promoSlides.length) % promoSlides.length)
            }
            className="absolute left-2.5 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-xs transition-all cursor-pointer"
            title="Oldingi aksiya"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() =>
              setCurrentSlideIndex((prev) => (prev + 1) % promoSlides.length)
            }
            className="absolute right-2.5 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-xs transition-all cursor-pointer"
            title="Keyingi aksiya"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Slide Indicator Dots on image bottom */}
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1.5">
            {promoSlides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentSlideIndex(idx)}
                className={`h-1.5 rounded-full transition-all cursor-pointer ${
                  currentSlideIndex === idx ? 'w-6 bg-amber-400' : 'w-1.5 bg-white/50 hover:bg-white'
                }`}
                title={`Aksiya ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Tariff Card Body */}
        <div className="p-5 sm:p-6 space-y-4 bg-stone-50 dark:bg-stone-900">
          {/* Active Tariff Price & Savings Box */}
          <div className="bg-white dark:bg-stone-850 p-4 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xs flex items-center justify-between gap-3 flex-wrap">
            <div>
              <div className="text-[11px] font-bold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider mb-0.5">
                Rasmiy Maxsus Tarif
              </div>
              <h3 className="font-extrabold text-stone-900 dark:text-white text-base">
                {currentSlide.tariffTitle}
              </h3>
            </div>

            <div className="text-right">
              <span className="text-xs text-stone-400 line-through mr-2 font-mono">
                {currentSlide.oldPrice}
              </span>
              <span className="text-lg sm:text-xl font-black text-amber-700 dark:text-amber-400 font-mono">
                {currentSlide.newPrice}
              </span>
            </div>
          </div>

          {/* Tariff Benefits list */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {currentSlide.tariffPoints.map((pt, i) => (
              <div
                key={i}
                className="flex items-center gap-2 p-2 rounded-xl bg-white dark:bg-stone-850 border border-stone-100 dark:border-stone-800 text-stone-700 dark:text-stone-300"
              >
                <div className="w-4 h-4 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                </div>
                <span className="font-medium">{pt}</span>
              </div>
            ))}
          </div>

          {/* Action Footer */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-stone-200 dark:border-stone-800">
            <label className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={dontShowAgain}
                onChange={(e) => setDontShowAgain(e.target.checked)}
                className="w-4 h-4 rounded border-stone-300 text-emerald-700 focus:ring-emerald-600"
              />
              <span>Bugun qayta koʻrsatilmasin</span>
            </label>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={handleClose}
                className="flex-1 sm:flex-initial px-4 py-2.5 text-xs font-semibold rounded-xl bg-stone-200 dark:bg-stone-800 hover:bg-stone-300 text-stone-800 dark:text-stone-200 transition-colors cursor-pointer"
              >
                Yopish
              </button>

              <button
                type="button"
                onClick={handleCtaClick}
                className="flex-1 sm:flex-initial px-5 py-2.5 text-xs font-bold rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>{currentSlide.ctaLabel}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
