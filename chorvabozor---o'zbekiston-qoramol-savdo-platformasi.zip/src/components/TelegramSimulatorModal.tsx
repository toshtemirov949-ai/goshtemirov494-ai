import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { X, Send, Bot, Smartphone, CheckCheck, ExternalLink, Sparkles, ShieldCheck } from 'lucide-react';

interface TelegramSimulatorModalProps {
  language: Language;
  onClose: () => void;
}

export const TelegramSimulatorModal: React.FC<TelegramSimulatorModalProps> = ({
  language,
  onClose,
}) => {
  const t = translations[language];
  const [messages, setMessages] = useState<
    { sender: 'bot' | 'user'; text: string; time: string; buttons?: string[] }[]
  >([
    {
      sender: 'bot',
      text: 'Assalomu alaykum! ChorvaBozor rasmiy Telegram botiga xush kelibsiz.\n\nBu yerda siz dallollarsiz, toʻgʻridan-toʻgʻri fermerlardan chorva sotib olishingiz yoki oʻz molingizni 2 daqiqada sotuvga qoʻyishingiz mumkin.',
      time: '12:00',
      buttons: ['🐂 Bozorni koʻrish', '➕ Eʼlon joylashtirish', '📊 Narxlar indeksi', '🚚 Transport topish'],
    },
  ]);
  const [userInput, setUserInput] = useState('');

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || userInput;
    if (!text.trim()) return;

    const time = new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });
    const newMsgList = [...messages, { sender: 'user' as const, text, time }];
    setMessages(newMsgList);
    setUserInput('');

    // Simulated Bot Responses
    setTimeout(() => {
      let botReply = '';
      let buttons: string[] | undefined = undefined;

      if (text.includes('Bozor') || text.includes('koʻrish')) {
        botReply = '🔍 Hozirda Samarqand, Toshkent va Andijonda 28 ta yangi tekshirilgan eʼlon bor.\n\n1. Golshtin sigir (26 L sut) - 28.5 mln\n2. Angus buqa (780 kg) - 38 mln\n3. Hisor qoʻchqor (135 kg) - 6.8 mln\n\nBatafsil koʻrish uchun quyidagi mini-ilovani oching:';
        buttons = ['📱 Mini-Appni ochish', '⬅️ Bosh menyu'];
      } else if (text.includes('Eʼlon') || text.includes('joylashtirish')) {
        botReply = '📸 Qoramolingizning 2 ta rasmini yoki 15 soniyalik videosini yuboring. Keyin viloyatingiz va narxini yozing. Biz uni darhol 45,000 chorvador aʼzo boʻlgan kanalimizga ham joylaymiz!';
        buttons = ['📷 Rasm yuborish', '⬅️ Bosh menyu'];
      } else if (text.includes('Narx') || text.includes('indeks')) {
        botReply = '📊 Bugungi tarozi narxi:\n• Toshkent: 50,000 - 52,500 soʻm/kg\n• Samarqand: 48,000 - 49,000 soʻm/kg\n• Vodiy: 49,500 - 51,000 soʻm/kg';
        buttons = ['⬅️ Bosh menyu'];
      } else if (text.includes('Transport')) {
        botReply = '🚚 Samarqand - Toshkent yoʻnalishida bugun 3 ta boʻsh Gazel va Isuzu bor. Qaysi tumanga yetkazish kerak?';
        buttons = ['📞 Haydovchi bilan bogʻlanish', '⬅️ Bosh menyu'];
      } else {
        botReply = 'Tushundim! Menyudan kerakli boʻlimni tanlang:';
        buttons = ['🐂 Bozorni koʻrish', '➕ Eʼlon joylashtirish', '📊 Narxlar indeksi'];
      }

      setMessages((prev) => [
        ...prev,
        {
          sender: 'bot',
          text: botReply,
          time: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }),
          buttons,
        },
      ]);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white dark:bg-stone-900 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-stone-200 dark:border-stone-800 transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-200 dark:border-stone-800 bg-sky-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-sky-700 flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base flex items-center gap-1.5">
                <span>ChorvaBozor Telegram Boti</span>
                <span className="text-[10px] bg-sky-800 text-sky-200 px-1.5 py-0.2 rounded font-mono">
                  @ChorvaBozor_bot
                </span>
              </h3>
              <p className="text-[11px] text-sky-200">
                Oʻzbekistondagi fermerlar uchun qulay savdo boti
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-sky-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Telegram Chat Simulation */}
        <div className="flex-1 bg-[#E7EBF0] dark:bg-stone-950 p-4 overflow-y-auto space-y-3 min-h-[360px] max-h-[460px] transition-colors">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed shadow-2xs ${
                  m.sender === 'user'
                    ? 'bg-[#EEFFDE] dark:bg-emerald-950/80 text-stone-900 dark:text-emerald-100 rounded-tr-xs border border-emerald-200/80 dark:border-emerald-800'
                    : 'bg-white dark:bg-stone-850 text-stone-900 dark:text-stone-100 rounded-tl-xs border border-stone-200/60 dark:border-stone-750'
                }`}
              >
                <div className="whitespace-pre-line">{m.text}</div>
                <div className="flex items-center justify-end gap-1 mt-1 text-[10px] text-stone-400">
                  <span>{m.time}</span>
                  {m.sender === 'user' && <CheckCheck className="w-3 h-3 text-sky-600 dark:text-sky-400" />}
                </div>
              </div>

              {/* Bot Interactive Reply Buttons */}
              {m.buttons && (
                <div className="flex flex-wrap gap-1.5 mt-2 max-w-[85%]">
                  {m.buttons.map((btn, bIdx) => (
                    <button
                      key={bIdx}
                      type="button"
                      onClick={() => handleSendMessage(btn)}
                      className="px-3 py-1.5 bg-white/90 dark:bg-stone-800 hover:bg-white dark:hover:bg-stone-750 text-sky-900 dark:text-sky-200 border border-sky-200/80 dark:border-sky-800 rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                    >
                      {btn}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Telegram input bar */}
        <div className="p-3 bg-white dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center gap-2 transition-colors">
          <input
            type="text"
            placeholder="Xabar yozing (masalan: Samarqanddagi buzoqlar)..."
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1 px-3 py-2 text-xs bg-stone-100 dark:bg-stone-800 text-stone-900 dark:text-white border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-sky-600"
          />
          <button
            type="button"
            onClick={() => handleSendMessage()}
            className="p-2 bg-sky-700 hover:bg-sky-800 text-white rounded-xl transition-colors cursor-pointer shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        {/* Strategic Guidance note */}
        <div className="bg-stone-50 dark:bg-stone-850 border-t border-stone-200 dark:border-stone-800 p-3 text-[11px] text-stone-600 dark:text-stone-400 transition-colors">
          <strong className="text-stone-900 dark:text-white">Strategik yoʻl:</strong> Oʻzbekiston qishloq joylarida dehqon va fermerlar 90% Telegramda savdo qiladi. Bot orqali 20-30 ta fermerni ulab birinchi bitimlarni oʻtkazish eng tejamkor va tezkor boshlash usulidir.
        </div>
      </div>
    </div>
  );
};
