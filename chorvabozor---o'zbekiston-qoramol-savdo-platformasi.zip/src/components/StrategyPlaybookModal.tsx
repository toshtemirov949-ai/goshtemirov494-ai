import React, { useState } from 'react';
import { X, Calendar, CheckSquare, ShieldCheck, DollarSign, Target, Users, TrendingUp, Sparkles, ChevronRight } from 'lucide-react';
import { Language } from '../types';

interface StrategyPlaybookModalProps {
  language: Language;
  onClose: () => void;
}

export const StrategyPlaybookModal: React.FC<StrategyPlaybookModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'mvp' | 'trust' | 'qurbonlik' | 'economics'>('mvp');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-emerald-950 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center">
              <Target className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                ChorvaBozor: Startap Amaliy Strategiyasi va Biznes-Rejasi
              </h3>
              <p className="text-xs text-emerald-300">
                MVP 2 haftalik reja · Ishonch tizimi · Qurbonlik tayyorgarligi · Unit-iqtisodiyot
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-emerald-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-stone-200 bg-stone-50 px-6 text-xs font-semibold overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('mvp')}
            className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'mvp'
                ? 'border-emerald-800 text-emerald-950 font-bold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            1. MVP va 30 ta Fermer
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('trust')}
            className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'trust'
                ? 'border-emerald-800 text-emerald-950 font-bold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            2. Ishonch va Anti-Fraud
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('qurbonlik')}
            className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'qurbonlik'
                ? 'border-emerald-800 text-emerald-950 font-bold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            3. Qurbonlik Tayyorgarlik Rejasi
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('economics')}
            className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'economics'
                ? 'border-emerald-800 text-emerald-950 font-bold'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            4. Unit-Iqtisodiyot va Daromad
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm text-stone-700 leading-relaxed">
          {/* TAB 1: MVP & 30 FARMERS */}
          {activeTab === 'mvp' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                <h4 className="font-bold text-emerald-950 text-sm mb-1">
                  Telegram Bot MVP (2 Haftalik Aniq Reja)
                </h4>
                <p className="text-xs text-emerald-900">
                  Maqsad: Murakkab mobil ilova yaratmasdan, mavjud odatlar (Telegram) orqali birinchi real bitimlarni oʻtkazish.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-stone-200 rounded-xl p-4 bg-stone-50 space-y-2">
                  <span className="font-bold text-stone-900 text-xs uppercase text-emerald-800 block">
                    1-Hafta: Texnik qism va Telegram Mini-App
                  </span>
                  <ul className="space-y-1.5 text-xs text-stone-600 list-disc pl-4">
                    <li><strong>1-3 kun:</strong> Oddiy katalog arxitekturasi: Nasl, viloyat, vazn, narx, foto/video maydonlari.</li>
                    <li><strong>4-5 kun:</strong> Telegram Bot menyusi: /start, /bozor (Web-view), /elon_berish (oddiy forma), /aloqa.</li>
                    <li><strong>6-7 kun:</strong> Admin panel va kanal integratsiyasi: Har bir tekshirilgan eʼlon avtomatik tarzda Telegram kanalga post boʻlib chiqadi.</li>
                  </ul>
                </div>

                <div className="border border-stone-200 rounded-xl p-4 bg-stone-50 space-y-2">
                  <span className="font-bold text-stone-900 text-xs uppercase text-emerald-800 block">
                    2-Hafta: Joylarga chiqish va Pilot bitimlar
                  </span>
                  <ul className="space-y-1.5 text-xs text-stone-600 list-disc pl-4">
                    <li><strong>8-10 kun:</strong> Tanlangan 2 ta viloyat (masalan, Toshkent vil. Chinoz/Yangiyoʻl yoki Samarqand Pastdargʻom) fermalariga shaxsan borish.</li>
                    <li><strong>11-12 kun:</strong> Birinchi 30 ta fermer bilan bepul eʼlon joylashtirish, video olish va tarozi tekshiruvi.</li>
                    <li><strong>13-14 kun:</strong> Dastlabki xaridorlarni jalb qilish va 3-5 ta birinchi sinov xaridini oʻtkazish.</li>
                  </ul>
                </div>
              </div>

              <div className="border border-stone-200 rounded-xl p-4 bg-white">
                <h5 className="font-bold text-stone-900 text-xs mb-2">
                  Dastlabki 30 ta ishonchli fermerni jalb qilish (Onboarding) taktikasi:
                </h5>
                <ol className="list-decimal pl-4 space-y-1.5 text-xs text-stone-600">
                  <li><strong>"Oyoq bilan marketing" (Ground Sales):</strong> Fermerlar raqamli vositalarga shubha bilan qaraydi. Ular bilan faqat joyiga borib, choy ustida gaplashish orqali ishonch oʻrnatiladi.</li>
                  <li><strong>"Biz oʻzimiz suratga olib beramiz" xizmati:</strong> Fermerga "Siz telefon qilmaysiz, biz oʻzimiz kelib mollaringizni professional video va taroziga tortib, eʼlon qilib beramiz" deb taklif bering.</li>
                  <li><strong>0% komissiya va bepul reklama:</strong> Birinchi 30 ta fermer uchun 3 oy davomida hech qanday komissiya yoki toʻlov olinmaydi.</li>
                  <li><strong>Mahalliy vetvrachlar bilan ittifoq:</strong> Tuman davlat veterinariya boʻlimi vrachlari barcha faol fermerlarni taniydi. Vrachga har bir tasdiqlangan fermer uchun kichik bonus berish eng tez onboarding yoʻlidir.</li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 2: TRUST & SAFETY */}
          {activeTab === 'trust' && (
            <div className="space-y-4">
              <div className="bg-sky-50 border border-sky-200 rounded-xl p-4">
                <h4 className="font-bold text-sky-950 text-sm mb-1">
                  Ishonch va Xavfsizlik: Soxta Eʼlonlarni Yoʻq Qilishning 5 Mexanizmi
                </h4>
                <p className="text-xs text-sky-900">
                  Chorva savdosida asosiy muammo — soxta vazn, kasal mol va dallollarning aldovi. Quyidagi 5 filtr buni 99% bartaraf etadi.
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <strong className="text-stone-900 block text-xs font-bold mb-0.5">
                    1. Majburiy "Jonli Qogʻoz" videosi (Live Date Verification)
                  </strong>
                  <p className="text-xs text-stone-600">
                    Sotuvchi videoda hayvonning yonida bugungi sana va "ChorvaBozor" deb qoʻlda yozilgan qogʻozni koʻrsatishi shart. Bu internetdan oʻgʻirlangan eski rasm va videolarni 100% cheklaydi.
                  </p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <strong className="text-stone-900 block text-xs font-bold mb-0.5">
                    2. Quloq birkasi va VetPasport sinxronizatsiyasi
                  </strong>
                  <p className="text-xs text-stone-600">
                    Hayvon qulogʻidagi 12 xonali metall/plastik birka raqami veterinariya guvohnomasidagi (Forma-1 / Yashil pasport) raqam bilan mos kelishi tekshiriladi. Mos kelmagan eʼlonlar eʼlon qilinmaydi.
                  </p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <strong className="text-stone-900 block text-xs font-bold mb-0.5">
                    3. Shartli depozit (Escrow - Payme/Click)
                  </strong>
                  <p className="text-xs text-stone-600">
                    Xaridor pulni toʻlaydi, ammo pul platforma hisobida muzlatiladi. Mol yetib borgach, xaridor taroziga qoʻyib, vazn va sogʻligʻini koʻrib tasdiqlaganidan keyingina pul sotuvchiga oʻtadi.
                  </p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <strong className="text-stone-900 block text-xs font-bold mb-0.5">
                    4. Tarix va Zarar qoplovchi Kafillik Jamgʻarmasi (Buyer Protection Fund)
                  </strong>
                  <p className="text-xs text-stone-600">
                    Har bir komissiyadan 10% fondga ajratiladi. Agar hayvonda yashirin kasallik aniqlansa yoki vazni koʻrsatilganidan 5% dan ortiq kam chiqsa, platforma xaridorga kompensatsiya toʻlaydi.
                  </p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <strong className="text-stone-900 block text-xs font-bold mb-0.5">
                    5. Pasport va OneID orqali fermerni toʻliq verifikatsiya qilish
                  </strong>
                  <p className="text-xs text-stone-600">
                    Sotuvchi oʻz pasporti/ID-kartasi va fermer xoʻjaligi guvohnomasini yuklaydi. Firibgarlik qilgan shaxs bir umrga platformadan chetlatiladi va huquq-tartibot organlariga maʼlumot uzatiladi.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: QURBONLIK TIMELINE */}
          {activeTab === 'qurbonlik' && (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                <h4 className="font-bold text-amber-950 text-sm mb-1">
                  Qurbonlik Mavsumiga Tayyorgarlik (Hayitdan 3 Oy Oldin - 90 Kunlik Reja)
                </h4>
                <p className="text-xs text-amber-900">
                  Qurbonlik paytida Oʻzbekiston chorva bozorida 1 yillik aylanmaning 35-40% amalga oshadi. Bu platforma uchun asosiy oʻsish drayveri!
                </p>
              </div>

              <div className="space-y-3 font-mono text-xs">
                <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-3">
                  <div className="bg-amber-100 text-amber-900 font-bold px-2 py-1 rounded text-xs shrink-0">
                    T-90 kun
                  </div>
                  <div className="font-sans">
                    <strong className="text-stone-900 block font-bold">1-Oy: Zaxira va Fermerlar bilan shartnomalar</strong>
                    <p className="text-stone-600 text-xs mt-0.5">
                      Qashqadaryo, Samarqand va Jizzaxdagi 50 ta fermer bilan 1,000 bosh qurbonlik qoʻy va qoramollarini oldindan qatʼiy narxda qotirish boʻyicha memorandum imzolash. Shariat talablari (yoshi, tish yorganligi) boʻyicha saralash.
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-3">
                  <div className="bg-amber-100 text-amber-900 font-bold px-2 py-1 rounded text-xs shrink-0">
                    T-60 kun
                  </div>
                  <div className="font-sans">
                    <strong className="text-stone-900 block font-bold">2-Oy: Logistika tarmogʻi va Soʻyish / Qassoblik bazalari</strong>
                    <p className="text-stone-600 text-xs mt-0.5">
                      Toshkent shahri va viloyat markazlari yaqinidagi sanitariya talablariga javob beradigan 3-5 ta zamonaviy kushxona va 20 nafar professional qassob bilan hamkorlik oʻrnatish. Mol tashuvchi 30 ta haydovchi bilan grafik tuzish.
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-3">
                  <div className="bg-amber-100 text-amber-900 font-bold px-2 py-1 rounded text-xs shrink-0">
                    T-30 kun
                  </div>
                  <div className="font-sans">
                    <strong className="text-stone-900 block font-bold">3-Oy (Boshi): "Oldindan Bron Qilish" kampaniyasini boshlash</strong>
                    <p className="text-stone-600 text-xs mt-0.5">
                      Ijtimoiy tarmoqlar (Telegram, Instagram) orqali eʼlon qilish: "Bozordagi tirbandlik va qimmat narxlarsiz, toza shariatga mos qurbonlik molini 15% arzonroq oldindan bron qiling!". 20% boʻnak (depozit) olish.
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-3">
                  <div className="bg-amber-100 text-amber-900 font-bold px-2 py-1 rounded text-xs shrink-0">
                    T-10 kun
                  </div>
                  <div className="font-sans">
                    <strong className="text-stone-900 block font-bold">Soʻnggi palla: Marshrutlar va Manzillar sinxronizatsiyasi</strong>
                    <p className="text-stone-600 text-xs mt-0.5">
                      Barcha buyurtmachilar bilan yetkazib berish vaqti (Arafa kuni kechqurun yoki Hayit tongi) kelishiladi. Hayvonlarga birkalar taqilib, mijozga yakuniy tasdiq videosi yuboriladi.
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-start gap-3">
                  <div className="bg-emerald-600 text-white font-bold px-2 py-1 rounded text-xs shrink-0">
                    Hayit kuni
                  </div>
                  <div className="font-sans">
                    <strong className="text-emerald-950 block font-bold">Yetkazish va Halol soʻyish ijrosi</strong>
                    <p className="text-emerald-900 text-xs mt-0.5">
                      Hayvon eshikkacha yetkaziladi yoki soʻyilgan goʻshti maxsus sovutgichli furgonda toza taqsimlangan holda yetkazib beriladi.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ECONOMICS & MONETIZATION */}
          {activeTab === 'economics' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                <h4 className="font-bold text-emerald-950 text-sm mb-1">
                  Unit-Iqtisodiyot va Daromad Optimizatsiyasi
                </h4>
                <p className="text-xs text-emerald-900">
                  Ortiqcha operatsion xarajatlarsiz (OPEX) yuqori rentabellikka erishish strategiyasi.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-stone-50 border border-stone-200 rounded-xl space-y-2">
                  <h5 className="font-bold text-stone-900 text-xs uppercase tracking-wide">
                    Komissiya Strukturasi Tavsiyasi
                  </h5>
                  <div className="space-y-1.5 text-xs text-stone-600 font-mono">
                    <div className="flex justify-between py-1 border-b border-stone-200">
                      <span className="font-sans">Mayda tuyoqlilar (Qoʻy/Echki):</span>
                      <strong className="text-stone-900">2.5% - 3.0%</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-stone-200">
                      <span className="font-sans">Qoramol (10 - 30 mln soʻm):</span>
                      <strong className="text-stone-900">1.5%</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-stone-200">
                      <span className="font-sans">Ulgurji partiyalar (50+ mln):</span>
                      <strong className="text-stone-900">1.0%</strong>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="font-sans">VIP / Top eʼlonlar:</span>
                      <strong className="text-stone-900">50,000 - 150,000 soʻm</strong>
                    </div>
                  </div>
                  <p className="text-[11px] text-stone-500 font-sans pt-1">
                    * Qoramolda 1.5% juda adolatli: masalan 25 mln soʻmlik sigir uchun 375,000 soʻm toʻlanadi. Bozor dalloli esa odatda 1.5 - 3 mln soʻm ustama qoʻyadi!
                  </p>
                </div>

                <div className="p-4 bg-stone-50 border border-stone-200 rounded-xl space-y-2">
                  <h5 className="font-bold text-stone-900 text-xs uppercase tracking-wide">
                    Xarajatlarni (OPEX) Minimal Saqlash Qoidalari
                  </h5>
                  <ul className="space-y-1.5 text-xs text-stone-600 list-disc pl-4">
                    <li><strong>Shaxsiy server va infratuzilma qurmang:</strong> Serverless va Telegram bot API boshlangʻich 6 oyda deyarli 0$ xarajat talab qiladi.</li>
                    <li><strong>Shaxsiy avtopark sotib olmang:</strong> Oʻzbekistondagi mavjud 500+ mustaqil mol tashuvchi haydovchilarni agregator sifatida birlashtiring.</li>
                    <li><strong>Moderatsiyada AI vositalaridan foydalaning:</strong> Rasm va videolarni dastlabki tekshirishni avtomatlashtiring, operator faqat shubhali eʼlonlarni koʻradi.</li>
                  </ul>
                </div>
              </div>

              {/* 100 Deals Model Calculation */}
              <div className="bg-stone-900 text-white p-4 rounded-xl font-mono text-xs space-y-2">
                <div className="text-amber-400 font-bold uppercase font-sans text-xs">
                  Bir oylik 100 ta bitim misolida daromad modeli:
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center pt-2">
                  <div className="bg-stone-800 p-2 rounded">
                    <span className="text-[10px] text-stone-400 block font-sans">Aylanma (GMV)</span>
                    <strong className="text-white font-bold">2.0 mlrd soʻm</strong>
                  </div>
                  <div className="bg-stone-800 p-2 rounded">
                    <span className="text-[10px] text-stone-400 block font-sans">Komissiya (1.5%)</span>
                    <strong className="text-emerald-400 font-bold">30.0 mln soʻm</strong>
                  </div>
                  <div className="bg-stone-800 p-2 rounded">
                    <span className="text-[10px] text-stone-400 block font-sans">VIP eʼlonlar</span>
                    <strong className="text-amber-400 font-bold">6.0 mln soʻm</strong>
                  </div>
                  <div className="bg-stone-800 p-2 rounded">
                    <span className="text-[10px] text-stone-400 block font-sans">Transport ulushi</span>
                    <strong className="text-sky-400 font-bold">7.5 mln soʻm</strong>
                  </div>
                </div>
                <div className="text-right text-[11px] text-stone-400 pt-1 font-sans">
                  Kichik jamoa bilan sof oylik marja: ~35-40 mln soʻm (birinchi 3-4 oy ichida).
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
