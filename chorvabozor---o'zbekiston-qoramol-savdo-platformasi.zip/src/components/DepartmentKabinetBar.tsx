import React from 'react';
import { AnimalDepartment, BreedInfo, Language } from '../types';
import { breedCatalog } from '../data/breedCatalog';
import { Info, Sparkles, Check, ChevronRight, BookOpen, Layers } from 'lucide-react';

interface DepartmentKabinetBarProps {
  selectedDepartment: AnimalDepartment;
  onSelectDepartment: (dept: AnimalDepartment) => void;
  selectedBreedKey: string;
  onSelectBreedKey: (breedKey: string) => void;
  language: Language;
  onOpenBreedGuide: () => void;
}

export const DepartmentKabinetBar: React.FC<DepartmentKabinetBarProps> = ({
  selectedDepartment,
  onSelectDepartment,
  selectedBreedKey,
  onSelectBreedKey,
  language,
  onOpenBreedGuide,
}) => {
  const departments: {
    key: AnimalDepartment;
    labelUz: string;
    labelRu: string;
    icon: string;
    subtitleUz: string;
    subtitleRu: string;
    badgeCount: string;
  }[] = [
    {
      key: 'all',
      labelUz: 'Barcha Kabinetlar',
      labelRu: 'Все кабинеты',
      icon: '🌐',
      subtitleUz: 'Qoramol, qoʻy va otlar umumiy katalogi',
      subtitleRu: 'Общий каталог КРС, овец и лошадей',
      badgeCount: '13 ta zot'
    },
    {
      key: 'qoramol',
      labelUz: 'Qoramol Kabineti',
      labelRu: 'Кабинет КРС',
      icon: '🐂',
      subtitleUz: 'Holstein, Qizil choʻl, Simmental, Angus, Jaydari',
      subtitleRu: 'Черно-пестрая, Симментал, Ангус, Красная степная',
      badgeCount: '5 ta asosiy zot'
    },
    {
      key: 'quy',
      labelUz: 'Qoʻy va Qoʻchqorlar',
      labelRu: 'Овцы и Бараны',
      icon: '🐑',
      subtitleUz: 'Hisor, Edilboy, Merinos, Jaydari qoʻylar',
      subtitleRu: 'Гиссарские, Эдильбай, Меринос, Джайдари',
      badgeCount: '4 ta asosiy zot'
    },
    {
      key: 'ot',
      labelUz: 'Otchilik Kabineti',
      labelRu: 'Коневодство',
      icon: '🐎',
      subtitleUz: 'Qorabayir, Axaltaka, Rus ogʻir yukchi, Lofard',
      subtitleRu: 'Карабаир, Ахалтекинская, Тяжеловоз, Лофард',
      badgeCount: '4 ta zot'
    },
  ];

  // Current breeds for active department
  const currentBreeds = selectedDepartment === 'all'
    ? []
    : breedCatalog.filter((b) => b.department === selectedDepartment);

  // Active selected breed item
  const activeBreedInfo: BreedInfo | undefined = breedCatalog.find((b) => b.id === selectedBreedKey);

  return (
    <div className="bg-white dark:bg-stone-900 border-y border-stone-200 dark:border-stone-800 transition-colors shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        {/* Top Header Row: Section Label + Guide Action */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3.5">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-400">
              <Layers className="w-4 h-4" />
            </span>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-stone-900 dark:text-stone-100 tracking-tight">
                {language === 'uz' ? 'Alohida Maxsus Kabinetlar:' : 'Специализированные кабинеты:'}
              </h2>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                {language === 'uz' 
                  ? 'Qoramol, qoʻy va ot turlarini alohida kabinetlar orqali saralang va har bir zotning aniq tavsifini oʻrganing'
                  : 'Выберите специализированный кабинет КРС, овец или лошадей для точного подбора по породам'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenBreedGuide}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 rounded-xl text-xs font-bold transition-all cursor-pointer self-start sm:self-auto shrink-0 shadow-2xs"
          >
            <BookOpen className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
            <span>{language === 'uz' ? 'Zotlar Qomusi & Ensiklopediya' : 'Энциклопедия пород'}</span>
            <ChevronRight className="w-3.5 h-3.5 opacity-70" />
          </button>
        </div>

        {/* 4 Kabinet Switcher Cards (All, Qoramol, Quy, Ot) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {departments.map((dept) => {
            const isActive = selectedDepartment === dept.key;
            return (
              <button
                key={dept.key}
                type="button"
                onClick={() => {
                  onSelectDepartment(dept.key);
                  onSelectBreedKey('all');
                }}
                className={`p-3 sm:p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                  isActive
                    ? 'border-emerald-600 bg-emerald-600 text-white shadow-md shadow-emerald-600/25 ring-2 ring-emerald-500/25'
                    : 'border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/80 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl sm:text-3xl">{dept.icon}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-emerald-700 text-emerald-100 border border-emerald-500'
                        : 'bg-stone-200/80 dark:bg-stone-700 text-stone-600 dark:text-stone-300'
                    }`}
                  >
                    {dept.badgeCount}
                  </span>
                </div>
                <div>
                  <h3 className="font-extrabold text-xs sm:text-sm tracking-tight mb-0.5">
                    {language === 'uz' ? dept.labelUz : dept.labelRu}
                  </h3>
                  <p
                    className={`text-[11px] line-clamp-1 ${
                      isActive ? 'text-emerald-100 font-medium' : 'text-stone-500 dark:text-stone-400'
                    }`}
                  >
                    {language === 'uz' ? dept.subtitleUz : dept.subtitleRu}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Sub-bar: Specific Breeds Selection when a Cabinet is selected */}
        {selectedDepartment !== 'all' && (
          <div className="mt-4 pt-3.5 border-t border-stone-200/80 dark:border-stone-800">
            <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
              <span className="text-[11px] font-bold text-stone-600 dark:text-stone-300 uppercase tracking-wider">
                {language === 'uz'
                  ? `${departments.find(d => d.key === selectedDepartment)?.labelUz} zotlari:`
                  : `Породы (${departments.find(d => d.key === selectedDepartment)?.labelRu}):`}
              </span>
              <span className="text-[11px] text-stone-500 dark:text-stone-400">
                {language === 'uz' ? 'Aniq zotni tanlab eʼlonlarni koʻring' : 'Выберите породу для фильтрации'}
              </span>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              <button
                type="button"
                onClick={() => onSelectBreedKey('all')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all shrink-0 cursor-pointer text-xs ${
                  selectedBreedKey === 'all'
                    ? 'bg-emerald-600 text-white shadow-xs ring-1 ring-emerald-500'
                    : 'bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300'
                }`}
              >
                {language === 'uz' ? 'Barcha zotlar' : 'Все породы'}
              </button>

              {currentBreeds.map((breed) => {
                const isSelected = selectedBreedKey === breed.id;
                return (
                  <button
                    key={breed.id}
                    type="button"
                    onClick={() => onSelectBreedKey(breed.id)}
                    className={`px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 cursor-pointer text-xs flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-emerald-600 text-white font-bold shadow-xs ring-1 ring-emerald-500'
                        : 'bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300'
                    }`}
                  >
                    <span>{breed.icon}</span>
                    <span>{breed.nameUz.split('(')[0].trim()}</span>
                  </button>
                );
              })}
            </div>

            {/* If a specific breed is selected, show its verified breed card right here! */}
            {activeBreedInfo && (
              <div className="mt-3 p-3.5 bg-emerald-50/70 dark:bg-stone-800/80 rounded-2xl border border-emerald-200 dark:border-stone-700 text-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{activeBreedInfo.icon}</span>
                    <strong className="text-stone-900 dark:text-stone-100 text-sm font-extrabold">
                      {language === 'uz' ? activeBreedInfo.nameUz : activeBreedInfo.nameRu}
                    </strong>
                    <span className="font-mono text-[11px] font-bold bg-white dark:bg-stone-900 border border-emerald-300 dark:border-stone-600 px-2 py-0.5 rounded-lg text-emerald-800 dark:text-emerald-400">
                      {activeBreedInfo.weightRange}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenBreedGuide}
                    className="text-emerald-800 dark:text-emerald-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span>{language === 'uz' ? 'Toʻliq maʼlumot' : 'Подробнее'}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-stone-700 dark:text-stone-300 leading-relaxed">
                  {language === 'uz' ? activeBreedInfo.descriptionUz : activeBreedInfo.descriptionRu}
                </p>
                <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-stone-600 dark:text-stone-400">
                  <span className="font-semibold text-emerald-900 dark:text-emerald-300">
                    {language === 'uz' ? 'Tavsiya etiladi:' : 'Рекомендуется:'}{' '}
                    {language === 'uz' ? activeBreedInfo.recommendedForUz : activeBreedInfo.recommendedForRu}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
