import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Send,
  Phone,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  AlertCircle,
  FileText,
  Truck,
  HeartPulse,
  Award,
  Mic,
  MessageSquare,
  Stethoscope
} from 'lucide-react';
import { Language, LivestockItem } from '../types';

interface Message {
  id: string;
  sender: 'vet' | 'user';
  text: string;
  timestamp: string;
}

interface VeterinarianConsultModalProps {
  isOpen: boolean;
  onClose: () => void;
  livestockItem: LivestockItem | null;
  language: Language;
}

export const VeterinarianConsultModal: React.FC<VeterinarianConsultModalProps> = ({
  isOpen,
  onClose,
  livestockItem,
  language,
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize consultation chat when opened
  useEffect(() => {
    if (isOpen && livestockItem) {
      const vetName = livestockItem.vetInfo?.veterinarianName || 'Dr. Rustam Alimov';
      const clinic = livestockItem.vetInfo?.districtVetClinic || 'Davlat Veterinariya Markazi';
      const breed = livestockItem.breed;

      const welcomeText =
        language === 'uz'
          ? `Assalomu alaykum! Men ${clinic} bosh vrach-inspektori ${vetName}man. Ushbu ${breed} (${livestockItem.weightKg} kg, Vet pasport №: ${livestockItem.vetInfo?.passportNumber}) boʻyicha tibbiy koʻrik xulosasi, emlash tarixi va karantin holati haqida qanday savollaringiz bor? Marhamat, soʻrang!`
          : `Здравствуйте! Я главный ветеринарный врач ${clinic} — ${vetName}. Готов ответить на любые вопросы о здоровье, вакцинациях и ветпаспорте (${livestockItem.vetInfo?.passportNumber}) данного животного (${breed}).`;

      setMessages([
        {
          id: 'msg-welcome',
          sender: 'vet',
          text: welcomeText,
          timestamp: 'Hozir',
        },
      ]);
    }
  }, [isOpen, livestockItem, language]);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (!isOpen || !livestockItem) return null;

  const vetInfo = livestockItem.vetInfo;
  const vetName = vetInfo?.veterinarianName || 'Dr. Rustam Alimov';
  const clinic = vetInfo?.districtVetClinic || 'Davlat Veterinariya Inspeksiyasi';

  const quickQuestions =
    language === 'uz'
      ? [
          '💉 Vaksinalari toʻliq qilinganmi?',
          '📋 Vet pasport tekshiruv muddati qachongacha?',
          '⚖️ Tarozi vazni va semizlik darajasi qanday?',
          '🚚 Viloyatlararo fura bilan tashishga ruxsati bormi?',
          '🌾 Qanday ozuqa ratsioni tavsiya qilinadi?',
        ]
      : [
          '💉 Сделаны ли все обязательные прививки?',
          '📋 Срок действия ветеринарного паспорта',
          '⚖️ Соответствует ли вес стандарту?',
          '🚚 Есть ли разрешение на межрегиональную перевозку?',
          '🌾 Рекомендации по кормовому рациону',
        ];

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputMessage.trim();
    if (!text) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Hozir',
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMessage('');
    setIsTyping(true);

    // Simulate intelligent veterinary response
    setTimeout(() => {
      let reply = '';
      const lower = text.toLowerCase();

      if (lower.includes('vaksin') || lower.includes('emlash') || lower.includes('привив')) {
        const vacs =
          vetInfo?.vaccinatedFor?.map((v) => `${v.nameUz} (${v.date})`).join(', ') ||
          'Kuydirgi va Oqsil';
        reply =
          language === 'uz'
            ? `Ha, hayvon barcha majburiy emlashlardan oʻtgan: ${vacs}. Qon tahlillari toza chiqqan, brutselloz va sil kasalliklaridan xoli ekanligi laboratoriyada tasdiqlangan. Qayta emlash 6 oydan keyin talab etiladi.`
            : `Да, животное полностью привито: ${vacs}. Лабораторные анализы крови чистые, животное здорово.`;
      } else if (lower.includes('pasport') || lower.includes('hujjat') || lower.includes('паспорт')) {
        reply =
          language === 'uz'
            ? `Ushbu hayvonga rasmiy elektron Davlat Veterinariya Pasporti (№ ${vetInfo?.passportNumber}) berilgan. Davlat Veterinariya qoʻmitasining yagona elektron bazasidan tekshirishingiz mumkin. Hujjat toʻliq qonuniy va 1 yil davomida amal qiladi.`
            : `Ветеринарный паспорт № ${vetInfo?.passportNumber} официально зарегистрирован в государственной базе и действителен.`;
      } else if (lower.includes('tashish') || lower.includes('fura') || lower.includes('yoʻl') || lower.includes('перевоз')) {
        reply =
          language === 'uz'
            ? `Ha! Hayvon karantin tekshiruvidan toʻliq oʻtgan va Viloyatlararo transport guvohnomasi (№1 shakl) rasmiylashtirilgan. Shamollatiladigan maxsus chorvavoz fura yoki isuzu transportida bemalol uyingizgacha olib borish mumkin.`
            : `Да, получено ветеринарное свидетельство Форма №1 на вывоз. Транспортировка в специализированном скотовозе полностью безопасна.`;
      } else if (lower.includes('vazn') || lower.includes('tarozi') || lower.includes('semiz') || lower.includes('вес')) {
        reply =
          language === 'uz'
            ? `Hayvon elektron tarozi orqali oʻlchangan va tirik vazni ${livestockItem.weightKg} kg ni tashkil etadi. Suyagi baquvvat, muskullari toʻliq rivojlangan, semizlik darajasi standartdan yuqori. Hech qanday jismoniy nuqsoni yoʻq.`
            : `Вес животного ${livestockItem.weightKg} кг зафиксирован на электронных весах. Физическое состояние и упитанность отличные.`;
      } else if (lower.includes('ratsion') || lower.includes('yem') || lower.includes('ozuqa') || lower.includes('корм')) {
        reply =
          language === 'uz'
            ? `Yangi manzilga borgan dastlabki 3-4 kunda hayvonga faqat quruq beda va toza iliq suv berishni tavsiya qilamiz. Kunjara, kepak yoki silosni asta-sekin, 5-kundan boshlab kuniga 1-1.5 kg dan oshirib borish maqsadga muvofiq.`
            : `В первые дни на новом месте рекомендуем качественное сено и чистую воду. Концентраты вводите постепенно, начиная с 5-го дня.`;
      } else {
        reply =
          language === 'uz'
            ? `Savolingiz qabul qilindi. Ushbu ${livestockItem.breed} boʻyicha klinik holat toʻliq meʼyorda: tana harorati 38.6°C, shilliq qavatlar toza, nafas olishi erkin. Manzilingizga yetkazib berilgach, 24 soat davomida bepul qoʻshimcha maslahat olishingiz mumkin.`
            : `Ваш вопрос принят. Животное клинически здорово: температура 38.6°C, дыхание чистое, аппетит в норме.`;
      }

      const vetReply: Message = {
        id: `vet-${Date.now()}`,
        sender: 'vet',
        text: reply,
        timestamp: 'Hozir',
      };

      setMessages((prev) => [...prev, vetReply]);
      setIsTyping(false);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 w-full max-w-2xl rounded-3xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col h-[620px] max-h-[92vh]">
        {/* Vet Profile Header Bar */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-stone-950 text-white p-4 sm:p-5 flex items-center justify-between gap-3 shrink-0 relative">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-emerald-800 text-white flex items-center justify-center font-bold text-lg border-2 border-emerald-400/60 shadow-md">
                <Stethoscope className="w-6 h-6 text-emerald-300" />
              </div>
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-emerald-950 animate-pulse" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white">{vetName}</h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Davlat Vrach-Inspektori
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 truncate max-w-xs">{clinic}</p>
              <div className="flex items-center gap-2 text-[10px] text-emerald-300 mt-0.5 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>Onlayn · Javob vaqti: ~1 daqiqa</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="tel:+998712004422"
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-200 text-xs font-semibold transition-all border border-white/15"
              title="Tezkor veterinar liniyasi"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Qoʻngʻiroq</span>
            </a>

            <button
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-all cursor-pointer"
              title="Yopish"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Selected Livestock Mini Context Bar */}
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border-b border-emerald-200 dark:border-emerald-900/60 p-2.5 px-4 flex items-center justify-between text-xs text-stone-800 dark:text-stone-200 shrink-0">
          <div className="flex items-center gap-2.5 truncate">
            <div className="w-9 h-9 rounded-lg overflow-hidden shrink-0 border border-emerald-300 dark:border-emerald-800">
              <img
                src={livestockItem.imageUrl}
                alt={livestockItem.breed}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="truncate">
              <div className="font-extrabold text-stone-900 dark:text-white truncate">
                {language === 'uz' ? livestockItem.titleUz : livestockItem.titleRu}
              </div>
              <div className="text-[11px] text-stone-500 dark:text-stone-400 flex items-center gap-2">
                <span>{livestockItem.breed} · {livestockItem.weightKg} kg</span>
                <span>·</span>
                <span className="text-emerald-700 dark:text-emerald-400 font-mono font-bold">
                  Pasport: {vetInfo?.passportNumber}
                </span>
              </div>
            </div>
          </div>

          <span className="shrink-0 px-2.5 py-1 rounded-full bg-emerald-600 text-white font-black text-[10px] hidden sm:flex items-center gap-1 shadow-2xs">
            <CheckCircle2 className="w-3 h-3" />
            Tekshirilgan
          </span>
        </div>

        {/* Chat Messages Log */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-stone-50/50 dark:bg-stone-900/60">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-start gap-2 max-w-[85%]">
                {msg.sender === 'vet' && (
                  <div className="w-7 h-7 rounded-xl bg-emerald-800 text-white flex items-center justify-center shrink-0 text-xs shadow-xs mt-0.5">
                    <Stethoscope className="w-3.5 h-3.5 text-emerald-300" />
                  </div>
                )}
                <div>
                  <div
                    className={`p-3 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-emerald-800 text-white rounded-tr-xs shadow-sm font-medium'
                        : 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 rounded-tl-xs shadow-sm border border-stone-200/80 dark:border-stone-700/80'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-stone-400 mt-1 block px-1">
                    {msg.sender === 'vet' ? `${vetName} · ` : 'Siz · '}
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-stone-500 text-xs italic animate-pulse">
              <div className="w-6 h-6 rounded-lg bg-emerald-800/30 flex items-center justify-center">
                <Stethoscope className="w-3 h-3 text-emerald-700" />
              </div>
              <span>{vetName} javob yozmoqda...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Questions Pills */}
        <div className="p-2.5 bg-white dark:bg-stone-850 border-t border-stone-100 dark:border-stone-800 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0">
          <span className="text-[11px] font-bold text-stone-400 shrink-0 uppercase tracking-wider pl-1">
            Tezkor savollar:
          </span>
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(q)}
              className="px-2.5 py-1 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 hover:text-emerald-800 dark:hover:text-emerald-300 text-stone-700 dark:text-stone-300 text-xs font-semibold transition-all shrink-0 border border-stone-200/60 dark:border-stone-700 cursor-pointer whitespace-nowrap"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-white dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder={
              language === 'uz'
                ? 'Veterinarga savolingizni yozing...'
                : 'Задайте вопрос ветеринару...'
            }
            className="flex-1 px-4 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 placeholder:text-stone-400"
          />

          <button
            type="submit"
            disabled={!inputMessage.trim()}
            className="p-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 disabled:opacity-40 text-white transition-all shadow-md cursor-pointer shrink-0"
            title="Yuborish"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
