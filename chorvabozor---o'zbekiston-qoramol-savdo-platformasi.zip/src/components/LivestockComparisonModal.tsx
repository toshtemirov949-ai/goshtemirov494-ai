import React from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import {
  X,
  Scale,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Truck,
  Lock,
  Phone,
  Send,
  Plus,
  Trash2,
  ExternalLink,
  Award
} from 'lucide-react';

interface LivestockComparisonModalProps {
  items: LivestockItem[];
  allItems: LivestockItem[];
  language: Language;
  onClose: () => void;
  onRemoveItem: (id: string) => void;
  onAddItem: (item: LivestockItem) => void;
  onStartEscrow: (item: LivestockItem) => void;
  onViewDetails: (item: LivestockItem) => void;
}

export const LivestockComparisonModal: React.FC<LivestockComparisonModalProps> = ({
  items,
  allItems,
  language,
  onClose,
  onRemoveItem,
  onAddItem,
  onStartEscrow,
  onViewDetails,
}) => {
  const t = translations[language];

  const formatPrice = (val: number) => {
    return new Intl.NumberFormat('uz-UZ').format(val);
  };

  // Find lowest price and highest weight among compared items for smart badges
  const minPrice = items.length > 1 ? Math.min(...items.map((it) => it.priceUzs)) : null;
  const maxWeight = items.length > 1 ? Math.max(...items.map((it) => it.weightKg)) : null;

  // Unselected items that can be added (up to 3 max)
  const availableToAdd = allItems.filter(
    (a) => !items.some((it) => it.id === a.id)
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white dark:bg-stone-900 rounded-3xl max-w-6xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[94vh] border border-stone-200 dark:border-stone-800">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-stone-200 dark:border-stone-800 bg-emerald-950 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800/90 border border-emerald-600 flex items-center justify-center text-emerald-200 shadow-xs">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg tracking-tight">
                  {t.compareModalTitle}
                </h3>
                <span className="text-xs font-mono font-bold bg-emerald-800/80 text-emerald-200 px-2 py-0.5 rounded-full border border-emerald-600">
                  {items.length}/3
                </span>
              </div>
              <p className="text-xs text-emerald-300">
                {t.compareModalSubtitle}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-emerald-300 hover:text-white rounded-lg hover:bg-emerald-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area: Side-by-Side Comparison Table */}
        <div className="p-4 sm:p-6 overflow-y-auto overflow-x-auto flex-1 text-xs">
          {items.length === 0 ? (
            <div className="py-16 text-center max-w-md mx-auto">
              <span className="text-4xl block mb-3">⚖️</span>
              <h4 className="text-base font-bold text-stone-900 dark:text-stone-100 mb-1">
                Taqqoslash uchun eʼlon tanlanmagan
              </h4>
              <p className="text-stone-500 dark:text-stone-400 text-xs mb-4">
                Katalogdan oʻzingizga qiziq boʻlgan 2 yoki 3 ta chorva eʼlonidagi "Taqqoslash" tugmasini bosing.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Katalogga qaytish
              </button>
            </div>
          ) : (
            <div className="min-w-[650px]">
              {items.length === 1 && (
                <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-900 dark:text-amber-200 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                    <span>{t.compareMinNotice}</span>
                  </div>
                  {availableToAdd.length > 0 && (
                    <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-300">
                      Oʻng tarafdagi ustundan yana bir chorva qoʻshing ➔
                    </span>
                  )}
                </div>
              )}

              {/* Table Structure */}
              <table className="w-full border-collapse border border-stone-200 dark:border-stone-800">
                <thead>
                  <tr className="bg-stone-50 dark:bg-stone-850">
                    <th className="w-40 sm:w-48 p-3.5 text-left font-bold text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-800">
                      {t.compareParamMetric}
                    </th>
                    {items.map((item) => (
                      <th
                        key={item.id}
                        className="p-3.5 text-left border border-stone-200 dark:border-stone-800 align-top min-w-[200px]"
                      >
                        <div className="relative flex flex-col space-y-2">
                          <button
                            type="button"
                            onClick={() => onRemoveItem(item.id)}
                            className="absolute -top-1.5 -right-1.5 p-1 bg-stone-200 dark:bg-stone-700 hover:bg-rose-600 hover:text-white rounded-md text-stone-600 dark:text-stone-300 transition-colors cursor-pointer"
                            title={t.removeFromCompare}
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>

                          <img
                            src={item.imageUrl}
                            alt={item.titleUz}
                            className="w-full h-32 rounded-xl object-cover border border-stone-200 dark:border-stone-700 shadow-2xs cursor-pointer"
                            onClick={() => onViewDetails(item)}
                          />

                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/80 text-emerald-900 dark:text-emerald-300">
                              {item.department === 'qoramol' ? '🐂 Qoramol' : item.department === 'quy' ? '🐑 Qoʻy' : '🐎 Ot'}
                            </span>
                            {item.isFeatured && (
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/80 text-amber-900 dark:text-amber-300">
                                VIP
                              </span>
                            )}
                          </div>

                          <h4
                            onClick={() => onViewDetails(item)}
                            className="font-extrabold text-stone-900 dark:text-stone-100 text-xs sm:text-sm line-clamp-2 hover:text-emerald-800 dark:hover:text-emerald-400 cursor-pointer"
                          >
                            {language === 'uz' ? item.titleUz : item.titleRu}
                          </h4>
                        </div>
                      </th>
                    ))}

                    {/* Placeholder Slot to Add Next Item if under 3 */}
                    {items.length < 3 && (
                      <th className="p-3.5 text-center border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/40 align-middle min-w-[200px]">
                        <div className="p-4 border-2 border-dashed border-stone-300 dark:border-stone-700 rounded-2xl flex flex-col items-center justify-center space-y-2">
                          <Plus className="w-8 h-8 text-stone-400" />
                          <span className="font-bold text-stone-700 dark:text-stone-300 text-xs">
                            {t.addMoreToCompare}
                          </span>
                          <span className="text-[10px] text-stone-500">
                            (Maksimal 3 ta)
                          </span>

                          {availableToAdd.length > 0 && (
                            <select
                              onChange={(e) => {
                                const selected = allItems.find((a) => a.id === e.target.value);
                                if (selected) onAddItem(selected);
                              }}
                              defaultValue=""
                              className="mt-2 w-full p-2 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-stone-800 dark:text-stone-200 text-xs font-semibold focus:outline-none"
                            >
                              <option value="" disabled>
                                + Eʼlonlardan tanlang
                              </option>
                              {availableToAdd.map((av) => (
                                <option key={av.id} value={av.id}>
                                  {av.titleUz.slice(0, 32)}... ({av.weightKg} kg)
                                </option>
                              ))}
                            </select>
                          )}
                        </div>
                      </th>
                    )}
                  </tr>
                </thead>

                <tbody className="divide-y divide-stone-200 dark:divide-stone-800">
                  {/* Row: Narxi (Price) */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Narxi (Umumiy)
                    </td>
                    {items.map((item) => {
                      const isBestPrice = minPrice !== null && item.priceUzs === minPrice;
                      return (
                        <td
                          key={item.id}
                          className={`p-3.5 border border-stone-200 dark:border-stone-800 ${
                            isBestPrice ? 'bg-emerald-50/60 dark:bg-emerald-950/20' : ''
                          }`}
                        >
                          <div className="flex items-baseline gap-1">
                            <span className="font-mono text-base font-extrabold text-stone-900 dark:text-stone-100">
                              {formatPrice(item.priceUzs)}
                            </span>
                            <span className="text-stone-500 text-[11px]">{t.currency}</span>
                          </div>
                          {isBestPrice && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 dark:text-emerald-400 mt-1 bg-emerald-100 dark:bg-emerald-900/60 px-2 py-0.5 rounded-md">
                              ✓ {t.bestPriceBadge}
                            </span>
                          )}
                        </td>
                      );
                    })}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Tirik kg narxi */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Tirik kg narxi
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 font-mono border border-stone-200 dark:border-stone-800">
                        {item.pricePerKg ? (
                          <span className="font-semibold text-emerald-900 dark:text-emerald-300">
                            {formatPrice(item.pricePerKg)} soʻm/kg
                          </span>
                        ) : (
                          <span className="text-stone-400">Dona narxda</span>
                        )}
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Tirik vazni (Weight) */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Tirik vazni
                    </td>
                    {items.map((item) => {
                      const isMaxWeight = maxWeight !== null && item.weightKg === maxWeight;
                      return (
                        <td
                          key={item.id}
                          className={`p-3.5 border border-stone-200 dark:border-stone-800 ${
                            isMaxWeight ? 'bg-amber-50/50 dark:bg-amber-950/20' : ''
                          }`}
                        >
                          <span className="font-mono text-base font-extrabold text-stone-900 dark:text-stone-100">
                            {item.weightKg} kg
                          </span>
                          {isMaxWeight && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 dark:text-amber-400 mt-1 block">
                              ★ {t.highestWeightBadge}
                            </span>
                          )}
                        </td>
                      );
                    })}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Zoti (Breed) */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Nasli / Zoti
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 font-semibold border border-stone-200 dark:border-stone-800 text-stone-800 dark:text-stone-200">
                        {item.breed}
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Yoshi & Jinsi */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Yoshi va Jinsi
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800">
                        <div className="font-semibold text-stone-900 dark:text-stone-100">
                          {item.ageMonths >= 12
                            ? `${(item.ageMonths / 12).toFixed(1)} yosh (${item.ageMonths} oy)`
                            : `${item.ageMonths} oylik`}
                        </div>
                        <div className="text-stone-500 capitalize mt-0.5">
                          Jinsi: <strong className="text-stone-700 dark:text-stone-300">{item.gender}</strong>
                        </div>
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Veterinariya Holati & Pasport */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Veterinariya Pasporti
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800 space-y-1">
                        {item.vetInfo?.hasVetPassport ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 font-bold text-emerald-800 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/80 px-2 py-0.5 rounded-md">
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                              <span>{t.vetVerified}</span>
                            </span>
                            <div className="font-mono text-[11px] text-stone-600 dark:text-stone-300">
                              {item.vetInfo.passportNumber}
                            </div>
                            <div className="text-[10px] text-stone-500">
                              {item.vetInfo.districtVetClinic}
                            </div>
                          </div>
                        ) : (
                          <span className="text-stone-400">Pasport yuklanmagan</span>
                        )}
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Emlashlar (Vaccines) */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Emlangan kasalliklar
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800">
                        {item.vetInfo?.vaccinatedFor && item.vetInfo.vaccinatedFor.length > 0 ? (
                          <div className="space-y-1">
                            {item.vetInfo.vaccinatedFor.map((vac, idx) => (
                              <div key={idx} className="flex items-center gap-1 text-[11px] text-stone-700 dark:text-stone-300">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                <span>{language === 'uz' ? vac.nameUz : vac.nameRu} ({vac.date})</span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-stone-400">Maʼlumot yoʻq</span>
                        )}
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Sogʻliq va Tavsif */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Sogʻliq xulosasi
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 leading-relaxed">
                        {item.vetInfo?.healthNotes || 'Klinik tekshirilgan, sogʻlom.'}
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Xavfsiz Toʻlov & Yetkazish */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Kafolat & Transport
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800 space-y-1.5">
                        <div className="flex items-center gap-1.5 text-stone-800 dark:text-stone-200">
                          <Lock className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{item.isEscrowSupported ? 'Eskrou toʻlov bor' : 'Faqat naqd'}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-stone-800 dark:text-stone-200">
                          <Truck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{item.isDeliveryAvailable ? 'Yetkazib beriladi' : 'Olib ketish'}</span>
                        </div>
                        {item.isQurbonlikFit && (
                          <div className="text-amber-800 dark:text-amber-400 font-semibold text-[11px]">
                            ★ Qurbonlikka muvofiq
                          </div>
                        )}
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Manzil (Location) */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Manzil
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800 font-medium">
                        <span className="font-bold text-stone-900 dark:text-stone-100">{item.region}</span>
                        <div className="text-stone-500">{item.district}</div>
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Sotuvchi & Reyting */}
                  <tr>
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Fermer / Sotuvchi
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800 space-y-1">
                        <div className="font-bold text-stone-900 dark:text-stone-100 flex items-center gap-1">
                          <span>{item.seller.name}</span>
                          {item.seller.isPassportVerified && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          )}
                        </div>
                        <div className="text-[11px] text-stone-500">{item.seller.farmName}</div>
                        <div className="text-amber-700 dark:text-amber-400 font-bold font-mono">
                          ★ {item.seller.rating.toFixed(1)} ({item.seller.dealsCompleted} bitim)
                        </div>
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>

                  {/* Row: Quick Action Buttons */}
                  <tr className="bg-stone-50/70 dark:bg-stone-850/70">
                    <td className="p-3.5 font-bold text-stone-600 dark:text-stone-300 bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800">
                      Xarid & Bogʻlanish
                    </td>
                    {items.map((item) => (
                      <td key={item.id} className="p-3.5 border border-stone-200 dark:border-stone-800">
                        <div className="space-y-2">
                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onStartEscrow(item);
                            }}
                            className="w-full py-2 px-3 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl font-bold text-xs shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <Lock className="w-3.5 h-3.5" />
                            <span>{t.buyWithEscrow}</span>
                          </button>

                          <div className="grid grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                onClose();
                                onViewDetails(item);
                              }}
                              className="py-1.5 px-2 bg-stone-200 dark:bg-stone-700 hover:bg-stone-300 text-stone-800 dark:text-stone-200 rounded-lg text-center font-semibold text-[11px] cursor-pointer"
                            >
                              Batafsil
                            </button>

                            <a
                              href={`tel:${item.seller.phone}`}
                              className="py-1.5 px-2 border border-stone-300 dark:border-stone-600 hover:bg-stone-100 text-stone-800 dark:text-stone-200 rounded-lg text-center font-semibold text-[11px] flex items-center justify-center gap-1"
                            >
                              <Phone className="w-3 h-3 text-emerald-600" />
                              <span>Qoʻngʻiroq</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    ))}
                    {items.length < 3 && <td className="border border-stone-200 dark:border-stone-800" />}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900 flex items-center justify-between text-xs text-stone-500">
          <span>
            {items.length} ta hayvon taqqoslanmoqda (maksimal 3 ta)
          </span>
          <button
            type="button"
            onClick={onClose}
            className="py-1.5 px-4 bg-stone-200 dark:bg-stone-700 hover:bg-stone-300 text-stone-800 dark:text-stone-200 font-bold rounded-xl cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
