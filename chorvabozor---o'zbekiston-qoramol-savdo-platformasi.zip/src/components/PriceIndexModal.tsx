import React, { useState } from 'react';
import { mockPriceIndex } from '../data/mockData';
import { Language, RegionPriceStat } from '../types';
import { translations } from '../translations';
import { X, TrendingUp, TrendingDown, Minus, Search, Info, HelpCircle } from 'lucide-react';

interface PriceIndexModalProps {
  language: Language;
  onClose: () => void;
  onOpenBreedTrends?: (breedKey?: string) => void;
}

export const PriceIndexModal: React.FC<PriceIndexModalProps> = ({
  language,
  onClose,
  onOpenBreedTrends,
}) => {
  const t = translations[language];
  const [regionFilter, setRegionFilter] = useState('');
  const [selectedStat, setSelectedStat] = useState<RegionPriceStat | null>(mockPriceIndex[0]);

  const filteredStats = mockPriceIndex.filter((item) =>
    item.region.toLowerCase().includes(regionFilter.toLowerCase())
  );

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('uz-UZ').format(p);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh] border border-[#E5ECE7] dark:border-[#0E3D32] transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#047857]/40 dark:border-[#0E3D32] bg-gradient-to-r from-[#064E3B] to-[#047857] text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#041C16]/50 flex items-center justify-center border border-[#10B981]/30">
              <TrendingUp className="w-4 h-4 text-[#10B981]" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                {t.priceIndexTitle}
              </h3>
              <p className="text-xs text-emerald-100">
                {t.priceIndexSubtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Breed Trends CTA Bar */}
        {onOpenBreedTrends && (
          <div className="bg-gradient-to-r from-emerald-900 via-stone-900 to-teal-950 text-white px-5 sm:px-6 py-2.5 flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-emerald-800">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-base">📈</span>
              <span className="font-bold">
                {language === 'uz'
                  ? 'Zotlar boʻyicha 2024-2026 narx dinamikasi va bozor mavsumiyligi grafigi:'
                  : 'График сезонности и динамики цен 2024-2026 по породам скота:'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenBreedTrends();
              }}
              className="px-3.5 py-1 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-stone-950 text-xs font-extrabold transition-all cursor-pointer shadow-xs flex items-center gap-1.5 shrink-0"
            >
              <span>{language === 'uz' ? 'Dinamik Grafikni Koʻrish' : 'Смотреть график'}</span>
              <span>→</span>
            </button>
          </div>
        )}

        {/* Search bar & Notice */}
        <div className="p-4 sm:p-6 bg-stone-50 dark:bg-stone-850 border-b border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 transition-colors">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={regionFilter}
              onChange={(e) => setRegionFilter(e.target.value)}
              placeholder="Viloyatni qidirish..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-stone-800 text-stone-900 dark:text-white border border-stone-300 dark:border-stone-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div className="text-xs text-stone-600 dark:text-stone-300 flex items-center gap-2">
            <Info className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
            <span>
              Maʼlumotlar har dushanba kuni respublika bozorlari tarozi maʼlumotlari asosida yangilanadi.
            </span>
          </div>
        </div>

        {/* Content Table & Insights */}
        <div className="p-4 sm:p-6 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Table (8 cols) */}
          <div className="lg:col-span-8 overflow-x-auto">
            <table className="w-full text-left text-xs border border-stone-200 dark:border-stone-800 rounded-xl overflow-hidden">
              <thead className="bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-semibold uppercase text-[11px] border-b border-stone-200 dark:border-stone-750">
                <tr>
                  <th className="py-2.5 px-3">Viloyat</th>
                  <th className="py-2.5 px-3 text-right">Qoramol tirik vazn</th>
                  <th className="py-2.5 px-3 text-right">Qoʻy tirik vazn</th>
                  <th className="py-2.5 px-3 text-right">Sogʻin sigir</th>
                  <th className="py-2.5 px-3 text-center">Trend (30 kun)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 font-mono">
                {filteredStats.map((st) => {
                  const isSelected = selectedStat?.region === st.region;
                  return (
                    <tr
                      key={st.region}
                      onClick={() => setSelectedStat(st)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/80 font-bold' : 'hover:bg-stone-50'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-sans font-medium text-stone-900">
                        {st.region}
                      </td>
                      <td className="py-2.5 px-3 text-right text-stone-900 tabular-nums">
                        {formatPrice(st.averageLiveWeightPriceBeef)} soʻm/kg
                      </td>
                      <td className="py-2.5 px-3 text-right text-stone-700 tabular-nums">
                        {formatPrice(st.averageLiveWeightPriceSheep)} soʻm/kg
                      </td>
                      <td className="py-2.5 px-3 text-right text-emerald-900 font-semibold tabular-nums">
                        ~{st.averageDairyCowPrice} mln
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`inline-flex items-center gap-1 font-semibold text-[11px] ${
                            st.trend === 'up'
                              ? 'text-emerald-700'
                              : st.trend === 'down'
                              ? 'text-rose-600'
                              : 'text-stone-500'
                          }`}
                        >
                          {st.trend === 'up' && <TrendingUp className="w-3.5 h-3.5" />}
                          {st.trend === 'down' && <TrendingDown className="w-3.5 h-3.5" />}
                          {st.trend === 'stable' && <Minus className="w-3.5 h-3.5" />}
                          <span>{st.changePercentageLastMonth > 0 ? `+${st.changePercentageLastMonth}%` : `${st.changePercentageLastMonth}%`}</span>
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Regional Insight Card (4 cols) */}
          <div className="lg:col-span-4 bg-stone-50 rounded-xl p-4 border border-stone-200 flex flex-col justify-between">
            {selectedStat ? (
              <div className="space-y-3">
                <div>
                  <span className="text-[10px] text-stone-400 uppercase font-bold tracking-wider">
                    Tanlangan Hudud
                  </span>
                  <h4 className="text-base font-bold text-stone-900">
                    {selectedStat.region}
                  </h4>
                </div>

                <div className="space-y-2 text-xs font-mono">
                  <div className="bg-white p-2.5 rounded-lg border border-stone-200">
                    <span className="text-stone-500 block text-[10px] font-sans">
                      Qoramol tavsiya narxi:
                    </span>
                    <span className="text-stone-900 font-bold">
                      {formatPrice(selectedStat.averageLiveWeightPriceBeef)} soʻm / kg
                    </span>
                  </div>

                  <div className="bg-white p-2.5 rounded-lg border border-stone-200">
                    <span className="text-stone-500 block text-[10px] font-sans">
                      Qoʻy / qoʻchqor tavsiya narxi:
                    </span>
                    <span className="text-stone-900 font-bold">
                      {formatPrice(selectedStat.averageLiveWeightPriceSheep)} soʻm / kg
                    </span>
                  </div>

                  <div className="bg-white p-2.5 rounded-lg border border-stone-200">
                    <span className="text-stone-500 block text-[10px] font-sans">
                      Sogʻin zotli sigirlar oʻrtacha:
                    </span>
                    <span className="text-emerald-900 font-bold">
                      {selectedStat.averageDairyCowPrice} million soʻm
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-stone-200">
                  <span className="text-[11px] font-bold text-stone-800 block mb-1">
                    Bozor tahlili va fermerga maslahat:
                  </span>
                  <p className="text-xs text-stone-600 leading-relaxed font-sans">
                    {language === 'uz' ? selectedStat.notesUz : selectedStat.notesRu}
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-xs text-stone-500">Viloyatni tanlang</p>
            )}

            <div className="mt-4 pt-3 border-t border-stone-200 text-[11px] text-stone-500">
              * Narxlar bozor dallollarining ustamasisiz hisoblangan toza tarozi bahosidir.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
