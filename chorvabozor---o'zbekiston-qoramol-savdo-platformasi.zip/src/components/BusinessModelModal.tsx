import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { X, DollarSign, Crown, Building2, Truck, ShieldCheck, ArrowRight } from 'lucide-react';

interface BusinessModelModalProps {
  language: Language;
  onClose: () => void;
}

export const BusinessModelModal: React.FC<BusinessModelModalProps> = ({
  language,
  onClose,
}) => {
  const t = translations[language];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-emerald-950 text-white">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                ChorvaBozor Monetizatsiya & Daromad Modeli
              </h3>
              <p className="text-xs text-emerald-300">
                Platformaning barqaror biznes modeli va daromad oqimlari
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-emerald-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-stone-700">
          {/* Revenue Stream 1 */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 font-bold">
              1%
            </div>
            <div>
              <h4 className="font-bold text-stone-900 text-sm mb-0.5">
                Xavfsiz Bitim Komissiyasi (1 - 3%)
              </h4>
              <p className="text-stone-600 leading-relaxed">
                Payme/Click/Uzum orqali oʻtgan har bir xavfsiz eskrou bitimidan 1.5% olinadi. Oʻrtacha bitta qoramol bitimi (25 mln soʻm) uchun komissiya 375,000 soʻmni tashkil etadi. Bu xaridorga kafolat, platformaga asosiy daromad keltiradi.
              </p>
            </div>
          </div>

          {/* Revenue Stream 2 */}
          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0">
              <Crown className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-stone-900 text-sm mb-0.5">
                VIP va "Ommabop" Eʼlonlar Xizmati
              </h4>
              <p className="text-stone-600 leading-relaxed">
                Eʼlonni qidiruv va katalogning eng yuqorisiga chiqarish hamda @ChorvaBozor Telegram kanalida (45,000 chorvador) 1 marta post qilish: 50,000 - 150,000 soʻm.
              </p>
            </div>
          </div>

          {/* Revenue Stream 3 */}
          <div className="p-4 bg-sky-50/70 border border-sky-200 rounded-xl flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-sky-700 text-white flex items-center justify-center shrink-0">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-stone-900 text-sm mb-0.5">
                Fermer xoʻjaliklari uchun Oylik Obuna (SaaS B2B)
              </h4>
              <p className="text-stone-600 leading-relaxed">
                Yirik naslchilik fermalari va boʻrdoqichilik komplekslari uchun oylik tarif (oyiga 300,000 - 800,000 soʻm): cheksiz eʼlonlar, fermer brend sahifasi, auksion ochish huquqi va shaxsiy menejer.
              </p>
            </div>
          </div>

          {/* Revenue Stream 4 */}
          <div className="p-4 bg-purple-50/70 border border-purple-200 rounded-xl flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-700 text-white flex items-center justify-center shrink-0">
              <Truck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-stone-900 text-sm mb-0.5">
                Transport, Veterinariya va Sugʻurta Hamkorlik Ulushi
              </h4>
              <p className="text-stone-600 leading-relaxed">
                Viloyatlararo mol tashuvchi haydovchilarga buyurtma yetkazib berishdan 5-7% sheriklik toʻlovi hamda hayvon sogʻligʻini sugʻurtalash polislaridan agentlik ulushi.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
