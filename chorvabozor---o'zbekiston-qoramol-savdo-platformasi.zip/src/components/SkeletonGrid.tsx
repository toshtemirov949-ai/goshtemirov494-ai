import React from 'react';

export const SkeletonGrid: React.FC<{ count?: number }> = ({ count = 6 }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, idx) => (
        <div
          key={idx}
          className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-3.5 space-y-3 shadow-2xs overflow-hidden"
        >
          {/* Media Skeleton */}
          <div className="aspect-[4/3] rounded-xl bg-stone-200 dark:bg-stone-800 animate-shimmer" />

          {/* Unboxed Metadata Skeleton */}
          <div className="h-3 w-1/2 bg-stone-200 dark:bg-stone-800 rounded animate-shimmer" />

          {/* Title Skeleton */}
          <div className="space-y-1.5">
            <div className="h-4 w-5/6 bg-stone-200 dark:bg-stone-800 rounded animate-shimmer" />
            <div className="h-4 w-2/3 bg-stone-200 dark:bg-stone-800 rounded animate-shimmer" />
          </div>

          {/* 3 Specs Blocks */}
          <div className="grid grid-cols-3 gap-2 py-2 border-y border-stone-100 dark:border-stone-800/60">
            <div className="h-7 bg-stone-100 dark:bg-stone-800 rounded animate-shimmer" />
            <div className="h-7 bg-stone-100 dark:bg-stone-800 rounded animate-shimmer" />
            <div className="h-7 bg-stone-100 dark:bg-stone-800 rounded animate-shimmer" />
          </div>

          {/* Farmer & Price Skeleton */}
          <div className="flex justify-between items-center pt-1">
            <div className="h-3.5 w-1/3 bg-stone-200 dark:bg-stone-800 rounded animate-shimmer" />
            <div className="h-5 w-1/3 bg-stone-200 dark:bg-stone-800 rounded animate-shimmer" />
          </div>

          {/* Buttons Skeleton */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="h-9 bg-stone-100 dark:bg-stone-800 rounded-xl animate-shimmer" />
            <div className="h-9 bg-stone-200 dark:bg-stone-800 rounded-xl animate-shimmer" />
          </div>
        </div>
      ))}
    </div>
  );
};
