import React from 'react';
import { AnimalDepartment, Language, LivestockCategory } from '../types';
import { translations } from '../translations';
import {
  Search,
  ShieldCheck,
  CheckCircle2,
  FileCheck2,
  TrendingUp,
  Truck,
  Zap,
  Play,
  BookOpen,
  Mic,
  MicOff,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Sparkles,
  Plus,
} from 'lucide-react';

interface HeroSectionProps {
  language: Language;
  selectedDepartment: AnimalDepartment;
  onSelectDepartment: (dept: AnimalDepartment) => void;
  selectedCategory: LivestockCategory;
  onSelectCategory: (category: LivestockCategory) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenPriceIndex: () => void;
  onOpenTransport: () => void;
  onOpenAuctions: () => void;
  onOpenReels?: () => void;
  onOpenBreedGuide?: () => void;
  onOpenSellerGuide?: () => void;
  onOpenPromo?: () => void;
  onOpenQurbonlik?: () => void;
  onOpenAddListingWithDept?: (dept: 'qoramol' | 'quy' | 'ot') => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  language,
  selectedDepartment,
  onSelectDepartment,
  selectedCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  onOpenPriceIndex,
  onOpenTransport,
  onOpenAuctions,
  onOpenReels,
  onOpenBreedGuide,
  onOpenSellerGuide,
  onOpenPromo,
  onOpenQurbonlik,
  onOpenAddListingWithDept,
}) => {
  const t = translations[language];

  // Alternating Rotating Advertisement Carousel State
  const [adIndex, setAdIndex] = React.useState(0);
  const [isAdPaused, setIsAdPaused] = React.useState(false);

  // Voice Search (Web Speech API)
  const [isListening, setIsListening] = React.useState(false);
  const [voiceNotice, setVoiceNotice] = React.useState<string | null>(null);
  const recognitionRef = React.useRef<any>(null);

  const isSpeechSupported =
    typeof window !== 'undefined' &&
    !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);

  React.useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const startVoiceSearch = () => {
    if (!isSpeechSupported) {
      setVoiceNotice(
        language === 'uz'
          ? 'Brauzeringiz ovozli qidiruvni qoʻllab-quvvatlamaydi (Google Chrome yoki Edge tavsiya etiladi)'
          : 'Ваш браузер не поддерживает голосовой ввод (рекомендуется Chrome)'
      );
      setTimeout(() => setVoiceNotice(null), 4000);
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
      setIsListening(false);
      setVoiceNotice(null);
      return;
    }

    try {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;

      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = language === 'uz' ? 'uz-UZ' : 'ru-RU';

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceNotice(
          language === 'uz'
            ? '🎙️ Tinglanmoqda... Gapiring (Masalan: "Golshtin 500kg", "Hisor qoʻchqor")'
            : '🎙️ Слушаю... Говорите (Например: "Голштин 500кг", "Гиссарский баран")'
        );
      };

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        if (transcript) {
          onSearchChange(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('SpeechRecognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setVoiceNotice(
            language === 'uz'
              ? 'Mikrofondan foydalanishga ruxsat berilmadi.'
              : 'Доступ к микрофону заблокирован.'
          );
        } else if (event.error === 'no-speech') {
          setVoiceNotice(
            language === 'uz'
              ? 'Ovoz eshitilmadi. Qaytadan urinib koʻring.'
              : 'Речь не распознана. Попробуйте еще раз.'
          );
        } else {
          setVoiceNotice(
            language === 'uz'
              ? 'Ovozni aniqlashda xatolik yuz berdi.'
              : 'Ошибка распознавания речи.'
          );
        }
        setTimeout(() => setVoiceNotice(null), 3500);
      };

      recognition.onend = () => {
        setIsListening(false);
        setTimeout(() => {
          setVoiceNotice(null);
          const el = document.getElementById('catalog');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }, 1200);
      };

      recognition.start();
    } catch (err) {
      console.error(err);
      setIsListening(false);
      setVoiceNotice('Mikrofonni ishga tushirishda xatolik.');
      setTimeout(() => setVoiceNotice(null), 3000);
    }
  };

  const categories: { key: LivestockCategory; label: string }[] = [
    { key: 'all', label: t.catAll },
    { key: 'dairy', label: t.catDairy },
    { key: 'beef', label: t.catBeef },
    { key: 'calf', label: t.catCalf },
    { key: 'qurbonlik', label: t.catQurbonlik },
    { key: 'sheep', label: t.catSheep },
    { key: 'wholesale', label: t.catWholesale },
  ];

  const heroAds = [
    {
      id: 'ad-fura',
      badge: '🚚 100 KM BEPUL FURA',
      badgeColor: 'bg-amber-400 text-stone-950 font-black',
      title: 'Chorvavoz Fura: Bepul Yetkazish',
      subtitle: 'Velosiped emas! Katta qoramol va qoʻylar uchun 2 qavatli shamollatgichli maxsus yuk furasida eshikkacha yetkazamiz.',
      tag: '0 soʻm (TEKIN)',
      image: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&q=80',
      actionLabel: 'Fura xizmatini koʻrish',
      action: onOpenTransport,
    },
    {
      id: 'ad-qurbonlik',
      badge: '🐑 QURBONLIK 2026 BRON',
      badgeColor: 'bg-emerald-500 text-white font-black',
      title: 'Qurbonlik 2026: 30% Arzon Bron',
      subtitle: 'Shariat talablariga mos, tish yorgan semiz Hisor va Jaydari qoʻchqorlar. Bepul soʻyish va eshikkacha toza yetkazish.',
      tag: '3 200 000 soʻmdan',
      image: 'https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80',
      actionLabel: 'Qurbonlikni bron qilish',
      action: () => {
        if (onOpenQurbonlik) onOpenQurbonlik();
        else {
          const el = document.getElementById('catalog');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }
      },
    },
    {
      id: 'ad-golshtin',
      badge: '🐂 SUT FERMASI: 30L+ SUT',
      badgeColor: 'bg-sky-500 text-white font-black',
      title: 'Naslli Golshtin & Simmental Sigirlar',
      subtitle: 'Kunlik 28-35 litr sut kafolati, Davlat veterinariya pasporti va sunʼiy qochirish sertifikati bilan.',
      tag: '28-35 L Sut/kun',
      image: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?auto=format&fit=crop&w=800&q=80',
      actionLabel: 'Qoramol kabinetiga oʻtish',
      action: () => {
        onSelectDepartment('qoramol');
        const el = document.getElementById('catalog');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      },
    },
    {
      id: 'ad-otlar',
      badge: '🐎 QORABAYIR & AXALTAKA',
      badgeColor: 'bg-amber-600 text-white font-black',
      title: 'Poyga va Koʻpkari Uchun Chopqir Otlar',
      subtitle: 'Zotdor aygʻir va toygʻirlar. Nasl pasporti, tezlik (60+ km/soat) va boʻy koʻrsatkichlari toʻliq tekshirilgan.',
      tag: 'Nasl Pasporti Bor',
      image: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?auto=format&fit=crop&w=800&q=80',
      actionLabel: 'Otlar kabinetiga oʻtish',
      action: () => {
        onSelectDepartment('ot');
        const el = document.getElementById('catalog');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      },
    },
    {
      id: 'ad-farmer-vip',
      badge: '⚡ FERMERLARGA 0% KOMISSIYA',
      badgeColor: 'bg-indigo-600 text-white font-black',
      title: 'Fermerlar Uchun: 1 Oy Bepul VIP Reklama',
      subtitle: 'Mollaringizni dallolsiz, toʻgʻridan-toʻgʻri 100 000+ chorvadorlarga soting. Telegram botimizda tekin eʼlon joylashtirish.',
      tag: '0% Komissiya',
      image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=800&q=80',
      actionLabel: 'VIP Aksiya Tafsilotlari',
      action: () => {
        if (onOpenPromo) onOpenPromo();
      },
    },
    {
      id: 'ad-escrow',
      badge: '🛡️ 100% XAVFSIZ SAVDO',
      badgeColor: 'bg-emerald-600 text-white font-black',
      title: 'Xavfsiz Toʻlov (Eskrou) Kafolati',
      subtitle: 'Hayvon fura bilan uyingizga yetib kelib, koʻzingiz bilan koʻrmaguningizcha pul platformada xavfsiz saqlanadi.',
      tag: '100% Kafolat',
      image: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=800&q=80',
      actionLabel: 'Eskrou tizimi haqida',
      action: () => {
        if (onOpenPromo) onOpenPromo();
      },
    },
  ];

  // Auto rotate every 3.8s
  React.useEffect(() => {
    if (isAdPaused) return;
    const timer = setInterval(() => {
      setAdIndex((prev) => (prev + 1) % heroAds.length);
    }, 3800);
    return () => clearInterval(timer);
  }, [isAdPaused, heroAds.length]);

  const currentAd = heroAds[adIndex];

  return (
    <section className="relative bg-gradient-to-br from-[#064E3B] via-[#043327] to-[#021A14] dark:from-[#061210] dark:via-[#041C16] dark:to-[#02100C] text-white pt-6 pb-8 sm:pt-12 sm:pb-14 px-3 sm:px-6 lg:px-8 border-b border-[#047857]/30 dark:border-[#0E3D32] transition-colors overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Split 2-Column: Left Side Text (Chekada) + Right Side Alternating Ad Showcase (Yonida aylanuvchi reklama) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center mb-8 sm:mb-10">
          {/* Left Column: Yozuvlar chekada */}
          <div className="lg:col-span-7 text-left space-y-3 sm:space-y-4">
            {/* Subtle kicker (Oasis Emerald) */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#064E3B]/80 border border-[#10B981]/40 text-[#ECFDF5] text-xs font-semibold shadow-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Oʻzbekistonda 1-raqamli kafolatlangan chorva bozori</span>
            </div>

            {/* Primary Headline */}
            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white font-serif leading-[1.15]">
              {t.heroHeadline}
            </h1>

            {/* Subtitle */}
            <p className="text-emerald-100/90 dark:text-stone-300 text-xs sm:text-sm md:text-base font-normal leading-relaxed max-w-2xl">
              {t.heroSubheadline}
            </p>

            {/* Live Search Input Bar with Voice Search */}
            <div className="pt-1">
              <div
                className={`relative flex items-center bg-white dark:bg-[#072D24] rounded-2xl shadow-xl p-1.5 border border-[#E5ECE7] dark:border-[#0E3D32] transition-all ${
                  isListening
                    ? 'ring-2 ring-red-500 shadow-red-500/20'
                    : 'focus-within:ring-2 focus-within:ring-[#10B981]'
                }`}
              >
                <Search className="w-5 h-5 text-stone-400 dark:text-emerald-400/70 ml-3 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder={
                    isListening
                      ? (language === 'uz' ? 'Ovozingiz tinglanmoqda... (Gapiring)' : 'Идет распознавание голоса...')
                      : t.searchPlaceholder
                  }
                  className="w-full px-3 py-2.5 text-[#1C2A23] dark:text-white text-xs sm:text-sm md:text-base focus:outline-none placeholder:text-stone-400 dark:placeholder:text-stone-400 bg-transparent"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => onSearchChange('')}
                    className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 text-xs px-2 py-1 mr-1 cursor-pointer"
                    title="Tozalash"
                  >
                    ✕
                  </button>
                )}

                {/* Voice Search Microphone Button */}
                <button
                  type="button"
                  onClick={startVoiceSearch}
                  title={
                    isListening
                      ? (language === 'uz' ? 'Ovozli yozishni toʻxtatish' : 'Остановить запись')
                      : (language === 'uz' ? 'Ovozli qidiruv (Masalan: "Golshtin 500kg")' : 'Голосовой поиск (Например: "Голштин 500кг")')
                  }
                  className={`p-2 sm:p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0 mr-1 ${
                    isListening
                      ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse shadow-md shadow-red-500/40 ring-2 ring-red-300'
                      : 'bg-[#F7F9F6] dark:bg-[#041C16] hover:bg-emerald-100 dark:hover:bg-[#0E3D32] text-stone-700 dark:text-stone-300'
                  }`}
                >
                  {isListening ? (
                    <Mic className="w-4 h-4 animate-bounce" />
                  ) : (
                    <Mic className="w-4 h-4" />
                  )}
                </button>

                {/* Primary Search CTA Button (Accent Gold) */}
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById('catalog');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-[#F59E0B]/20 shrink-0 flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span>Izlash</span>
                </button>
              </div>

              {/* Voice Search Status Notification */}
              {voiceNotice && (
                <div className="mt-2 text-xs font-semibold px-3 py-1.5 rounded-lg bg-stone-800 border border-emerald-500 text-emerald-300 inline-flex items-center gap-2 animate-in fade-in shadow-md">
                  <span className={`w-2 h-2 rounded-full ${isListening ? 'bg-red-400 animate-ping' : 'bg-emerald-400'}`} />
                  <span>{voiceNotice}</span>
                </div>
              )}
            </div>

            {/* Trust highlights */}
            <div className="flex flex-wrap items-center gap-2.5 sm:gap-4 text-[11px] sm:text-xs text-emerald-200/90 font-medium pt-1">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>280+ Fermer</span>
              </span>
              <span className="text-emerald-700">·</span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% Xavfsiz Toʻlov</span>
              </span>
              <span className="text-emerald-700">·</span>
              <span className="flex items-center gap-1.5">
                <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Davlat Vet Muhri</span>
              </span>
            </div>
          </div>

          {/* Right Column: Yonidan aylanib turuvchi reklama (Rotating Ad Showcase Card) */}
          <div
            className="lg:col-span-5 w-full"
            onMouseEnter={() => setIsAdPaused(true)}
            onMouseLeave={() => setIsAdPaused(false)}
          >
            <div className="relative rounded-3xl overflow-hidden border border-[#10B981]/40 bg-[#02100C] shadow-2xl group transition-all">
              {/* Background Promo Image */}
              <div className="relative h-64 sm:h-72 w-full overflow-hidden">
                <img
                  src={currentAd.image}
                  alt={currentAd.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#02100C] via-[#02100C]/70 to-black/30" />
              </div>

              {/* Top Controls Overlay */}
              <div className="absolute top-3.5 inset-x-3.5 flex items-center justify-between gap-2 z-10">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 shadow-md animate-pulse ${currentAd.badgeColor}`}>
                  <Zap className="w-3 h-3 fill-current" />
                  <span>{currentAd.badge}</span>
                </span>

                <div className="flex items-center gap-1 bg-[#02100C]/80 backdrop-blur-md px-2 py-1 rounded-xl border border-[#0E3D32] text-[10px] font-mono text-[#10B981]">
                  <span>{adIndex + 1}/{heroAds.length}</span>
                  <div className="flex items-center ml-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setAdIndex((prev) => (prev - 1 + heroAds.length) % heroAds.length);
                      }}
                      className="p-1 hover:text-white cursor-pointer"
                      title="Oldingi aksiya"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setAdIndex((prev) => (prev + 1) % heroAds.length);
                      }}
                      className="p-1 hover:text-white cursor-pointer"
                      title="Keyingi aksiya"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Bottom Card Content */}
              <div className="absolute bottom-0 inset-x-0 p-4 sm:p-5 z-10 text-left">
                <div className="inline-block px-2 py-0.5 rounded-md bg-[#F59E0B] text-[#02100C] font-mono font-extrabold text-[11px] mb-2 shadow-xs">
                  {currentAd.tag}
                </div>

                <h3 className="font-extrabold text-base sm:text-lg text-white font-serif leading-snug mb-1 drop-shadow-md">
                  {currentAd.title}
                </h3>

                <p className="text-xs text-stone-200 line-clamp-2 leading-relaxed mb-3">
                  {currentAd.subtitle}
                </p>

                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={currentAd.action}
                    className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-[#F59E0B]/20 transition-all cursor-pointer"
                  >
                    <span>{currentAd.actionLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  {/* Dots Navigator */}
                  <div className="flex items-center gap-1.5">
                    {heroAds.map((_, dotIdx) => (
                      <button
                        key={dotIdx}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setAdIndex(dotIdx);
                        }}
                        className={`h-1.5 rounded-full transition-all cursor-pointer ${
                          adIndex === dotIdx ? 'w-5 bg-amber-400' : 'w-1.5 bg-white/40 hover:bg-white/80'
                        }`}
                        title={`Aksiya ${dotIdx + 1}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Add Livestock Buttons (Mol qoʻshish, Qoʻy qoʻshish, Ot qoʻshish) */}
        <div className="max-w-3xl mx-auto mb-7">
          <div className="text-xs font-semibold text-stone-300 uppercase tracking-wider mb-2.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <Plus className="w-3.5 h-3.5" />
              <span>{language === 'uz' ? 'Eʼlon Joylashtirish (Dallolsiz Sotuv):' : 'Разместить объявление без посредников:'}</span>
            </span>
            {onOpenBreedGuide && (
              <button
                type="button"
                onClick={onOpenBreedGuide}
                className="underline text-emerald-300 hover:text-white cursor-pointer font-bold inline-flex items-center gap-1 normal-case text-xs"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Zotlar Qomusi</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* 1. MOL QO'SHISH */}
            <button
              type="button"
              onClick={() => onOpenAddListingWithDept ? onOpenAddListingWithDept('qoramol') : null}
              className="p-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white border border-emerald-500 shadow-md shadow-emerald-700/20 text-left transition-all cursor-pointer flex items-center gap-3 group"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform shrink-0">🐂</span>
              <div className="overflow-hidden">
                <div className="font-extrabold text-xs sm:text-sm flex items-center gap-1">
                  <span>Mol qoʻshish</span>
                  <Plus className="w-3.5 h-3.5 text-emerald-200 group-hover:rotate-90 transition-transform" />
                </div>
                <div className="text-[10px] text-emerald-100 truncate">
                  Sigir, buqa, buzoq eʼloni berish
                </div>
              </div>
            </button>

            {/* 2. QO'Y QO'SHISH */}
            <button
              type="button"
              onClick={() => onOpenAddListingWithDept ? onOpenAddListingWithDept('quy') : null}
              className="p-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white border border-emerald-500 shadow-md shadow-emerald-700/20 text-left transition-all cursor-pointer flex items-center gap-3 group"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform shrink-0">🐑</span>
              <div className="overflow-hidden">
                <div className="font-extrabold text-xs sm:text-sm flex items-center gap-1">
                  <span>Qoʻy qoʻshish</span>
                  <Plus className="w-3.5 h-3.5 text-emerald-200 group-hover:rotate-90 transition-transform" />
                </div>
                <div className="text-[10px] text-emerald-100 truncate">
                  Hisor, qoʻchqor, sovliq eʼloni
                </div>
              </div>
            </button>

            {/* 3. OT QO'SHISH */}
            <button
              type="button"
              onClick={() => onOpenAddListingWithDept ? onOpenAddListingWithDept('ot') : null}
              className="p-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white border border-emerald-500 shadow-md shadow-emerald-700/20 text-left transition-all cursor-pointer flex items-center gap-3 group"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform shrink-0">🐎</span>
              <div className="overflow-hidden">
                <div className="font-extrabold text-xs sm:text-sm flex items-center gap-1">
                  <span>Ot qoʻshish</span>
                  <Plus className="w-3.5 h-3.5 text-emerald-200 group-hover:rotate-90 transition-transform" />
                </div>
                <div className="text-[10px] text-emerald-100 truncate">
                  Qorabayir, Axaltaka, tulpor eʼloni
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Category Segmented Filter Controls (30% Neutral vs 10% Accent) */}
        <div className="flex items-center justify-center flex-wrap gap-2 mb-8">
          {categories.map((c) => {
            const isActive = selectedCategory === c.key;
            return (
              <button
                key={c.key}
                type="button"
                onClick={() => onSelectCategory(c.key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600 text-white font-bold shadow-md shadow-emerald-600/25 ring-1 ring-emerald-400'
                    : 'bg-stone-800/90 text-stone-300 border border-stone-700/80 hover:bg-stone-750 hover:text-white'
                }`}
              >
                {c.label}
              </button>
            );
          })}
        </div>

        {/* Quick Utility Shortcut Badges */}
        <div className="flex items-center justify-center flex-wrap gap-3 text-xs text-stone-300 pt-3 border-t border-stone-800">
          <button
            onClick={onOpenPriceIndex}
            className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
          >
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="underline decoration-emerald-500/50 underline-offset-4">{t.navPriceIndex}</span>
          </button>
          <span className="text-emerald-700">·</span>
          <button
            onClick={onOpenTransport}
            className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
          >
            <Truck className="w-4 h-4 text-emerald-400" />
            <span className="underline decoration-emerald-500/50 underline-offset-4">{t.navTransport}</span>
          </button>
          <span className="text-emerald-700">·</span>
          <button
            onClick={onOpenAuctions}
            className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="underline decoration-amber-500/50 underline-offset-4">{t.navAuctions}</span>
          </button>
          {onOpenReels && (
            <>
              <span className="text-emerald-700">·</span>
              <button
                onClick={onOpenReels}
                className="flex items-center gap-1.5 text-amber-300 hover:text-white transition-colors cursor-pointer font-semibold"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span className="underline decoration-amber-400/50 underline-offset-4">Dinamik Reels</span>
              </button>
            </>
          )}
          {onOpenSellerGuide && (
            <>
              <span className="text-emerald-700">·</span>
              <button
                onClick={onOpenSellerGuide}
                className="flex items-center gap-1.5 text-amber-300 hover:text-white transition-colors cursor-pointer font-bold"
              >
                <TrendingUp className="w-4 h-4 text-amber-400" />
                <span className="underline decoration-amber-400 underline-offset-4">Oltin Sotuvchi Qoʻllanmasi</span>
              </button>
            </>
          )}
        </div>
      </div>
    </section>
  );
};
