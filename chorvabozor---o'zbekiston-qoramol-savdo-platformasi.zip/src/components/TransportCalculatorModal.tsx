import React, { useState } from 'react';
import { distanceMatrixKm } from '../data/mockData';
import { Language, UzbekistanRegion, LivestockItem } from '../types';
import { translations } from '../translations';
import { X, Truck, Phone, Send, MapPin, Clock, ArrowRight, ShieldCheck, Check } from 'lucide-react';

interface TransportCalculatorModalProps {
  language: Language;
  onClose: () => void;
  preselectedListing?: LivestockItem | null;
}

const regionsList: UzbekistanRegion[] = [
  'Toshkent shahri',
  'Toshkent viloyati',
  'Samarqand',
  'Andijon',
  'Fargʻona',
  'Namangan',
  'Qashqadaryo',
  'Surxondaryo',
  'Buxoro',
  'Xorazm',
  'Jizzax',
  'Sirdaryo',
  'Navoiy',
  'Qoraqalpogʻiston Respublikasi',
];

interface DriverInfo {
  name: string;
  vehicle: string;
  plateNumber: string;
  phone: string;
  rating: number;
  completedTrips: number;
  region: string;
}

const mockDrivers: DriverInfo[] = [
  {
    name: 'Shavkatbek Haydarov',
    vehicle: 'MAN TGX Maxsus 2 Qavatli Chorvavoz Fura (40-50 bosh)',
    plateNumber: '01 442 ABC',
    phone: '+998 90 912 34 56',
    rating: 4.98,
    completedTrips: 248,
    region: 'Toshkent - Samarqand - Buxoro - Vodiy',
  },
  {
    name: 'Ilhomjon Qodirov',
    vehicle: 'Isuzu NPR 75 (2 qavatli chorvavoz)',
    plateNumber: '30 819 BAA',
    phone: '+998 93 321 00 11',
    rating: 4.88,
    completedTrips: 230,
    region: 'Samarqand - Qashqadaryo - Buxoro',
  },
  {
    name: 'Akbar Shodmonov',
    vehicle: 'Labo Furgon (Mayda tuyoqli mollar)',
    plateNumber: '60 707 VAA',
    phone: '+998 91 555 88 44',
    rating: 4.9,
    completedTrips: 92,
    region: 'Andijon - Namangan - Fargʻona',
  },
];

export const TransportCalculatorModal: React.FC<TransportCalculatorModalProps> = ({
  language,
  onClose,
  preselectedListing,
}) => {
  const t = translations[language];

  const [fromRegion, setFromRegion] = useState<UzbekistanRegion>(
    preselectedListing ? preselectedListing.region : 'Samarqand'
  );
  const [toRegion, setToRegion] = useState<UzbekistanRegion>('Toshkent shahri');
  const [vehicleType, setVehicleType] = useState<'cattle_truck' | 'isuzu' | 'gazel' | 'labo'>('cattle_truck');
  const [bookingSuccess, setBookingSuccess] = useState(false);

  // Calculate approximate distance
  const getDistance = (from: string, to: string): number => {
    if (from === to) return 40;
    if (distanceMatrixKm[from] && distanceMatrixKm[from][to]) {
      return distanceMatrixKm[from][to];
    }
    if (distanceMatrixKm[to] && distanceMatrixKm[to][from]) {
      return distanceMatrixKm[to][from];
    }
    return 350; // fallback average
  };

  const distanceKm = getDistance(fromRegion, toRegion);

  // Rate per km based on vehicle
  const ratesPerKm: Record<string, number> = {
    labo: 3500,        // 3,500 so'm / km
    gazel: 6000,       // 6,000 so'm / km
    isuzu: 11000,      // 11,000 so'm / km
    cattle_truck: 18000 // 18,000 so'm / km
  };

  const baseStartFee = 150000;
  const estimatedCost = Math.round(baseStartFee + distanceKm * (ratesPerKm[vehicleType] || 6000));
  const estimatedHours = Math.max(1, Math.round((distanceKm / 65) * 10) / 10);

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('uz-UZ').format(p);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-[#E5ECE7] dark:border-[#0E3D32] transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#047857]/40 dark:border-[#0E3D32] bg-gradient-to-r from-[#064E3B] to-[#047857] text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#041C16]/50 flex items-center justify-center border border-[#10B981]/30">
              <Truck className="w-4 h-4 text-[#10B981]" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                {t.transportTitle}
              </h3>
              <p className="text-xs text-emerald-100">
                {t.transportSubtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Real Fura Photo Banner */}
          <div className="relative rounded-2xl overflow-hidden border border-stone-200 shadow-sm h-36 sm:h-44 group">
            <img
              src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1200&q=85"
              alt="Chorvavoz Fura"
              className="w-full h-full object-cover object-center brightness-75 group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-stone-950/40 to-transparent" />
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-amber-400 text-stone-950 text-[10px] font-black tracking-wider uppercase flex items-center gap-1 shadow-md">
                <Truck className="w-3.5 h-3.5" />
                PROFESSIONAL CHORVAVOZ FURA
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-600/90 text-white text-[10px] font-bold">
                100% Xavfsiz Logistika
              </span>
            </div>
            <div className="absolute bottom-3 left-3 right-3 text-white">
              <h4 className="font-extrabold text-sm sm:text-base leading-tight drop-shadow-sm">
                Ogʻir Vaznli Chorva Uchun Maxsus 2 Qavatli Fura va Furgonlar
              </h4>
              <p className="text-[11px] text-stone-200 mt-0.5 font-normal line-clamp-1">
                Velosiped yoki moslashtirilmagan texnika emas — shamollatish tizimli, sirpanmaydigan polli va sugʻurtalangan ogʻir yuk furalari.
              </p>
            </div>
          </div>

          {preselectedListing && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center justify-between text-xs text-emerald-950">
              <div className="flex items-center gap-2">
                <span className="font-bold">Tanlangan hayvon:</span>
                <span>{preselectedListing.titleUz} ({preselectedListing.region})</span>
              </div>
              <span className="font-mono font-bold">{preselectedListing.weightKg} kg</span>
            </div>
          )}

          {/* Route Config */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-rose-600" />
                <span>{t.fromLocation}</span>
              </label>
              <select
                value={fromRegion}
                onChange={(e) => setFromRegion(e.target.value as UzbekistanRegion)}
                className="w-full text-xs font-semibold p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 text-stone-900 dark:text-stone-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-700"
              >
                {regionsList.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t.toLocation}</span>
              </label>
              <select
                value={toRegion}
                onChange={(e) => setToRegion(e.target.value as UzbekistanRegion)}
                className="w-full text-xs font-semibold p-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 text-stone-900 dark:text-stone-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-700"
              >
                {regionsList.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Vehicle Selection */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-2">
              {t.selectVehicle}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <button
                type="button"
                onClick={() => setVehicleType('cattle_truck')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative ${
                  vehicleType === 'cattle_truck'
                    ? 'border-emerald-700 bg-emerald-50/70 dark:bg-emerald-950/60 ring-2 ring-emerald-700 font-semibold shadow-xs'
                    : 'border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="font-extrabold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                    <span>Maxsus Chorvavoz Fura</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-amber-400 text-stone-950 text-[9px] font-black uppercase">
                    Tavsiya
                  </span>
                </div>
                <div className="text-stone-600 dark:text-stone-400 text-[11px] leading-tight">
                  Katta qoramol, 40-50 bosh qoʻylar va otlar uchun 2 qavatli xavfsiz fura.
                </div>
                <div className="font-mono text-emerald-800 dark:text-emerald-400 text-[11px] mt-1.5 font-bold">~18,000 soʻm/km</div>
              </button>

              <button
                type="button"
                onClick={() => setVehicleType('isuzu')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  vehicleType === 'isuzu'
                    ? 'border-emerald-700 bg-emerald-50/60 dark:bg-emerald-950/60 ring-2 ring-emerald-700 font-semibold'
                    : 'border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-800'
                }`}
              >
                <div className="font-bold text-stone-900 dark:text-stone-100 mb-0.5">Isuzu Furgon / Bort</div>
                <div className="text-stone-500 dark:text-stone-400 text-[11px]">{t.isuzuDesc}</div>
                <div className="font-mono text-emerald-800 dark:text-emerald-400 text-[11px] mt-1 font-bold">~11,000 soʻm/km</div>
              </button>

              <button
                type="button"
                onClick={() => setVehicleType('gazel')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  vehicleType === 'gazel'
                    ? 'border-emerald-700 bg-emerald-50/60 dark:bg-emerald-950/60 ring-2 ring-emerald-700 font-semibold'
                    : 'border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-800'
                }`}
              >
                <div className="font-bold text-stone-900 dark:text-stone-100 mb-0.5">Gazel Moslashtirilgan</div>
                <div className="text-stone-500 dark:text-stone-400 text-[11px]">{t.gazelDesc}</div>
                <div className="font-mono text-emerald-800 dark:text-emerald-400 text-[11px] mt-1 font-bold">~6,000 soʻm/km</div>
              </button>

              <button
                type="button"
                onClick={() => setVehicleType('labo')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  vehicleType === 'labo'
                    ? 'border-emerald-700 bg-emerald-50/60 dark:bg-emerald-950/60 ring-2 ring-emerald-700 font-semibold'
                    : 'border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-800'
                }`}
              >
                <div className="font-bold text-stone-900 dark:text-stone-100 mb-0.5">Labo / Damas Furgon</div>
                <div className="text-stone-500 dark:text-stone-400 text-[11px]">{t.laboDesc}</div>
                <div className="font-mono text-emerald-800 dark:text-emerald-400 text-[11px] mt-1 font-bold">~3,500 soʻm/km</div>
              </button>
            </div>
          </div>

          {/* Estimation Summary Box */}
          <div className="bg-stone-900 text-white rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono">
            <div>
              <div className="text-stone-400 text-xs font-sans">
                Yoʻnalish masofasi: <span className="text-white font-bold">{distanceKm} km</span>
              </div>
              <div className="text-stone-400 text-xs font-sans mt-0.5">
                {t.estimatedTime} <span className="text-white font-bold">~{estimatedHours} soat</span>
              </div>
            </div>

            <div className="text-right sm:border-l sm:border-stone-800 sm:pl-6">
              <span className="text-stone-400 text-[11px] font-sans block">
                {t.estimatedCost}
              </span>
              <span className="text-2xl font-extrabold text-amber-400 tabular-nums">
                {formatPrice(estimatedCost)}
              </span>
              <span className="text-xs text-stone-300 ml-1.5 font-sans">soʻm</span>
            </div>
          </div>

          {/* Verified Drivers Directory */}
          <div>
            <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
              Yoʻnalishdagi Tasdiqlangan Haydovchilar (GPS + Sogʻlom saqlash kafolati)
            </h4>

            {bookingSuccess ? (
              <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 text-center text-xs text-emerald-900">
                <div className="w-8 h-8 rounded-full bg-emerald-200 text-emerald-800 flex items-center justify-center mx-auto mb-1.5">
                  <Check className="w-5 h-5 stroke-[3]" />
                </div>
                <span className="font-bold text-sm block">Buyurtma haydovchiga yuborildi!</span>
                <span>Haydovchi 10 daqiqa ichida telefoningizga qoʻngʻiroq qiladi.</span>
              </div>
            ) : (
              <div className="space-y-2">
                {mockDrivers.map((d, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="font-bold text-stone-900">{d.name}</div>
                      <div className="text-stone-500 font-mono text-[11px]">
                        {d.vehicle} · {d.plateNumber}
                      </div>
                      <div className="text-stone-600 text-[11px] mt-0.5">
                        Faol hudud: <span className="font-medium">{d.region}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${d.phone}`}
                        className="p-2 rounded-lg bg-white border border-stone-300 hover:bg-stone-100 text-stone-800 transition-colors"
                        title="Qoʻngʻiroq qilish"
                      >
                        <Phone className="w-3.5 h-3.5 text-emerald-700" />
                      </a>
                      <button
                        type="button"
                        onClick={() => setBookingSuccess(true)}
                        className="py-1.5 px-3 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold transition-colors cursor-pointer text-xs"
                      >
                        Buyurtma
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
