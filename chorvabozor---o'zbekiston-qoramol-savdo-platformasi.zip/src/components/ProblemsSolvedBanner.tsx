import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { BadgePercent, Video, Stethoscope, Lock, Truck } from 'lucide-react';

interface ProblemsSolvedBannerProps {
  language: Language;
}

export const ProblemsSolvedBanner: React.FC<ProblemsSolvedBannerProps> = ({ language }) => {
  const t = translations[language];

  return (
    <div className="bg-stone-50 dark:bg-stone-900/40 border-b border-stone-200 dark:border-stone-800 py-8 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 tracking-tight">
            {t.problemSolvedTitle}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Problem 1 */}
          <div className="bg-white dark:bg-stone-900 p-4 rounded-2xl border border-stone-200/90 dark:border-stone-800 shadow-2xs">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center mb-2.5">
              <BadgePercent className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1">
              Dallolsiz Toʻgʻridan-toʻgʻri Narx
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
              {t.problem1}
            </p>
          </div>

          {/* Problem 2 */}
          <div className="bg-white dark:bg-stone-900 p-4 rounded-2xl border border-stone-200/90 dark:border-stone-800 shadow-2xs">
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 flex items-center justify-center mb-2.5">
              <Video className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1">
              Video va Tarozi Koʻrigi
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
              {t.problem2}
            </p>
          </div>

          {/* Problem 3 */}
          <div className="bg-white dark:bg-stone-900 p-4 rounded-2xl border border-stone-200/90 dark:border-stone-800 shadow-2xs">
            <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 flex items-center justify-center mb-2.5">
              <Stethoscope className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1">
              Rasmiy Davlat Vet Pasporti
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
              {t.problem3}
            </p>
          </div>

          {/* Problem 4 */}
          <div className="bg-white dark:bg-stone-900 p-4 rounded-2xl border border-stone-200/90 dark:border-stone-800 shadow-2xs">
            <div className="w-8 h-8 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 flex items-center justify-center mb-2.5">
              <Lock className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1">
              Xavfsiz Toʻlov (Eskrou)
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
              {t.problem4}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
