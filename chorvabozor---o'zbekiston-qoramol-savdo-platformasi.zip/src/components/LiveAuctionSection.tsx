import React, { useState, useMemo } from 'react';
import { mockAuctions } from '../data/mockData';
import { AuctionItem, Language } from '../types';
import { translations } from '../translations';
import { Zap, Clock, TrendingUp, Check, AlertCircle, X, ShieldAlert, Users, RotateCcw } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

interface LiveAuctionSectionProps {
  language: Language;
  onClose?: () => void;
  isModal?: boolean;
}

export const LiveAuctionSection: React.FC<LiveAuctionSectionProps> = ({
  language,
  onClose,
  isModal = false,
}) => {
  const t = translations[language];
  const [auctions, setAuctions] = useState<AuctionItem[]>(mockAuctions);
  const [selectedAuctionId, setSelectedAuctionId] = useState<string>(mockAuctions[0].id);
  const [bidAmountInput, setBidAmountInput] = useState<string>('');
  const [bidError, setBidError] = useState<string>('');
  const [bidSuccess, setBidSuccess] = useState<string>('');

  const currentAuction = auctions.find((a) => a.id === selectedAuctionId) || auctions[0];

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat('uz-UZ').format(p);
  };

  const minAcceptableBid = currentAuction.currentBidUzs + currentAuction.minStepUzs;

  // Price Trend History Data for Recharts
  const chartData = useMemo(() => {
    const points = [
      {
        shortLabel: language === 'uz' ? 'Start' : 'Старт',
        step: 0,
        amount: currentAuction.startingPriceUzs,
        bidder: language === 'uz' ? 'Boshlangʻich narx' : 'Стартовая цена',
        timestamp: language === 'uz' ? 'Auksion start' : 'Старт аукциона',
      },
    ];

    const reversedBids = [...currentAuction.bids].reverse();
    reversedBids.forEach((b, idx) => {
      points.push({
        shortLabel: `#${idx + 1}`,
        step: idx + 1,
        amount: b.amountUzs,
        bidder: b.bidderName,
        timestamp: b.timestamp,
      });
    });

    return points;
  }, [currentAuction, language]);

  const priceGrowthUzs = currentAuction.currentBidUzs - currentAuction.startingPriceUzs;
  const priceGrowthPercent = currentAuction.startingPriceUzs > 0
    ? ((priceGrowthUzs / currentAuction.startingPriceUzs) * 100).toFixed(1)
    : '0';

  const handlePlaceBid = (e: React.FormEvent) => {
    e.preventDefault();
    setBidError('');
    setBidSuccess('');

    const numericBid = parseInt(bidAmountInput.replace(/\D/g, ''), 10);
    if (isNaN(numericBid) || numericBid < minAcceptableBid) {
      setBidError(
        `Minimal stavka miqdori kamida ${formatPrice(minAcceptableBid)} soʻm boʻlishi lozim!`
      );
      return;
    }

    // Add bid to current auction
    const newBid = {
      id: `b-${Date.now()}`,
      bidderName: 'Siz (Tasdiqlangan xaridor)',
      bidderRegion: 'Toshkent',
      amountUzs: numericBid,
      timestamp: 'Hozirgina',
    };

    setAuctions((prev) =>
      prev.map((auc) => {
        if (auc.id === currentAuction.id) {
          return {
            ...auc,
            currentBidUzs: numericBid,
            bids: [newBid, ...auc.bids],
          };
        }
        return auc;
      })
    );

    setBidSuccess(`Tabriklaymiz! Sizning ${formatPrice(numericBid)} soʻm stavkangiz yetakchi boʻldi!`);
    setBidAmountInput('');
  };

  // Find if current user has an active bid in this auction
  const userBid = currentAuction.bids.find((b) => b.bidderName.includes('Siz'));

  const handleRefundBid = () => {
    setBidError('');
    if (!userBid) {
      setBidError(
        language === 'uz'
          ? 'Sizning ushbu auksionda qaytariladigan faol stavkangiz mavjud emas. Avval stavka qoʻyib koʻring.'
          : 'У вас нет активной ставки в этом аукционе.'
      );
      return;
    }

    const refundAmount = userBid.amountUzs;

    setAuctions((prev) =>
      prev.map((auc) => {
        if (auc.id === currentAuction.id) {
          const remainingBids = auc.bids.filter((b) => b.id !== userBid.id);
          const nextHighestBid =
            remainingBids.length > 0 ? remainingBids[0].amountUzs : auc.startingPriceUzs;
          return {
            ...auc,
            currentBidUzs: nextHighestBid,
            bids: remainingBids,
          };
        }
        return auc;
      })
    );

    setBidSuccess(
      language === 'uz'
        ? `↩️ Stavkaga qoʻyilgan ${formatPrice(refundAmount)} soʻm mablagʻingiz hisobingizga toʻliq qaytarildi va stavka bekor qilindi!`
        : `↩️ Средства ставки (${formatPrice(refundAmount)} сум) успешно возвращены на ваш баланс!`
    );
  };

  const content = (
    <div className="space-y-6">
      {/* Title & Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-[#041C16] via-[#072D24] to-[#041C16] text-[#ECFDF5] p-5 rounded-3xl border border-[#0E3D32]">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs text-[#F59E0B] font-semibold mb-1">
            <Zap className="w-4 h-4 text-[#F59E0B] fill-[#F59E0B]" />
            <span>ChorvaBozor Jonli Auksion Tizimi</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-white">
            {t.auctionTitle}
          </h2>
          <p className="text-xs text-stone-300 max-w-xl mt-1">
            {t.auctionSubtitle}
          </p>
        </div>

        {/* Tab switch between auctions */}
        <div className="flex sm:flex-col gap-2 shrink-0">
          {auctions.map((auc) => (
            <button
              key={auc.id}
              onClick={() => {
                setSelectedAuctionId(auc.id);
                setBidError('');
                setBidSuccess('');
              }}
              className={`px-3 py-2 text-xs rounded-xl text-left transition-all cursor-pointer ${
                selectedAuctionId === auc.id
                  ? 'bg-gradient-to-r from-[#D97706] to-[#F59E0B] text-white font-bold shadow-md shadow-[#F59E0B]/20'
                  : 'bg-white/10 text-stone-300 hover:bg-white/20 border border-white/10'
              }`}
            >
              <div className="truncate max-w-[180px]">{auc.titleUz}</div>
              <div className="font-mono text-[10px] opacity-80">
                {formatPrice(auc.currentBidUzs)} soʻm
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Auction Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
        {/* Left: Media & Details (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative aspect-[16/10] rounded-xl overflow-hidden bg-stone-900">
            <img
              src={currentAuction.imageUrl}
              alt={currentAuction.titleUz}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-3 left-3 bg-black/75 backdrop-blur-xs text-amber-300 px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>JONLI SAVDO</span>
            </div>
            <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-xs text-white px-3 py-1.5 rounded-lg text-xs font-mono flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Qolgan vaqt: 2 kun 04 soat</span>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 mb-1">
              <span className="font-semibold text-emerald-900 dark:text-emerald-400">{currentAuction.region}</span>
              <span>·</span>
              <span>{currentAuction.breed}</span>
              <span>·</span>
              <span className="font-bold text-stone-700 dark:text-stone-300">{currentAuction.headCount} bosh</span>
            </div>
            <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
              {language === 'uz' ? currentAuction.titleUz : currentAuction.titleRu}
            </h3>

            <div className="grid grid-cols-3 gap-2 bg-stone-50 dark:bg-stone-800/80 p-3 rounded-xl border border-stone-200 dark:border-stone-700 mt-3 text-xs font-mono">
              <div>
                <span className="text-[10px] text-stone-400 uppercase font-sans block">Bosh soni</span>
                <strong className="text-stone-900 dark:text-stone-100 font-bold">{currentAuction.headCount} ta</strong>
              </div>
              <div>
                <span className="text-[10px] text-stone-400 uppercase font-sans block">Umumiy vazn</span>
                <strong className="text-stone-900 dark:text-stone-100 font-bold">{currentAuction.totalWeightKg} kg</strong>
              </div>
              <div>
                <span className="text-[10px] text-stone-400 uppercase font-sans block">Fermer</span>
                <strong className="text-stone-900 dark:text-stone-100 font-bold truncate block">{currentAuction.sellerName}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Bidding Module & History (5 cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
          <div>
            {/* Price Box with vertically stacked prices (ustma-ust) */}
            <div className="bg-gradient-to-br from-stone-900 via-stone-950 to-stone-900 text-white rounded-2xl p-4 sm:p-5 font-mono mb-4 border border-stone-800 shadow-md">
              {/* 1. Hozirgi eng yuqori narx (Current Highest Bid) */}
              <div className="pb-3 border-b border-stone-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-stone-400 text-xs font-sans">
                    {t.currentHighestBid}
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-sans font-bold border border-amber-500/30">
                    Yetakchi stavka
                  </span>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-amber-400 tabular-nums break-words leading-tight">
                  {formatPrice(currentAuction.currentBidUzs)}{' '}
                  <span className="text-sm text-stone-300 font-sans font-normal">soʻm</span>
                </div>
              </div>

              {/* 2. Ustma-ust narxlar (Boshlang'ich narx, qadam, minimal qabul qilinadigan stavka) */}
              <div className="pt-3 space-y-2 font-sans text-xs">
                {/* Boshlang'ich narx */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 bg-stone-800/60 p-2.5 rounded-xl border border-stone-700/60">
                  <span className="text-stone-400 text-[11px] font-medium">{t.startingPrice}:</span>
                  <span className="font-mono font-bold text-stone-100 text-xs sm:text-sm">
                    {formatPrice(currentAuction.startingPriceUzs)} soʻm
                  </span>
                </div>

                {/* Minimal oshirish qadami */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 bg-amber-950/40 p-2.5 rounded-xl border border-amber-900/60">
                  <span className="text-amber-300/90 text-[11px] font-medium">Minimal qadam:</span>
                  <span className="font-mono font-bold text-amber-300 text-xs sm:text-sm">
                    +{formatPrice(currentAuction.minStepUzs)} soʻm
                  </span>
                </div>

                {/* Keyingi qabul qilinadigan stavka */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-900/60">
                  <span className="text-emerald-300/90 text-[11px] font-medium">Keyingi tavsiya stavka:</span>
                  <span className="font-mono font-bold text-emerald-300 text-xs sm:text-sm">
                    ≥ {formatPrice(minAcceptableBid)} soʻm
                  </span>
                </div>
              </div>
            </div>

            {/* Small Inline Price Trend History Line Chart (recharts) */}
            <div className="bg-stone-50 dark:bg-stone-850 rounded-2xl p-3 sm:p-4 border border-stone-200 dark:border-stone-800 mb-4 shadow-2xs">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-stone-900 dark:text-stone-100">
                  <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
                  <span>
                    {language === 'uz' ? 'Narx oʻsish dinamikasi (Trend)' : 'Динамика роста цены'}
                  </span>
                </div>
                <span className="text-[10px] font-mono font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-100/70 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                  +{formatPrice(priceGrowthUzs)} soʻm (+{priceGrowthPercent}%)
                </span>
              </div>

              {/* Inline Chart */}
              <div className="h-28 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 8, right: 12, left: -22, bottom: 2 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#9ca3af" opacity={0.15} />
                    <XAxis
                      dataKey="shortLabel"
                      tick={{ fontSize: 9, fill: '#9ca3af' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      domain={['auto', 'auto']}
                      tickFormatter={(val: number) => `${(val / 1_000_000).toFixed(0)}M`}
                      tick={{ fontSize: 9, fill: '#9ca3af' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-stone-900/95 dark:bg-stone-950/95 text-white p-2.5 rounded-xl text-xs shadow-xl border border-stone-700 font-sans z-50">
                              <div className="text-[10px] text-stone-400 font-medium">{data.bidder}</div>
                              <div className="font-mono font-bold text-amber-400 text-xs sm:text-sm mt-0.5">
                                {formatPrice(data.amount)} soʻm
                              </div>
                              <div className="text-[9px] text-stone-400 mt-0.5 flex items-center justify-between gap-2">
                                <span>{data.timestamp}</span>
                                {data.step > 0 && (
                                  <span className="text-emerald-400 font-mono font-semibold">
                                    +{formatPrice(data.amount - currentAuction.startingPriceUzs)}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="amount"
                      stroke="#f59e0b"
                      strokeWidth={2.5}
                      dot={{ r: 3.5, fill: '#f59e0b', stroke: '#ffffff', strokeWidth: 1.5 }}
                      activeDot={{ r: 5, fill: '#d97706', stroke: '#ffffff', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="flex items-center justify-between text-[10px] text-stone-400 mt-1 px-1 font-mono">
                <span>Start: {formatPrice(currentAuction.startingPriceUzs)} soʻm</span>
                <span className="text-amber-600 dark:text-amber-400 font-bold">
                  Hozir: {formatPrice(currentAuction.currentBidUzs)} soʻm
                </span>
              </div>
            </div>

            {/* Bid Form */}
            <form onSubmit={handlePlaceBid} className="space-y-3 mb-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-stone-800 dark:text-stone-200">
                    Sizning taklifingiz (soʻmda):
                  </label>
                  <span className="text-[11px] text-stone-500 font-mono">
                    Min: {formatPrice(minAcceptableBid)}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    placeholder={`Min. ${formatPrice(minAcceptableBid)}`}
                    value={bidAmountInput}
                    onChange={(e) => setBidAmountInput(e.target.value)}
                    className="w-full p-2.5 pr-24 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 text-stone-900 dark:text-white rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setBidAmountInput(minAcceptableBid.toString())}
                    className="absolute right-2 top-2 text-[11px] bg-stone-200 hover:bg-stone-300 dark:bg-stone-700 dark:hover:bg-stone-600 px-2.5 py-1 rounded-lg text-stone-800 dark:text-stone-200 font-semibold cursor-pointer transition-colors"
                  >
                    +Min qadam
                  </button>
                </div>

                {/* Quick Add Amount Chips */}
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-stone-400 font-medium mr-0.5">Tezkor:</span>
                  {[
                    { label: `+${formatPrice(currentAuction.minStepUzs)}`, val: minAcceptableBid },
                    { label: `+${formatPrice(currentAuction.minStepUzs * 2)}`, val: currentAuction.currentBidUzs + currentAuction.minStepUzs * 2 },
                    { label: `+${formatPrice(currentAuction.minStepUzs * 3)}`, val: currentAuction.currentBidUzs + currentAuction.minStepUzs * 3 },
                  ].map((chip, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setBidAmountInput(chip.val.toString())}
                      className="px-2 py-1 rounded-lg bg-stone-100 hover:bg-amber-100 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-[10px] font-mono font-bold border border-stone-200 dark:border-stone-700 cursor-pointer transition-colors"
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              </div>

              {bidError && (
                <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{bidError}</span>
                </div>
              )}

              {bidSuccess && (
                <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 text-xs rounded-xl flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{bidSuccess}</span>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer uppercase tracking-wider"
                >
                  {t.placeBid}
                </button>

                <button
                  type="button"
                  onClick={handleRefundBid}
                  className={`py-3 px-3.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                    userBid
                      ? 'bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 shadow-sm active:scale-95'
                      : 'bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-750 border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300'
                  }`}
                  title="Stavkaga qoʻyilgan mablagʻni qaytarish (0% komissiya)"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${userBid ? 'text-rose-600 dark:text-rose-400' : 'text-stone-500'}`} />
                  <span>
                    {userBid
                      ? `Stavka mablagʻini qaytarish (${formatPrice(userBid.amountUzs)})`
                      : `Stavka mablagʻini qaytarish`}
                  </span>
                </button>
              </div>

              {userBid && (
                <div className="p-2.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-900/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    <span className="text-stone-700 dark:text-stone-300">
                      Faol stavkangiz: <strong className="font-mono text-stone-900 dark:text-white">{formatPrice(userBid.amountUzs)} soʻm</strong>
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleRefundBid}
                    className="underline text-rose-700 dark:text-rose-400 font-bold hover:text-rose-800 cursor-pointer text-[11px]"
                  >
                    Mablagʻni qaytarish →
                  </button>
                </div>
              )}
            </form>

            {/* Bids History with stacked entries */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-stone-900 dark:text-stone-100">
                  {t.bidsHistory}
                </span>
                <span className="text-[10px] text-stone-500 font-mono">
                  {currentAuction.bids.length} ta stavka
                </span>
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto font-mono text-xs pr-0.5">
                {currentAuction.bids.map((b, idx) => {
                  const isUser = b.bidderName.includes('Siz');
                  return (
                    <div
                      key={b.id}
                      className={`flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-xl gap-1 transition-all ${
                        isUser
                          ? 'bg-amber-50/80 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-stone-900 dark:text-white font-bold'
                          : idx === 0
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-100 border border-emerald-300 dark:border-emerald-800 font-bold shadow-2xs'
                          : 'bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200/60 dark:border-stone-700/60'
                      }`}
                    >
                      <div className="flex items-center justify-between sm:justify-start gap-2">
                        <span className="truncate text-[11px] font-sans font-medium">
                          {b.bidderName}
                          {isUser && <span className="ml-1 text-[10px] bg-amber-400 text-stone-950 px-1 rounded-sm font-bold">SIZ</span>}
                        </span>
                        <span className="text-[9px] text-stone-400 font-sans sm:hidden">{b.timestamp}</span>
                      </div>
                      <div className="flex items-center justify-between sm:justify-end gap-2 text-right">
                        <span className={`font-bold text-xs sm:text-sm ${idx === 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-stone-900 dark:text-stone-100'}`}>
                          {formatPrice(b.amountUzs)} soʻm
                        </span>
                        <span className="text-[10px] text-stone-400 font-sans hidden sm:inline">{b.timestamp}</span>
                        {isUser && (
                          <button
                            type="button"
                            onClick={handleRefundBid}
                            className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-[10px] font-bold font-sans cursor-pointer transition-colors shrink-0"
                            title="Stavkaga qoʻyilgan mablagʻni qaytarish"
                          >
                            Qaytarish
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="text-[11px] text-stone-500 border-t border-stone-100 pt-2 flex items-center gap-1.5 font-sans">
            <Users className="w-3.5 h-3.5 text-stone-400" />
            <span>Auksion gʻolibi aniqlangach, xarid xavfsiz toʻlov tizimi orqali yakunlanadi.</span>
          </div>
        </div>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
        <div className="relative bg-[#F7F9F6] dark:bg-[#041C16] text-[#1C2A23] dark:text-[#ECFDF5] border border-[#E5ECE7] dark:border-[#0E3D32] rounded-3xl max-w-4xl w-full shadow-2xl p-4 sm:p-6 max-h-[92vh] overflow-y-auto">
          <div className="flex justify-end mb-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {content}
        </div>
      </div>
    );
  }

  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {content}
    </section>
  );
};
