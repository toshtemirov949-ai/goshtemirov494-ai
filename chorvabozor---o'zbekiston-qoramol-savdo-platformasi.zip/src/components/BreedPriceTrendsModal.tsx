import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';
import {
  X,
  TrendingUp,
  TrendingDown,
  Calendar,
  Sparkles,
  ArrowRight,
  Info,
  Layers,
  Calculator,
  CheckCircle2,
  DollarSign,
  Scale,
  Maximize2,
  HelpCircle,
  Award,
  Filter,
} from 'lucide-react';
import {
  BreedSeasonalityProfile,
  breedSeasonalityCatalog,
  getAllSeasonalityBreeds,
  resolveSeasonalityBreed,
} from '../data/breedSeasonalityData';
import { AnimalDepartment, Language } from '../types';

interface BreedPriceTrendsModalProps {
  language: Language;
  initialBreedId?: string;
  onClose: () => void;
  onFilterByBreed?: (breedKey: string, department: AnimalDepartment) => void;
}

export const BreedPriceTrendsModal: React.FC<BreedPriceTrendsModalProps> = ({
  language,
  initialBreedId,
  onClose,
  onFilterByBreed,
}) => {
  const allProfiles = useMemo(() => getAllSeasonalityBreeds(), []);
  const initial = useMemo(() => resolveSeasonalityBreed(initialBreedId), [initialBreedId]);

  const [selectedBreedId, setSelectedBreedId] = useState<string>(initial.breedId);
  const [departmentFilter, setDepartmentFilter] = useState<'all' | 'qoramol' | 'quy' | 'ot'>('all');
  const [metricMode, setMetricMode] = useState<'total' | 'perKg'>('total');
  const [visibleYears, setVisibleYears] = useState<{ y2024: boolean; y2025: boolean; y2026: boolean }>({
    y2024: true,
    y2025: true,
    y2026: true,
  });
  const [compareBreedId, setCompareBreedId] = useState<string>('none');
  const [activeTab, setActiveTab] = useState<'chart' | 'calculator' | 'months'>('chart');

  // Seasonality Bo'rdoqi Simulator state
  const [simHeadCount, setSimHeadCount] = useState<number>(5);
  const [simBuyMonth, setSimBuyMonth] = useState<string>('yan');
  const [simSellMonth, setSimSellMonth] = useState<string>('iyn');

  const currentProfile = useMemo(() => {
    return breedSeasonalityCatalog[selectedBreedId] || allProfiles[0];
  }, [selectedBreedId, allProfiles]);

  const compareProfile = useMemo(() => {
    if (compareBreedId === 'none') return null;
    return breedSeasonalityCatalog[compareBreedId] || null;
  }, [compareBreedId]);

  const filteredBreedsList = useMemo(() => {
    if (departmentFilter === 'all') return allProfiles;
    return allProfiles.filter((b) => b.category === departmentFilter);
  }, [allProfiles, departmentFilter]);

  // Chart data preparation
  const chartData = useMemo(() => {
    return currentProfile.points.map((pt, idx) => {
      const cmpPt = compareProfile ? compareProfile.points[idx] : null;

      const p2024 = metricMode === 'total' ? pt.price2024Mln : Math.round((pt.price2024Mln * 1000000) / currentProfile.baseWeightKg);
      const p2025 = metricMode === 'total' ? pt.price2025Mln : Math.round((pt.price2025Mln * 1000000) / currentProfile.baseWeightKg);
      const p2026 = metricMode === 'total' ? pt.price2026Mln : pt.pricePerKg2026;

      let cmp2026: number | undefined = undefined;
      if (cmpPt && compareProfile) {
        cmp2026 = metricMode === 'total' ? cmpPt.price2026Mln : cmpPt.pricePerKg2026;
      }

      return {
        monthKey: pt.monthKey,
        name: language === 'uz' ? pt.monthNameUz.slice(0, 3) : pt.monthNameRu.slice(0, 3),
        fullName: language === 'uz' ? pt.monthNameUz : pt.monthNameRu,
        season: pt.season,
        seasonName: pt.seasonNameUz,
        price2024: p2024,
        price2025: p2025,
        price2026: p2026,
        pricePerKg2026: pt.pricePerKg2026,
        priceTotalMln2026: pt.price2026Mln,
        comparePrice2026: cmp2026,
        eventTag: pt.eventTag,
        insight: language === 'uz' ? pt.seasonalInsightUz : pt.seasonalInsightRu,
      };
    });
  }, [currentProfile, compareProfile, metricMode, language]);

  // Max peak month & min trough month
  const peakPoint = useMemo(() => {
    return [...currentProfile.points].sort((a, b) => b.price2026Mln - a.price2026Mln)[0];
  }, [currentProfile]);

  const troughPoint = useMemo(() => {
    return [...currentProfile.points].sort((a, b) => a.price2026Mln - b.price2026Mln)[0];
  }, [currentProfile]);

  // Profit Simulator Calculations
  const simResults = useMemo(() => {
    const buyPt = currentProfile.points.find((p) => p.monthKey === simBuyMonth) || currentProfile.points[0];
    const sellPt = currentProfile.points.find((p) => p.monthKey === simSellMonth) || currentProfile.points[5];

    const buyPricePerHead = buyPt.price2026Mln * 1000000;
    const sellPricePerHead = sellPt.price2026Mln * 1000000;

    // Estimate months duration
    const monthKeys = ['yan', 'fev', 'mar', 'apr', 'may', 'iyn', 'iyl', 'avg', 'sen', 'okt', 'noy', 'dek'];
    const bIdx = monthKeys.indexOf(simBuyMonth);
    const sIdx = monthKeys.indexOf(simSellMonth);
    let durationMonths = sIdx >= bIdx ? sIdx - bIdx : 12 - bIdx + sIdx;
    if (durationMonths === 0) durationMonths = 1;

    // Approximate monthly feed cost per head
    const isBig = currentProfile.category === 'qoramol' || currentProfile.category === 'ot';
    const feedCostPerMonthPerHead = isBig ? 850000 : 250000;
    const totalFeedCost = feedCostPerMonthPerHead * durationMonths * simHeadCount;

    const totalBuyCost = buyPricePerHead * simHeadCount;
    const totalSellRevenue = sellPricePerHead * simHeadCount;
    const totalInvestment = totalBuyCost + totalFeedCost;
    const netProfit = totalSellRevenue - totalInvestment;
    const roiPercentage = totalInvestment > 0 ? Math.round((netProfit / totalInvestment) * 100) : 0;

    return {
      buyPt,
      sellPt,
      durationMonths,
      totalBuyCost,
      totalFeedCost,
      totalSellRevenue,
      netProfit,
      roiPercentage,
      gainPerHead: sellPricePerHead - buyPricePerHead,
    };
  }, [currentProfile, simHeadCount, simBuyMonth, simSellMonth]);

  const formatUzs = (val: number) => {
    return new Intl.NumberFormat('uz-UZ').format(Math.round(val));
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="relative bg-white dark:bg-stone-900 rounded-3xl max-w-5xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[94vh] border border-stone-200 dark:border-stone-800 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-7 py-4 border-b border-stone-200 dark:border-stone-800 bg-stone-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-xl shadow-md">
              📈
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg">
                  {language === 'uz' ? 'Zotlar Boʻyicha Tarixiy Narx Dinamikasi' : 'Историческая динамика цен по породам'}
                </h3>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-800/80 text-emerald-200 border border-emerald-600/40">
                  2024 - 2026
                </span>
              </div>
              <p className="text-xs text-stone-300">
                {language === 'uz'
                  ? 'Fermerlar uchun bozor mavsumiyligi, choʻqqi narxlar va qulay xarid davrlari tahlili'
                  : 'Сезонность рынка, ценовые пики и оптимальные месяцы для покупки скота'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white rounded-xl hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Controls: Department Filter & Breed Switcher */}
        <div className="p-4 sm:p-5 bg-stone-50 dark:bg-stone-850 border-b border-stone-200 dark:border-stone-800 flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Department filters */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold">
              <span className="text-stone-400 text-[11px] uppercase mr-1 hidden sm:inline">Toifa:</span>
              <button
                type="button"
                onClick={() => setDepartmentFilter('all')}
                className={`py-1.5 px-3 rounded-xl transition-all cursor-pointer ${
                  departmentFilter === 'all'
                    ? 'bg-emerald-900 text-white font-bold shadow-xs'
                    : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
                }`}
              >
                {language === 'uz' ? 'Barcha zotlar' : 'Все породы'}
              </button>
              <button
                type="button"
                onClick={() => setDepartmentFilter('qoramol')}
                className={`py-1.5 px-3 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  departmentFilter === 'qoramol'
                    ? 'bg-emerald-900 text-white font-bold shadow-xs'
                    : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
                }`}
              >
                <span>🐄</span>
                <span>{language === 'uz' ? 'Qoramol' : 'КРС'}</span>
              </button>
              <button
                type="button"
                onClick={() => setDepartmentFilter('quy')}
                className={`py-1.5 px-3 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  departmentFilter === 'quy'
                    ? 'bg-emerald-900 text-white font-bold shadow-xs'
                    : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
                }`}
              >
                <span>🐑</span>
                <span>{language === 'uz' ? 'Qoʻy / Dumba' : 'Овцы'}</span>
              </button>
              <button
                type="button"
                onClick={() => setDepartmentFilter('ot')}
                className={`py-1.5 px-3 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  departmentFilter === 'ot'
                    ? 'bg-emerald-900 text-white font-bold shadow-xs'
                    : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100'
                }`}
              >
                <span>🐎</span>
                <span>{language === 'uz' ? 'Ot / Tulpor' : 'Лошади'}</span>
              </button>
            </div>

            {/* View Mode & Subtabs */}
            <div className="flex items-center gap-1.5 self-end sm:self-auto">
              <button
                type="button"
                onClick={() => setActiveTab('chart')}
                className={`text-xs font-bold py-1.5 px-3 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'chart'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>{language === 'uz' ? 'Dinamik Grafik' : 'График'}</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('calculator')}
                className={`text-xs font-bold py-1.5 px-3 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'calculator'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700'
                }`}
              >
                <Calculator className="w-3.5 h-3.5" />
                <span>{language === 'uz' ? 'Boʻrdoqi Kalkulyatori' : 'Калькулятор откорма'}</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('months')}
                className={`text-xs font-bold py-1.5 px-3 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'months'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>{language === 'uz' ? '12 Oylik Kalendar' : '12 Месяцев'}</span>
              </button>
            </div>
          </div>

          {/* Breeds Selection Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {filteredBreedsList.map((breed) => {
              const isSelected = breed.breedId === currentProfile.breedId;
              return (
                <button
                  key={breed.breedId}
                  type="button"
                  onClick={() => setSelectedBreedId(breed.breedId)}
                  className={`px-3 py-2 rounded-2xl shrink-0 text-left transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-emerald-900 border-emerald-700 text-white shadow-sm ring-2 ring-emerald-500/30'
                      : 'bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:border-emerald-600'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{breed.categoryIcon}</span>
                    <div>
                      <div className="text-xs font-bold leading-tight">
                        {language === 'uz' ? breed.breedNameUz.split('(')[0].trim() : breed.breedNameRu.split('(')[0].trim()}
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] opacity-80">
                        <span>~{breed.annualAverageMln} mln</span>
                        <span>•</span>
                        <span className="text-amber-400 font-bold">±{breed.volatilityPercentage}%</span>
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Main Selected Breed Summary Hero */}
          <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-emerald-900 rounded-3xl p-4 sm:p-6 text-white shadow-xl relative overflow-hidden">
            <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 relative z-10">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-2xl">{currentProfile.categoryIcon}</span>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-900/60 px-2.5 py-0.5 rounded-lg border border-emerald-600/30">
                    {currentProfile.categoryLabelUz}
                  </span>
                  <span className="text-xs text-stone-300">
                    Tirik vazn: ~{currentProfile.baseWeightKg} kg
                  </span>
                </div>
                <h4 className="text-lg sm:text-2xl font-black text-white">
                  {language === 'uz' ? currentProfile.breedNameUz : currentProfile.breedNameRu}
                </h4>
                <p className="text-xs sm:text-sm text-stone-300 max-w-2xl leading-relaxed">
                  {language === 'uz' ? currentProfile.summaryInsightUz : currentProfile.summaryInsightRu}
                </p>
              </div>

              {/* Quick Seasonality Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 shrink-0">
                <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
                  <div className="text-[10px] text-emerald-300 uppercase font-bold flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    <span>Eng qimmat sotish</span>
                  </div>
                  <div className="text-xs sm:text-sm font-extrabold text-white mt-1">
                    {currentProfile.bestSellingMonthUz}
                  </div>
                  <div className="text-[10px] text-emerald-200 mt-0.5">
                    Maksimal daromad
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
                  <div className="text-[10px] text-teal-300 uppercase font-bold flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" />
                    <span>Eng arzon xarid</span>
                  </div>
                  <div className="text-xs sm:text-sm font-extrabold text-white mt-1">
                    {currentProfile.bestBuyingMonthUz}
                  </div>
                  <div className="text-[10px] text-teal-200 mt-0.5">
                    Boʻrdoqi uchun arzon
                  </div>
                </div>

                <div className="col-span-2 sm:col-span-1 bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
                  <div className="text-[10px] text-amber-300 uppercase font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>Mavsumiy tebranish</span>
                  </div>
                  <div className="text-base sm:text-lg font-black text-amber-400 mt-1">
                    ±{currentProfile.volatilityPercentage}%
                  </div>
                  <div className="text-[10px] text-stone-300 mt-0.5">
                    Choʻqqi vs pastlik
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* TAB 1: DYNAMIC LINE CHART */}
          {activeTab === 'chart' && (
            <div className="space-y-4">
              {/* Chart Toolbar Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-stone-50 dark:bg-stone-850 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800">
                {/* Metric Unit Toggle */}
                <div className="flex items-center gap-1.5 bg-white dark:bg-stone-800 p-1 rounded-xl border border-stone-200 dark:border-stone-700 text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setMetricMode('total')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      metricMode === 'total'
                        ? 'bg-emerald-900 text-white font-bold shadow-xs'
                        : 'text-stone-600 dark:text-stone-300 hover:text-stone-900'
                    }`}
                  >
                    {language === 'uz' ? 'Bosh narxi (Mln soʻm)' : 'Цена за голову (млн)'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMetricMode('perKg')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      metricMode === 'perKg'
                        ? 'bg-emerald-900 text-white font-bold shadow-xs'
                        : 'text-stone-600 dark:text-stone-300 hover:text-stone-900'
                    }`}
                  >
                    {language === 'uz' ? 'Tirik vazn 1 kg (soʻm/kg)' : 'За 1 кг жив. веса (сум)'}
                  </button>
                </div>

                {/* Years checkboxes */}
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-stone-400 text-[11px] uppercase hidden sm:inline">Yillar:</span>
                  <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 cursor-pointer text-stone-700 dark:text-stone-300">
                    <input
                      type="checkbox"
                      checked={visibleYears.y2024}
                      onChange={(e) => setVisibleYears({ ...visibleYears, y2024: e.target.checked })}
                      className="accent-slate-500 rounded"
                    />
                    <span className="font-semibold text-slate-500">2024</span>
                  </label>
                  <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 cursor-pointer text-stone-700 dark:text-stone-300">
                    <input
                      type="checkbox"
                      checked={visibleYears.y2025}
                      onChange={(e) => setVisibleYears({ ...visibleYears, y2025: e.target.checked })}
                      className="accent-amber-500 rounded"
                    />
                    <span className="font-semibold text-amber-600 dark:text-amber-400">2025</span>
                  </label>
                  <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 cursor-pointer text-emerald-800 dark:text-emerald-300 font-bold">
                    <input
                      type="checkbox"
                      checked={visibleYears.y2026}
                      onChange={(e) => setVisibleYears({ ...visibleYears, y2026: e.target.checked })}
                      className="accent-emerald-600 rounded"
                    />
                    <span>2026 (Joriy / Prognoz)</span>
                  </label>
                </div>

                {/* Compare Breed dropdown */}
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-stone-400 text-[11px] uppercase">Taqqoslash:</span>
                  <select
                    value={compareBreedId}
                    onChange={(e) => setCompareBreedId(e.target.value)}
                    className="bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 text-stone-800 dark:text-stone-200 py-1.5 px-3 rounded-xl focus:ring-2 focus:ring-emerald-600 text-xs font-medium cursor-pointer"
                  >
                    <option value="none">{language === 'uz' ? '— Hech qanday zot —' : '— Без сравнения —'}</option>
                    {allProfiles
                      .filter((b) => b.breedId !== currentProfile.breedId)
                      .map((b) => (
                        <option key={b.breedId} value={b.breedId}>
                          {b.categoryIcon} {language === 'uz' ? b.breedNameUz.split('(')[0] : b.breedNameRu.split('(')[0]}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Dynamic Line Chart Container */}
              <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-4 sm:p-6 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-2 border-b border-stone-100 dark:border-stone-800 gap-2">
                  <div>
                    <h5 className="font-extrabold text-stone-900 dark:text-white text-sm sm:text-base flex items-center gap-2">
                      <span>12 Oylik Dinamika & Mavsumiy Toʻlqinlar</span>
                      <span className="text-xs font-normal text-stone-500">
                        ({metricMode === 'total' ? 'Million soʻm / bosh' : 'soʻm / kg tirik vazn'})
                      </span>
                    </h5>
                    <p className="text-xs text-stone-500">
                      Grafik ustiga kursor olib boring: har bir oyning oʻziga xos dehqonchilik sababi koʻrsatiladi.
                    </p>
                  </div>

                  {/* Season Legend */}
                  <div className="flex items-center gap-2 text-[11px] font-medium text-stone-600 dark:text-stone-400">
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" />
                      <span>Qish</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                      <span>Bahor</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
                      <span>Yoz</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-orange-500 inline-block" />
                      <span>Kuz</span>
                    </span>
                  </div>
                </div>

                <div className="w-full h-80 sm:h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.6} />
                      <XAxis
                        dataKey="name"
                        stroke="#64748b"
                        tick={{ fontSize: 12, fontWeight: 600 }}
                      />
                      <YAxis
                        stroke="#64748b"
                        tick={{ fontSize: 11 }}
                        tickFormatter={(val) => {
                          if (metricMode === 'total') return `${val}m`;
                          return `${Math.round(val / 1000)}k`;
                        }}
                      />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-stone-900/95 text-white p-3.5 rounded-2xl shadow-2xl border border-stone-700 max-w-xs text-xs backdrop-blur-md">
                                <div className="flex items-center justify-between border-b border-stone-700 pb-2 mb-2">
                                  <span className="font-extrabold text-sm text-emerald-400">
                                    {data.fullName} ({data.seasonName})
                                  </span>
                                  {data.eventTag && (
                                    <span className="bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-md text-[10px] font-bold border border-amber-500/30">
                                      {data.eventTag}
                                    </span>
                                  )}
                                </div>
                                <div className="space-y-1.5 font-mono text-[11px]">
                                  {visibleYears.y2026 && (
                                    <div className="flex justify-between items-center text-emerald-400 font-bold">
                                      <span>2026 Joriy / Prognoz:</span>
                                      <span>
                                        {metricMode === 'total'
                                          ? `${data.price2026} mln soʻm`
                                          : `${formatUzs(data.price2026)} soʻm/kg`}
                                      </span>
                                    </div>
                                  )}
                                  {visibleYears.y2025 && (
                                    <div className="flex justify-between items-center text-amber-300">
                                      <span>2025 Narx:</span>
                                      <span>
                                        {metricMode === 'total'
                                          ? `${data.price2025} mln soʻm`
                                          : `${formatUzs(data.price2025)} soʻm/kg`}
                                      </span>
                                    </div>
                                  )}
                                  {visibleYears.y2024 && (
                                    <div className="flex justify-between items-center text-slate-300">
                                      <span>2024 Tarixiy:</span>
                                      <span>
                                        {metricMode === 'total'
                                          ? `${data.price2024} mln soʻm`
                                          : `${formatUzs(data.price2024)} soʻm/kg`}
                                      </span>
                                    </div>
                                  )}
                                  {compareProfile && data.comparePrice2026 !== undefined && (
                                    <div className="flex justify-between items-center text-purple-300 pt-1 border-t border-stone-700">
                                      <span>{compareProfile.breedNameUz.split('(')[0]}:</span>
                                      <span className="font-bold">
                                        {metricMode === 'total'
                                          ? `${data.comparePrice2026} mln soʻm`
                                          : `${formatUzs(data.comparePrice2026)} soʻm/kg`}
                                      </span>
                                    </div>
                                  )}
                                </div>
                                <div className="mt-2.5 pt-2 border-t border-stone-700/80 text-[11px] text-stone-300 leading-snug">
                                  <strong className="text-stone-200">Bozor sababi:</strong> {data.insight}
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Legend verticalAlign="top" height={36} />

                      {/* Reference line for annual average */}
                      <ReferenceLine
                        y={
                          metricMode === 'total'
                            ? currentProfile.annualAverageMln
                            : Math.round((currentProfile.annualAverageMln * 1000000) / currentProfile.baseWeightKg)
                        }
                        stroke="#10b981"
                        strokeDasharray="4 4"
                        label={{
                          value: `Oʻrtacha yillik: ${
                            metricMode === 'total'
                              ? `${currentProfile.annualAverageMln}m`
                              : `${formatUzs(
                                  Math.round((currentProfile.annualAverageMln * 1000000) / currentProfile.baseWeightKg)
                                )} soʻm/kg`
                          }`,
                          position: 'insideTopLeft',
                          fill: '#059669',
                          fontSize: 10,
                          fontWeight: 700,
                        }}
                      />

                      {/* 2024 historical Line */}
                      {visibleYears.y2024 && (
                        <Line
                          type="monotone"
                          dataKey="price2024"
                          name="2024 Tarixiy"
                          stroke="#94a3b8"
                          strokeWidth={2}
                          strokeDasharray="4 4"
                          dot={{ r: 3, fill: '#94a3b8' }}
                          activeDot={{ r: 5 }}
                        />
                      )}

                      {/* 2025 historical Line */}
                      {visibleYears.y2025 && (
                        <Line
                          type="monotone"
                          dataKey="price2025"
                          name="2025 Tarixiy"
                          stroke="#f59e0b"
                          strokeWidth={2.5}
                          dot={{ r: 3.5, fill: '#f59e0b' }}
                          activeDot={{ r: 6 }}
                        />
                      )}

                      {/* 2026 Current & Forecast Line */}
                      {visibleYears.y2026 && (
                        <Line
                          type="monotone"
                          dataKey="price2026"
                          name={`2026 (${currentProfile.breedNameUz.split('(')[0].trim()})`}
                          stroke="#059669"
                          strokeWidth={3.5}
                          dot={{ r: 4.5, fill: '#059669', stroke: '#fff', strokeWidth: 1.5 }}
                          activeDot={{ r: 8, stroke: '#10b981', strokeWidth: 2 }}
                        />
                      )}

                      {/* Comparison Breed Line */}
                      {compareProfile && (
                        <Line
                          type="monotone"
                          dataKey="comparePrice2026"
                          name={`Taqqoslash: ${compareProfile.breedNameUz.split('(')[0].trim()}`}
                          stroke="#8b5cf6"
                          strokeWidth={2.5}
                          strokeDasharray="2 2"
                          dot={{ r: 4, fill: '#8b5cf6' }}
                          activeDot={{ r: 7 }}
                        />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* 4 Seasonality Strategy Pillars for the Farmer */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
                <div className="bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-2xl p-4">
                  <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs uppercase">
                    <span className="p-1 rounded-lg bg-emerald-200 dark:bg-emerald-800 text-emerald-950">🏆</span>
                    <span>Choʻqqi Sotish Oyi</span>
                  </div>
                  <div className="text-lg font-black text-emerald-950 dark:text-emerald-200 mt-2">
                    {peakPoint.monthNameUz} ({peakPoint.price2026Mln} mln)
                  </div>
                  <p className="text-xs text-emerald-800 dark:text-emerald-300/90 mt-1 leading-relaxed">
                    {peakPoint.eventTag ? `${peakPoint.eventTag}: ` : ''}
                    Maksimal ustama (+{currentProfile.volatilityPercentage}%) olish uchun ayni vaqt.
                  </p>
                </div>

                <div className="bg-sky-50/80 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800 rounded-2xl p-4">
                  <div className="flex items-center gap-2 text-sky-800 dark:text-sky-300 font-bold text-xs uppercase">
                    <span className="p-1 rounded-lg bg-sky-200 dark:bg-sky-800 text-sky-950">🛒</span>
                    <span>Arzon Xarid Oyi</span>
                  </div>
                  <div className="text-lg font-black text-sky-950 dark:text-sky-200 mt-2">
                    {troughPoint.monthNameUz} ({troughPoint.price2026Mln} mln)
                  </div>
                  <p className="text-xs text-sky-800 dark:text-sky-300/90 mt-1 leading-relaxed">
                    Bozor tinch, yem qimmat boʻlgani uchun sotuvchilar chegirma beradi. Boʻrdoqi boshlash uchun eng maqbul davr.
                  </p>
                </div>

                <div className="bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-2xl p-4">
                  <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-xs uppercase">
                    <span className="p-1 rounded-lg bg-amber-200 dark:bg-amber-800 text-amber-950">⚖️</span>
                    <span>Oʻrtacha Yillik Baho</span>
                  </div>
                  <div className="text-lg font-black text-amber-950 dark:text-amber-200 mt-2">
                    ~{currentProfile.annualAverageMln} mln soʻm
                  </div>
                  <p className="text-xs text-amber-800 dark:text-amber-300/90 mt-1 leading-relaxed">
                    1 kg tirik vazn: ~{formatUzs(Math.round((currentProfile.annualAverageMln * 1000000) / currentProfile.baseWeightKg))} soʻm.
                  </p>
                </div>

                <div className="bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-2xl p-4">
                  <div className="flex items-center gap-2 text-stone-800 dark:text-stone-300 font-bold text-xs uppercase">
                    <span className="p-1 rounded-lg bg-stone-200 dark:bg-stone-700 text-stone-900">💡</span>
                    <span>Fermer Tavsiyasi</span>
                  </div>
                  <div className="text-xs font-semibold text-stone-900 dark:text-stone-200 mt-2 leading-relaxed">
                    «{troughPoint.monthNameUz}da arzon olib, boʻrdoqiga boqib, {peakPoint.monthNameUz}da sotish sof foydani 35-45% ga oshiradi.»
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BO'RDOQI & MAVSUMIY FOYDA KALKULYATORI */}
          {activeTab === 'calculator' && (
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-5 sm:p-7 shadow-sm space-y-6">
              <div className="border-b border-stone-100 dark:border-stone-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-800 text-emerald-100 flex items-center justify-center text-lg">
                    🧮
                  </div>
                  <div>
                    <h5 className="font-extrabold text-stone-900 dark:text-white text-base">
                      {language === 'uz'
                        ? 'Mavsumiy Boʻrdoqi & Xarid-Sotuv Foyda Simulyatori'
                        : 'Симулятор сезонного откорма и чистой прибыли'}
                    </h5>
                    <p className="text-xs text-stone-500">
                      Qachon arzon olib, qachon sotishingizni tanlang. Bozor mavsumiyligi asosida prognoz foyda hisoblanadi.
                    </p>
                  </div>
                </div>
              </div>

              {/* Calculator Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1.5">
                    Bosh soni (Chorva miqdori):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={500}
                      value={simHeadCount}
                      onChange={(e) => setSimHeadCount(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full px-3 py-2 text-sm font-bold bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-emerald-600"
                    />
                    <span className="text-xs text-stone-500 font-medium">bosh</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1.5">
                    Xarid qilish oyi (Sotib olish):
                  </label>
                  <select
                    value={simBuyMonth}
                    onChange={(e) => setSimBuyMonth(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-emerald-600 cursor-pointer"
                  >
                    {currentProfile.points.map((p) => (
                      <option key={p.monthKey} value={p.monthKey}>
                        {p.monthNameUz} — {p.price2026Mln} mln ({p.seasonNameUz})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1.5">
                    Sotish oyi (Choʻqqi bozori):
                  </label>
                  <select
                    value={simSellMonth}
                    onChange={(e) => setSimSellMonth(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-emerald-600 cursor-pointer"
                  >
                    {currentProfile.points.map((p) => (
                      <option key={p.monthKey} value={p.monthKey}>
                        {p.monthNameUz} — {p.price2026Mln} mln {p.eventTag ? `(${p.eventTag})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Simulation Results Display */}
              <div className="bg-stone-900 text-white rounded-3xl p-5 sm:p-7 shadow-xl grid grid-cols-1 md:grid-cols-4 gap-5">
                <div className="space-y-1">
                  <div className="text-[11px] text-stone-400 uppercase font-semibold">
                    Dastlabki Xarid Xarajati
                  </div>
                  <div className="text-xl font-extrabold text-white">
                    {formatUzs(simResults.totalBuyCost)} soʻm
                  </div>
                  <div className="text-[11px] text-stone-400">
                    {simHeadCount} bosh × {simResults.buyPt.price2026Mln} mln
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[11px] text-stone-400 uppercase font-semibold">
                    Taxminiy Ozuqa & Parvarish
                  </div>
                  <div className="text-xl font-extrabold text-amber-300">
                    ~{formatUzs(simResults.totalFeedCost)} soʻm
                  </div>
                  <div className="text-[11px] text-stone-400">
                    {simResults.durationMonths} oy parvarish
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[11px] text-stone-400 uppercase font-semibold">
                    Kutilayotgan Sotish Tushumi
                  </div>
                  <div className="text-xl font-extrabold text-emerald-400">
                    {formatUzs(simResults.totalSellRevenue)} soʻm
                  </div>
                  <div className="text-[11px] text-stone-400">
                    {simHeadCount} bosh × {simResults.sellPt.price2026Mln} mln
                  </div>
                </div>

                <div className="bg-emerald-800/80 rounded-2xl p-4 border border-emerald-500/40 flex flex-col justify-between">
                  <div>
                    <div className="text-[10px] text-emerald-200 uppercase font-bold tracking-wider">
                      Sof Prognoz Foyda
                    </div>
                    <div className="text-2xl font-black text-white mt-1">
                      {simResults.netProfit >= 0 ? `+${formatUzs(simResults.netProfit)}` : `${formatUzs(simResults.netProfit)}`} soʻm
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-200 mt-2 pt-2 border-t border-emerald-700">
                    <span>Rentabellik (ROI):</span>
                    <span className="text-amber-300 text-sm">+{simResults.roiPercentage}%</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 bg-stone-50 dark:bg-stone-800/60 p-3 rounded-xl">
                <Info className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  * Ushbu simulyator Oʻzbekiston chorvachilik bozorlaridagi soʻnggi 3 yillik narx tebranishlari va yem-xashak (beda, kepak, kunjara) meʼyorlari asosida taxminiy hisoblangan.
                </span>
              </div>
            </div>
          )}

          {/* TAB 3: 12 OYLIK MAVSUMIY KALENDAR GRID */}
          {activeTab === 'months' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h5 className="font-extrabold text-stone-900 dark:text-white text-sm sm:text-base">
                  12 Oylik Bozor Kalendari & Xalqona Tahlil
                </h5>
                <span className="text-xs text-stone-500">
                  {currentProfile.breedNameUz.split('(')[0]}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {currentProfile.points.map((pt) => {
                  const isPeak = pt.monthKey === peakPoint.monthKey;
                  const isTrough = pt.monthKey === troughPoint.monthKey;

                  return (
                    <div
                      key={pt.monthKey}
                      className={`p-4 rounded-2xl border transition-all ${
                        isPeak
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-700 shadow-sm'
                          : isTrough
                          ? 'bg-sky-50 dark:bg-sky-950/40 border-sky-400 dark:border-sky-700 shadow-sm'
                          : 'bg-white dark:bg-stone-850 border-stone-200 dark:border-stone-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-stone-900 dark:text-white">
                            {pt.monthNameUz}
                          </span>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300">
                            {pt.seasonNameUz}
                          </span>
                        </div>
                        {isPeak && (
                          <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-200/80 dark:bg-emerald-900 px-2 py-0.5 rounded-full">
                            👑 Eng baland
                          </span>
                        )}
                        {isTrough && (
                          <span className="text-[10px] font-bold text-sky-800 dark:text-sky-300 bg-sky-200/80 dark:bg-sky-900 px-2 py-0.5 rounded-full">
                            🛒 Eng arzon
                          </span>
                        )}
                      </div>

                      <div className="mt-2.5 flex items-baseline justify-between font-mono">
                        <div>
                          <span className="text-xs text-stone-400 block font-sans">Bosh narxi:</span>
                          <span className="text-base font-black text-stone-900 dark:text-white">
                            {pt.price2026Mln} mln
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs text-stone-400 block font-sans">1 kg tirik vazn:</span>
                          <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                            {formatUzs(pt.pricePerKg2026)} soʻm
                          </span>
                        </div>
                      </div>

                      {pt.eventTag && (
                        <div className="mt-2 text-[11px] font-bold text-amber-800 dark:text-amber-300 bg-amber-100/70 dark:bg-amber-950/50 px-2 py-1 rounded-lg">
                          {pt.eventTag}
                        </div>
                      )}

                      <p className="mt-2 text-xs text-stone-600 dark:text-stone-300 leading-relaxed font-sans">
                        {language === 'uz' ? pt.seasonalInsightUz : pt.seasonalInsightRu}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Action Footer: Filter Catalog by this breed */}
          <div className="bg-stone-100 dark:bg-stone-850 p-4 sm:p-5 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-3 border border-stone-200 dark:border-stone-800">
            <div className="text-xs text-stone-700 dark:text-stone-300">
              <span className="font-bold">
                {language === 'uz' ? 'Ushbu zot bozorida hozir sotilayotgan mollarni koʻrmoqchimisiz?' : 'Хотите посмотреть актуальные объявления этой породы?'}
              </span>
              <p className="text-stone-500 text-[11px] mt-0.5">
                Katalogdan faqat {currentProfile.breedNameUz.split('(')[0].trim()} eʼlonlarini filtrlash
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                if (onFilterByBreed) {
                  onFilterByBreed(currentProfile.breedId, currentProfile.category as AnimalDepartment);
                }
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs shrink-0"
            >
              <span>{language === 'uz' ? 'Shu zotdagi eʼlonlarni koʻrish' : 'Смотреть объявления'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
