import React from 'react';
import { LivestockItem, Language } from '../types';
import { translations } from '../translations';
import { Scale, X, ArrowRight, Trash2 } from 'lucide-react';

interface ComparisonFloatingBarProps {
  items: LivestockItem[];
  language: Language;
  onRemoveItem: (id: string) => void;
  onClearAll: () => void;
  onOpenComparisonModal: () => void;
}

export const ComparisonFloatingBar: React.FC<ComparisonFloatingBarProps> = ({
  items,
  language,
  onRemoveItem,
  onClearAll,
  onOpenComparisonModal,
}) => {
  const t = translations[language];

  if (items.length === 0) return null;

  const formatPrice = (val: number) => {
    return new Intl.NumberFormat('uz-UZ').format(val);
  };

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 w-[96%] max-w-4xl animate-in slide-in-from-bottom-5 duration-200">
      <div className="bg-stone-900/95 dark:bg-stone-900/95 text-white backdrop-blur-md rounded-2xl p-3 sm:p-4 shadow-2xl border border-emerald-500/40 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Left: Info & Counter */}
        <div className="flex items-center gap-2.5 self-start md:self-auto">
          <div className="w-9 h-9 rounded-xl bg-emerald-600/30 border border-emerald-500/50 flex items-center justify-center text-emerald-400 shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-extrabold tracking-tight">
                {t.compareTrayTitle}
              </span>
              <span className="text-[11px] font-mono font-bold bg-emerald-800 text-emerald-100 px-2 py-0.5 rounded-full border border-emerald-600">
                {items.length}/3
              </span>
            </div>
            <p className="text-[11px] text-stone-400 hidden sm:block">
              {items.length < 2 ? t.compareMinNotice : `${items.length} ta chorva xususiyatlari tayyor`}
            </p>
          </div>
        </div>

        {/* Center: Selected Animal Thumbnails */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto py-1">
          {items.map((item) => (
            <div
              key={item.id}
              className="group relative flex items-center gap-2 bg-stone-800/90 border border-stone-700 rounded-xl p-1.5 pr-2.5 shrink-0 max-w-[200px]"
            >
              <img
                src={item.imageUrl}
                alt={item.titleUz}
                className="w-8 h-8 rounded-lg object-cover shrink-0"
              />
              <div className="overflow-hidden text-left">
                <span className="text-[11px] font-bold block truncate text-stone-200">
                  {language === 'uz' ? item.titleUz : item.titleRu}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono block">
                  {item.weightKg} kg · {formatPrice(item.priceUzs)} {t.currency}
                </span>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveItem(item.id);
                }}
                className="text-stone-400 hover:text-rose-400 p-0.5 rounded-md hover:bg-stone-700/60 transition-colors cursor-pointer shrink-0 ml-1"
                title={t.removeFromCompare}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}

          {/* Empty slot placeholder if less than 3 */}
          {items.length < 3 && (
            <div className="hidden sm:flex items-center justify-center border border-dashed border-stone-700 rounded-xl px-3 py-2 text-[11px] text-stone-400 shrink-0">
              <span>{t.addMoreToCompare} ({3 - items.length})</span>
            </div>
          )}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end shrink-0">
          <button
            type="button"
            onClick={onClearAll}
            className="p-2 text-stone-400 hover:text-stone-200 hover:bg-stone-800 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1"
            title={t.clearCompare}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t.clearCompare}</span>
          </button>

          <button
            type="button"
            onClick={onOpenComparisonModal}
            className="flex-1 md:flex-none py-2 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs sm:text-sm font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer hover:shadow-emerald-600/30"
          >
            <Scale className="w-4 h-4" />
            <span>{t.compareActionBtn}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
