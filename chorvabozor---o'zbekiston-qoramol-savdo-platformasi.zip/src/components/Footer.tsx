import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { ShieldCheck, Phone, Send, Info, Building2, ChevronRight, Sparkles } from 'lucide-react';

interface FooterProps {
  language: Language;
  onOpenPriceIndex: () => void;
  onOpenTransport: () => void;
  onOpenTelegram: () => void;
  onOpenBusinessModel: () => void;
  onOpenQurbonlik: () => void;
  onOpenStrategy?: () => void;
  onOpenSellerGuide?: () => void;
  onOpenAllInfo?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  onOpenPriceIndex,
  onOpenTransport,
  onOpenTelegram,
  onOpenBusinessModel,
  onOpenQurbonlik,
  onOpenStrategy,
  onOpenSellerGuide,
  onOpenAllInfo,
}) => {
  const t = translations[language];

  return (
    <footer className="bg-[#02100C] text-stone-300 pt-12 pb-8 border-t border-[#0E3D32] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-[#0E3D32]">
          {/* Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#064E3B] to-[#047857] text-white flex items-center justify-center font-bold text-sm border border-[#10B981]/30">
                CH
              </div>
              <span className="font-extrabold text-xl tracking-tight text-white font-serif">
                ChorvaBozor
              </span>
            </div>
            <p className="text-stone-400 text-xs leading-relaxed">
              Oʻzbekistonda chorva mollari, qoramol va nasldor mollarning birinchi kafolatlangan raqamli savdo ekotizimi.
            </p>
            <div className="flex items-center gap-2 text-stone-400 text-[11px]">
              <ShieldCheck className="w-4 h-4 text-[#10B981] shrink-0" />
              <span>Veterinariya va tarozi nazorati ostida</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Platforma Xizmatlari
            </h4>
            <ul className="space-y-1.5 text-stone-400">
              <li>
                <button
                  type="button"
                  onClick={onOpenPriceIndex}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  {t.navPriceIndex}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenTransport}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  {t.navTransport}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenQurbonlik}
                  className="hover:text-white transition-colors cursor-pointer text-left text-amber-300"
                >
                  {t.navQurbonlik}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenTelegram}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Telegram Bot va Mini-App
                </button>
              </li>
              {onOpenSellerGuide && (
                <li>
                  <button
                    type="button"
                    onClick={onOpenSellerGuide}
                    className="hover:text-amber-400 text-amber-300 font-semibold transition-colors cursor-pointer text-left flex items-center gap-1.5"
                  >
                    <span>📈</span>
                    <span>Oltin Sotuvchi Qoʻllanmasi</span>
                  </button>
                </li>
              )}
            </ul>
          </div>

          {/* Business & Monetization */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Hamkorlik & Biznes
            </h4>
            <ul className="space-y-1.5 text-stone-400">
              <li>
                <button
                  type="button"
                  onClick={onOpenBusinessModel}
                  className="hover:text-white transition-colors cursor-pointer text-left text-emerald-400 font-semibold"
                >
                  Daromad Modeli & Monetizatsiya
                </button>
              </li>
              {onOpenStrategy && (
                <li>
                  <button
                    type="button"
                    onClick={onOpenStrategy}
                    className="hover:text-white transition-colors cursor-pointer text-left text-amber-300 font-semibold"
                  >
                    Startap Rejasi & MVP (2 Hafta)
                  </button>
                </li>
              )}
              <li>
                <span>Fermerlar toʻgʻridan-toʻgʻri savdo tizimi</span>
              </li>
              <li>
                <span>Goʻsht kombinatlari ulgurji buyurtmalari</span>
              </li>
              <li>
                <span>Veterinariya shifokorlari reyestri</span>
              </li>
            </ul>
          </div>

          {/* Contact & Support */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Aloqa va Yordam
            </h4>
            <div className="space-y-1.5 text-stone-400">
              <div className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>+998 71 200 45 45 (Call-markaz)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5 text-sky-400" />
                <span>@ChorvaBozor_Aloqa</span>
              </div>
              <div className="text-[11px] text-stone-500 pt-1">
                Toshkent, Samarqand, Andijon va boshqa viloyatlardagi 280+ fermer xoʻjaliklari bilan integratsiyalashgan.
              </div>
            </div>
          </div>
        </div>

        {/* Master Single Button for All Platform Information */}
        {onOpenAllInfo && (
          <div className="my-8 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#041C16] via-[#072D24] to-[#041C16] border border-[#0E3D32] shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] text-white flex items-center justify-center font-bold shrink-0 shadow-md">
                <Building2 className="w-6 h-6" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-black text-sm sm:text-base text-white">
                    Platformaning Barcha Maʼlumotlari
                  </h4>
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30">
                    Bitta Tugmada
                  </span>
                </div>
                <p className="text-stone-300/80 text-xs mt-0.5 max-w-2xl leading-relaxed">
                  12 ta xizmat, 4 bosqichli xavfsizlik va eskrou, 280+ fermerlar qamrovi, statistika, litsenziya, biznes model va rasmiy aloqa rekvizitlari.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onOpenAllInfo}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D97706] to-[#F59E0B] hover:from-[#B45309] hover:to-[#D97706] text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-[#F59E0B]/20 hover:scale-[1.02] active:scale-95 shrink-0"
            >
              <Sparkles className="w-4 h-4 text-white" />
              <span>Barcha Maʼlumotlarni Koʻrish</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-stone-500 text-[11px]">
          <div>
            © 2026 ChorvaBozor. Barcha huquqlar himoyalangan.
          </div>
          <div className="flex items-center gap-4">
            <span>Foydalanish shartlari</span>
            <span>·</span>
            <span>Maxfiylik siyosati</span>
            <span>·</span>
            <span>Veterinariya qoidalari</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
